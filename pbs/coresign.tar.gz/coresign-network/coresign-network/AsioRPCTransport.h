#pragma once

#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <condition_variable>
#include <Asio/asio/include/asio.hpp>

#include <network/NotificationTypes.hpp>

#ifndef SSL_DISABLE
typedef asio::ssl::stream<asio::ip::tcp::socket>  SslSocket;
#else
typedef asio::ip::tcp::socket                            TCPSocket;
typedef TCPSocket SslSocket;
#endif

class AsioRPCTransport: public std::enable_shared_from_this<AsioRPCTransport>
{
    public:
        AsioRPCTransport(const std::string& address, const std::string& port);
        AsioRPCTransport() = delete;
        AsioRPCTransport(const AsioRPCTransport&) = delete;
        AsioRPCTransport(AsioRPCTransport&&) = delete;
        AsioRPCTransport& operator=(const AsioRPCTransport&) = delete;
        AsioRPCTransport& operator=(AsioRPCTransport&&) = delete;
        ~AsioRPCTransport();

        OperationStatus start       ();
        OperationStatus call        (const std::string& data_out, std::string& data_in);

        std::string get_port        () const {return _port;}
        std::string get_address     () const {return _address;}

        bool    is_connected        ();

    private:
        enum ConnectionState
        {
            Opened            = 0,
            Resolve           = 1,
            Connect           = 2,
            Handshake         = 3,
            Write_Data_Size   = 10,
            Write_Data        = 11,
            Write_KeepAlive   = 12,
            Read_Data_Size    = 20,
            Read_Data         = 21,
            Read_KeepAlive    = 22,
            Waiting_Request   = 30,
            Shutdown          = 40,
            Close_Force       = 41,
            Error             = 42,
            Closed            = 50
        };

        void    work                ();
        void    execute_command     (ConnectionState new_state);
        void    wait_for_operation  (std::unique_lock<std::mutex>& lock);

        void    async_timeout_start     ();
        void    async_timeout_stop      ();
        void    handle_timeout          (const asio::error_code& error);

        void    async_resolve           ();
        void    async_connect           ();
        void    async_handshake         ();
        void    async_write_size        ();
        void    async_write_data        ();
        void    async_write_keepalive   ();
        void    async_read_size         ();
        void    async_read_data         ();
        void    async_read_keepalive    ();
        void    async_shutdown          ();
        void    close                   ();

        void        handle_resolve      (const asio::error_code& error, asio::ip::tcp::resolver::iterator iterator);
        void        handle_connect      (const asio::error_code& error, asio::ip::tcp::resolver::iterator iterator);
        void        handle_handshake    (const asio::error_code& error);
        std::size_t handle_read         (const asio::error_code& error, std::size_t bytes_transferred, int type);
        void        handle_write        (const asio::error_code& error, int type);

        void        operation_complete  (OperationStatus status);

        std::size_t handle_notification (const asio::error_code& error, std::size_t bytes_transferred);

        ConnectionState                 _state;
        SslSocket                       _socket;
        asio::deadline_timer            _timer;
        asio::strand                    _strand;
        asio::ip::tcp::resolver         _resolver;
        asio::ip::tcp::resolver::iterator _endpoints;

        std::string                     _address;
        std::string                     _port;

        int64_t                         _data_in_size_planned_current;
        int64_t                         _data_in_size_planned;
        int64_t                         _data_in_size_real_current;
        int64_t                         _data_in_size_real;
        int64_t                         _data_out_size;
        int64_t                         _data_keepalive;
        std::vector<char>               _data_in_vector;
        std::string                     _data_in;
        std::string                     _data_out;

        int32_t                         _timeout_ms;
        bool                            _is_ok;

        std::condition_variable         _condition_var;
        std::mutex                      _mutex;
        OperationStatus                 _operation_status;
};
