/*
 * logic.h
 *
 *  Created on: 18 бер. 2011
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/folder_encryption_type.h"
#include "types/file_folder_info.h"
#include "types/access_rights.h"
#include "types/request_context.h"


/**
 * Class that contains main logic of server:
 * determines which actions should be taken when performing RPC call
 */
class	FileLogic
{
public:
    static rpc_status_code          filesList           (RequestContext& context, int filesFilter, int64_t folderId, int64_t parentId, FilesInfoList& filesList, int64_t& lastEventId);
    static rpc_status_code          fileHistory         (RequestContext& context, int filesFilter, int64_t folderId, int64_t fileId, FilesInfoList& filesList);
    static rpc_status_code          fileRename          (RequestContext& context, int64_t folderId, int64_t fileId, const std::string& fileNameNew, int64_t& revision_ret);
    static rpc_status_code          fileDelete          (RequestContext& context, int64_t folderId, int64_t fileId, int64_t revision, bool removeNow);
    static rpc_status_code          fileDeleteRecursiveSafe(int64_t userId,  const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t revision, bool removeNow, const KSD::AccessRightsHelper& access_rights, bool isFirst = false);
    static rpc_status_code          fileInfo            (RequestContext& context, FileInfo& fileInfo);
    static rpc_status_code          fileUpload          (RequestContext& context, FileInfo& fileInfo);
    static rpc_status_code          fileUploadApprove   (RequestContext& context, FileInfo& fileInfo);
    static rpc_status_code          fileDownload        (RequestContext& context, FileInfo& fileInfo);
    static rpc_status_code          fileDirectoryCreate (RequestContext& context, FileInfo& fileInfo);
    static rpc_status_code          fileDirectoryHierarchy(RequestContext& context, const FileInfo& fileInfo, FilesInfoList& filesInfoList);
    static rpc_status_code          fileSearch          (RequestContext& context, int64_t folderId, const std::string& searchString, int64_t minSize, int64_t maxSize, FilesInfoList& filesInfoList);
    static rpc_status_code          fileUndelete        (RequestContext& context, int64_t folderId, int64_t fileId, int64_t revision);
    static rpc_status_code          fileMove            (RequestContext& context, int64_t folderId, int64_t fileId, int64_t newParentId);
};

