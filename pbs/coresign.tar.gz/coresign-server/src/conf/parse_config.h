/*
 * parse_config.h
 *
 *  Created on: 4 трав. 2011
 *      Author: fireball
 */

#ifndef PARSE_CONFIG_H_
#define PARSE_CONFIG_H_
#include <string>

int parse_config_file (const std::string& filename);

#endif /* PARSE_CONFIG_H_ */
