/*
 * invitation.h
 *
 *  Created on: Aug 29, 2011
 *      Author: fireball
 */

#ifndef INVITATION_H_
#define INVITATION_H_

#include <string>
#include <vector>
#include <map>


struct InviteInfo
{
    InviteInfo():
        inviter_id(-1),
        invitee_id(-1),
        workgroup_id(-1),
        access_mode(0),
        is_anonymous(false),
        service_type(0)
    {
    }

    std::string     inviter_login;
    std::string     invitee_login;

    std::string     inviter_name;
    std::string     invitee_name;

    void set_inviter_name(const std::string& first_name, const std::string& last_name)
    {
        if (!first_name.empty() && !last_name.empty())
        {
            inviter_name=" ";
        }
        inviter_name = first_name + inviter_name + last_name;
    }

    void set_invitee_name(const std::string& first_name, const std::string& last_name)
    {
        if (!first_name.empty() && !last_name.empty())
        {
            invitee_name=" ";
        }
        invitee_name = first_name + invitee_name + last_name;
    }

    int64_t         inviter_id;
    int64_t         invitee_id;

    int64_t         workgroup_id;
    std::string     workgroup_name;

    int64_t         access_mode;
    std::string     key;

    std::string     invite_id;
    bool            is_anonymous;

    int64_t         service_type;
};

typedef std::vector<InviteInfo>  InviteInfoList;

typedef std::multimap<int64_t, InviteInfo> InviteInfosByWorkGroups;
typedef std::pair<int64_t,InviteInfo> InvitePair;


bool compare_invite_pairs_by_access             (const InvitePair& a, const InvitePair& b);
bool compare_invites_by_access                  (const InviteInfo& a, const InviteInfo& b);

InviteInfoList filter_out_max_rights_invites    (const InviteInfosByWorkGroups& iibw);
InviteInfoList get_max_rights_invite            (const InviteInfoList& iil);

#endif /* INVITATION_H_ */
