#ifndef PARSE_ARGUMENTS
#define PARSE_ARGUMENTS

int parse_arguments(int argc, char** argv);

#endif
