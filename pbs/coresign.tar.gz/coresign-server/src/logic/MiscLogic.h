/*
 * logic.h
 *
 *  Created on: 18 бер. 2011
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/misc_info.h"
#include "types/request_context.h"


/**
 * Class that contains main logic of server:
 * determines which actions should be taken when performing RPC call
 */
class	MiscLogic
{
public:

    static rpc_status_code          check_for_update    (RequestContext& context, const std::string& version, const std::string& platform, UpdateInfo& updateInfo);

    static rpc_status_code          subscribeEvents     (RequestContext& context, int64_t& userId);

    static rpc_status_code          createKeyPair       (RequestContext& context, const std::string& password, std::string& keyId, std::string& public_key);
    static rpc_status_code          getKeyPair          (RequestContext& context, const std::string& keyId, std::string& public_key, std::string& private_key );

};

