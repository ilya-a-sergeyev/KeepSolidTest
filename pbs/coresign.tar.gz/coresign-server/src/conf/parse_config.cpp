/*
 * parse_config.cpp
 *
 *  Created on: 4 трав. 2011
 *      Author: fireball
 */

#include "parse_config.h"
#include "daemon_config.h"
#include <cstdio>
#include <libconfig.h++>

void read_general_params    (const libconfig::Config& cfg);
void read_network_params    (const libconfig::Config& cfg);
void read_email_params      (const libconfig::Config& cfg);
void read_misc_params       (const libconfig::Config& cfg);
void read_worker_params     (const libconfig::Config& cfg);
void read_db_params         (const libconfig::Config& cfg);

/**
 * Parses file for program's preferences.
 * read_*_params helper functions just try to fill still empty(!)
 * DaemonParams preferences with data from configuration file
 */
int parse_config_file (const std::string& filename)
{
    libconfig::Config cfg;

    try
    {
        cfg.readFile(daemon_params().getConfFilePath().c_str());
    }
    catch(const libconfig::ParseException& e)
    {
        fprintf(stderr,"Failure parsing config file %s : %s \n", filename.c_str(),e.what());
        return EXIT_FAILURE;
    }
    catch(const libconfig::ConfigException& e)
    {
        fprintf(stderr,"Failure opening config file %s : %s \n", filename.c_str(),e.what());
        return EXIT_FAILURE;
    }

    try
    {
        read_general_params(cfg);

        read_network_params(cfg);

        read_email_params(cfg);

        read_misc_params(cfg);

        read_worker_params(cfg);
    }
    catch(const libconfig::ConfigException& e)
    {
        fprintf(stderr,"Problem reading config file %s : %s \n", filename.c_str(),e.what());
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}

void read_general_params    (const libconfig::Config& cfg)
{
    if (daemon_params().getDaemonize() == -1)
    {
        bool daemonize;
        if (cfg.lookupValue("application.daemonize",daemonize))
        {
            daemon_params().setDaemonize(daemonize ? 1 : 0);
        }
    }
}

void read_network_params    (const libconfig::Config& cfg)
{
    if (daemon_params().getListenAddress().empty())
    {
        std::string listenAddress;
        if (cfg.lookupValue("application.network.listen_address", listenAddress))
        {
            daemon_params().setListenAddress(listenAddress);
        }
    }
    if (daemon_params().getListenPort() == -1)
    {
        int listenPort;
        if (cfg.lookupValue("application.network.listen_port", listenPort))
        {
            daemon_params().setListenPort(listenPort);
        }
    }
    if (daemon_params().getRedirectAddress().empty())
    {
        std::string redirectAddress;
        if (cfg.lookupValue("application.network.redirect_address", redirectAddress))
        {
            daemon_params().setRedirectAddress(redirectAddress);
        }
    }
    if (daemon_params().getRedirectPort() == -1)
    {
        int redirectPort;
        if (cfg.lookupValue("application.network.redirect_port", redirectPort))
        {
            daemon_params().setRedirectPort(redirectPort);
        }
    }
    if (daemon_params().getRequestMaxSize() == -1)
    {
        int request_max_size;
        if (cfg.lookupValue("application.network.request_max_size", request_max_size))
        {
            daemon_params().setRequestMaxSize(request_max_size);
        }
    }
    if (daemon_params().getConnectionTimeout() == -1)
    {
        int connection_timeout;
        if (cfg.lookupValue("application.network.connection_timeout", connection_timeout))
        {
            daemon_params().setConnectionTimeout(connection_timeout);
        }
    }
    if (daemon_params().getNotificationEmitPort() == -1)
    {
        int notification_emit_port;
        if (cfg.lookupValue("application.network.notification_emit_port", notification_emit_port))
        {
            daemon_params().setNotificationEmitPort(notification_emit_port);
        }
    }
    if (daemon_params().getNotificationRegPort() == -1)
    {
        int notification_reg_port;
        if (cfg.lookupValue("application.network.notification_reg_port", notification_reg_port))
        {
            daemon_params().setNotificationRegPort(notification_reg_port);
        }
    }
}

void read_email_params    (const libconfig::Config& cfg)
{
    if (daemon_params().getEmailEnabled() == -1)
    {
        bool email_enabled;
        if (cfg.lookupValue("application.email.email_enabled", email_enabled))
        {
            daemon_params().setEmailEnabled(email_enabled ? 1 : 0);
        }
    }
    if (daemon_params().getEmailClient().empty())
    {
        std::string email_client;
        if (cfg.lookupValue("application.email.email_client", email_client))
        {
            daemon_params().setEmailClient(email_client);
        }
    }
    if (daemon_params().getEmailSender().empty())
    {
        std::string email_sender;
        if (cfg.lookupValue("application.email.email_sender", email_sender))
        {
            daemon_params().setEmailSender(email_sender);
        }
    }
}


void read_misc_params    (const libconfig::Config& cfg)
{
    if (daemon_params().getAmazonS3Expiration() == -1)
    {
        int amazon_s3_expiration;
        if (cfg.lookupValue("application.misc.amazon_s3_expiration", amazon_s3_expiration))
        {
            daemon_params().setAmazonS3Expiration(amazon_s3_expiration);
        }
    }
    if (daemon_params().getTimersEnabled() == -1)
    {
        bool timers_enabled;
        if (cfg.lookupValue("application.misc.timers_enabled", timers_enabled))
        {
            daemon_params().setTimersEnabled(timers_enabled ? 1 : 0);
        }
    }
    if (daemon_params().getSecurityCodesKey().empty())
    {
        std::string security_codes_key;
        if (cfg.lookupValue("application.misc.security_codes_key", security_codes_key))
        {
            daemon_params().setSecurityCodesKey(security_codes_key);
        }
    }
}


void read_worker_params     (const libconfig::Config& cfg)
{
    if (daemon_params().getWorkerPoolSize() == -1)
    {
        int workerPoolSize;
        if (cfg.lookupValue("application.worker.workers_pool_size", workerPoolSize))
        {
            daemon_params().setWorkerPoolSize(workerPoolSize);
        }
    }
    if (daemon_params().getMaxWorkers() == -1)
    {
        int maxWorkers;
        if (cfg.lookupValue("application.worker.max_workers", maxWorkers))
        {
            daemon_params().setMaxWorkers(maxWorkers);
        }
    }
}


