#include "status_codes.h"
/*
 * status_codes.cpp
 *
 *  Created on: Jun 16, 2011
 *      Author: fireball
 */

rpc_status_code status_code_from_int(int code)
{
    switch (code)
    {
        case status_success:
            return status_success;

        case status_permanent_redirect:
            return status_permanent_redirect;
        case status_temporary_redirect:
            return status_temporary_redirect;

        case status_bad_request:
            return status_bad_request;
        case status_unauthorized:
            return status_unauthorized;
        case status_payment_required:
            return status_payment_required;
        case status_login_exists:
            return status_login_exists;
        case status_login_failure:
            return status_login_failure;
        case status_agreement_unaccepted:
            return status_agreement_unaccepted;
        case status_access_denied:
            return status_access_denied;
        case status_does_not_exist:
            return status_does_not_exist;
        case status_already_exist:
            return status_already_exist;
        case status_user_not_activated:
            return status_user_not_activated;
        case status_user_is_dummy:
            return status_user_is_dummy;
        case status_bad_syntax:
            return status_bad_syntax;
        case status_invalid_utf8:
            return status_invalid_utf8;

        case status_internal_error:
            return status_internal_error;
        case status_not_implemented:
            return status_not_implemented;
        case status_service_unavailable:
            return status_service_unavailable;
        case status_unsupported_client:
            return status_unsupported_client;

        default:
            return status_unknown;

    }

}


std::string status_code_to_string(int status_code)
{
    std::string result;

    switch (status_code)
    {
            //Successful 2xx
        case status_success:
        {result = "OK";                                                     break;}

        //Redirection 3xx.
        case status_permanent_redirect:
        {result = "Client should remember new redirected address";          break;}
        case status_temporary_redirect:
        {result = "Client should use redirect URL just for this session.";  break;}

        //Client Error 4xx
        case status_bad_request:
        {result = "Bad request.";                                           break;}
        case status_unauthorized:
        {result = "Need to login again.";                                   break;}
        case status_payment_required:
        {result = "Function needs payment.";                                break;}
        case status_login_exists:
        {result = "Cant register, login already exists.";                   break;}
        case status_login_failure:
        {result = "User not found or password is incorrect.";               break;}
        case status_agreement_unaccepted:
        {result = "User did not confirm license acceptance.";               break;}
        case status_access_denied:
        {result = "Action is prohibited for this user.";                    break;}
        case status_does_not_exist:
        {result = "Requested object does not exist.";                       break;}
        case status_already_exist:
        {result = "Cannot create object that already exists.";              break;}
        case status_user_not_activated:
        {result = "User is not activated.";                                 break;}
        case status_user_is_dummy:
        {result = "User needs to update their profile.";                    break;}
        case status_bad_syntax:
        {result = "Bad parameters syntax";                                  break;}
        case status_invalid_utf8:
        {result = "Got invalid UTF8 input string";                          break;}

        //Server Error 5xx
        case status_internal_error:
        {result = "General error.";                                         break;}
        case status_not_implemented:
        {result = "Method does not work yet.";                              break;}
        case status_service_unavailable:
        {result = "Service is stopping or reloading.";                      break;}
        case status_unsupported_client:
        {result = "Client is too old to be supported.";                     break;}

        //Rest Error 7xx
        case status_no_connect_to_server:
        {result = "Not connect to server.";                             break;}
        case status_task_syntax_error:
        {result = "Task syntax error.";                                 break;}
        case status_task_error:
        {result = "Task error.";                                        break;}
        case status_category_error:
        {result = "Category error.";                                    break;}
        case status_action_error:
        {result = "Action error.";                                      break;}
        case status_bad_parameters:
        {result = "Bad parameters.";                                    break;}
        case status_bad_return_parameters:
        {result = "Bad return parameters.";                             break;}
        case status_UDLoad_file_error:
        {result = "Could not download/upload file.";                    break;}
        case status_IO_file_error:
        {result = "Problem with file IO";                               break;}
        case status_upload_file_terminate:
        {result = "Upload file terminate.";                             break;}
        case status_file_parameters_error:
        {result = "Error file parameters.";                             break;}
        case status_RSA_decrypt_error:
        {result = "RSA decrypt error";                                  break;}


        default:
        {result = "Unknown error. Whats goin on?"; break;}
    }
    return result;
}

std::string status_code_enum_to_string(rpc_status_code status_code)
{
    return status_code_to_string(status_code);
}
