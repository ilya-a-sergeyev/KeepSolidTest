/*
 * TariffManagerPgSql.cpp
 *
 *  Created on: 6 апр. 2012
 *      Author: fireballdark
 */

#include "TariffManagerPgSql.h"
#include "db/PgSqlHelper.h"
#include <sutil/logging.h>
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>

rpc_status_code TariffManagerPgSql::get_user_limits(int64_t user_id, TariffLimits& userLimits)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getLimits"))
            {
                pg_connection->prepare  ("getLimits",
                                         "SELECT Tariffs.tariff_id, creation_date, tariff_name, data_size_limit, users_limit, "
                                         "history_limit, admins_limit FROM Tariffs INNER JOIN Users ON Users.tariff_id = Tariffs.tariff_id "
                                         "WHERE Users.user_id = $1;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetLimits");

            pqxx::result query_result = pg_transaction.prepared("getLimits")(user_id).exec();

            if (query_result.size()>0)
            {
                query_result.begin()["data_size_limit"].to(userLimits.data_size_limit);
                query_result.begin()["history_limit"]. to(userLimits.history_limit);
                query_result.begin()["admins_limit"].  to(userLimits.admins_limit);
                query_result.begin()["users_limit"].   to(userLimits.users_limit);
                query_result.begin()["tariff_id"].     to(userLimits.tariff_id);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query limits for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}
