/*
 * xopenssl_pbkdf2.h
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>

std::string sha256_pbkdf2_raw   (const std::string& secret, const std::string& salt, int cycles);   //works with raw data and returns raw data
std::string sha256_pbkdf2       (const std::string& secret, const std::string& salt, int cycles);   //recommended 2^16 or more cycles

//return hash of secret
std::string sha256_pbkdf2_password_generate (const std::string& secret, std::string& salt_out, int cycles);  //auto-generates salt
std::string sha256_pbkdf2_password_stretch  (const std::string& secret, const std::string& salt);            //uses const salt
bool        sha256_pbkdf2_verify            (const std::string& good_hash, const std::string& secret, const std::string& salt);
