﻿#pragma once

#include <string>
#include <vector>
#include <memory>
#include <Asio/asio/include/asio.hpp>

#include <network/NotificationTypes.hpp>

class AsioNotificationTransportSync : public std::enable_shared_from_this<AsioNotificationTransportSync>
{
    public:
        AsioNotificationTransportSync(const std::string& address, const std::string& port);
        AsioNotificationTransportSync() = delete;
        AsioNotificationTransportSync(const AsioNotificationTransportSync&) = delete;
        AsioNotificationTransportSync(AsioNotificationTransportSync&&) = delete;
        AsioNotificationTransportSync& operator=(const AsioNotificationTransportSync&) = delete;
        AsioNotificationTransportSync& operator=(AsioNotificationTransportSync&&) = delete;
        ~AsioNotificationTransportSync();

        OperationStatus read        (asio::error_code& err, std::string& data_in);
        OperationStatus write       (const std::string& data_out);
        void    subscribe           (const function_MessageCallback& callback, const function_ConnectionCallback& connection_cb, bool start_service);
        void    stop                ();

        std::string get_port        () const {return _port;}
        std::string get_address     () const {return _address;}

        bool    is_connected        ();

    private:
        bool    connect             ();
        void    disconnect          ();
        void    run_service         ();
        void    stop_service        ();

        std::size_t handle_notification     (const asio::error_code& error, std::size_t bytes_transferred);

        asio::io_service                _io_service;
        asio::ip::tcp::socket           _socket;
        function_MessageCallback        _callback;
        function_ConnectionCallback     _connection_cb;
        std::string                     _address;
        std::string                     _port;
        std::vector<char>               _data_in_vector;
        std::string                     _data_push;
        uint64_t                        _test_alive;
        bool                            _stop_waiting;
};
