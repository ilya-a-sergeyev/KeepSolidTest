/*
 * SimplexNotificationsPgSql.cpp
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#include "SimplexNotificationsPgSql.h"
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <sutil/logging.h>
#include "db/PgSqlHelper.h"


rpc_status_code SimplexNotificationsPgSql::get_params(const std::string& notification_name, int64_t service_type,
                                                      std::string& service_name, KeyValueMap& params)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getSimplexNotifications"))
            {
                pg_connection->prepare  ("getSimplexNotifications",
                                         "SELECT notif_name as name, type, value, service_name FROM SimplexNotifications "
                                         "INNER JOIN ServiceTypes "
                                         "ON SimplexNotifications.service_type=ServiceTypes.service_id "
                                         "WHERE notif_name = $1 "
                                         "OR notif_name = 'address' "
                                         "OR notif_name = 'auth' "
                                         "AND service_type = $2;");
            }
            pqxx::work pg_transaction(*pg_connection, "getSimplexNotifications");
            pqxx::result query_result = pg_transaction.prepared("getSimplexNotifications")
                    (notification_name)
                    (service_type).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            for (pqxx::result::const_iterator iter = query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                service_name = iter["service_name"].as<std::string>();
                params[iter["type"].as<std::string>()][iter["name"].as<std::string>()] = iter["value"].as<std::string>();
//                LOG_INFORMATION("FFFFFFFFFFFFFFFFFFFFFFFFFFFF [%s][%s][%s][%s]",
//                        iter["service_name"].as<std::string>().c_str(),
//                        iter["type"].as<std::string>().c_str(),
//                        iter["name"].as<std::string>().c_str(),
//                        iter["value"].as<std::string>().c_str());
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query simplex notifications for [%s]:[%lli] err: [%s]",notification_name.c_str(),service_type,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}






