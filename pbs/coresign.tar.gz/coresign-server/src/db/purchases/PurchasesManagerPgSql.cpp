/*
 * PurchasesManagerPgSql.cpp
 *
 *  Created on: Apr 3, 2014
 *      Author: fireballdark
 */

#include "PurchasesManagerPgSql.h"
#include "db/PgSqlHelper.h"
#include <util/logging.h>
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>

rpc_status_code PurchasesManagerPgSql::create_purchase(int64_t userId, const PurchaseData& pd)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("createPurchase"))
            {
                pg_connection->prepare  ("createPurchase",
                                         "INSERT INTO Purchases(service_type, login, user_id, type, name, sandbox, hash, info) "
                                         "VALUES ($1, $2, $3, $4, $5, $6, $7, $8);");
            }
            pqxx::work pg_transaction(*pg_connection, "createPurchase");
            pqxx::result query_result = pg_transaction.prepared("createPurchase")
                    (pd.service_type)(pd.login)(userId)
                    (pd.type)(pd.name)(pd.sandbox)(pd.hash)(pd.infos_to_string()).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate err: %s",e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Info: trying to create err: %s",e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code PurchasesManagerPgSql::refund_purchase(int64_t userId, const std::string& purchase_hash)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("refund_purchase"))
            {
                pg_connection->prepare  ("refund_purchase",
                                         "UPDATE Purchases SET refunded = true "
                                         "WHERE user_id = $1 AND hash = $2;");
            }
            pqxx::work pg_transaction(*pg_connection, "refund_purchase");
            pqxx::result query_result = pg_transaction.prepared("refund_purchase")
                                                (userId)(purchase_hash).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate err: %s",e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Info: trying to create err: %s",e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code PurchasesManagerPgSql::get_purchase(int64_t userId, const std::string& purchase_hash, PurchaseData& pd)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("get_purchase"))
            {
                pg_connection->prepare  ("get_purchase",
                                         "SELECT service_type, login, user_id, type, name, sandbox, hash, info FROM Purchases "
                                         "WHERE user_id = $1 AND hash = $2;");
            }

            pqxx::work pg_transaction(*pg_connection, "get_purchase");
            pqxx::result query_result = pg_transaction.prepared("get_purchase")(userId)(purchase_hash).exec();

            if (query_result.empty())
            {
                LOG_INFORMATION("Purchase [%s] not found", purchase_hash.c_str());
                returnStatus = status_does_not_exist;
                break;
            }

            pd.service_type = query_result.begin()["service_type"].as<int64_t>();
            pd.login        = query_result.begin()["login"].as<std::string>();
            pd.type         = query_result.begin()["type"].as<std::string>();
            pd.name         = query_result.begin()["name"].as<std::string>();
            pd.sandbox      = query_result.begin()["sandbox"].as<bool>();
            pd.hash         = query_result.begin()["hash"].as<std::string>();
            std::string info = query_result.begin()["info"].as<std::string>();
            pd.string_to_infos(info);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query purchase by hash [%s] err: [%s]", purchase_hash.c_str(), e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}
