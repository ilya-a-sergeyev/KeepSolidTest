/*
 * access_rights.h
 *
 *  Created on: Jun 23, 2011
 *      Author: fireball
 */

#ifndef ACCESS_RIGHTS_H_
#define ACCESS_RIGHTS_H_
#include <string>

namespace KSD
{
    enum AccessRights : int64_t
    {
        admin_rights    = -1LL,                               //absolute full access (all bits are up)

        no_access       = 0x0LL,

        read_folder     = 0x1LL,      //  1       // 2^0      //read and download files
        write_folder    = 0x2LL,      //  2       // 2^1      //create, rename files and workgroups. restore files only
        delete_folder   = 0x4LL,      //  4       // 2^2      //delete files in workgroup
        share_folder    = 0x8LL,      //  8       // 2^3      //can re-share workgroup

        kill_folder     = 0x10LL,     //  16      // 2^4      //can remove or restore workgroup itself
        reserved32      = 0x20LL,     //  32      // 2^5
        reserved64      = 0x40LL,     //  64      // 2^6
        reserved128     = 0x80LL,     //  128     // 2^7

        read_messages   = 0x100LL,    //  256     // 2^8      //read any messages
        write_messages  = 0x200LL,    //  512     // 2^9      //create new messages, edit/rename your own messages and own topics, delete your own messages
        admin_messages  = 0x400LL,    //  1024    // 2^10     //delete any topics, rename any topic, delete any message

        reserved2048    = 0x800LL,    //  2048    // 2^11
        reserved4096    = 0x1000LL,   //  4096    // 2^12

        kick_user       = 0x2000LL,   //  8192    // 2^13     //can kick any user in this workgroup
        control_access  = 0x4000LL,   //  16384   // 2^14     //can change access rights for any user in workgroup
        reserved32768   = 0x8000LL,   //  32768   // 2^15
        reserved65535   = 0x10000LL,   //  65535   // 2^16

        reserved_big    = 0x1000000000000000LL   //  // 2^60
    };


    enum RegisteredAccessModes
    {
        Unknown,
        NotAccepted,
        NoAccess,
        ReadOnlyAccess,          //read_workgroup + read_messages
        LimitedAccessNoSharing,  //read_workgroup + write_workgroup + read_messages + write_messages
        LimitedAccess,           //read_workgroup + write_workgroup + share_workgroup + read_messages + write_messages
        FullAccess,              //read_workgroup + write_workgroup + delete_workgroup + share_workgroup + read_messages + write_messages
        AdminAccess              //-1
    };

    RegisteredAccessModes access_mode_to_registered(int64_t access_mode);

    int64_t registered_to_access_mode(RegisteredAccessModes registered_access_mode);

    bool compare_access_rights(int64_t a, int64_t b);


    class AccessRightsHelper
    {
    public:
        AccessRightsHelper(int64_t init_mode):
            access_mode(init_mode)
        {
        };

        AccessRightsHelper():
            access_mode(0)
        {
        };

        int64_t       get_access_mode () const  {return access_mode;};

        bool get_read_folder    () const  {return (access_mode&read_folder)     != 0;};
        bool get_write_folder   () const  {return (access_mode&write_folder)    != 0;};
        bool get_delete_folder  () const  {return (access_mode&delete_folder)   != 0;};
        bool get_share_folder   () const  {return (access_mode&share_folder)    != 0;};
        bool get_kill_folder    () const  {return (access_mode&kill_folder)     != 0;};
        bool get_read_messages  () const  {return (access_mode&read_messages)   != 0;};
        bool get_write_messages () const  {return (access_mode&write_messages)  != 0;};
        bool get_admin_messages () const  {return (access_mode&admin_messages)  != 0;};
        bool get_kick_user      () const  {return (access_mode&kick_user)       != 0;};
        bool get_control_access () const  {return (access_mode&control_access)  != 0;};


        void set_no_access      ()  { access_mode=no_access; };
        void set_admin_rights   ()  { access_mode=admin_rights; };

        void set_read_folder    (bool value)  {if (value) { access_mode|=read_folder; }     else { access_mode&=~read_folder; }};
        void set_write_folder   (bool value)  {if (value) { access_mode|=write_folder; }    else { access_mode&=~write_folder; }};
        void set_delete_folder  (bool value)  {if (value) { access_mode|=delete_folder; }   else { access_mode&=~delete_folder; }};
        void set_share_folder   (bool value)  {if (value) { access_mode|=share_folder; }    else { access_mode&=~share_folder; }};
        void set_kill_folder    (bool value)  {if (value) { access_mode|=kill_folder; }     else { access_mode&=~kill_folder; }};
        void set_read_messages  (bool value)  {if (value) { access_mode|=read_messages; }   else { access_mode&=~read_messages; }};
        void set_write_messages (bool value)  {if (value) { access_mode|=write_messages; }  else { access_mode&=~write_messages; }};
        void set_admin_messages (bool value)  {if (value) { access_mode|=admin_messages; }  else { access_mode&=~admin_messages; }};
        void set_kick_user      (bool value)  {if (value) { access_mode|=kick_user; }       else { access_mode&=~kick_user; }};
        void set_control_access (bool value)  {if (value) { access_mode|=control_access; }  else { access_mode&=~control_access; }};

        bool verify_access_mode ();
        std::string access_mode_to_string();

    private:
        int64_t   access_mode;
    };
}

#endif /* ACCESS_RIGHTS_H_ */
