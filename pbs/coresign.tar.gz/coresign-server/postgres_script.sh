createuser -DRSP fileserver
createdb -O fileserver -E UTF8 KeepSolid
psql -c "CREATE EXTENSION hstore;"
#ALTER ROLE postgres WITH PASSWORD 'password';
