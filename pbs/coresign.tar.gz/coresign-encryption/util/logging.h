/*
 * logging.h
 *
 *  Created on: May 27, 2013
 *      Author: fireballdark
 */

#pragma once

#ifndef NDEBUG
#if ( defined (SERVER_LOGGING) )
    #include <sutil/logging.h>
    #define DEBUG_FUNCTION          LOG_ABSOLUTE("Entered function %s:%s:%i",__FILE__,__FUNCTION__,__LINE__);
#elif defined ( DESKTOP_CLIENT )
    #include <headers/DebugHelper/DebugHelper.h>
    #define LOG_ERROR(...)          ERROR_MSG(__VA_ARGS__);
    #define LOG_INFORMATION(...)    DEBUG_MSG(__VA_ARGS__);
    #define LOG_ABSOLUTE(...)       DEBUG_MSG(__VA_ARGS__);
#else
#include <stdio.h>
    #define DEBUG_FUNCTION          printf("%s:%s:%i",__FILE__,__FUNCTION__,__LINE__); printf("\n");
    #define LOG_ERROR(...)          printf("%s:%s:%i ",__FILE__,__FUNCTION__,__LINE__);printf(__VA_ARGS__);printf("\n");
    #define LOG_INFORMATION(...)    printf("%s:%s:%i ",__FILE__,__FUNCTION__,__LINE__);printf(__VA_ARGS__);printf("\n");
    #define LOG_ABSOLUTE(...)       printf("%s:%s:%i ",__FILE__,__FUNCTION__,__LINE__);printf(__VA_ARGS__);printf("\n");
#endif
#else
#define DEBUG_FUNCTION
#define LOG_ERROR(...)
#define LOG_INFORMATION(...)
#define LOG_ABSOLUTE(...)
#endif
