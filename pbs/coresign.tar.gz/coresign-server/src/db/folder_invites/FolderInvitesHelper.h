/*
 * UserManagerHelper.h
 *
 *  Created on: Apr 3, 2014
 *      Author: fireballdark
 */

#pragma once

#include <pqxx/result.hxx>
#include "types/invitation.h"

#define GET_WORKGROUP_INVITE " invite_id, inviter_login, inviter_id, invitee_login, invitee_id, workgroup_id, access_mode, workgroup_name, encryption_key, invitation_date, is_anonymous, service_type "

void convert_inviteinfo_db        (const pqxx::result::const_iterator& query_result, InviteInfo& ii);


