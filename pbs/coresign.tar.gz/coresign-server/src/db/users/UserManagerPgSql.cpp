/*
 * UserManagerPgSql.cpp
 *
 *  Created on: 25 бер. 2011
 *      Author: fireball
 */

#include "UserManagerPgSql.h"
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <cstdlib>
#include <sutil/logging.h>
#include "util/getNotificationLiterals.h"
#include "db/PgSqlHelper.h"
#include "UserManagerHelper.h"


rpc_status_code UserManagerPgSql::createDummyUser(UserCredentials& uc)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("createInactiveUser"))
            {
                pg_connection->prepare  ("createInactiveUser",
                                         "INSERT INTO Users("
                        "login, password, salt_password, secret_question, secret_answer, salt_answer, public_key, private_key, "
                        "private_key_answer, salt_pk_password, salt_pk_answer, is_activated, license_accepted, is_dummy, "
                        "encrypted_external_password) "
                        "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING user_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "CreateInactiveUser");
            pqxx::result query_result = pg_transaction.prepared("createInactiveUser")
                    (uc.login)(uc.password)(uc.salt_password)(uc.secret_question)(uc.secret_answer)(uc.salt_answer)(uc.public_key)(uc.private_key)
                    (uc.private_key_answer)(uc.salt_pk_password)(uc.salt_pk_answer)(true)(uc.license_accepted)(uc.is_dummy)
                    (uc.encrypted_external_password).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            uc.user_id = query_result.begin()["user_id"].as<int64_t>();

            pg_transaction.commit();
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_INFORMATION("Info: trying to create duplicate user %s err %s",uc.login.c_str(),e.what());
            returnStatus = status_login_exists;
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_INFORMATION("Failure: trying to create user %s err %s",uc.login.c_str(),e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::updateUserCredentials(const UserCredentials& uc)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("updateUserCredentials"))
            {
                pg_connection->prepare  ("updateUserCredentials",
                                         "UPDATE Users SET "
                        "password=$2, salt_password=$3, secret_question=$4, secret_answer=$5, salt_answer=$6, public_key=$7, private_key=$8, "
                        "private_key_answer=$9, salt_pk_password=$10, salt_pk_answer=$11, is_activated=$12, license_accepted=$13, is_dummy=$14 "
                        "WHERE login=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "updateUserCredentials");
            pg_transaction.prepared("updateUserCredentials")
                    (uc.login)(uc.password)(uc.salt_password)(uc.secret_question)(uc.secret_answer)(uc.salt_answer)(uc.public_key)(uc.private_key)
                    (uc.private_key_answer)(uc.salt_pk_password)(uc.salt_pk_answer)(true)(uc.license_accepted)(uc.is_dummy).exec();

            pg_transaction.commit();
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_INFORMATION("Info: trying to update duplicate user %s err %s",uc.login.c_str(),e.what());
            returnStatus = status_login_exists;
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_INFORMATION("Failure: trying to update user %s err %s",uc.login.c_str(),e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::activateUser(const std::string& login)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("activateUser"))
            {
                pg_connection->prepare  ("activateUser",
                                         "UPDATE Users SET is_activated=true WHERE login=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "ActivateUser");
            pg_transaction.prepared("activateUser")(login).exec();

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_INFORMATION("Failure: trying to create user %s err %s",login.c_str(),e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::updatePassword(const std::string& login, const std::string& password, const std::string& saltForPass, const std::string& privateKey, const std::string& privateKeySalt)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("updatePassword"))
            {
                pg_connection->prepare  ("updatePassword",
                                         "UPDATE Users SET password=$2, salt_password = $3, private_key=$4, salt_pk_password=$5 WHERE login=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "UpdatePassword");
            pg_transaction.prepared("updatePassword")(login)(password)(saltForPass)(privateKey)(privateKeySalt).exec();

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_INFORMATION("Failure: trying to update password for user [%s] err [%s]",login.c_str(),e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::updateSecretAnswer(const std::string& login, const std::string& secretQuestion, const std::string& secretAnswer, const std::string& saltForAnswer, const std::string& privateAnswerKey,const std::string& saltForPrivateAnswerKey)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("updateSecretAnswer"))
            {
                pg_connection->prepare  ("updateSecretAnswer",
                                         "UPDATE Users SET secret_question=$2, secret_answer=$3, salt_answer=$4, private_key_answer=$5, "
                                         "salt_pk_answer=$6 WHERE login=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "UpdateSecretAnswer");
            pg_transaction.prepared("updateSecretAnswer")(login)(secretQuestion)(secretAnswer)(saltForAnswer)(privateAnswerKey)(saltForPrivateAnswerKey).exec();

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_INFORMATION("Failure: trying to update answer %s err %s",login.c_str(),e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::updateUserProfile(const std::string& login, const std::string& email, const std::string& firstName, const std::string& lastName, const std::string& userPicture)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("updateUserProfile"))
            {
                pg_connection->prepare  ("updateUserProfile",
                                         "UPDATE Users SET email = $2, first_name=$3, last_name=$4, user_pic=$5 WHERE login=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "updateUserProfile");
            pg_transaction.prepared("updateUserProfile")(email)(login)(firstName)(lastName)(userPicture).exec();

            pg_transaction.commit();
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_INFORMATION("Info: trying to create duplicate user %s err %s",login.c_str(),e.what());
            returnStatus = status_login_exists;
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_INFORMATION("Failure: trying to update user info %s err %s",login.c_str(),e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::getUserInfoByUserId(int64_t userId, UserInfo& userInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getUserInfoByUserId"))
            {
                pg_connection->prepare  ("getUserInfoByUserId",
                                         "SELECT "
                                         GET_USER_INFO
                                         " FROM Users WHERE user_id = $1;");
            }
            pqxx::work pg_transaction(*pg_connection, "getUserInfoByUserId");
            pqxx::result query_result = pg_transaction.prepared("getUserInfoByUserId")(userId).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            convert_userinfo_db(query_result.begin(), userInfo);

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query user info for userId %lli err: %s",userInfo.user_id,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::getUserInfoByLogin(const std::string& login, UserInfo& userInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getUserInfoByLogin"))
            {
                pg_connection->prepare  ("getUserInfoByLogin",
                                         "SELECT "
                                         GET_USER_INFO
                                         " FROM Users WHERE login = $1;");
            }
            pqxx::work pg_transaction(*pg_connection, "getUserInfoByLogin");
            pqxx::result query_result = pg_transaction.prepared("getUserInfoByLogin")(login).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            convert_userinfo_db(query_result.begin(), userInfo);

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query user info for login %s err: %s",userInfo.login.c_str(),e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::getCredentialsByUserId(int64_t userId, UserCredentials& userInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getUserCredentialsById"))
            {
                pg_connection->prepare  ("getUserCredentialsById",
                                         "SELECT "
                                         GET_USER_CREDENTIALS
                                         " FROM Users WHERE user_id = $1;");
            }
            pqxx::work pg_transaction(*pg_connection, "getUserCredentialsById");
            pqxx::result query_result = pg_transaction.prepared("getUserCredentialsById")(userId).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            convert_usercredentials_db(query_result.begin(), userInfo);

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query user credentials for userId %lli err: %s",userId,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::getCredentialsByLogin(const std::string& login, UserCredentials& userInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getUserCredentialsByLogin"))
            {
                pg_connection->prepare  ("getUserCredentialsByLogin",
                                         "SELECT "
                                         GET_USER_CREDENTIALS
                                         " FROM Users WHERE login = $1;");
            }
            pqxx::work pg_transaction(*pg_connection, "getUserCredentialsByLogin");
            pqxx::result query_result = pg_transaction.prepared("getUserCredentialsByLogin")(login).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                LOG_DEBUGGING("User [%s] does not exist", login.c_str());
                break;
            }

            convert_usercredentials_db(query_result.begin(), userInfo);

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query user credentials for login %s err: %s",login.c_str(),e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::getNotifications(int64_t userId, const std::vector<std::string>& notifyLiterals, NotificationsSubscription& notifySub)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            std::stringstream query;
            query<<"SELECT ";
            bool first = true;

            for (unsigned int i = 0 ; i<notifyLiterals.size() ; i++)
            {
                if (!first)
                {
                    query<<", ";
                }
                query<<"flags->"<<"'"<<notifyLiterals[i]<<"'"<<" AS "<<notifyLiterals[i]<<" ";
                first=false;
            }

            query<<" FROM Users WHERE user_id = "<<userId<<" ;";

            LOG_ABSOLUTE("NotificationGet query is [%s]",query.str().c_str());

            pqxx::work pg_transaction(*pg_connection, "getNotifications");
            pqxx::result query_result = pg_transaction.exec(query);

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            for (unsigned int i = 0 ; i<notifyLiterals.size() ; i++)
            {
                notifySub[notifyLiterals[i]] = query_result.begin()[notifyLiterals[i]].is_null() ? "1" : query_result.begin()[notifyLiterals[i]].as<std::string>();
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query user notifications for userId %lli err: %s",userId,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::setNotifications(int64_t userId, const NotificationsSubscription& notifySub)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (notifySub.empty())
            {
                LOG_ERROR("Empty data to change");
                break;
            }

            std::stringstream query;
            for (NotificationsSubscription::const_iterator i = notifySub.begin() ; i!= notifySub.end() ; i++)
            {
                if (i != notifySub.begin())
                {
                    query<<", ";
                }
                query<<pg_connection->esc(i->first);
                query<<"=>";
                query<<pg_connection->esc(i->second);
            }

            LOG_ABSOLUTE("NotificationSet query is [%s]",query.str().c_str());

            if (pgSqlHelper().register_prep_statement("setUserNotifications"))
            {
                pg_connection->prepare  ("setUserNotifications",
                                         "UPDATE Users SET flags = flags || $1 ::hstore WHERE user_id = $2 RETURNING user_id ;");
            }
            pqxx::work pg_transaction(*pg_connection, "setUserNotifications");
            pqxx::result query_result = pg_transaction.prepared("setUserNotifications")(query.str())(userId).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query user notifications for userId %lli err: %s",userId,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::prolongExpiration(const std::string& login, const std::string& interval)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("prolongExpiration"))
            {
                pg_connection->prepare  ("prolongExpiration",
                                         "UPDATE Users SET expiration_date = (GREATEST(NOW(),expiration_date) + $2::interval) "
                                         "WHERE login=$1 RETURNING expiration_date;");
            }
            pqxx::work pg_transaction(*pg_connection, "prolongExpiration");
            pg_transaction.prepared("prolongExpiration")(login)(interval).exec();

            LOG_INFORMATION("Incrementing time for [%s] for [%s]", login.c_str(), interval.c_str());

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to prolongExpiration [%s] for [%s] err %s", login.c_str(), interval.c_str(), e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::reduceExpiration(const std::string& login, const std::string& interval)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("reduceExpiration"))
            {
                pg_connection->prepare  ("reduceExpiration",
                                         "UPDATE Users SET expiration_date = expiration_date - $2::interval WHERE login=$1 "
                                         "RETURNING expiration_date;");
            }
            pqxx::work pg_transaction(*pg_connection, "reduceExpiration");
            pg_transaction.prepared("reduceExpiration")(login)(interval).exec();

            LOG_INFORMATION("Incrementing time for [%s] for [%s]", login.c_str(), interval.c_str());

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to reduceExpiration [%s] for [%s] err %s", login.c_str(), interval.c_str(), e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::prolongExpirationOverwrite(const std::string& login, const std::string& interval, const std::string& overwrite_date)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("prolongExpirationOverwrite"))
            {
                pg_connection->prepare  ("prolongExpirationOverwrite",
                                         "UPDATE Users SET expiration_date = GREATEST(expiration_date, $3::timestamp + $2::interval) "
                                         "WHERE login=$1 RETURNING expiration_date;");
            }
            pqxx::work pg_transaction(*pg_connection, "prolongExpirationOverwrite");
            pg_transaction.prepared("prolongExpirationOverwrite")(login)(interval)(overwrite_date).exec();

            LOG_INFORMATION("Incrementing time for [%s] for [%s]", login.c_str(), interval.c_str());

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to prolongExpiration [%s] for [%s] err %s", login.c_str(), interval.c_str(), e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}

rpc_status_code UserManagerPgSql::removeUser(int64_t userId)
{
    rpc_status_code  returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("removeUser"))
            {
                pg_connection->prepare  ("removeUser",
                                         "DELETE FROM Users "
                                         "WHERE user_id=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "removeUser");
            pg_transaction.prepared("removeUser")(userId).exec();

            LOG_INFORMATION("REMOVED USER [%lli]", userId);

            pg_transaction.commit();
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to remove user [%lli] err %s", userId, e.base().what());
            break;
        }

        returnStatus = status_success;

    }
    while (false);

    return returnStatus;
}
