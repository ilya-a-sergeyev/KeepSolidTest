/*
 * SimplexNotificationsPgSql.h
 *
 *  Created on: Mar 25, 2014
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/invitation.h"

#include <types/keyvalue.h>

class SimplexNotificationsPgSql
{
public:
    static rpc_status_code get_params (const std::string& notification_name, int64_t service_type,
                                       std::string& service_name, KeyValueMap& params);
};

