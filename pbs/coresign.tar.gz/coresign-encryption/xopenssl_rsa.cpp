/*
 * xopenssl_rsa.cpp
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */


#include "xopenssl_rsa.h"
#include <openssl/engine.h>
#include <openssl/rsa.h>
#include <openssl/bio.h>
#include <openssl/pem.h>
#include "xopenssl_defines.h"
#include "xopenssl_util.h"
#include "util/logging.h"


void rsa2string(const std::string& iv, const std::string& data_key, const std::string& encrypted_data, std::string& rsa_full_data )
{
    rsa_full_data = base64_encodestring(iv, true);
    rsa_full_data += '$'; //delimiter
    rsa_full_data += base64_encodestring(data_key, true);
    rsa_full_data += '$'; //delimiter
    rsa_full_data += base64_encodestring(encrypted_data, true);
}

void string2rsa(const std::string& rsa_full_data, std::string& iv, std::string& data_key, std::string& encrypted_data )
{
    std::vector<std::string> exploded;        //data exploded by $

    split_string(rsa_full_data, '$', exploded);

    if (exploded.size() != 3)
    {
        LOG_ERROR("OpenSSL: string2rsa - one or more of delimiters in [%s] not found", rsa_full_data.c_str());
        return;
    }

    iv = base64_decodestring(exploded[0]);
    data_key = base64_decodestring(exploded[1]);
    encrypted_data = base64_decodestring(exploded[2]);
}


#pragma mark- RSA
bool rsa_encode_private_keys(const std::string& key_pass_old, const std::string& private_key_old, const std::string& key_pass_new, std::string& private_key_new)
{
    if (key_pass_old.empty())
    {
        LOG_ERROR("OpenSSL RSA encode keys: old key pass is empty");
        return false;
    }
    if (private_key_old.empty())
    {
        LOG_ERROR("OpenSSL RSA encode keys: old private key is empty");
        return false;
    }
    if (key_pass_new.empty())
    {
        LOG_ERROR("OpenSSL RSA encode keys: new key pass is empty");
        return false;
    }

    random_seed();

    bool status = false;

    BIO* memory = NULL;
    EVP_PKEY* priv_key = NULL;

    do
    {
        memory = BIO_new_mem_buf((void*) private_key_old.c_str(), (int)private_key_old.length());
        priv_key = PEM_read_bio_PrivateKey(memory, NULL, NULL, (char*) key_pass_old.c_str());

        if (!priv_key)
        {
            LOG_ERROR("OpenSSL RSA encode keys: could not read private key - wrong password?");
            break;
        }

        memory = BIO_new(BIO_s_mem());
        int res = PEM_write_bio_PKCS8PrivateKey(memory, priv_key, EVP_aes_256_cbc(), (char*) key_pass_new.c_str(), (int)key_pass_new.length(), NULL, NULL);
        if (!res)
        {
            LOG_ERROR("OpenSSL RSA encode keys: could not write new private key");
            break;
        }
        char* data = NULL;
        //BIO_get_mem_data just sets data pointer, so does not need free
        long int size = BIO_get_mem_data(memory,&data);
        private_key_new.assign(data, size);
        BIO_free(memory);

        status = true;
    }
    while (false);

    EVP_PKEY_free(priv_key);

    if (!status)
    {
        SHOW_OPENSSL_ERRORS("Problem encoding RSA private keys");
    }
    return status;
}

bool rsa_generate_keys(const std::vector<std::string>& key_passes, std::vector<std::string>& private_keys, std::string& public_key, int key_length)
{
    random_seed();

    bool status = false;

    BIO* memory = NULL;
    RSA* rsa_key = NULL;
    EVP_PKEY* evp_key = NULL;

    do
    {
        rsa_key = RSA_generate_key((key_length > 0) ? key_length : RSA_KEY_LENGTH, RSA_F4, NULL, NULL);
        if (!rsa_key || !RSA_check_key(rsa_key))
        {
            LOG_ERROR("OpenSSL RSA genkeys: RSA generated key is corrupt or NULL");
            break;
        }

        evp_key = EVP_PKEY_new();
        EVP_PKEY_set1_RSA(evp_key, rsa_key);
        if (!evp_key)
        {
            LOG_ERROR( "OpenSSL RSA genkeys: RSA generated key could not be converted to EVP_PKEY");
            break;
        }

        for (unsigned int i = 0; i < key_passes.size(); i++)
        {
            memory = BIO_new(BIO_s_mem());
            int res = PEM_write_bio_PKCS8PrivateKey(memory, evp_key, EVP_aes_256_cbc(), (char*) key_passes[i].c_str(), (int)key_passes[i].length(), NULL, NULL);
            if (!res)
            {
                LOG_ERROR("OpenSSL RSA genkeys: Problem writing Privatekey to BIO");
                break;
            }
            char* data = NULL;
            //BIO_get_mem_data just sets data pointer, so does not need free
            long int size = BIO_get_mem_data(memory,&data);
            private_keys.push_back(std::string(data, size));
            BIO_free(memory);
        }

        if (key_passes.size() != private_keys.size())
        {
            LOG_ERROR( "OpenSSL RSA genkeys: Key passes quantity is not the same as private keys");
            break;
        }

        {
            memory = BIO_new(BIO_s_mem());
            int res = PEM_write_bio_PUBKEY(memory, evp_key);
            if (!res)
            {
                LOG_ERROR("OpenSSL RSA genkeys: Could not write public key");
                break;
            }
            char* data = NULL;
            //BIO_get_mem_data just sets data pointer, so does not need free
            long int size = BIO_get_mem_data(memory,&data);
            public_key.assign(data, size);
            BIO_free(memory);
        }
        status = true;
    }
    while (false);

    RSA_free(rsa_key);
    EVP_PKEY_free(evp_key);

    if (!status)
    {
        SHOW_OPENSSL_ERRORS("Generating RSA private keys error");
    }
    return status;
}

bool rsa_encrypt(const std::string& data, const std::string& public_key, std::string& iv, std::string& data_key, std::string& encrypted_data)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL RSA encrypt: data is empty");
        return false;
    }
    if (public_key.empty())
    {
        LOG_ERROR("OpenSSL RSA encrypt: public key is empty");
        return false;
    }

    random_seed();

    bool status = false;

    BIO* memory = NULL;
    EVP_PKEY* pub_keys[1];
    pub_keys[0] = NULL;
    unsigned char* keys[1];
    int keylen[1];
    keys[0] = NULL;
    unsigned char* out = NULL;
    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    do
    {
        memory = BIO_new_mem_buf((unsigned char*) public_key.c_str(), (int)public_key.length());
        if (!memory)
        {
            LOG_ERROR("OpenSSL RSA encrypt: could not allocate memory for BIO");
            break;
        }

        pub_keys[0] = PEM_read_bio_PUBKEY(memory, NULL, NULL, NULL);

        if (!pub_keys[0])
        {
            LOG_ERROR("OpenSSL RSA encrypt: could not open public key");
            break;
        }

        keys[0] = (unsigned char*) calloc(EVP_PKEY_size(pub_keys[0]), sizeof(char));
        out = (unsigned char*) calloc((data.size() / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE, sizeof(char));
        int curr_len = 0;
        int total_len = 0;
        unsigned char iv_char[AES256_BLOCK_SIZE];

        if (!keys[0] || !out)
        {
            LOG_ERROR( "OpenSSL RSA encrypt: could not allocate memory for keys and encrypted data");
            break;
        }

        int stat_code = EVP_SealInit(&ectx, EVP_aes_256_cbc(), keys, keylen, iv_char, pub_keys, 1);
        if(!stat_code)
        {
            LOG_ERROR("OpenSSL RSA encrypt: problem in EVP_SealInit");
            break;
        }

        stat_code = EVP_SealUpdate(&ectx, out, &curr_len, (const unsigned char*)data.c_str(), (int)data.size() );
        if(!stat_code)
        {
            LOG_ERROR("OpenSSL RSA encrypt: problem in EVP_SealUpdate");
            break;
        }
        total_len += curr_len;

        stat_code = EVP_SealFinal(&ectx, out + total_len, &curr_len);
        if(!stat_code)
        {
            LOG_ERROR("OpenSSL RSA encrypt: problem in EVP_SealFinal");
            break;
        }
        total_len += curr_len;

        if (total_len <= 0)
        {
            LOG_ERROR("OpenSSL RSA encrypt: bad total_len [%i]", total_len);
            break;
        }

        status = true;

        iv.assign((const char*) iv_char, sizeof(iv_char));
        data_key.assign((const char*) keys[0], keylen[0]);
        encrypted_data.assign((const char*) out, total_len);
    }
    while (false);

    BIO_free(memory);
    EVP_PKEY_free(pub_keys[0]);
    free(keys[0]);
    free(out);
    EVP_CIPHER_CTX_cleanup(&ectx);

    if (!status)
    {
        SHOW_OPENSSL_ERRORS("RSA encryption error");
    }
    return status;
}

bool rsa_decrypt(const std::string& data, const std::string& private_key, const std::string& private_key_password, const std::string& iv, const std::string& data_key, std::string& decrypted_data)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: data is empty");
        return false;
    }
    if (private_key.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: private key is empty");
        return false;
    }
    if (private_key_password.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: private key password is empty");
        return false;
    }
    if (iv.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: iv is empty");
        return false;
    }
    if (data_key.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: data key is empty");
        return false;
    }

    if (iv.size() != AES256_IV_SIZE)
    {
        LOG_ERROR("OpenSSL RSA decrypt: IV size is incorrect! got:expected [%i]:[%i]", (int)iv.size(), AES256_IV_SIZE);
        return false;
    }

    bool status = false;

    BIO* memory = NULL;
    EVP_PKEY* priv_key = NULL;
    unsigned char* out = NULL;
    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    do
    {
        memory = BIO_new_mem_buf((void*) private_key.c_str(), (int)private_key.length());
        priv_key = PEM_read_bio_PrivateKey(memory, NULL, NULL,(char*) private_key_password.c_str());

        if (!priv_key)
        {
            LOG_ERROR("OpenSSL RSA decrypt: could not open private key");
            break;
        }

        if (data_key.size() != EVP_PKEY_size(priv_key))
        {
            LOG_ERROR("OpenSSL RSA decrypt: DataKey size is incorrect! got:expected [%i]:[%i]", (int)data_key.size(), EVP_PKEY_size(priv_key));
            break;
        }

        out = (unsigned char*) calloc((data.size() / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE, sizeof(char));
        int curr_len = 0;
        int total_len = 0;

        int stat_code = EVP_OpenInit(&ectx, EVP_aes_256_cbc(), (const unsigned char*) data_key.c_str(), (int)data_key.length(), (const unsigned char*) iv.c_str(), priv_key);
        if(!stat_code)
        {
            LOG_ERROR("OpenSSL RSA decrypt: problem in EVP_OpenInit");
            break;
        }

        stat_code = EVP_OpenUpdate(&ectx, out, &curr_len, (const unsigned char*)data.c_str(), (int)data.size() );
        if(!stat_code)
        {
            LOG_ERROR("OpenSSL RSA decrypt: problem in EVP_OpenUpdate");
            break;
        }
        total_len += curr_len;

        stat_code = EVP_OpenFinal(&ectx, out + total_len, &curr_len);
        if(!stat_code)
        {
            LOG_ERROR("OpenSSL RSA decrypt: problem in EVP_OpenFinal");
            break;
        }
        total_len += curr_len;

        if (total_len <= 0)
        {
            LOG_ERROR("OpenSSL RSA decrypt: bad total_len [%i]", total_len);
            break;
        }

        status = true;

        decrypted_data.assign((const char*) out, total_len);
    }
    while (false);

    BIO_free(memory);
    EVP_PKEY_free(priv_key);
    free(out);
    EVP_CIPHER_CTX_cleanup(&ectx);

    if (!status)
    {
        SHOW_OPENSSL_ERRORS("RSA decryption error");
    }
    
    return status;
}

bool rsa_check_private_key(const std::string& private_key, const std::string& private_key_password)
{
    if (private_key.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: private key is empty");
        return false;
    }

    if (private_key_password.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: private key password is empty");
        return false;
    }

    BIO* memory = BIO_new_mem_buf((void*) private_key.c_str(), (int) private_key.length());
    EVP_PKEY* priv_key = PEM_read_bio_PrivateKey(memory, NULL, NULL, (char*) private_key_password.c_str());

    bool result = (priv_key != NULL);

    if (!result)
    {
        SHOW_OPENSSL_ERRORS("RSA decryption error");
    }

    BIO_free(memory);
    EVP_PKEY_free(priv_key);

    return result;
}

bool rsa_easy_encrypt(const std::string& data, const std::string& public_key, std::string& encrypted_data_pack)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL RSA encrypt: data is empty");
        return false;
    }
    if (public_key.empty())
    {
        LOG_ERROR("OpenSSL RSA encrypt: public key is empty");
        return false;
    }

    std::string iv, data_key, encrypted_data;
    bool result = rsa_encrypt(data, public_key, iv, data_key, encrypted_data);
    rsa2string(iv, data_key, encrypted_data, encrypted_data_pack);
    return result;
}

bool rsa_easy_decrypt(const std::string& encrypted_data_pack, const std::string& private_key, const std::string& private_key_password, std::string& decrypted_data)
{
    if (encrypted_data_pack.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: data is empty");
        return false;
    }
    if (private_key_password.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: private key password is empty");
        return false;
    }
    if (private_key.empty())
    {
        LOG_ERROR("OpenSSL RSA decrypt: private key is empty");
        return false;
    }

    std::string iv, data_key, encrypted_data;
    string2rsa(encrypted_data_pack, iv, data_key, encrypted_data);
    bool result = rsa_decrypt(encrypted_data, private_key, private_key_password, iv, data_key, decrypted_data);
    return result;
}
