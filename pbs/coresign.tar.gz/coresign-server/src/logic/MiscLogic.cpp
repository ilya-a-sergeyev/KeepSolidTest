/*
 * logic.cpp
 *
 *  Created on: 31 бер. 2011
 *      Author: fireball
 */

#include "logic/MiscLogic.h"

#include "encryption/xopenssl.h"

#include <sutil/logging.h>
#include <util/DataVerifier.h>
#include <sutil/MailerHelper.h>
#include <sutil/amazon_s3.h>
#include <sutil/Timer.h>
#include <util/url_encode.h>
#include "util/getNotificationLiterals.h"

#include "db/keys/KeysManagerPgSql.h"

#include "logic/EventLogic.h"
#include "logic/HelperLogic.h"


rpc_status_code MiscLogic::createKeyPair(RequestContext& context, const std::string& password, std::string& keyId, std::string& public_key)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        keyId = randomstring(32);
        if (keyId.empty())
        {
            LOG_ERROR("Problem generating UUID");
            statusCode = status_internal_error;
            break;
        }
        std::vector<std::string> passwords;
        passwords.push_back(password);
        std::vector<std::string> private_keys;
        bool result = rsa_generate_keys(passwords,private_keys,public_key,1024);

        if (!result || public_key.empty() || private_keys.empty() || private_keys[0].empty())
        {
            LOG_ERROR("Problem generating RSA keys");
            statusCode = status_internal_error;
            break;
        }

        statusCode = KeysManagerPgSql::create_key(userId, keyId, public_key, private_keys[0]);

        if (statusCode == status_success)
        {
            bStatus = true;
        }
    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("CreateKeyPair function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("CreateKeyPair function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code MiscLogic::getKeyPair(RequestContext& context, const std::string& keyId, std::string& public_key, std::string& private_key)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if(keyId.empty())
        {
            statusCode = status_does_not_exist;
            break;
        }
        statusCode = KeysManagerPgSql::get_key(keyId,public_key,private_key);

        if (statusCode == status_success)
        {
            bStatus = true;
        }
    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("GetKeyPair function ended: keyId [%s]", keyId.c_str());
    }
    else
    {
        LOG_INFORMATION("GetKeyPair function failed: keyId [%s]", keyId.c_str());
    }

    return statusCode;
}


