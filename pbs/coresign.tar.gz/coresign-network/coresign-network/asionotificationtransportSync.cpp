﻿#include "asionotificationtransportSync.h"

#include <thread>
#include <util/logging.h>

struct default_callback
{
    void operator()(const std::string& message) const
    {
        LOG_ERROR("NotificationReceiver: No callback for notification specified! got message [%s]", message.c_str());
    }
};

struct default_connection_cb
{
    void operator()(OperationStatus opstat, bool status) const
    {
        LOG_ERROR("NotificationReceiver: No callback for connection status! Got opstat [%i] and status [%s]", opstat, status ? "true" : "false");
    }
};

AsioNotificationTransportSync::AsioNotificationTransportSync(const std::string &address, const std::string &port):
    _io_service(1),
    _socket(_io_service),
    _callback(default_callback()),
    _connection_cb(default_connection_cb()),
    _address(address),
    _port(port),
    _stop_waiting(false)
{
    connect();
}

AsioNotificationTransportSync::~AsioNotificationTransportSync()
{
    _callback = default_callback();
    _test_alive = 0xDEADBEEF;
}

bool AsioNotificationTransportSync::connect()
{
    try
    {
        asio::ip::tcp::resolver resolver(_socket.get_io_service());
        asio::ip::tcp::resolver::query query(_address,_port);
        asio::ip::tcp::endpoint endpoint = *resolver.resolve(query);

        _socket.lowest_layer().connect(endpoint);

        asio::socket_base::keep_alive option(true);
        _socket.lowest_layer().set_option(option);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("NotificationReceiver: Problem connecting %s",e.what());
        return false;
    }

    LOG_INFORMATION("NotificationReceiver: Connected OK");
    return true;
}

OperationStatus AsioNotificationTransportSync::read(asio::error_code& err, std::string& data_in)
{
    int64_t     data_in_size_planned = 0;
    int64_t     data_in_size_real    = 0;

    try
    {
        asio::read(_socket, asio::buffer(&data_in_size_planned, sizeof(data_in_size_planned)), err);

        if (err && err != asio::error::eof)
        {
            LOG_ERROR("NotificationReceiver: Got error reading data_size... [%s]",err.message().c_str());
            return OPSTATUS_ERROR;
        }

        if (data_in_size_planned <0 || data_in_size_planned>16000000)
        {
            LOG_ERROR("NotificationReceiver: Incorrect size received %lli",data_in_size_planned); ///BAD!!
            return OPSTATUS_ERROR;
        }

        if(_data_in_vector.size() < data_in_size_planned)
        {
            _data_in_vector.resize((data_in_size_planned/64+1)*64);
        }

        data_in_size_real = asio::read(_socket, asio::buffer(_data_in_vector), asio::transfer_exactly(data_in_size_planned), err);//read data frame

        if (err && err != asio::error::eof)
        {
            LOG_ERROR("NotificationReceiver: Got error reading data... [%s]", err.message().c_str());
            return OPSTATUS_ERROR;
        }

        if (data_in_size_planned != data_in_size_real)
        {
            LOG_ERROR("NotificationReceiver: Size mismatch %lli <> %lli", data_in_size_planned, data_in_size_real); ///BAD!!
            return OPSTATUS_ERROR;
        }

        data_in.assign(_data_in_vector.data(), data_in_size_real);

        asio::write(_socket, asio::buffer(&data_in_size_real, sizeof(data_in_size_real)), err);//write confirmation

        if (err && err != asio::error::eof)
        {
            LOG_ERROR("NotificationReceiver: Got error writing data confirmation... [%s]", err.message().c_str());
            return OPSTATUS_ERROR;
        }
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("NotificationReceiver: Problem reading data [%s]", e.what());
        return OPSTATUS_ERROR;
    }

    return OPSTATUS_OK;
}

OperationStatus AsioNotificationTransportSync::write       (const std::string& data_out)
{
    uint64_t data_out_size = data_out.size();
    size_t s2 = 0;

    try
    {
        asio::write(_socket, asio::buffer(&data_out_size,sizeof(data_out_size)));
        s2 = asio::write(_socket, asio::buffer(data_out.c_str(),data_out.size()));
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("NotificationReceiver: Problem writing data %s",e.what());
        return OPSTATUS_ERROR;
    }

    return OPSTATUS_OK;
}

void AsioNotificationTransportSync::disconnect  ()
{
    asio::error_code ignored_ec;
    _socket.lowest_layer().shutdown(asio::ip::tcp::socket::shutdown_both, ignored_ec);
    _socket.lowest_layer().close(ignored_ec);

    //LOG_INFORMATION("NotificationReceiver: Disconnected OK");
}

bool AsioNotificationTransportSync::is_connected()
{
    return _socket.is_open();
}

void AsioNotificationTransportSync::run_service()
{
    asio::error_code err;

    LOG_INFORMATION("NotificationReceiver: IO Service started");

    while(!_stop_waiting)
    {
        int64_t data_read = read(err, _data_push);
        handle_notification(err, _data_push.size());
        #pragma unused(data_read)
    }

    LOG_INFORMATION("NotificationReceiver: IO Service stopped with err %s",err.message().c_str());
}

void AsioNotificationTransportSync::stop_service()
{
    LOG_INFORMATION("NotificationReceiver: IO Service stop fired");

    _stop_waiting = true;
}

void AsioNotificationTransportSync::subscribe (const function_MessageCallback& callback, const function_ConnectionCallback& connection_cb, bool start_service)
{
    if (start_service)
    {
        _callback = callback;
        _connection_cb = connection_cb;
        _connection_cb(OPSTATUS_OK, true);
        std::function<void()> run_service = std::bind(&AsioNotificationTransportSync::run_service, shared_from_this());
        std::thread t(run_service);
    }
}

void AsioNotificationTransportSync::stop()
{
    LOG_INFORMATION("NotificationReceiver: STOP");
    try
    {
        _callback = default_callback();
        _connection_cb = default_connection_cb();
        disconnect();
        stop_service();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("NotificationReceiver: Exception stopping IO service %s",e.what());
    }
}

std::size_t AsioNotificationTransportSync::handle_notification(const asio::error_code& error, std::size_t bytes_transferred)
{
    do
    {
        bool wasError = false;
        if (_stop_waiting)
        {
            LOG_INFORMATION("NotificationReceiver: was stopped, skipping callback");
            break;
        }

        if (error.value())
        {
            LOG_ERROR("NotificationReceiver: error: %s", error.message().c_str());
            wasError = true;
        }

        if (false == wasError)
        {
            try
            {
                if (bytes_transferred > 0)
                {
                    _callback(_data_push);
                }
            }
            catch (const std::exception& e)
            {
                LOG_ERROR("NotificationReceiver: error calling callback: %s", e.what());
                break;
            }
            subscribe(_callback, _connection_cb, false);
        }
        else
        {
            //If got error = stop all that jive
            LOG_ERROR("NotificationReceiver: I got an error. I`ll stop!");
            try
            {
                _connection_cb(OPSTATUS_ERROR, false);
            }
            catch (const std::exception& e)
            {
                LOG_ERROR("NotificationReceiver: error calling callback: %s", e.what());
                break;
            }
            _stop_waiting = true;
        }
    }
    while (false);

    return bytes_transferred;
}
