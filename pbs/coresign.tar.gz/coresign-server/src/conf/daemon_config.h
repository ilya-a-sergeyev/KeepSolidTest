#ifndef DAEMON_CONFIG
#define DAEMON_CONFIG

#include "conf/DaemonParams.h"
#include "conf/Globals.h"
#include <pthread.h>
#include <queue>
#include <cstdio>
#include <cstdlib>
#include <cstring>

//#define LOGGING_SOURCE_INFO
#define LOGGING_ENABLED

#define	PATH_LENGTH	255
#define	ADDR_LENGTH	16

#define DEFAULT_CONFIG_FILE             "./daemon_keepsolid.conf"
#define DEFAULT_ADDRESS					"0.0.0.0"
#define DEFAULT_PORT    				6667
#define DEFAULT_LOGFILE_VERBOSITY		Nothing
#define DEFAULT_SYSLOG_VERBOSITY		Normal
//#define DEFAULT_WORKER_MODEL			Pthreads
#define DEFAULT_DAEMONIZE				0
//#define DEFAULT_RPC_VARIANT				PROTOBUF_ASIO
#define DEFAULT_LOGFILE_PATH			"./evxml_daemon.log"
#define DEFAULT_CONNECTION_QUEUE		8
#define DEFAULT_WORKERS_POOL_SIZE		8
#define DEFAULT_MAX_WORKERS				16
#define DEFAULT_AMAZON_EXPIRATION       100
#define DEFAULT_EMAIL_ENABLED           true
#define DEFAULT_TIMERS_ENABLED          true
#define DEFAULT_REQUEST_MAX_SIZE        32768
#define DEFAULT_CONNECTION_TIMEOUT      300
#define DEFAULT_CONNECTION_STACK_SIZE   32



void print_daemon_params();

#endif
