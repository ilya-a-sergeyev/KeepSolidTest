
#include "xopenssl_hash.h"
#include <openssl/engine.h>
#include <openssl/evp.h>
#include <istream>
#include "util/logging.h"
#include "xopenssl_defines.h"
#include "xopenssl_util.h"


std::string md5_raw(const std::string& text)
{
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_md5());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return std::string((char*)md_value, md_len);
}

std::string sha1_raw(const std::string& text)
{
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_sha1());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return std::string((char*)md_value, md_len);
}

std::string sha256_raw(const std::string& text)
{
    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_sha256());
    EVP_DigestUpdate(&mdctx, text.c_str(), text.size());
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    return std::string ((char*) md_value, md_len);
}


/******************************************************************************
 md5
 ******************************************************************************/
#pragma mark- Hash MD5

std::string md5(std::istream& in_stream)
{
    if (!in_stream.good())
    {
        LOG_ERROR("OpenSSL md5() failed reading file!");
        return std::string("");
    }

    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_md5());

    char buffer[IO_BLOCK_SIZE]={0};
    in_stream.seekg(0, std::ios::beg);
    while (!in_stream.eof() && !in_stream.fail())
    {
        in_stream.read(buffer, sizeof(buffer));

        EVP_DigestUpdate(&mdctx, buffer, (size_t)in_stream.gcount() * sizeof(char));
    }
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    if (in_stream.fail() && !in_stream.eof())
    {
        LOG_ERROR("OpenSSL md5() failed reading file!");
    }

    return digest_to_hex_string(md_value, md_len);
}

std::string md5( FILE* in_stream )
{
    if (in_stream == NULL || ferror(in_stream))
    {
        LOG_ERROR("OpenSSL md5() failed reading file!");
        return std::string("");
    }

    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_md5());

    char buffer[IO_BLOCK_SIZE]={0};
    FSEEK64(in_stream, 0, SEEK_SET);

    while (!feof(in_stream) && !ferror(in_stream))
    {
        size_t count = fread(buffer, sizeof(char), sizeof(buffer), in_stream);

        EVP_DigestUpdate(&mdctx, buffer, count * sizeof(char));
    }
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    if (ferror(in_stream))
    {
        LOG_ERROR("OpenSSL md5() failed reading file!");
    }

    return digest_to_hex_string(md_value, md_len);
}

std::string md5(const std::string& text)
{
    return digest_to_hex_string(md5_raw(text));
}

/******************************************************************************
 shaxxx
 ******************************************************************************/
#pragma mark- Hash SHA

std::string sha1(const std::string& text)
{
    return digest_to_hex_string(sha1_raw(text));
}

std::string sha256(std::istream& in_stream)
{
    if (!in_stream.good())
    {
        LOG_ERROR("OpenSSL sha256() failed reading file!");
        return std::string("");
    }

    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_sha256());

    char buffer[IO_BLOCK_SIZE];
    in_stream.seekg(0, std::ios::beg);
    while (!in_stream.eof() && !in_stream.fail())
    {
        in_stream.read(buffer, sizeof(buffer));

        EVP_DigestUpdate(&mdctx, buffer, (size_t)in_stream.gcount() * sizeof(char));
    }
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    if (in_stream.fail() && !in_stream.eof())
    {
        LOG_ERROR("OpenSSL sha256() failed reading file!");
    }

    return digest_to_hex_string(md_value, md_len);
}

std::string sha256( FILE* in_stream )
{
    if (in_stream == NULL || ferror(in_stream))
    {
        LOG_ERROR("OpenSSL sha256() failed reading file!");
        return std::string("");
    }

    EVP_MD_CTX mdctx;
    unsigned char md_value[EVP_MAX_MD_SIZE]={0};
    unsigned int md_len = 0;

    EVP_DigestInit(&mdctx, EVP_sha256());

    char buffer[IO_BLOCK_SIZE];
    FSEEK64(in_stream, 0, SEEK_SET);

    while (!feof(in_stream) && !ferror(in_stream))
    {
        size_t count = fread(buffer, sizeof(char), sizeof(buffer), in_stream);

        EVP_DigestUpdate(&mdctx, buffer, count * sizeof(char));
    }
    EVP_DigestFinal_ex(&mdctx, md_value, &md_len);
    EVP_MD_CTX_cleanup(&mdctx);

    if (ferror(in_stream))
    {
        LOG_ERROR("OpenSSL sha256() failed reading file!");
    }

    return digest_to_hex_string(md_value, md_len);
}

std::string sha256(const std::string& text)
{
    return digest_to_hex_string(sha256_raw(text));
}
