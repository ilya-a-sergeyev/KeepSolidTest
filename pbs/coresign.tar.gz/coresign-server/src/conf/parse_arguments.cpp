#include "conf/daemon_config.h"
#include "conf/parse_arguments.h"

#include <getopt.h>

static int printUsage(int exit_status);

/**
 * Parses program's arguments and fills in DaemonParams
 * global object
 */
int parse_arguments(int argc, char** argv)
{

    daemon_params().setProgramName(argv[0]);

    static struct option long_options[] =
    {
        {"help", no_argument, 0, 'h'},
        {"config", required_argument, 0, 'c'},
        {"daemon", no_argument, 0, 'd'},
        {"nodaemon", no_argument, 0, 'n'},
        {"address", required_argument, 0, 'a'},
        {"port", required_argument, 0, 'p'},
        {"eventport", required_argument, 0, 'e'},
        {"eventregport", required_argument, 0, 'r'},
        {0, 0, 0, 0}
    };

    while (1)
    {
        int option_index = 0;

        int c = getopt_long(argc, argv, "hc:dna:p:e:r:",
                            long_options, &option_index);
        if (c == -1)
        {
            break;
        }

        switch (c)
        {
            case 'h':
                printUsage(EXIT_SUCCESS);
                break;

            case 'c':
                daemon_params().setConfFilePath(optarg);
                break;

            case 'd':
                daemon_params().setDaemonize(1);
                break;

            case 'n':
                daemon_params().setDaemonize(0);
                break;

            case 'a':
                daemon_params().setListenAddress(optarg);
                break;

            case 'p':
                daemon_params().setListenPort(atoi(optarg));
                break;

            case 'e':
                daemon_params().setNotificationEmitPort(atoi(optarg));
                break;

            case 'r':
                daemon_params().setNotificationRegPort(atoi(optarg));
                break;

            case '?':
                printUsage(EXIT_FAILURE);
                break;

            default:
                fprintf(stderr, "EvXML: getopt returned character code 0%o %c \n", c, c);
                break;
        }
    }

    return EXIT_SUCCESS;
}

/**
 * Prints out help about command line parameters usage
 */
static int printUsage(int exit_status)
{
    if (exit_status == EXIT_SUCCESS)
    {
        fprintf(stdout,"Usage %s [options] \n",daemon_params().getProgramName().c_str());
        fprintf(stdout,"\t -h --help \t\t\t Smth \n");
        fprintf(stdout,"\t -c --config=conf_file \t\t Set config file \n");
        fprintf(stdout,"\t -x --verbosity[=level] \t Set verbosity level \n");
        fprintf(stdout,"\t -v --verbose \t\t\t Set VERBOSE level \n");
        fprintf(stdout,"\t -l --log=log_file \t\t Set log file path \n");
        fprintf(stdout,"\t -d --daemon \t\t\t Daemonize after start \n");
        fprintf(stdout,"\t -n --nodaemon \t\t\t No daemonizing \n");
        fprintf(stdout,"\t -a --address \t\t\t Listen address \n");
        fprintf(stdout,"\t -p --port \t\t\t Listen RPC port \n");
        fprintf(stdout,"\t -e --eventport \t\t Listen EventNotifications port \n");
        fprintf(stdout,"\t -r --eventregport \t\t Listen registration for events port\n");
    }
    else
    {
        fprintf(stderr,"Try `%s --help' for more information\n", daemon_params().getProgramName().c_str());
    }
    exit(exit_status);
}
