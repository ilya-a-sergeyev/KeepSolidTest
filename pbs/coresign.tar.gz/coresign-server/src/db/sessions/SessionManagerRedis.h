/*
 * SessionManagerPgSql.h
 *
 *  Created on: 25 бер. 2011
 *      Author: fireball
 */

#ifndef SESSIONMANAGERREDIS_H_
#define SESSIONMANAGERREDIS_H_

#include <cstdint>
#include "types/status_codes.h"
#include "types/user_info.h"
#include "types/request_context.h"

class SessionManagerRedis
{
public:
    static rpc_status_code		get_session				(const std::string& sessionId,
                                                         const std::string& ip_address,
                                                         SessionInfo& session);
    static rpc_status_code      get_event_session       (const std::string& event_session_id,
                                                         const std::string& ip_address,
                                                         SessionInfo& session);
    static rpc_status_code      update_session          (const SessionInfo& session);
};

#endif /* SESSIONMANAGERREDIS_H_ */
