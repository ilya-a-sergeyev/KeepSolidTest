#pragma once

#include <curl/curl.h>
#include <curl/easy.h>
#include <string>
#include <map>

#include "CurlSignalsDeclarations.hpp"

class CurlUploader
{
public:
    //Data type
    typedef std::map<std::string, std::string> tPostParams;

    //Methods section
    explicit CurlUploader(const std::string& certificateFolder, bool verifyCerts = true);
    CurlUploader() = delete;
    CurlUploader(const CurlUploader&) = delete;
    CurlUploader(CurlUploader&&) = delete;
    CurlUploader& operator=(const CurlUploader&) = delete;
    CurlUploader& operator=(CurlUploader&&) = delete;
    virtual ~CurlUploader();

    CURLcode            upload_file         (const std::string& fileName, const std::string& uploadUrl, const std::string& fileHash);
    CURLcode            download_file       (const std::string& save_fileName, const std::string& downloadUrl);

    /**
    *   @brief                      Upload file using HTTP POST request to server
    *   @param  fileName            Path to the file to upload
    *   @param  serverUrl           Address server for uploading
    *   @param  params              Map of required POST fields.
    *                               Example: "sid":"2oK9RoTxT54YPVyS97ZEMGfm06dYGpK6UIckrAFGQHLxGg_zRRVA3d+1WEH23MdL"
    *   @param  uploaded_file_url   Returned url of uploaded file if operation was successful
    *   @return                     TRUE if operation was successful, otherwise FALSE
    **/
    CURLcode            upload_file         (const std::string& fileName, const std::string& serverUrl, const tPostParams& params, std::string& uploaded_file_url);
    CURLcode            post_request        (const std::string& serverUrl, const tPostParams& params, std::string& result, const std::string& basic_auth = "");
    CURLcode            post_request_base64 (const std::string& serverUrl, const tPostParams& params, std::string& result, const std::string& basic_auth = "");

    std::string         getSertificateFolder() const { return m_CertificateFolder; }

    static tCurlCancelSignal*      getCancelSignal() { return &ms_cancelSignal; }
    static tCurlProgressSignal*    getUploadProgressSignal() { return &ms_uploadProgressSignal; }
    static tCurlProgressSignal*    getDownloadProgressSignal() { return &ms_downloadProgressSignal; }

private:
    //Methods section
    static size_t                 upload_write_data    (void *data, size_t size, size_t nmemb, void *destination);
    static size_t                 upload_header_data   (void *data, size_t size, size_t nmemb, void *destination);
    static size_t                 upload_read_file     (void *data, size_t size, size_t nmemb, void *file);
    static size_t                 download_write_file  (void *data, size_t size, size_t nmemb, void *file);
    static size_t                 download_write_data  (void *data, size_t size, size_t nmemb, void *destination);
    void                          clean_data           ();

    static int                    upload_progress      (void*, double, double, double ultotal, double ulnow);
    static int                    download_progress    (void*, double dltotal, double dlnow, double, double);

    static int                    handle_trace           (CURL *handle, curl_infotype type, char *data, size_t size, void *userp);

    //Members section
    CURL*                         curl_up;
    CURL*                         curl_down;
    std::string                   reply_data;
    std::string                   header_data;
    static bool                   bCurlInitialized;
    struct curl_httppost*         formpost;
    struct curl_httppost*         lastptr;
    std::string                   m_CertificateFolder;
    char                          mErrorBuffer[CURL_ERROR_SIZE];

    std::string                   m_curFileName;
    static tCurlCancelSignal      ms_cancelSignal;
    static tCurlProgressSignal    ms_uploadProgressSignal;
    static tCurlProgressSignal    ms_downloadProgressSignal;

    double                        m_Ultotal;
    double                        m_Ulnow;
    double                        m_Dltotal;
    double                        m_Dlnow;

};
