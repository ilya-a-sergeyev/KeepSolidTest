/*
 * logic.h
 *
 *  Created on: 18 бер. 2011
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/user_info.h"
#include "types/misc_info.h"
#include "types/request_context.h"


/**
 * Class that contains main logic of server:
 * determines which actions should be taken when performing RPC call
 */
class	UserLogic
{
public:
    static rpc_status_code          accountStatsNoSession (RequestContext& context, const std::string& login, AccountStats& accountStats);
    static rpc_status_code          accountStats        (RequestContext& context, AccountStats& accountStats, bool isExtended, bool getServersList, bool createIfNull);
    static rpc_status_code          userInfoMass        (RequestContext& context, const UserLoginList& userEmailList, UserInfoList& userInfo, bool createIfNull);
    static rpc_status_code          userInfoKS          (RequestContext& context, const UserInfo& inviterUserInfo, UserInfo& userInfo, bool createIfNull);
    static rpc_status_code          userInfoSX          (RequestContext& context, UserInfo& userInfo);
    static rpc_status_code          getMyData           (RequestContext& context, UserInfo& userInfo, UserCredentials& userCredentials);
    static rpc_status_code          setMyData           (RequestContext& context, UserInfo& userInfo);
    static rpc_status_code          notificationsGet    (RequestContext& context, NotificationsSubscription& notifySub);
    static rpc_status_code          notificationsSet    (RequestContext& context, NotificationsSubscription& notifySub);

    static rpc_status_code          purchaseApply       (RequestContext& context, const PurchaseData& purchase);
    static rpc_status_code          purchaseRefund      (RequestContext& context, const std::string& login, const std::string& purchase_hash);

    static rpc_status_code          userRemove          (RequestContext& context, const std::string& login);

};

