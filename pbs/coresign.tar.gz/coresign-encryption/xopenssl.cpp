#include "xopenssl.h"
#include <openssl/e_os2.h>
#include <openssl/ssl.h>

#include <openssl/engine.h>
#include <openssl/rand.h>
#include <cstring>

#include "xopenssl_defines.h"
#include "xopenssl_util.h"
#include "xopenssl_aes_file.h"
#include "BlockDataCrypto.h"

#include "util/logging.h"

#ifdef OPENSSL_SYS_UNIX

#define MUTEX_TYPE       pthread_mutex_t
#define MUTEX_SETUP(x)   pthread_mutex_init(&(x), NULL)
#define MUTEX_CLEANUP(x) pthread_mutex_destroy(&(x))
#define MUTEX_LOCK(x)    pthread_mutex_lock(&(x))
#define MUTEX_UNLOCK(x)  pthread_mutex_unlock(&(x))
#define THREAD_ID        pthread_self(  )

/* This array will store all of the mutexes available to OpenSSL. */
static MUTEX_TYPE* mutex_buf = NULL;

static void locking_function(int mode, int n, const char* file, int line)
{
    if (mode & CRYPTO_LOCK)
    {
        MUTEX_LOCK(mutex_buf[n]);
    }
    else
    {
        MUTEX_UNLOCK(mutex_buf[n]);
    }
}

static unsigned long id_function(void)
{
    return ((unsigned long) THREAD_ID);
}

int thread_setup(void)
{
    int i;

    mutex_buf = (pthread_mutex_t*) calloc(CRYPTO_num_locks() * sizeof(MUTEX_TYPE), sizeof(char));
    if (!mutex_buf)
    {
        return 0;
    }
    for (i = 0; i < CRYPTO_num_locks(); i++)
    {
        MUTEX_SETUP(mutex_buf[i]);
    }
    CRYPTO_set_id_callback(id_function);
    CRYPTO_set_locking_callback(locking_function);
    return 1;
}

int thread_cleanup(void)
{
    int i;

    if (!mutex_buf)
    {
        return 0;
    }
    CRYPTO_set_id_callback(NULL);
    CRYPTO_set_locking_callback(NULL);
    for (i = 0; i < CRYPTO_num_locks(); i++)
    {
        MUTEX_CLEANUP(mutex_buf[i]);
    }
    free(mutex_buf);
    mutex_buf = NULL;
    return 1;
}
#endif

#ifdef OPENSSL_SYS_WIN32
#include <windows.h>

static HANDLE* lock_cs;

void win32_locking_callback(int mode, int type, const char* file, int line)
{
    if (mode & CRYPTO_LOCK)
    {
        WaitForSingleObject(lock_cs[type],INFINITE);
    }
    else
    {
        ReleaseMutex(lock_cs[type]);
    }
}

int thread_setup(void)
{
    int i;

    lock_cs=(HANDLE*)OPENSSL_malloc(CRYPTO_num_locks() * sizeof(HANDLE));
    if (!lock_cs)
    {
        return 0;
    }
    for (i=0; i<CRYPTO_num_locks(); i++)
    {
        lock_cs[i]=CreateMutex(NULL,FALSE,NULL);
    }

    if (CRYPTO_get_locking_callback() == NULL)
    {
        CRYPTO_set_locking_callback((void (*)(int,int, const char*,int))win32_locking_callback);
    }
    /* id callback defined */
    return 1;
}

int thread_cleanup(void)
{
    int i;
    if (!lock_cs)
    {
        return 0;
    }

    if (CRYPTO_get_locking_callback() == win32_locking_callback)
    {
        CRYPTO_set_locking_callback(NULL);
    }

    for (i=0; i<CRYPTO_num_locks(); i++)
    {
        CloseHandle(lock_cs[i]);
    }
    OPENSSL_free(lock_cs);

    return 1;
}

#endif /* OPENSSL_SYS_WIN32 */

void openssl_init()
{
    SSL_library_init();
    OpenSSL_add_all_algorithms();
    OpenSSL_add_all_ciphers();
    OpenSSL_add_all_digests();
    ERR_load_crypto_strings();

    random_seed();
#ifdef OPENSSL_SYS_WIN32
    RAND_screen();
#endif

    thread_setup();
}

void openssl_cleanup()
{
    thread_cleanup();

    EVP_cleanup();
}

void disable_ssl_cache(void* context)
{
    SSL_CTX* real_cont = (SSL_CTX*) context;

    if (!real_cont)
    {
        return;
    }

    LOG_INFORMATION("Default SSL Cache value is %li",SSL_CTX_get_session_cache_mode(real_cont));

    SSL_CTX_set_session_cache_mode(real_cont,SSL_SESS_CACHE_OFF);
}

void clear_ssl_cache(void* context)
{
    SSL_CTX* real_cont = (SSL_CTX*) context;

    if (!real_cont)
    {
        return;
    }

    SSL_CTX_flush_sessions(real_cont,time(0));
}


bool encrypt_key_with_password(const std::string& key, const std::string& secret, std::string& key_salt, std::string& key_sign, std::string& key_encrypted, int cycles)
{
    bool ret = false;
    do
    {
        if (key.empty() || secret.empty())
        {
            LOG_ERROR("OpenSSL encrypt_key_with_password: input parameters are empty!");
            break;
        }

        std::string temp_enc_key = sha256_pbkdf2_password_generate(secret, key_salt, cycles);

        if (true == key_salt.empty() || true == temp_enc_key.empty())
        {
            LOG_ERROR("OpenSSL encrypt_key_with_password: key's salt or temporary key are empty!");
            break;
        }

        key_sign = sha256_hmac_easy_sign(temp_enc_key);
        if (true == key_sign.empty())
        {
            LOG_ERROR("OpenSSL encrypt_key_with_password: result of work sha256_hmac_easy_sign() function is empty!");
            break;
        }

        key_encrypted = aes_easy_encrypt(key, temp_enc_key);
        if (true == key_encrypted.empty())
        {
            LOG_ERROR("OpenSSL encrypt_key_with_password: result of work aes_easy_encrypt() function is empty!");
            break;
        }

        ret = true;
    } while (false);

    return ret;
}

bool decrypt_key_with_password(const std::string& secret, const std::string& key_salt, const std::string& key_sign, const std::string& key_encrypted, std::string& key)
{
    bool ret = false;
    do
    {
        if (secret.empty() || key_salt.empty() || key_sign.empty() || key_encrypted.empty())
        {
            LOG_ERROR("OpenSLL decrypt_key_with_password: input parameters are empty!");
            break;
        }

        std::string temp_enc_key = sha256_pbkdf2_password_stretch(secret, key_salt);

        if (true == temp_enc_key.empty())
        {
            LOG_ERROR("OpenSSL decrypt_key_with_password: result of work sha256_pbkdf2_password_stretch() function is empty!");
            break;
        }

        if(false == sha256_hmac_easy_verify(key_sign, temp_enc_key))
        {
            LOG_ERROR("OpenSSL decrypt_key_with_password: secret is wrong!");
            break;
        }

        key = aes_easy_decrypt(key_encrypted, temp_enc_key);
        if (true == key.empty())
        {
            LOG_ERROR("OpenSSL decrypt_key_with_password: result of work aes_easy_decrypt() function is empty!");
            break;
        }

        ret = true;
    } while(false);

    return ret;
}
