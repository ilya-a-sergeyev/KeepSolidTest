/*
 * EventNotifier.cpp
 *
 *  Created on: 1 feb 2011
 *      Author: fireballdark
 */

#include "EventNotifier.h"
#include "EventNotifierImpl.h"
#include <boost/thread.hpp>
#include "threadpool/boost/threadpool/pool.hpp"


boost::thread_specific_ptr<EventNotifierImpl> eventNotifier;

class NEWrapper
{
public:
    static boost::threadpool::pool& getThreadPool()
    {
        static boost::threadpool::pool pool(1);
        return pool;
    }

    static void notify_event_wrapper(int64_t userId, int64_t eventType)
    {
        if (eventNotifier.get() == NULL)
        {
            eventNotifier.reset(new EventNotifierImpl());
        }
        eventNotifier.get()->notify_event(userId,eventType);
    };

    static void close_wrapper()
    {
        if (eventNotifier.get() == NULL)
        {
            return;
        }
        eventNotifier.get()->close();
    };
};


void    EventNotifier::notify_event(int64_t userId, int64_t eventType)
{
    NEWrapper::getThreadPool().schedule(boost::bind(&NEWrapper::notify_event_wrapper,userId,eventType));
}

void    EventNotifier::close()
{
    NEWrapper::getThreadPool().schedule(boost::bind(&NEWrapper::close_wrapper));
    NEWrapper::getThreadPool().wait();
}
