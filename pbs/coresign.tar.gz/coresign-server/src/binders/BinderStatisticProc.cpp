#include "BinderStatisticProc.h"
#include <sutil/AtomicConnectionStats.h>
#include <sutil/ProcessStats.h>
#include <snetwork/ServiceExecutor.h>
#include <sutil/ObjectSignalsProccessor.h>

#include <jsoncpp/json/json.h>
#include <stdio.h>
#include "time.h"
#include "rpc/protobuf/ProtobufZmqRpc.h"
#include <boost/bind.hpp>
#include <sutil/Timer.h>

//statistic functions
Json::Value general_con_stat(const KeyValue& params)
{
    KeyValue _params = params;
    Json::Value responce_json;

    responce_json["request_state"]                           = "OK";
    responce_json["statistic"]["open_connections"]           = (long long int)AtomicConnectionStats::get_open_connections();
    responce_json["statistic"]["ssl_connections"]            = (long long int)AtomicConnectionStats::get_ssl_connections();
    responce_json["statistic"]["mature_connections"]         = (long long int)AtomicConnectionStats::get_mature_connections();

    responce_json["statistic"]["total_open_connections"]     = (long long int)AtomicConnectionStats::get_total_open_connections();
    responce_json["statistic"]["total_ssl_connections"]      = (long long int)AtomicConnectionStats::get_total_ssl_connections();
    responce_json["statistic"]["total_mature_connections"]   = (long long int)AtomicConnectionStats::get_total_mature_connections();

    return responce_json;
}

Json::Value open_con_stat(const KeyValue& params)
{
    KeyValue _params = params;
    Json::Value responce_json;

    responce_json["request_state"]                           = "OK";
    responce_json["statistic"]["open_connections"]           = (long long int)AtomicConnectionStats::get_open_connections();
    responce_json["statistic"]["total_open_connections"]     = (long long int)AtomicConnectionStats::get_total_open_connections();

    return responce_json;
}

Json::Value mature_con_stat(const KeyValue& params)
{
    KeyValue _params = params;
    Json::Value responce_json;

    responce_json["request_state"]                           = "OK";
    responce_json["statistic"]["mature_connections"]         = (long long int)AtomicConnectionStats::get_mature_connections();
    responce_json["statistic"]["total_mature_connections"]   = (long long int)AtomicConnectionStats::get_total_mature_connections();

    return responce_json;
}

Json::Value thread_con_stat(const KeyValue& params)
{
    KeyValue _params = params;
    Json::Value responce_json;

    responce_json["request_state"] = "OK";
    ////////////////////////////////////////////////////////////
    /* Start timer */
    Timer t("thread_con_stat");

    std::vector<description_type> all_states = ObjectSignalsProccessor::get_signal()();

    Json::Value thread_desc(Json::arrayValue);
    for( std::vector<description_type>::const_iterator itrDesc = all_states.begin(); itrDesc != all_states.end(); ++itrDesc)
    {
        Json::Value jsonIndex;
        description_type descrition = *itrDesc;
        for (description_type::iterator it = descrition.begin(); it != descrition.end(); ++it)
        {
            jsonIndex[it->first]  = it->second;
        }
        thread_desc.append(jsonIndex);
    }
    responce_json["thread_state"] = thread_desc;

    ////////////////////////////////////////////////////////////
    responce_json["time"] = t.prepare_total();
    return responce_json;
}

Json::Value gen_proc_stat(const KeyValue& params)
{
    KeyValue _params = params;
    Json::Value responce_json;
    ProcessStats procStat;

    responce_json["request_state"]                           = "OK";
    responce_json["name"]                                    = procStat.get_name();
    responce_json["pid"]                                     = procStat.get_pid();
    responce_json["ppid"]                                    = procStat.get_ppid();
    responce_json["rss_memory"]                              = procStat.get_rss_memory();
    responce_json["state"]                                   = procStat.get_state();
    responce_json["sys_time"]                                = procStat.get_system_time();
    responce_json["threads"]                                 = procStat.get_threads();
    responce_json["user_time"]                               = procStat.get_user_time();
    responce_json["description"] =
            "Process State is"
            "one character from the string \"RSDZTW\" where R is running,"
            "S is sleeping in an interruptible wait,"
            "D is waiting in uninterruptible disk sleep,"
            "Z is zombie,"
            "T is traced or stopped (on a signal),"
            "and W is paging";

    return responce_json;
}

///////////////
namespace BinderStatisticProc
{
int prepareBinding()
{
    ServiceExecutor& executor = ServiceExecutor::instance();
    if(executor.add_stat_function("gen_con_stat", &general_con_stat) != 0)
    {
        exit(EXIT_FAILURE);
    }
    if(executor.add_stat_function("open_con_stat", &open_con_stat) != 0)
    {
        exit(EXIT_FAILURE);
    }
    if(executor.add_stat_function("mature_con_stat", &mature_con_stat) != 0)
    {
        exit(EXIT_FAILURE);
    }
    if(executor.add_stat_function("gen_proc_stat", &gen_proc_stat) != 0)
    {
        exit(EXIT_FAILURE);
    }
    if(executor.add_stat_function("thread_con_stat", &thread_con_stat) != 0)
    {
        exit(EXIT_FAILURE);
    }

    std::string empty;
    executor.add_protobuf_processor("default", boost::bind(&ProtobufZmqRpc::processDataServer, _1, _2, _3));
    executor.add_protobuf_processor("client_api", boost::bind(&ProtobufZmqRpc::processData, _1, _2, _3, "undefined"));

    return 0;
}
}

