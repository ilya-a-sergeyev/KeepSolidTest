﻿/*
 * xopenssl_aes_file.cpp
 *
 *  Created on: May 27, 2013
 *      Author: fireballdark
 */

#include <string.h>
#include <fstream>
#include "xopenssl_aes_file.h"
#include <openssl/engine.h>
#include <openssl/evp.h>
#include "util/logging.h"
#include "xopenssl_defines.h"
#include "xopenssl_util.h"
#include "xopenssl_hash.h"
#include "BlockDataCrypto.h"
#include "xopenssl.h"
#include "KSFileSignature.h"



xopenssl_status aes_easy_encrypt_old            ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_encrypt_with_signature ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_encrypt_old            ( FILE* in_stream, const std::string& password, FILE* out_stream , std::string& result_hash, const bool * const pbCanContinue = 0 );

xopenssl_status aes_easy_decrypt_old            ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, const bool * const pbCanContinue = 0);
xopenssl_status aes_easy_decrypt_with_signature ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, const std::string& signature, const bool * const pbCanContinue = 0 );



#ifndef DISABLE_XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT
xopenssl_status aes_easy_encrypt_old(std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash , const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (!in_stream.good() || !out_stream.good())
    {
        bool in = in_stream.fail();
        bool out = out_stream.fail();
        LOG_ERROR("OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad", in, out);
        return XOPENSSL_BAD_STREAM;
    }

    random_seed();

    xopenssl_status status = XOPENSSL_UNKNOWN;

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    //MD5 original file structures and init
    EVP_MD_CTX mdctx_original;
    EVP_DigestInit(&mdctx_original, EVP_md5());

    //MD5 encrypted file structures and init
    EVP_MD_CTX mdctx_encrypted;
    EVP_DigestInit(&mdctx_encrypted, EVP_md5());

    do
    {
        //get file size and return to beginning
        in_stream.seekg(0, std::ios::end);
        uint64_t file_length = in_stream.tellg();
        in_stream.seekg(0, std::ios::beg);

        char iv_char[AES256_IV_SIZE];
        RAND_bytes((unsigned char*) iv_char, (int)sizeof(iv_char));

        std::string key = sha256_raw(password);
        char buffer_in[IO_BLOCK_SIZE] = {0};
        char buffer_out[(IO_BLOCK_SIZE/AES256_BLOCK_SIZE+2)*AES256_BLOCK_SIZE];
        int curr_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;
        int result = 0;
        int digest_res_encrypted = 0;
        int digest_res_original = 0;

        EVP_EncryptInit( &ectx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv_char );

        unsigned char md_value_original[EVP_MAX_MD_SIZE] = {0};
        unsigned char md_value_encrypted[EVP_MAX_MD_SIZE] = {0};
        unsigned int md_len_original = 0;
        unsigned int md_len_encrypted = 0;

        while (!in_stream.eof())
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            in_stream.read(buffer_in, sizeof(buffer_in));
            total_read += in_stream.gcount() * sizeof(char);
            //encrypt block
            result = EVP_EncryptUpdate(&ectx, (unsigned char*) buffer_out, &curr_len, (const unsigned char*) buffer_in, (int)(in_stream.gcount() * sizeof(char)));
            //hash original block
            digest_res_original  = EVP_DigestUpdate(&mdctx_original, (const unsigned char*) buffer_in, (size_t)in_stream.gcount() * sizeof(char));
            //hash encrypted block
            digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, (const unsigned char*) buffer_out, curr_len);
            out_stream.write(buffer_out, curr_len);
            total_wrote += curr_len;

            if ((in_stream.fail() && !in_stream.eof()) || out_stream.fail())
            {
                bool in = in_stream.fail();
                bool out = out_stream.fail();
                LOG_ERROR( "OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad while encoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
            if (!result || !digest_res_original || !digest_res_encrypted)
            {
                LOG_ERROR( "OpenSSL AES encrypt: problem in crypto, hash_original, hash_encrypted: [%i:%i:%i]",result,digest_res_original,digest_res_encrypted);
                status = XOPENSSL_CRYPTO_ERR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        //encrypt final block and get its hash
        result = EVP_EncryptFinal(&ectx, (unsigned char*) buffer_out, &curr_len);
        digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, (const unsigned char*) buffer_out, curr_len);
        out_stream.write(buffer_out, curr_len);
        total_wrote += curr_len;

        //write IV
        digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, (const unsigned char*) iv_char, sizeof(iv_char));
        out_stream.write(iv_char, sizeof(iv_char));
        if (out_stream.fail())
        {
            LOG_ERROR("OpenSSL AES encrypt: failed writing IV to stream");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        //get and write MD5 hash
        digest_res_original = EVP_DigestFinal_ex(&mdctx_original, md_value_original, &md_len_original);
        digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, md_value_original, md_len_original);
        out_stream.write((const char*)md_value_original, md_len_original);

        if (out_stream.fail())
        {
            LOG_ERROR("OpenSSL: failed writing MD5 to stream");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        //Calculate final MD5 hash of encrypted file
        digest_res_encrypted = EVP_DigestFinal_ex(&mdctx_encrypted, md_value_encrypted, &md_len_encrypted);
        result_hash = digest_to_hex_string(md_value_encrypted, md_len_encrypted);

        if (!result || !digest_res_original || !digest_res_encrypted)
        {
            LOG_ERROR("OpenSSL AES encrypt: Problem finalizing encryption, calculating original or encrypted hash [%i:%i:%i]",  result, digest_res_original, digest_res_encrypted);
            status = XOPENSSL_CRYPTO_ERR;
            break;
        }

        out_stream.flush();

        if (total_wrote < total_read || total_read != file_length)
        {
            LOG_ERROR("OpenSSL AES encrypt: encrypted data size is less than input");
            status = XOPENSSL_SIZE_MISMATCH;
            break;
        }

        status = XOPENSSL_OK;

    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file encryption problem");
    }

    EVP_MD_CTX_cleanup(&mdctx_original);
    EVP_MD_CTX_cleanup(&mdctx_encrypted);

    EVP_CIPHER_CTX_cleanup(&ectx);

    return status;
}

xopenssl_status aes_easy_encrypt_old(FILE* in_stream, const std::string& password, FILE* out_stream , std::string& result_hash, const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (in_stream == NULL || out_stream == NULL)
    {
        LOG_ERROR("OpenSSL AES encrypt: input [%lli] or output [%lli] file is NULL", (int64_t)in_stream, (int64_t)out_stream);
        return XOPENSSL_BAD_STREAM;
    }

    random_seed();

    xopenssl_status status = XOPENSSL_UNKNOWN;

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    //MD5 original file structures and init
    EVP_MD_CTX mdctx_original;
    EVP_DigestInit(&mdctx_original, EVP_md5());

    //MD5 encrypted file structures and init
    EVP_MD_CTX mdctx_encrypted;
    EVP_DigestInit(&mdctx_encrypted, EVP_md5());

    do
    {
        if (ferror(in_stream) || ferror(out_stream))
        {
            int in = ferror(in_stream);
            int out = ferror(out_stream);
            LOG_ERROR("OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad", in, out);
            status = XOPENSSL_BAD_STREAM;
            break;
        }

        FSEEK64(in_stream, 0, SEEK_END);
        int64_t file_length = FTELL64(in_stream);
        FSEEK64(in_stream, 0, SEEK_SET);

        char iv_char[AES256_IV_SIZE];
        RAND_bytes((unsigned char*) iv_char, (int)sizeof(iv_char));

        std::string key = sha256_raw(password);
        char buffer_in[IO_BLOCK_SIZE] = {0};
        char buffer_out[(IO_BLOCK_SIZE/AES256_BLOCK_SIZE+2)*AES256_BLOCK_SIZE];
        int curr_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;
        int result = 0;
        int digest_res_encrypted = 0;
        int digest_res_original = 0;

        EVP_EncryptInit( &ectx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv_char );

        unsigned char md_value_original[EVP_MAX_MD_SIZE] = {0};
        unsigned char md_value_encrypted[EVP_MAX_MD_SIZE] = {0};
        unsigned int md_len_original = 0;
        unsigned int md_len_encrypted = 0;

        while (!feof(in_stream))
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            size_t cur_read = fread(buffer_in, sizeof(char), sizeof(buffer_in), in_stream);
            total_read += cur_read * sizeof(char);
            //encrypt block
            result = EVP_EncryptUpdate(&ectx, (unsigned char*) buffer_out, &curr_len, (const unsigned char*) buffer_in, (int)(cur_read * sizeof(char)));
            //hash original block
            digest_res_original = EVP_DigestUpdate(&mdctx_original, (const unsigned char*) buffer_in, (size_t)cur_read * sizeof(char));
            //hash encrypted block
            digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, (const unsigned char*) buffer_out, curr_len);
            size_t cur_wrote = fwrite(buffer_out, sizeof(char), curr_len, out_stream);
            if (cur_wrote!=curr_len)
            {
                LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%i] bytes", cur_wrote, curr_len);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
            total_wrote += curr_len;

            if (ferror(in_stream) || ferror(out_stream))
            {
                int in = ferror(in_stream);
                int out = ferror(out_stream);
                LOG_ERROR( "OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad while encoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }

            if (!result || !digest_res_original || !digest_res_encrypted)
            {
                LOG_ERROR( "OpenSSL AES encrypt: problem in crypto, hash_original, hash_encrypted: [%i:%i:%i]",result,digest_res_original,digest_res_encrypted);
                status = XOPENSSL_CRYPTO_ERR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        //encrypt final block and get its hash
        result = EVP_EncryptFinal(&ectx, (unsigned char*) buffer_out, &curr_len);
        digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, (const unsigned char*) buffer_out, curr_len);
        size_t cur_wrote = 0;
        cur_wrote = fwrite(buffer_out, sizeof(char), curr_len, out_stream);
        if (cur_wrote!=curr_len)
        {
            LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%i] bytes", cur_wrote, curr_len);
            status = XOPENSSL_STREAM_ERROR;
            break;
        }
        total_wrote += curr_len;

        //write IV
        digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, (const unsigned char*) iv_char, sizeof(iv_char));
        cur_wrote = fwrite(iv_char, sizeof(char), sizeof(iv_char), out_stream);
        if (cur_wrote!=sizeof(iv_char))
        {
            LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%i] bytes for IV", cur_wrote, curr_len);
            status = XOPENSSL_STREAM_ERROR;
            break;
        }
        if (ferror(out_stream))
        {
            LOG_ERROR("OpenSSL AES encrypt: failed writing IV to stream");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        //get and write MD5 hash
        digest_res_original = EVP_DigestFinal_ex(&mdctx_original, md_value_original, &md_len_original);
        digest_res_encrypted = EVP_DigestUpdate(&mdctx_encrypted, md_value_original, md_len_original);
        cur_wrote = fwrite(md_value_original, sizeof(char), md_len_original, out_stream);
        if (cur_wrote!=md_len_original)
        {
            LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%i] bytes", cur_wrote, md_len_original);
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        if (ferror(out_stream))
        {
            LOG_ERROR("OpenSSL: failed writing MD5 to stream");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        //Calculate final MD5 hash of encrypted file
        digest_res_encrypted = EVP_DigestFinal_ex(&mdctx_encrypted, md_value_encrypted, &md_len_encrypted);
        result_hash = digest_to_hex_string(md_value_encrypted, md_len_encrypted);

        if (!result || !digest_res_original || !digest_res_encrypted)
        {
            LOG_ERROR("OpenSSL AES encrypt: Problem finalizing encryption, calculating original or encrypted hash [%i:%i:%i]",  result, digest_res_original, digest_res_encrypted);
            status = XOPENSSL_CRYPTO_ERR;
            break;
        }

        fflush(out_stream);

        if (total_wrote < total_read || total_read != file_length)
        {
            LOG_ERROR("OpenSSL AES encrypt: encrypted data size is less than input");
            status = XOPENSSL_SIZE_MISMATCH;
            break;
        }

        status = XOPENSSL_OK;

    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file encryption problem");
    }

    EVP_MD_CTX_cleanup(&mdctx_original);
    EVP_MD_CTX_cleanup(&mdctx_encrypted);

    EVP_CIPHER_CTX_cleanup(&ectx);

    return status;
}
#endif

xopenssl_status aes_easy_encrypt_with_signature(std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash , const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (!in_stream.good() || !out_stream.good())
    {
        bool in = in_stream.fail();
        bool out = out_stream.fail();
        LOG_ERROR("OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad", in, out);
        return XOPENSSL_BAD_STREAM;
    }

    random_seed();

    bool need_hash = true;
    if ( result_hash.compare("NOHASH") == 0 )
    {
        need_hash = false;
    }

    KSD::BlockDataEncrypt data_encryptor(need_hash);

    xopenssl_status status = XOPENSSL_UNKNOWN;

    do
    {
        //get file size and return to beginning
        in_stream.seekg(0, std::ios::end);
        uint64_t file_length = in_stream.tellg();
        in_stream.seekg(0, std::ios::beg);


        unsigned char buffer_in[IO_BLOCK_SIZE] = {0};
        unsigned char buffer_out[(IO_BLOCK_SIZE/AES256_BLOCK_SIZE+2)*AES256_BLOCK_SIZE];
        int curr_out_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;

        status = data_encryptor.init(password);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        //Main file reading and encrypting cycle
        while (!in_stream.eof())
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            curr_out_len = sizeof(buffer_out);
            in_stream.read((char*)buffer_in, sizeof(buffer_in));
            size_t curr_read = in_stream.gcount() * sizeof(char);
            total_read += curr_read;

            status = data_encryptor.update(buffer_in, curr_read, buffer_out, curr_out_len);
            if (status != XOPENSSL_OK)
            {
                break;
            }

            out_stream.write((const char*)buffer_out, curr_out_len);
            total_wrote += curr_out_len;

            if ((in_stream.fail() && !in_stream.eof()) || out_stream.fail())
            {
                bool in = in_stream.fail();
                bool out = out_stream.fail();
                LOG_ERROR( "OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad while encoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        //Get last encrypted data and write it to file
        curr_out_len = sizeof(buffer_out);
        status = data_encryptor.finalize(buffer_out, curr_out_len);
        if (status != XOPENSSL_OK)
        {
            break;
        }
        out_stream.write((const char*)buffer_out, curr_out_len);
        total_wrote += curr_out_len;

        //Get file signature and write it to file
        std::string signature;
        status = data_encryptor.signature(signature, result_hash);
        if (status != XOPENSSL_OK)
        {
            break;
        }
        out_stream.write(signature.c_str(), signature.size());
        total_wrote += signature.size();
        if (out_stream.fail())
        {
            LOG_ERROR("OpenSSL AES encrypt: failed writing signature to stream");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        //Last sanity check before OK status
        out_stream.flush();
        if (total_wrote < total_read || total_read != file_length)
        {
            LOG_ERROR("OpenSSL AES encrypt: encrypted data size is less than input [%llu:%llu:%llu]", total_wrote, total_read, file_length);
            status = XOPENSSL_SIZE_MISMATCH;
            break;
        }

        //PROFIT!!!
        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file encryption problem");
    }

    return status;
}

xopenssl_status aes_easy_encrypt_with_signature(FILE* in_stream, const std::string& password, FILE* out_stream , std::string& result_hash, const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (in_stream == NULL || out_stream == NULL)
    {
        LOG_ERROR("OpenSSL AES encrypt: input [%lli] or output [%lli] file is NULL", (int64_t)in_stream, (int64_t)out_stream);
        return XOPENSSL_BAD_STREAM;
    }

    random_seed();

    bool need_hash = true;
    if ( result_hash.compare("NOHASH") == 0 )
    {
        need_hash = false;
    }

    KSD::BlockDataEncrypt data_encryptor(need_hash);

    xopenssl_status status = XOPENSSL_UNKNOWN;

    do
    {
        if (ferror(in_stream) || ferror(out_stream))
        {
            int in = ferror(in_stream);
            int out = ferror(out_stream);
            LOG_ERROR("OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad", in, out);
            status = XOPENSSL_BAD_STREAM;
            break;
        }

        FSEEK64(in_stream, 0, SEEK_END);
        int64_t file_length = FTELL64(in_stream);
        FSEEK64(in_stream, 0, SEEK_SET);

        unsigned char buffer_in[IO_BLOCK_SIZE] = {0};
        unsigned char buffer_out[(IO_BLOCK_SIZE/AES256_BLOCK_SIZE+2)*AES256_BLOCK_SIZE];
        int curr_out_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;

        status = data_encryptor.init(password);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        //Main file reading and encrypting cycle
        while (!feof(in_stream))
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }
            curr_out_len = sizeof(buffer_out);
            size_t cur_read = fread(buffer_in, sizeof(char), sizeof(buffer_in), in_stream);
            total_read += cur_read * sizeof(char);

            status = data_encryptor.update(buffer_in, cur_read, buffer_out, curr_out_len);
            if (status != XOPENSSL_OK)
            {
                break;
            }

            size_t cur_wrote = fwrite(buffer_out, sizeof(char), curr_out_len, out_stream);
            if (cur_wrote!=curr_out_len)
            {
                LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%i] bytes", cur_wrote, curr_out_len);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
            total_wrote += curr_out_len;

            if (ferror(in_stream) || ferror(out_stream))
            {
                int in = ferror(in_stream);
                int out = ferror(out_stream);
                LOG_ERROR( "OpenSSL AES encrypt: Input [%i] or output [%i] stream are bad while encoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        //Get last encrypted data and write it to file
        curr_out_len = sizeof(buffer_out);
        status = data_encryptor.finalize(buffer_out, curr_out_len);
        if (status != XOPENSSL_OK)
        {
            break;
        }
        size_t cur_wrote = 0;
        cur_wrote = fwrite(buffer_out, sizeof(char), curr_out_len, out_stream);
        if (cur_wrote!=curr_out_len)
        {
            LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%i] bytes", cur_wrote, curr_out_len);
            status = XOPENSSL_STREAM_ERROR;
            break;
        }
        total_wrote += curr_out_len;

        //Get file signature and write it to file
        std::string signature;
        status = data_encryptor.signature(signature, result_hash);
        if (status != XOPENSSL_OK)
        {
            break;
        }
        cur_wrote = fwrite(signature.c_str(), sizeof(char), signature.size(), out_stream);
        if (cur_wrote!=signature.size())
        {
            LOG_ERROR("OpenSSL AES encrypt: wrote [%lu] instead of [%lu] bytes for signature", cur_wrote, signature.size());
            status = XOPENSSL_STREAM_ERROR;
            break;
        }
        if (ferror(out_stream))
        {
            LOG_ERROR("OpenSSL AES encrypt: failed writing signature to stream");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        fflush(out_stream);
        if (total_wrote < total_read || total_read != file_length)
        {
            LOG_ERROR("OpenSSL AES encrypt: encrypted data size is less than input [%llu:%llu:%llu]", total_wrote, total_read, file_length);
            status = XOPENSSL_SIZE_MISMATCH;
            break;
        }

        status = XOPENSSL_OK;

    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file encryption problem");
    }

    return status;
}

#ifndef DISABLE_XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT
xopenssl_status aes_easy_decrypt_old(std::istream& in_stream, const std::string& password, std::ostream& out_stream, const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (!in_stream.good() || !out_stream.good())
    {
        bool in = in_stream.fail();
        bool out = out_stream.fail();
        LOG_ERROR("OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad", in, out);
        return XOPENSSL_BAD_STREAM;
    }

    xopenssl_status status = XOPENSSL_UNKNOWN;

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    //MD5 structures and init
    EVP_MD_CTX mdctx;
    EVP_DigestInit(&mdctx, EVP_md5());

    do
    {
        int offset = MD5_DIGEST_SIZE + AES256_IV_SIZE;
        in_stream.seekg(-offset, std::ios::end);

        int64_t file_length = in_stream.tellg();

        char iv_char[AES256_IV_SIZE];
        in_stream.read(iv_char, sizeof(iv_char));

        if (in_stream.fail() || in_stream.gcount() != sizeof(iv_char))
        {
            LOG_ERROR("OpenSSL AES decrypt: Input stream is bad after reading IV");
            status = XOPENSSL_METADATA_ERROR;
            break;
        }

        char ref_md5[MD5_DIGEST_SIZE];
        in_stream.read(ref_md5, sizeof(ref_md5));

        if (in_stream.fail() || in_stream.gcount() != sizeof(ref_md5))
        {
            LOG_ERROR("OpenSSL AES decrypt: Input stream is bad after reading MD5");
            status = XOPENSSL_METADATA_ERROR;
            break;
        }

        in_stream.seekg(0, std::ios::beg);

        std::string key = sha256_raw(password);
        char buffer_in[IO_BLOCK_SIZE];
        char buffer_out[(IO_BLOCK_SIZE / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE];
        int curr_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;
        int result = 0;

        char md_value[EVP_MAX_MD_SIZE];
        unsigned int md_len;

        EVP_DecryptInit(&ectx, EVP_aes_256_cbc(), (const unsigned char*) key.c_str(), (const unsigned char*) iv_char);

        while (!in_stream.eof() && file_length > 0)
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            file_length -= sizeof(buffer_in);
            if (file_length > 0)
            {
                in_stream.read(buffer_in, sizeof(buffer_in));
            }
            else
            {
                in_stream.read(buffer_in, sizeof(buffer_in) + file_length);
            }
            total_read += in_stream.gcount() * sizeof(char);
            //decrypt block
            result = EVP_DecryptUpdate(&ectx, (unsigned char*) buffer_out, &curr_len, (const unsigned char*) buffer_in, (int)(in_stream.gcount() * sizeof(char)));
            //hash block
            int digest_res = EVP_DigestUpdate(&mdctx, (const unsigned char*) buffer_out, curr_len);
            out_stream.write(buffer_out, curr_len);
            total_wrote += curr_len;

            if ((in_stream.fail() && !in_stream.eof()) || out_stream.fail() || !result || !digest_res)
            {
                bool in = in_stream.fail();
                bool out = out_stream.fail();
                LOG_ERROR( "OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad while decoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        result = EVP_DecryptFinal(&ectx, (unsigned char*) buffer_out, &curr_len);
        int digest_res = EVP_DigestUpdate(&mdctx, (const unsigned char*) buffer_out, curr_len);
        out_stream.write(buffer_out, curr_len);
        total_wrote += curr_len;

        if (out_stream.fail())
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem while decrypting file");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        if (!digest_res || !result)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem decrypting or calculating hash");
            status = XOPENSSL_CRYPTO_ERR;
            break;
        }

        out_stream.flush();

        //get and write MD5 hash
        digest_res = EVP_DigestFinal_ex(&mdctx, (unsigned char*) md_value, &md_len);
        if (!digest_res)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem calculating hash");
            status = XOPENSSL_CRYPTO_ERR;
            break;
        }

        if (strncmp(md_value, ref_md5, md_len))
        {
            LOG_ERROR( "OpenSSL AES decrypt: Hash of original and decrypted files differ! [%s] : [%s]\n", digest_to_hex_string((const unsigned char*)ref_md5,md_len).c_str(), digest_to_hex_string((const unsigned char*)md_value,md_len).c_str());
            status = XOPENSSL_HASH_CHECK_ERROR;
            break;
        }

        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file decryption problem");
    }

    EVP_MD_CTX_cleanup(&mdctx);

    EVP_CIPHER_CTX_cleanup(&ectx);

    return status;
}
#endif

xopenssl_status aes_easy_decrypt_with_signature(std::istream& in_stream, const std::string& password, std::ostream& out_stream, const std::string& signature, const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (!in_stream.good() || !out_stream.good())
    {
        bool in = in_stream.fail();
        bool out = out_stream.fail();
        LOG_ERROR("OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad", in, out);
        return XOPENSSL_BAD_STREAM;
    }

    xopenssl_status status = XOPENSSL_UNKNOWN;

    KSD::BlockDataDecrypt data_decryptor;

    do
    {
        in_stream.seekg(0, std::ios::beg);

        char buffer_in[IO_BLOCK_SIZE];
        char buffer_out[(IO_BLOCK_SIZE / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE];
        int curr_len_out = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;

        status = data_decryptor.init(password, signature);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        int64_t file_length = data_decryptor.get_signature().get_encrypted_raw_size();
        if (file_length<0)
        {
            LOG_ERROR("OpenSSL AES decrypt: file size is less than zero");
            status = XOPENSSL_BAD_STREAM;
            break;
        }

        while (!in_stream.eof() && file_length > 0)
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            file_length -= sizeof(buffer_in);
            if (file_length > 0)
            {
                in_stream.read(buffer_in, sizeof(buffer_in));
            }
            else
            {
                in_stream.read(buffer_in, sizeof(buffer_in) + file_length);
            }
            size_t cur_read = in_stream.gcount() * sizeof(char);
            total_read += cur_read;

            curr_len_out = sizeof(buffer_out);
            status = data_decryptor.update((const unsigned char*)buffer_in, cur_read, (unsigned char*)buffer_out, curr_len_out);
            if (status != XOPENSSL_OK)
            {
                break;
            }

            out_stream.write(buffer_out, curr_len_out);
            total_wrote += curr_len_out;

            if ((in_stream.fail() && !in_stream.eof()) || out_stream.fail() || status!= XOPENSSL_OK )
            {
                bool in = in_stream.fail();
                bool out = out_stream.fail();
                LOG_ERROR( "OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad while decoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        status = data_decryptor.finalize((unsigned char*)buffer_out, curr_len_out);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        out_stream.write(buffer_out, curr_len_out);
        total_wrote += curr_len_out;

        if (out_stream.fail())
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem while decrypting file");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        out_stream.flush();

        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file decryption problem");
    }

    return status;
}

#ifndef DISABLE_XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT
xopenssl_status aes_easy_decrypt_old(FILE* in_stream, const std::string& password, FILE* out_stream, const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (in_stream == NULL || out_stream == NULL)
    {
        LOG_ERROR("OpenSSL AES decrypt: input [%lli] or output [%lli] file is NULL", (int64_t)in_stream, (int64_t)out_stream);
        return XOPENSSL_BAD_STREAM;
    }

    xopenssl_status status = XOPENSSL_UNKNOWN;

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    //MD5 structures and init
    EVP_MD_CTX mdctx;
    EVP_DigestInit(&mdctx, EVP_md5());

    do
    {
        if (ferror(in_stream) || ferror(out_stream))
        {
            int in = ferror(in_stream);
            int out = ferror(out_stream);
            LOG_ERROR("OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad", in, out);
            status =  XOPENSSL_BAD_STREAM;
            break;
        }

        int offset = MD5_DIGEST_SIZE + AES256_IV_SIZE;
        FSEEK64(in_stream, -offset, SEEK_END);

        int64_t file_length = FTELL64(in_stream);

        char iv_char[AES256_IV_SIZE];
        size_t iv_char_read = fread(iv_char,sizeof(char),sizeof(iv_char),in_stream);

        if (ferror(in_stream) || iv_char_read!=sizeof(iv_char))
        {
            LOG_ERROR("OpenSSL AES decrypt: Input stream is bad after reading IV");
            status = XOPENSSL_METADATA_ERROR;
            break;
        }

        char ref_md5[MD5_DIGEST_SIZE];
        size_t ref_md5_read = fread(ref_md5,sizeof(char),sizeof(ref_md5),in_stream);

        if (ferror(in_stream) || ref_md5_read!=sizeof(ref_md5))
        {
            LOG_ERROR("OpenSSL AES decrypt: Input stream is bad after reading MD5");
            status = XOPENSSL_METADATA_ERROR;
            break;
        }

        FSEEK64(in_stream, 0, SEEK_SET);

        std::string key = sha256_raw(password);
        char buffer_in[IO_BLOCK_SIZE];
        char buffer_out[(IO_BLOCK_SIZE / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE];
        int curr_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;
        int result = 0;

        char md_value[EVP_MAX_MD_SIZE];
        unsigned int md_len;

        EVP_DecryptInit( &ectx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv_char );

        while (!feof(in_stream) && file_length > 0)
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            file_length -= sizeof(buffer_in);
            size_t cur_read = 0;
            if (file_length > 0)
            {
                cur_read = fread(buffer_in, sizeof(char), sizeof(buffer_in), in_stream);
            }
            else
            {
                cur_read = fread(buffer_in, sizeof(char), sizeof(buffer_in) + file_length, in_stream);
            }
            total_read += cur_read * sizeof(char);
            //decrypt block
            result = EVP_DecryptUpdate(&ectx, (unsigned char*) buffer_out, &curr_len, (const unsigned char*) buffer_in, (int)(cur_read * sizeof(char)));
            //hash block
            int digest_res = EVP_DigestUpdate(&mdctx, (const unsigned char*) buffer_out, curr_len);
            total_wrote += fwrite(buffer_out, sizeof(char), curr_len, out_stream);

            if (ferror(in_stream) || ferror(out_stream) || !result || !digest_res)
            {
                int in = ferror(in_stream);
                int out = ferror(out_stream);
                LOG_ERROR( "OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad while decoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }

        if (status != XOPENSSL_OK)
        {
            break;
        }

        result = EVP_DecryptFinal(&ectx, (unsigned char*) buffer_out, &curr_len);
        int digest_res = EVP_DigestUpdate(&mdctx, (const unsigned char*) buffer_out, curr_len);
        total_wrote += fwrite(buffer_out, sizeof(char), curr_len, out_stream);

        if (ferror(out_stream) || feof(out_stream))
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem while decrypting file");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        if (!digest_res || !result)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem decrypting or calculating hash");
            status = XOPENSSL_CRYPTO_ERR;
            break;
        }

        fflush(out_stream);

        //get and write MD5 hash
        digest_res = EVP_DigestFinal_ex(&mdctx, (unsigned char*) md_value, &md_len);

        if (!digest_res)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem calculating hash");
            status = XOPENSSL_CRYPTO_ERR;
            break;
        }

        if (strncmp(md_value, ref_md5, md_len))
        {
            LOG_ERROR( "OpenSSL AES decrypt: Hash of original and decrypted files differ! [%s] : [%s]\n", digest_to_hex_string((const unsigned char*)ref_md5,md_len).c_str(), digest_to_hex_string((const unsigned char*)md_value,md_len).c_str());
            status = XOPENSSL_HASH_CHECK_ERROR;
            break;
        }

        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK  && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file decryption problem");
    }

    EVP_MD_CTX_cleanup(&mdctx);

    EVP_CIPHER_CTX_cleanup(&ectx);

    return status;
}
#endif

xopenssl_status aes_easy_decrypt_with_signature(FILE* in_stream, const std::string& password, FILE* out_stream, const std::string& signature, const bool * const pbCanContinue)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (in_stream == NULL || out_stream == NULL)
    {
        LOG_ERROR("OpenSSL AES decrypt: input [%lli] or output [%lli] file is NULL", (int64_t)in_stream, (int64_t)out_stream);
        return XOPENSSL_BAD_STREAM;
    }

    xopenssl_status status = XOPENSSL_UNKNOWN;

    KSD::BlockDataDecrypt data_decryptor;

    do
    {
        if (ferror(in_stream) || ferror(out_stream))
        {
            int in = ferror(in_stream);
            int out = ferror(out_stream);
            LOG_ERROR("OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad", in, out);
            status =  XOPENSSL_BAD_STREAM;
            break;
        }

        FSEEK64(in_stream, 0, SEEK_SET);

        char buffer_in[IO_BLOCK_SIZE];
        char buffer_out[(IO_BLOCK_SIZE / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE];
        int curr_len_out = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;

        status = data_decryptor.init(password, signature);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        int64_t file_length = data_decryptor.get_signature().get_encrypted_raw_size();
        if (file_length<0)
        {
            LOG_ERROR("OpenSSL AES decrypt: file size is less than zero");
            status = XOPENSSL_BAD_STREAM;
            break;
        }

        while (!feof(in_stream) && file_length > 0)
        {
            if (NULL != pbCanContinue && false == *pbCanContinue)
            {
                LOG_INFORMATION("AES file encryption was interrupted by callback");
                status = XOPENSSL_INTERRUPTED;
                break;
            }

            file_length -= sizeof(buffer_in);
            size_t cur_read = 0;
            if (file_length > 0)
            {
                cur_read = fread(buffer_in, sizeof(char), sizeof(buffer_in), in_stream);
            }
            else
            {
                cur_read = fread(buffer_in, sizeof(char), sizeof(buffer_in) + file_length, in_stream);
            }
            total_read += cur_read * sizeof(char);

            curr_len_out = sizeof(buffer_out);
            status = data_decryptor.update((const unsigned char*)buffer_in, cur_read, (unsigned char*)buffer_out, curr_len_out);
            if (status != XOPENSSL_OK)
            {
                break;
            }

            total_wrote += fwrite(buffer_out, sizeof(char), curr_len_out, out_stream);

            if (ferror(in_stream) || ferror(out_stream))
            {
                int in = ferror(in_stream);
                int out = ferror(out_stream);
                LOG_ERROR( "OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad while decoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }
        if (status != XOPENSSL_OK)
        {
            break;
        }

        status = data_decryptor.finalize((unsigned char*)buffer_out, curr_len_out);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        total_wrote += fwrite(buffer_out, sizeof(char), curr_len_out, out_stream);

        if (ferror(out_stream) || feof(out_stream))
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem while decrypting file");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        fflush(out_stream);

        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK && status != XOPENSSL_INTERRUPTED)
    {
        SHOW_OPENSSL_ERRORS("AES file decryption problem");
    }

    return status;
}

xopenssl_status aes_easy_encrypt( std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash, bool write_signature/* = false*/, const bool * const pbCanContinue )
{
    if ( write_signature == true )
    {
        return aes_easy_encrypt_with_signature(in_stream, password, out_stream, result_hash, pbCanContinue);
    }
    else
    {
        return aes_easy_encrypt_old(in_stream, password, out_stream, result_hash, pbCanContinue);
    }
}

xopenssl_status aes_easy_encrypt( std::istream& in_stream, const std::string& password, std::ostream& out_stream, bool write_signature/* = false */, const bool * const pbCanContinue)
{
    std::string hash = "NOHASH";
    return aes_easy_encrypt(in_stream, password, out_stream, hash, write_signature, pbCanContinue);
}

xopenssl_status aes_easy_encrypt(FILE* in_stream, const std::string& password, FILE* out_stream , std::string& result_hash, bool write_signature/* = false*/ , const bool * const pbCanContinue)
{
    if ( write_signature == true )
    {
        return aes_easy_encrypt_with_signature(in_stream, password, out_stream, result_hash, pbCanContinue);
    }
    else
    {
        return aes_easy_encrypt_old(in_stream, password, out_stream, result_hash, pbCanContinue);
    }
}

xopenssl_status aes_easy_encrypt( FILE* in_stream, const std::string& password, FILE* out_stream, bool write_signature/* = false */, const bool * const pbCanContinue)
{
    std::string hash = "NOHASH";
    return aes_easy_encrypt(in_stream, password, out_stream, hash, write_signature, pbCanContinue);
}

xopenssl_status aes_easy_decrypt( std::istream& in_stream, const std::string& password, std::ostream& out_stream, const bool * const pbCanContinue )
{
    xopenssl_status result = XOPENSSL_UNKNOWN;

    std::string signature;
    result = KSD::KSFileSignature::read_file_signature(in_stream, signature);

    //When got good signature - it's new file, if not - try old algo

    if (result == XOPENSSL_OK && signature.size() > 0)
    {
        result = aes_easy_decrypt_with_signature(in_stream, password, out_stream, signature, pbCanContinue);
    }
#ifndef DISABLE_XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT
    else
    {
        result = aes_easy_decrypt_old(in_stream, password, out_stream, pbCanContinue);
    }
#endif

    return result;
}

xopenssl_status aes_easy_decrypt( FILE* in_stream, const std::string& password, FILE* out_stream, const bool * const pbCanContinue)
{
    xopenssl_status result = XOPENSSL_UNKNOWN;

    std::string signature;
    result = KSD::KSFileSignature::read_file_signature(in_stream, signature);

    //When got good signature - it's new file, if not - try old algo

    if (result == XOPENSSL_OK && signature.size() > 0)
    {
        result = aes_easy_decrypt_with_signature(in_stream, password, out_stream, signature, pbCanContinue);
    }
#ifndef DISABLE_XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT
    else
    {
        result = aes_easy_decrypt_old(in_stream, password, out_stream, pbCanContinue);
    }
#endif

    return result;
}

#ifdef FILE_LOADER

xopenssl_status aes_easy_decrypt_old(std::istream& in_stream, const std::string& password, FCGI_FILE* out_stream)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    xopenssl_status status = XOPENSSL_UNKNOWN;

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);

    //MD5 structures and init
    EVP_MD_CTX mdctx;
    EVP_DigestInit(&mdctx, EVP_md5());

    do
    {
        if (!in_stream.good() || FCGI_feof(out_stream) || FCGI_ferror(out_stream))
        {
            bool in = in_stream.fail();
            int out = FCGI_ferror(out_stream);
            LOG_ERROR("OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad", in, out);
            break;
        }

        int offset = MD5_DIGEST_SIZE + AES256_IV_SIZE;
        in_stream.seekg(-offset, std::ios::end);

        int64_t file_length = in_stream.tellg();

        char iv_char[AES256_IV_SIZE];
        in_stream.read(iv_char, sizeof(iv_char));

        if (in_stream.fail() || in_stream.gcount()!=sizeof(iv_char))
        {
            LOG_ERROR("OpenSSL AES decrypt: Input stream is bad after reading IV");
            break;
        }

        char ref_md5[MD5_DIGEST_SIZE];
        in_stream.read(ref_md5, sizeof(ref_md5));

        if (in_stream.fail() || in_stream.gcount()!=sizeof(ref_md5))
        {
            LOG_ERROR("OpenSSL AES decrypt: Input stream is bad after reading MD5");
            break;
        }

        in_stream.seekg(0, std::ios::beg);

        std::string key = sha256_raw(password);
        char buffer_in[IO_BLOCK_SIZE];
        char buffer_out[(IO_BLOCK_SIZE / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE];
        int curr_len = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;
        int result = 0;

        char md_value[EVP_MAX_MD_SIZE];
        unsigned int md_len;

        EVP_DecryptInit( &ectx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv_char );

        while (!in_stream.eof() && file_length > 0)
        {
            file_length -= sizeof(buffer_in);
            if (file_length > 0)
            {
                in_stream.read(buffer_in, sizeof(buffer_in));
            }
            else
            {
                in_stream.read(buffer_in, sizeof(buffer_in) + file_length);
            }
            total_read += in_stream.gcount() * sizeof(char);
            //decrypt block
            result = EVP_DecryptUpdate(&ectx, (unsigned char*) buffer_out, &curr_len, (const unsigned char*) buffer_in, in_stream.gcount() * sizeof(char));
            //hash block
            int digest_res = EVP_DigestUpdate(&mdctx, (const unsigned char*) buffer_out, curr_len);
            total_wrote += FCGI_fwrite(buffer_out, sizeof(char), curr_len, out_stream);

            if ((in_stream.fail() && !in_stream.eof()) || FCGI_ferror(out_stream) || FCGI_feof(out_stream) || !result || !digest_res)
            {
                bool in = in_stream.fail();
                bool out = FCGI_ferror(out_stream) || FCGI_feof(out_stream);
                LOG_ERROR( "OpenSSL: Input [%i] or output [%i] stream are bad while decoding", in, out);
                break;
            }
        }

        result = EVP_DecryptFinal(&ectx, (unsigned char*) buffer_out, &curr_len);
        int digest_res = EVP_DigestUpdate(&mdctx, (const unsigned char*) buffer_out, curr_len);
        total_wrote += FCGI_fwrite(buffer_out, sizeof(char), curr_len, out_stream);

        if (FCGI_ferror(out_stream) || FCGI_feof(out_stream) || !result)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem while decrypting file");
            break;
        }

        if (!digest_res)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem calculating hash");
        }

        FCGI_fflush(out_stream);

        //get and write MD5 hash
        digest_res = EVP_DigestFinal_ex(&mdctx, (unsigned char*) md_value, &md_len);
        //LOG_ERROR("OpenSSL: Hash of original and decrypted files are [%s] : [%s]\n",digest_to_hex_string((const unsigned char*)ref_md5,md_len).c_str(),digest_to_hex_string((const unsigned char*)md_value,md_len).c_str());
        if (!digest_res)
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem calculating hash");
        }

        if (strncmp(md_value, ref_md5, md_len))
        {
            LOG_ERROR( "OpenSSL AES decrypt: Hash of original and decrypted files differ! [%s] : [%s]\n", digest_to_hex_string((const unsigned char*)ref_md5,md_len).c_str(), digest_to_hex_string((const unsigned char*)md_value,md_len).c_str());
            break;
        }

        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK)
    {
        SHOW_OPENSSL_ERRORS("AES file decryption problem");
    }

    EVP_MD_CTX_cleanup(&mdctx);

    EVP_CIPHER_CTX_cleanup(&ectx);

    return status;
}

xopenssl_status aes_easy_decrypt_with_signature(std::istream& in_stream, const std::string& password, FCGI_FILE* out_stream, const std::string& signature)
{
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return XOPENSSL_BAD_ARGUMENTS;
    }

    if (!in_stream.good() || out_stream == NULL)
    {
        LOG_ERROR("OpenSSL AES decrypt: Input [%i] or output [%i] stream are bad", in_stream.fail(), out_stream);
        return XOPENSSL_BAD_STREAM;
    }

    xopenssl_status status = XOPENSSL_UNKNOWN;

    KSD::BlockDataDecrypt data_decryptor;

    do
    {
        if (FCGI_feof(out_stream) || FCGI_ferror(out_stream))
        {
            int out = FCGI_ferror(out_stream);
            LOG_ERROR("OpenSSL AES decrypt: Output [%i] stream is bad", out);
            status =  XOPENSSL_BAD_STREAM;
            break;
        }

        in_stream.seekg(0, std::ios::beg);

        char buffer_in[IO_BLOCK_SIZE];
        char buffer_out[(IO_BLOCK_SIZE / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE];
        int curr_len_out = 0;
        uint64_t total_read = 0;
        uint64_t total_wrote = 0;

        status = data_decryptor.init(password, signature);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        int64_t file_length = data_decryptor.get_signature().get_encrypted_raw_size();
        if (file_length<0)
        {
            LOG_ERROR("OpenSSL AES decrypt: file size is less than zero");
            status = XOPENSSL_BAD_STREAM;
            break;
        }

        while (!in_stream.eof() && file_length > 0)
        {
            file_length -= sizeof(buffer_in);
            if (file_length > 0)
            {
                in_stream.read(buffer_in, sizeof(buffer_in));
            }
            else
            {
                in_stream.read(buffer_in, sizeof(buffer_in) + file_length);
            }
            size_t cur_read = in_stream.gcount() * sizeof(char);
            total_read += cur_read;

            curr_len_out = sizeof(buffer_out);
            status = data_decryptor.update((const unsigned char*)buffer_in, cur_read, (unsigned char*)buffer_out, curr_len_out);
            if (status != XOPENSSL_OK)
            {
                break;
            }

            total_wrote += FCGI_fwrite(buffer_out, sizeof(char), curr_len_out, out_stream);

            if ((in_stream.fail() && !in_stream.eof()) || FCGI_ferror(out_stream) || FCGI_feof(out_stream))
            {
                bool in = in_stream.fail();
                bool out = FCGI_ferror(out_stream) || FCGI_feof(out_stream);
                LOG_ERROR( "OpenSSL: Input [%i] or output [%i] stream are bad while decoding", in, out);
                status = XOPENSSL_STREAM_ERROR;
                break;
            }
        }
        if (status != XOPENSSL_OK)
        {
            break;
        }

        status = data_decryptor.finalize((unsigned char*)buffer_out, curr_len_out);
        if (status != XOPENSSL_OK)
        {
            break;
        }

        total_wrote += FCGI_fwrite(buffer_out, sizeof(char), curr_len_out, out_stream);

        if (FCGI_ferror(out_stream) || FCGI_feof(out_stream))
        {
            LOG_ERROR("OpenSSL AES decrypt: Problem while decrypting file");
            status = XOPENSSL_STREAM_ERROR;
            break;
        }

        FCGI_fflush(out_stream);

        status = XOPENSSL_OK;
    }
    while (false);

    if (status != XOPENSSL_OK)
    {
        SHOW_OPENSSL_ERRORS("AES file decryption problem");
    }

    return status;
}

xopenssl_status aes_easy_decrypt( std::istream& in_stream, const std::string& password, FCGI_FILE* out_stream )
{
    xopenssl_status result = XOPENSSL_UNKNOWN;

    std::string signature;
    result = KSD::KSFileSignature::read_file_signature(in_stream, signature);

    //When got good signature - it's new file, if not - try old algo

    if (result == XOPENSSL_OK && signature.size() > 0)
    {
        result = aes_easy_decrypt_with_signature(in_stream, password, out_stream, signature);
    }
#ifndef DISABLE_XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT
    else
    {
        result = aes_easy_decrypt_old(in_stream, password, out_stream);
    }
#endif

    return result;
}
#endif
