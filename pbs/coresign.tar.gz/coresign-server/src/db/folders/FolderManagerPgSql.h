/*
 * FolderManagerPgSql.h
 *
 *  Created on: 28 квіт. 2011
 *      Author: fireball
 */

#ifndef FOLDERMANAGERPGSQL_H_
#define FOLDERMANAGERPGSQL_H_

#include "types/status_codes.h"
#include "types/file_folder_info.h"
#include "types/user_info.h"
#include "types/folder_encryption_type.h"

class WorkGroupManagerPgSql
{
public:
    static rpc_status_code     create_folder           (int64_t userId, const std::string& userEmail, const WorkGroupInfo& folderInfo, int64_t& folderId);
    static rpc_status_code     share_folder            (int64_t userId, int64_t folderId, int64_t recipientId, const std::string& recipientEmail);
    static rpc_status_code     remove_folder           (int64_t userId, int64_t folderId);
    static rpc_status_code     remove_folder_now       (int64_t userId, int64_t folderId);
    static rpc_status_code     undelete_folder         (int64_t userId, int64_t folderId);
    static rpc_status_code     rename_folder           (int64_t userId, int64_t folderId, const std::string& newFolderName);
    static rpc_status_code     get_folders_sum_size    (int64_t userId, int64_t& foldersSumSize);
    static rpc_status_code     list_folders            (int64_t userId, bool showDeleted, WorkGroupsInfoList& foldersInfo, int64_t& lastEventId);
    static rpc_status_code     list_all_folders        (int64_t userId, WorkGroupsInfoList& foldersInfo, int64_t& lastEventId);
    static rpc_status_code     list_folder_coworkers   (int64_t userId, int64_t folderId, UserLoginList& userEmails);
    static rpc_status_code     list_folder_coworkers_extra(int64_t userId, int64_t folderId, UserWorkGroupInfoList& userEmails);
    static rpc_status_code     list_all_coworkers_for_wgs(int64_t userId, bool showDeleted, UserWorkGroupInfoMultiMap& userEmails);
    static rpc_status_code     list_all_coworkers_for_wgs_all(int64_t userId, UserWorkGroupInfoMultiMap& userEmails);
    static rpc_status_code     list_all_coworkers      (int64_t userId, UserLoginList& userEmails);
    static rpc_status_code     list_all_coworkers      (int64_t userId, int64_t exceptFolderId, UserLoginList& userEmails);
    static rpc_status_code     list_all_coworkers_ex   (int64_t userId, UserWorkGroupInfoList& userEmails);
    static rpc_status_code     list_all_coworkers_ex   (int64_t userId, int64_t exceptFolderId, UserWorkGroupInfoList& userEmails);
    static rpc_status_code     list_all_coworkers_ids  (int64_t userId, UserIdList& userIds);
    static rpc_status_code     list_all_coworkers_ids  (int64_t userId, int64_t folderId, UserIdList& userIds);
    static rpc_status_code     list_invited_coworkers_ids  (int64_t userId, int64_t folderId, UserIdList& userIds);
    static rpc_status_code     get_folder_info         (int64_t userId, int64_t folderId, WorkGroupInfo& folderInfo);
    static rpc_status_code     set_access_rights       (int64_t userId, int64_t folderId, int64_t accessRights);
    static rpc_status_code     update_folder_size      (int64_t userId, int64_t folderId, int64_t removedSize, int64_t addedSize);
    static rpc_status_code     subscribe_folder        (int64_t userId, int64_t folderId, int64_t accessMode, const std::string& encryptionKey);
    static rpc_status_code     unsubscribe_folder      (int64_t userId, int64_t folderId);
    static rpc_status_code     block_folder            (int64_t userId, int64_t folderId, bool isBlocked);
    static rpc_status_code     check_block_folder      (int64_t userId, int64_t folderId, bool& isBlocked);
    static rpc_status_code     metadata_update         (int64_t user_id, int64_t workgroup_id, const std::string& metadataUpdate);
};

#endif /* FOLDERMANAGERPGSQL_H_ */
