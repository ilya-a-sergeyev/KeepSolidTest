/*
 * BlockFileCrypto.cpp
 *
 *  Created on: May 19, 2013
 *      Author: fireballdark
 */

#include "BlockDataCrypto.h"
#include "xopenssl_defines.h"
#include "xopenssl_util.h"
#include "xopenssl_hash.h"

#include "util/logging.h"


namespace KSD
{

BlockDataEncrypt::BlockDataEncrypt(bool need_result_hash):
        _total_read(0),
        _total_wrote(0),
        _need_result_hash(need_result_hash)
{
    EVP_CIPHER_CTX_init(&_cipher_ctx);
    EVP_DigestInit(&_md_ctx_original, EVP_md5());
    EVP_DigestInit(&_md_ctx_encrypted, EVP_md5());
}

BlockDataEncrypt::~BlockDataEncrypt()
{
    EVP_MD_CTX_cleanup(&_md_ctx_original);
    EVP_MD_CTX_cleanup(&_md_ctx_encrypted);
    EVP_CIPHER_CTX_cleanup(&_cipher_ctx);
}

xopenssl_status BlockDataEncrypt::init(const std::string& password)
{
    char iv_char[AES256_IV_SIZE];
    RAND_bytes((unsigned char*) iv_char, (int)sizeof(iv_char));

    std::string key             = sha256_raw(password);
    int cipher_result           = EVP_EncryptInit(&_cipher_ctx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv_char);

    _signature.set_initialization_vector(std::string(iv_char, sizeof(iv_char)));

    if (!cipher_result)
    {
        LOG_ERROR("OpenSSL AES encrypt: problem in crypto init: [%i]", cipher_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    return XOPENSSL_OK;
}

xopenssl_status BlockDataEncrypt::update(const unsigned char* buffer_in, int in_size, unsigned char* buffer_out, int& out_size)
{
    if ( in_size >= out_size )
    {
        LOG_ERROR("OpenSSL AES encrypt: input buffer can not be bigger than output one: [%i:%i]", in_size, out_size);
        return XOPENSSL_BAD_ARGUMENTS;
    }

    //encrypt block
    int cipher_result           = EVP_EncryptUpdate(&_cipher_ctx, buffer_out, &out_size, buffer_in, in_size);
    //hash original block
    int digest_original_result  = EVP_DigestUpdate(&_md_ctx_original, buffer_in, in_size);
    //hash encrypted block
    int digest_encrypted_result = _need_result_hash ? EVP_DigestUpdate(&_md_ctx_encrypted, buffer_out, out_size) : 1;

    _total_read     += in_size;
    _total_wrote    += out_size;

    if (!cipher_result || !digest_original_result || !digest_encrypted_result)
    {
        LOG_ERROR("OpenSSL AES encrypt: problem in crypto, hash_original, hash_encrypted: [%i:%i:%i]", cipher_result, digest_original_result, digest_encrypted_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    return XOPENSSL_OK;
}

xopenssl_status BlockDataEncrypt::finalize(unsigned char* buffer_out, int& out_size)
{
    unsigned char   md_value_original[EVP_MAX_MD_SIZE] = {0};
    unsigned int    md_len_original = 0;

    //encrypt final block and get its hash
    int cipher_result           = EVP_EncryptFinal(&_cipher_ctx, (unsigned char*) buffer_out, &out_size);
    int digest_encrypted_result = _need_result_hash ? EVP_DigestUpdate(&_md_ctx_encrypted, (const unsigned char*) buffer_out, out_size) : 1;

    _total_wrote    += out_size;
    _signature.set_encrypted_raw_size(_total_wrote);

    //get MD5 hash
    int digest_original_result  = EVP_DigestFinal_ex(&_md_ctx_original, md_value_original, &md_len_original);
    _signature.set_original_raw_hash(std::string((const char*)md_value_original, md_len_original));

    if (!cipher_result || !digest_original_result || !digest_encrypted_result)
    {
        LOG_ERROR("OpenSSL AES encrypt: Problem finalizing encryption, calculating original or encrypted hash [%i:%i:%i]", cipher_result, digest_original_result, digest_encrypted_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    return XOPENSSL_OK;
}

xopenssl_status BlockDataEncrypt::signature(std::string& signature, std::string& result_hash)
{
    unsigned char md_value_encrypted[EVP_MAX_MD_SIZE] = {0};
    unsigned int md_len_encrypted = 0;

    bool result = KSD::KSFileSignature::serialize_signature(_signature, signature);

    LOG_INFORMATION("OpenSSL AES encrypt: Signature size is %lu", signature.size());

    if (!result)
    {
        LOG_ERROR("OpenSSL AES encrypt: Problem serializing signature");
        return XOPENSSL_METADATA_ERROR;
    }

    //Calculate MD5 hash of signature
    int digest_encrypted_result = _need_result_hash ? EVP_DigestUpdate(&_md_ctx_encrypted, signature.c_str(), signature.size()) : 1;

    if (!digest_encrypted_result)
    {
        LOG_ERROR("OpenSSL AES encrypt: Problem updating encrypted hash [%i]", digest_encrypted_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    //Get final MD5 hash of encrypted file
    digest_encrypted_result     = _need_result_hash ? EVP_DigestFinal_ex(&_md_ctx_encrypted, md_value_encrypted, &md_len_encrypted) : 1;
    result_hash = digest_to_hex_string(md_value_encrypted, md_len_encrypted);

    if (!digest_encrypted_result)
    {
        LOG_ERROR("OpenSSL AES encrypt: Problem finalizing calculating encrypted hash [%i]", digest_encrypted_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    return XOPENSSL_OK;
}


BlockDataDecrypt::BlockDataDecrypt():
        _total_read(0),
        _total_wrote(0)
{
    EVP_CIPHER_CTX_init(&_cipher_ctx);
    EVP_DigestInit(&_md_ctx_original, EVP_md5());
}

BlockDataDecrypt::~BlockDataDecrypt()
{
    EVP_MD_CTX_cleanup(&_md_ctx_original);
    EVP_CIPHER_CTX_cleanup(&_cipher_ctx);
}

xopenssl_status BlockDataDecrypt::init(const std::string& password, const std::string& signature)
{
    bool result = KSD::KSFileSignature::parse_signature(signature, _signature);
    if(!result)
    {
        return XOPENSSL_METADATA_ERROR;
    }

    std::string key             = sha256_raw(password);
    int cipher_result           = EVP_DecryptInit(&_cipher_ctx, EVP_aes_256_cbc(), (const unsigned char*) key.c_str(), (const unsigned char*) _signature.get_initialization_vector().c_str());

    if (!cipher_result)
    {
        LOG_ERROR("OpenSSL AES decrypt: problem in crypto init: [%i]", cipher_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    return XOPENSSL_OK;
}

xopenssl_status BlockDataDecrypt::update(const unsigned char* buffer_in, int in_size, unsigned char* buffer_out, int& out_size)
{
    if ( in_size > out_size )
    {
        LOG_ERROR("OpenSSL AES decrypt: input buffer can not be bigger than output one: [%i:%i]", in_size, out_size);
        return XOPENSSL_BAD_ARGUMENTS;
    }

    //encrypt block
    int cipher_result           = EVP_DecryptUpdate(&_cipher_ctx, buffer_out, &out_size, buffer_in, in_size);
    //hash original block
    int digest_original_result  = EVP_DigestUpdate(&_md_ctx_original, buffer_out, out_size);

    _total_read     += in_size;
    _total_wrote    += out_size;

    if (!cipher_result || !digest_original_result)
    {
        LOG_ERROR("OpenSSL AES decrypt: problem in crypto, hash_original: [%i:%i]", cipher_result, digest_original_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    return XOPENSSL_OK;
}

xopenssl_status BlockDataDecrypt::finalize(unsigned char* buffer_out, int& out_size)
{
    unsigned char   md_value_original[EVP_MAX_MD_SIZE] = {0};
    unsigned int    md_len_original = 0;

    //encrypt final block and get its hash
    int cipher_result           = EVP_DecryptFinal(&_cipher_ctx, (unsigned char*) buffer_out, &out_size);
    int digest_original_result  = EVP_DigestUpdate(&_md_ctx_original, (const unsigned char*) buffer_out, out_size);

    _total_wrote    += out_size;

    //get MD5 hash
    digest_original_result  = EVP_DigestFinal_ex(&_md_ctx_original, md_value_original, &md_len_original);
    std::string calculated_hash((const char*)md_value_original, md_len_original);

    if (!cipher_result || !digest_original_result)
    {
        LOG_ERROR("OpenSSL AES decrypt: Problem finalizing encryption, calculating original [%i:%i]", cipher_result, digest_original_result);
        return XOPENSSL_CRYPTO_ERR;
    }

    if (calculated_hash.compare(_signature.get_original_raw_hash()) != 0)
    {
        LOG_ERROR( "OpenSSL AES decrypt: Hash of original and decrypted files differ! [%s] : [%s]\n", _signature.get_original_hash().c_str(), digest_to_hex_string(calculated_hash).c_str());
        return XOPENSSL_HASH_CHECK_ERROR;
    }

    return XOPENSSL_OK;
}

} /* namespace KSD */
