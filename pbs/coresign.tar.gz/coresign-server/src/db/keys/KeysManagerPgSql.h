/*
 * FolderInvitesPgSql.h
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#ifndef KEYSMANAGERSPGSQL_H_
#define KEYSMANAGERPGSQL_H_

#include "types/status_codes.h"
#include "types/invitation.h"
#include "types/user_info.h"

class KeysManagerPgSql
{
public:
    static rpc_status_code     create_key                      (int64_t userId, const std::string& keyId, const std::string& public_key, const std::string& private_key);
    static rpc_status_code     get_key                         (const std::string& keyId, std::string& public_key, std::string& private_key);
};

#endif /* KEYSMANAGERPGSQL_H_ */
