#include "UserManagerRiak.h"

#include <exception>
#include <cstdlib>
#include <map>
#include <string>

#include <jsoncpp/json/json.h>

#include <sutil/logging.h>
#include "util/getNotificationLiterals.h"
#include <db/RiakHelper.h>
#include "UserManagerHelper.h"


#define USERID_IDX "userid_idx_bin"
#define USERNAME_IDX "username_idx_bin"

struct Riak;

void convert_json_userinfo(Json::Value json_ui, UserInfo& ui)
{
    //Json::Value json_ui;
    ui.user_id = json_ui["user_id"].asInt();
    /*
    ui.login                = query_result["login"].as<std::string>();
    ui.email                = query_result["email"].as<std::string>();
    ui.first_name           = query_result["first_name"].as<std::string>();
    ui.last_name            = query_result["last_name"].as<std::string>();
    ui.public_key           = query_result["public_key"].as<std::string>();
    ui.private_key          = query_result["private_key"].as<std::string>();
    ui.salt_pk_password     = query_result["salt_pk_password"].as<std::string>();
    ui.user_pic             = query_result["user_pic"].as<std::string>();
    ui.secret_question      = query_result["secret_question"].as<std::string>();
    ui.is_dummy             = query_result["is_dummy"].as<bool>();
    ui.is_activated         = query_result["is_activated"].as<bool>();
    ui.license_accepted     = query_result["license_accepted"].as<bool>();
    ui.is_tutorialated      = query_result["is_tutorialated"].as<bool>();
    ui.creation_date        = query_result["registration_date"].as<int64_t>();
    ui.expiration_date      = query_result["expiration_date"].as<int64_t>();
    */
}

rpc_status_code UserManageRiak::createDummyUser(UserCredentials& uc)
{
    LOG_INFORMATION("Info: trying to create user %s", uc.login.c_str());

    rpc_status_code returnStatus = status_internal_error;

    Riak *riak_connection = riakHelper("coresign_cluster").get_write_connection();
    riak_connection->setContentType(Riak::contentJson);

    do {
        if (!riak_connection)
        {
            returnStatus = status_no_connect_to_server;
        }

        Riak::RiakIndextable indexTable;
        indexTable.insert(std::pair<std::string, std::string>(USERNAME_IDX, uc.login));

        //std::string valuesStr = convert_json_userinfo();
        std::string bucketType = "leveldb";
        std::string bucketName = "users";
        std::string key = std::to_string(uc.user_id);

        if (!riak_connection->setWithIndexes(bucketName, key , valuesStr, indexTable, bucketType))
        {
                std::cout << "Failure: Riak set (" << bucketName << ":" << acctsessionid << ") with indexes:\n";
                for (auto idx: indexTable)
                {
                    std::cout <<  idx.first << ": " << idx.second << "\n";
                }
                std::cout << "err: ", riak_connection->getError();
                std::cout << "\n";

                returnStatus = status_action_error;
                return returnStatus;

        }

    } while (false);


    return rpc_status_code;
}

