#!/bin/bash

RPC_LIST="CreateUser Login Logout EventsList FileDownload FileInfo FileUpload FileUploadApprove FolderCreate FolderDelete FolderRename FoldersList FolderInvite Mail MessageCreate TopicCreate TopicsList UserInfo"

grep "~Timer" $1 > $1.temp

for RPC in $RPC_LIST
do
    grep $RPC $1.temp | cut -d " " -f 6 | grep -E "^[[:digit:]]+\.[[:digit:]]+$" | sort -n | tr "\n" " " > $2/$RPC.txt
    //echo $RPC | tr "\n" " " >> $2/Overall.txt ; cat $2/$RPC.txt >> $2/Overall.txt ; echo -e "\n" >> $2/Overall.txt
done

//echo -e "\n" >> $2/Overall.txt
