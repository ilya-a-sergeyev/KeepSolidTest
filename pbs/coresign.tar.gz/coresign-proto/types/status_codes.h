/*
 * status_codes.h
 *
 *  Created on: 3 april 2011
 *      Author: fireball
 */

#ifndef STATUS_CODES_H_
#define STATUS_CODES_H_
#include <string>

#ifdef _WIN32
    #ifdef RPC_EXPORTS
        #define RPC_API __declspec(dllexport)
    #else
        #define RPC_API __declspec(dllimport)
    #endif
#else
    #define RPC_API
#endif

enum rpc_status_code
{
    status_unknown              = 0,    //What's goin' on?
    //Informational 1xx
    //Successful 2xx
    status_success              = 200,  //OK
    //Redirection 3xx
    status_permanent_redirect   = 300,  //client should remember new redirected address
    status_temporary_redirect   = 301,  //client should use redirect URL just for this session
    //Client Error 4xx
    status_bad_request          = 400,  //some params are missing
    status_unauthorized         = 401,  //need to login again
    status_payment_required     = 402,  //function needs payment
    status_login_exists         = 403,  //can't register, login already exists
    status_login_failure        = 404,  //user not found or password is incorrect
    status_agreement_unaccepted = 405,  //user did not confirm license acceptance
    status_access_denied        = 406,  //action is prohibited for this user
    status_does_not_exist       = 407,  //requested object does not exist
    status_already_exist        = 408,  //cannot create object that already exists
    status_user_not_activated   = 409,  //user is not activated
    status_user_is_dummy        = 410,  //user needs to update their profile
    status_bad_syntax           = 411,  //bad parameters syntax
    status_invalid_utf8         = 412,  //got invalid UTF8 input string
    //Server Error 5xx
    status_internal_error       = 500,  //general error
    status_not_implemented      = 501,  //method does not work yet
    status_service_unavailable  = 502,  //service is stopping or reloading
    status_unsupported_client   = 503,  //client is too old to be supported

    //Rest Error 7xx
    status_no_connect_to_server = 700,  //Not connect to server
    status_task_syntax_error    = 701,  //Task syntax error
    status_task_error           = 702,  //Task error
    status_category_error       = 703,  //Category error
    status_action_error         = 704,  //Action error
    status_bad_parameters       = 705,  //Bad parameters
    status_bad_return_parameters= 706,  //Bad return parameters
    status_UDLoad_file_error    = 707,  //Could not download/upload file
    status_IO_file_error        = 708,  //Problem with file IO
    status_upload_file_terminate= 709,  //Upload file terminate
    status_file_parameters_error= 710,  //Error file parameters
    status_RSA_decrypt_error    = 720,  //RSA decrypt error


    //Rest/WEB Error 8xx
    status_JSON_error           = 800,  //JSON parse error

    //800-810 - WEB wrapper reserver

    //Local client internal error 8xx
    status_client_internal_error        = 900,
    status_cannot_create_local_item     = 901,
    status_curl_cannot_upload_file      = 902,
    status_curl_cannot_download_file    = 903,
    status_aes_easy_decrypt_error       = 904,
    status_aes_easy_encrypt_error       = 905,
    status_rename_local_item_error      = 906,
    status_cant_find_item_in_local_db   = 907,
    status_unable_delete_local_item     = 908,
    status_unable_to_open_file          = 909,  //when there is not associated application in OS
    status_canceled_by_user             = 910,
    status_canceled_as_unnecessary      = 911,
    status_broken_keys                  = 912,
    status_cant_generate_keys           = 913,
    status_cant_generate_credentials    = 914,
    status_unable_update_local_item     = 915,
    status_offline_event                = 916
    //900-999 - Client error reserver

    //1000 - REST not response

};

RPC_API rpc_status_code     status_code_from_int    (int code);

RPC_API std::string         status_code_to_string   (int status_code);

RPC_API std::string         status_code_enum_to_string   (rpc_status_code status_code);

struct rpc_status_code_struct
{
    rpc_status_code_struct():
        code(status_internal_error)
    {}

    rpc_status_code_struct(rpc_status_code code_ext):
        code(code_ext)
    {}

    bool operator ==(const rpc_status_code& code_ext)
    {
        return code_ext == code;
    }

    operator rpc_status_code() const
    {
        return code;
    }

    rpc_status_code_struct& operator =(const rpc_status_code& code_ext)
    {
        code = code_ext;
        return *this;
    }

    std::string code_to_string()
    {
        return status_code_enum_to_string(code);
    }

    rpc_status_code code;
    std::string     error_message;
};

#endif /* STATUS_CODES_H_ */
