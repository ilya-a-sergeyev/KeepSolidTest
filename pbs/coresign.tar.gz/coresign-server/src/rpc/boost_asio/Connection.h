/*
 * Connection.h
 *
 *  Created on: 23 янв. 2012
 *      Author: fireballdark
 */

#ifndef CONNECTION_H_
#define CONNECTION_H_

#include <string>
#include <deque>
#include <vector>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/array.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/thread.hpp>
#include <boost/thread/locks.hpp>
#include <boost/signals2.hpp>
#include <sutil/ObjectSignalsProccessor.h>

#ifndef SSL_DISABLED
typedef boost::asio::ssl::stream<boost::asio::ip::tcp::socket>  SslSocket;
#else
typedef boost::asio::ip::tcp::socket                            TCPSocket;
typedef TCPSocket SslSocket;
#endif
typedef boost::asio::deadline_timer                             DeadlineTimer;

//#define CONNECTION_STACK

/// Represents a single connection from a client.
class Connection
    : public boost::enable_shared_from_this<Connection>,
  private boost::noncopyable
{
public:
    /// Construct a connection
    explicit Connection();

    ~Connection();

    /// Get the socket associated with the connection.
    SslSocket::lowest_layer_type& socket();

    /// Start the first asynchronous operation for the connection.
    void start();

private:
    void work();

    void async_timeout_start();
    void async_timeout_stop();
    void handle_timeout(const boost::system::error_code& error);

    void async_handshake();
    void handle_handshake(const boost::system::error_code& e);

    void async_read_data_size();
    void async_read_keepalive();
    void async_read_data();
    std::size_t handle_read(const boost::system::error_code& e, std::size_t bytes_transferred, int type);
    std::size_t read_condition(const boost::system::error_code& error, std::size_t bytes_transferred);

    void async_write_data_size();
    void async_write_keepalive();
    void async_write_data();
    void handle_write(const boost::system::error_code& e, int type);

    void async_shutdown();
    void handle_shutdown(const boost::system::error_code& e);

    void processing();

    void close();

    void handle_stop_signal(int action);
    description_type handle_state_signal();

    uint64_t _data_in_control_size;
    uint64_t _data_in_size;
    uint64_t _data_out_size;
    uint64_t _data_keepalive_in;
    uint64_t _data_keepalive_out;

    enum ConnectionState
    {
        Opened            = 0,
        Read_Data_Size    = 1,
        Read_Data         = 2,
        Read_KeepAlive    = 3,
        Process_Data      = 4,
        Write_Data_Size   = 5,
        Write_Data        = 6,
        Write_KeepAlive   = 7,
        Shutdown          = 8,
        Close_Force       = 9,
        Error             = 10,
        Closed            = 11
    };

    Connection::ConnectionState   _state;
#ifdef CONNECTION_STACK
    std::deque<Connection::ConnectionState> connection_state;
#endif

    enum ConnectionStack
    {
        Constructor         = 0,
        Destructor          = 1,
        Start               = 2,
        Async_Timeout_Start = 3,
        Async_Timeout_Stop  = 4,
        Handle_Timeout      = 5,
        Async_Handshake     = 6,
        Handle_Handshake    = 7,
        Async_Read_Data_Size= 8,
        Async_Read_Data     = 9,
        Async_Read_KeepAlive= 10,
        Handle_Read         = 11,
        Read_Condition      = 12,
        Async_Write_Data_Size= 13,
        Async_Write_Data    = 14,
        Async_Write_Keepalive= 15,
        Handle_Write        = 16,
        Async_Shutdown      = 17,
        Handle_Shutdown     = 18,
        Processing          = 19,
        Handle_Stop_Signal  = 20,
        Close               = 21
    };

#ifdef CONNECTION_STACK
    std::deque<Connection::ConnectionStack> connection_stack;
#endif

    void add_connection_stack(ConnectionStack element, ConnectionState state);
    void print_connection_stack();

    SslSocket         _socket;      /// Socket for the connection.
    DeadlineTimer     _timer;
    boost::asio::strand     _strand;

    /// Buffer for incoming data.
    std::vector<char> _data_in_vector;
    std::string _data_in;
    std::string _data_out;

    std::string _ip_address;
    std::string _connection_number;

    boost::shared_lock<boost::shared_mutex>         _stop_lock;
    boost::signals2::scoped_connection              _sig_connection;
    boost::signals2::scoped_connection              _sig_desc;

    bool _is_ssl;
    //connection is mature if it had at least one OK transaction
    bool _is_mature;

    int64_t _user_id;
};

typedef boost::shared_ptr<Connection> connection_ptr;

#endif /* CONNECTION_H_ */
