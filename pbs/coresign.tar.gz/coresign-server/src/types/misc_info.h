#ifndef MISC_INFO_H_
#define MISC_INFO_H_

#include <vector>
#include <string>
#include "types/event_types.h"
#include "types/status_codes.h"

struct Event
{
    Event():
        event_id(0),
        event_type_v(Event_WorkGroupFirstEvent),
        workgroup_id(0),
        file_id(0),
        parent_id(0),
        event_date(0)
    {
    }

    int64_t       event_id;
    event_type          event_type_v;
    std::string         login;
    int64_t       workgroup_id;
    int64_t       file_id;
    int64_t       parent_id;
    int64_t       event_date;
    std::string         event_date_str;
    std::string         data1;
    std::string         data2;
    std::string         data3;
    std::string         path;
    std::string         device_id;
};

struct ReturnStatus
{
    ReturnStatus():
        workgroup_id(0),
        file_id(0),
        returnStatus(status_internal_error)
    {
    }

    int64_t       workgroup_id;
    int64_t       file_id;
    std::string         login;
    rpc_status_code     returnStatus;
};


struct UpdateInfo
{
    UpdateInfo():
        version_id(0),
        silent_update(false)
    {
    }

    int64_t   version_id;
    std::string     version;
    std::string     platform;
    std::string     update_link;
    std::string     whats_new;
    bool            silent_update;
    std::string 	file_hash;
};


struct PurchaseInfo
{
    PurchaseInfo()
    {}

    std::string type;
    std::string event;
    std::string count;
};

struct PurchaseData
{
    PurchaseData():
        sandbox(false),
        service_type(0),
        overwrite(false)
    {}

    std::string infos_to_string() const;
    void        string_to_infos(const std::string& json);

    std::string login;
    std::string type;
    std::string hash;
    std::string name;
    std::vector<PurchaseInfo> infos;
    bool        sandbox;
    int64_t     service_type;

    std::string purchase_date;
    bool        overwrite;
};



typedef std::vector<Event>          EventsList;
typedef std::vector<ReturnStatus>   ReturnStatusList;

#endif
