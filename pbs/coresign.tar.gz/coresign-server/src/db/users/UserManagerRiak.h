/*
 * UserManagerRiak.h
 *
 *  Created on: 02.10.2015
 *      Author: ilyas
 */

#ifndef USERMANAGERRIAK_H_
#define USERMANAGERRIAK_H_

#include "types/status_codes.h"
#include "types/user_info.h"

class UserManageRiak
{
public:
    static rpc_status_code  activateUser            (const std::string& login);
    static rpc_status_code  createDummyUser         (UserCredentials& uc);
    static rpc_status_code  updateUserCredentials   (const UserCredentials& uc);

    static rpc_status_code  updatePassword          (const std::string& login, const std::string& password, const std::string& saltForPass, const std::string& privateKey, const std::string& privateKeySalt);
    static rpc_status_code  updateSecretAnswer      (const std::string& login, const std::string& secretQuestion, const std::string& secretAnswer, const std::string& saltForAnswer, const std::string& privateAnswerKey,const std::string& saltForPrivateAnswerKey);

    static rpc_status_code  updateUserProfile       (const std::string& login, const std::string& email, const std::string& firstName, const std::string& lastName, const std::string& userPicture);

    static rpc_status_code  getCredentialsByLogin   (const std::string& login, UserCredentials& userCredentials);
    static rpc_status_code  getCredentialsByUserId  (int64_t     userId, UserCredentials& userCredentials);

    static rpc_status_code  getUserInfoByLogin      (const std::string& login, UserInfo& userInfo);
    static rpc_status_code  getUserInfoByUserId     (int64_t     userId, UserInfo& userInfo);

    static rpc_status_code  getNotifications        (int64_t     userId, const std::vector<std::string>& notifyLiterals, NotificationsSubscription& notifySub);
    static rpc_status_code  setNotifications        (int64_t     userId, const NotificationsSubscription& notifySub);

    static rpc_status_code  reduceExpiration        (const std::string& login, const std::string& interval);
    static rpc_status_code  prolongExpiration       (const std::string& login, const std::string& interval);
    static rpc_status_code  prolongExpirationOverwrite(const std::string& login, const std::string& interval, const std::string& overwrite_date);

    static rpc_status_code  removeUser              (int64_t    userId);
};

#endif /* USERMANAGERRIAK_H_ */
