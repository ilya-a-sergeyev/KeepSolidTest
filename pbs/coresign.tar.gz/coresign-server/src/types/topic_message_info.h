/*
 * topic_message_info.h
 *
 *  Created on: 29 сент. 2011
 *      Author: fireballdark
 */

#ifndef TOPIC_MESSAGE_INFO_H_
#define TOPIC_MESSAGE_INFO_H_

#include <vector>
#include <string>

struct TopicInfo
{
    TopicInfo():
        is_deleted(false),
        topic_id(0),
        workgroup_id(0),
        file_id(0),
        creation_date(0),
        creator_id(0),
        revision(0)
    {
    }

    std::string         topic_body;
    std::string         creator_login;

    bool                is_deleted;

    int64_t       topic_id;
    int64_t       workgroup_id;
    int64_t       file_id;
    int64_t       creation_date;
    int64_t       creator_id;
    int64_t       revision;

    std::string         creation_date_str;
};

struct MessageInfo
{
    MessageInfo():
        message_id(0),
        topic_id(0),
        workgroup_id(0),
        file_id(0),
        parent_id(0),
        creation_date(0),
        creator_id(0),
        revision(0)
    {

    }

    std::string         message_body;
    std::string         login;
    std::string         notify_users;

    int64_t       message_id;
    int64_t       topic_id;
    int64_t       workgroup_id;
    int64_t       file_id;
    int64_t       parent_id;
    int64_t       creation_date;
    int64_t       creator_id;
    int64_t       revision;

    std::string         creation_date_str;
};


typedef std::vector<MessageInfo>     MessagesInfoList;
typedef std::vector<TopicInfo>       TopicsInfoList;

#endif /* TOPIC_MESSAGE_INFO_H_ */
