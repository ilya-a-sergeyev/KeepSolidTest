#ifndef STATISTICMASTER_H
#define STATISTICMASTER_H

namespace BinderStatisticProc {
int prepareBinding();
}

#endif // STATISTICMASTER_H
