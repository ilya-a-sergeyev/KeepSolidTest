/*
 * UserManagerHelper.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */


#include "UserManagerHelper.h"
#include <pqxx/result.hxx>
#include "types/user_info.h"



void convert_userinfo_db(const pqxx::result::const_iterator& query_result, UserInfo& ui)
{
    ui.user_id              = query_result["user_id"].as<int64_t>();
    ui.login                = query_result["login"].as<std::string>();
    ui.email                = query_result["email"].as<std::string>();
    ui.first_name           = query_result["first_name"].as<std::string>();
    ui.last_name            = query_result["last_name"].as<std::string>();
    ui.public_key           = query_result["public_key"].as<std::string>();
    ui.private_key          = query_result["private_key"].as<std::string>();
    ui.salt_pk_password     = query_result["salt_pk_password"].as<std::string>();
    ui.user_pic             = query_result["user_pic"].as<std::string>();
    ui.secret_question      = query_result["secret_question"].as<std::string>();
    ui.is_dummy             = query_result["is_dummy"].as<bool>();
    ui.is_activated         = query_result["is_activated"].as<bool>();
    ui.license_accepted     = query_result["license_accepted"].as<bool>();
    ui.is_tutorialated      = query_result["is_tutorialated"].as<bool>();
    ui.creation_date        = query_result["registration_date"].as<int64_t>();
    ui.expiration_date      = query_result["expiration_date"].as<int64_t>();
}

void convert_usercredentials_db(const pqxx::result::const_iterator& query_result, UserCredentials& ui)
{
    ui.user_id              = query_result["user_id"].as<int64_t>();
    ui.login                = query_result["login"].as<std::string>();
    ui.password             = query_result["password"].as<std::string>();
    ui.salt_password        = query_result["salt_password"].as<std::string>();
    ui.secret_question      = query_result["secret_question"].as<std::string>();
    ui.secret_answer        = query_result["secret_answer"].as<std::string>();
    ui.salt_answer          = query_result["salt_answer"].as<std::string>();
    ui.public_key           = query_result["public_key"].as<std::string>();
    ui.private_key          = query_result["private_key"].as<std::string>();
    ui.private_key_answer   = query_result["private_key_answer"].as<std::string>();
    ui.salt_pk_password     = query_result["salt_pk_password"].as<std::string>();
    ui.salt_pk_answer       = query_result["salt_pk_answer"].as<std::string>();
    ui.is_dummy             = query_result["is_dummy"].as<bool>();
    ui.is_activated         = query_result["is_activated"].as<bool>();
    ui.license_accepted     = query_result["license_accepted"].as<bool>();
    ui.encrypted_external_password  = query_result["encrypted_external_password"].as<std::string>();
}
