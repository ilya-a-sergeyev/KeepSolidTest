/*
 * MiscRpc.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */


#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "logic/AuthLogic.h"
#include "logic/MiscLogic.h"
#include "logic/UserLogic.h"
#include "types/structs_to_protobuf.h"
#include "logic/EventLogic.h"



rpc_status_code_struct ProtobufZmqRpc::eventsList(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("EventsList critical timer",50,true);

    rpc::EventsListRequest   input;
    rpc::EventsListResponse*  output = response.mutable_events_list();
    response.set_message_type(RPC_EVENTS_LIST);

    do
    {
        if (request.has_events_list())
        {
            input = request.events_list();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_last_event_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string   sessionId           = input.session_id();
        int64_t lastEventId         = input.last_event_id();
        int64_t eventsLimit         = input.has_events_limit() ? input.events_limit() : 1000;
        bool          reverse             = input.has_reverse() ? input.reverse() : false;

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        //LOG_ABSOLUTE("EventsList function called with [%s] and last eventId %lli limit %lli reverse %i", sessionId.c_str(), lastEventId, eventsLimit, reverse);

        EventsList eventsList;
        context.session_id = sessionId;
        resultStatus = EventLogic::eventsListForUser(context, lastEventId, eventsLimit, reverse, eventsList);

        if (resultStatus != status_success)
        {
            break;
        }

        for (EventsList::iterator i = eventsList.begin() ; i!= eventsList.end() ; i++)
        {
            rpc::EventsListResponse_EventInfo* eventInfo = output->add_event_info_list();
            eventInfo->set_event_id             ((*i).event_id);
            eventInfo->set_event_type           ((*i).event_type_v);
            eventInfo->set_login                ((*i).login);
            eventInfo->set_workgroup_id         ((*i).workgroup_id);
            eventInfo->set_file_id              ((*i).file_id);
            eventInfo->set_parent_id            ((*i).parent_id);
            eventInfo->set_event_date           ((*i).event_date);
            eventInfo->set_event_date_str       ((*i).event_date_str);
            eventInfo->set_path                 ((*i).path);
            eventInfo->set_data1                ((*i).data1);
            eventInfo->set_data2                ((*i).data2);
            eventInfo->set_data3                ((*i).data3);
            eventInfo->set_device_id            ((*i).device_id);

            if (eventInfo->device_id().empty())
            {
                LOG_ABSOLUTE("Device id is empty for event %lli", (int64_t)eventInfo->event_id());
            }

            //LOG_ABSOLUTE("Got event %lli type %i on [%s] by [%s] on workgroup %lli file %lli parent %lli path [%s] data1 [%s] data2 [%s] data3 [%s]",(*i).eventId,(*i).eventType,(*i).eventDateStr.c_str(),(*i).userName.c_str(),(*i).workgroup_id,(*i).fileId,(*i).parent_id,(*i).path.c_str(),(*i).data1.c_str(),(*i).data2.c_str(),(*i).data3.c_str());
        }
        if (output->event_info_list_size()!=0)
        {
            LOG_ABSOLUTE("EventsList returned %i elements",output->event_info_list_size());
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    if (resultStatus!=status_success)
    {
        LOG_ABSOLUTE("EventsList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    }
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::createKeyPair(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("CreateKeyPair");

    rpc::CreateKeyPairRequest   input;
    rpc::CreateKeyPairResponse*  output = response.mutable_create_key_pair();
    response.set_message_type(RPC_CREATE_KEY_PAIR);

    do
    {
        if (request.has_create_key_pair())
        {
            input = request.create_key_pair();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();
        std::string    password           = input.key_password();

        if (!is_utf8_string(sessionId) || !is_utf8_string(password))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("CreateKeyPair function called with [%s]", sessionId.c_str());

        std::string keyId;
        std::string public_key;
        context.session_id  = sessionId;
        resultStatus = MiscLogic::createKeyPair(context, password, keyId, public_key);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_key_id(keyId);
        output->set_public_key(public_key);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("CreateKeyPair function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::getKeyPair(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("GetKeyPair");

    rpc::GetKeyPairRequest   input;
    rpc::GetKeyPairResponse*  output = response.mutable_get_key_pair();
    response.set_message_type(RPC_GET_KEY_PAIR);

    do
    {
        if (request.has_get_key_pair())
        {
            input = request.get_key_pair();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_key_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    keyId          = input.key_id();

        if (!is_utf8_string(keyId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("GetKeyPair function called with [%s]", keyId.c_str());

        std::string public_key;
        std::string private_key;
        resultStatus = MiscLogic::getKeyPair(context, keyId, public_key, private_key);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_public_key(public_key);
        output->set_private_key(private_key);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("GetKeyPair function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::tariffsList(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("TariffsList");

    rpc::TariffsListRequest   input;
    rpc::TariffsListResponse*  output = response.mutable_tariffs_list();
    response.set_message_type(RPC_COMPANY_CHANGE_ROLE);

    do
    {
        if (request.has_tariffs_list())
        {
            input = request.tariffs_list();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("TariffsList function called");
        //context.session_id = sessionId;
        //resultStatus = CompanyLogic::companyDelete(sessionId, companyId);

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("TariffsList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}
