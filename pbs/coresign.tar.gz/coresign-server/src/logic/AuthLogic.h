/*
 * logic.h
 *
 *  Created on: 18 бер. 2011
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/user_info.h"
#include "types/misc_info.h"
#include "types/request_context.h"

/**
 * Class that contains main logic of server:
 * determines which actions should be taken when performing RPC call
 */
class	AuthLogic
{
public:
    static rpc_status_code          login 			    (RequestContext& context, const std::string& login, const std::string& password, LoginStatsExtended& loginStats, std::string& sessionId, std::string& eventSessionId, RedirectInfo& redirectInfo);
    static rpc_status_code          logout              (RequestContext& context);
    static rpc_status_code          createUser 		    (RequestContext& context, const std::string& login, const std::string& email, const std::string& password, const std::string& secretQuestion, const std::string& secretAnswer, const std::string& firstName, const std::string& lastName, bool licenseAccepted);
    static rpc_status_code          activateUser        (RequestContext& context, const std::string& login, const std::string& oldPassword, const std::string& newPassword, const std::string& secretQuestion, const std::string& secretAnswer, const std::string& firstName, const std::string& lastName, bool licenseAccepted);
    static rpc_status_code          changePassword      (RequestContext& context, const std::string& login, const std::string& oldPassword, const std::string& newPassword);
    static rpc_status_code          changeSecretQA      (RequestContext& context, const std::string& login, const std::string& password, const std::string& newSecretQuestion, const std::string& newSecretAnswer);
    static rpc_status_code          subscribeEvents     (RequestContext& context, int64_t& userId);
    static rpc_status_code          forgotPassword      (RequestContext& context, const std::string& login);
    static rpc_status_code          getSecretQuestion   (RequestContext& context, const std::string& login, const std::string& securityCodeIn, std::string& secretQuestion, std::string& securityCodeOut);
    static rpc_status_code          recoverPassword     (RequestContext& context, const std::string& login, const std::string& securityCode, const std::string& secretAnswer, const std::string& newPassword);

    //internal usage
    static rpc_status_code          createDummyUserWithCredentials  (UserCredentials& uc);
private:
    static rpc_status_code          checkLoginPassword                              (const std::string& login, const std::string& password, UserCredentials& uc, bool checkSecretAnswer = false);
    static rpc_status_code          updateUserCredentials                           (const std::string& oldPassword, UserCredentials& uc);
    static rpc_status_code          updateUserCredentialsPasswordWithPassword       (const std::string& oldPassword, UserCredentials& uc);
    static rpc_status_code          updateUserCredentialsPasswordWithSecretAnswer   (const std::string& secretAnswer, UserCredentials& uc);
    static rpc_status_code          updateUserCredentialsSecretAnswerWithPassword   (const std::string& oldPassword, UserCredentials& uc);
};
