/*
 * EventLogic.cpp
 *
 *  Created on: Apr 1, 2013
 *      Author: fireballdark
 */

#include "EventLogic.h"
#include "db/events/EventManagerPgSql.h"
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include "logic/HelperLogic.h"
#include "types/user_info.h"
#include "network/EventNotifier.h"
#include "db/folders/FolderManagerPgSql.h"
#include "inttypes.h"
#include <boost/lexical_cast.hpp>


rpc_status_code EventLogic::eventsListForUser(RequestContext& context, int64_t lastEventId, int64_t eventsLimit, bool reverse, EventsList& eventsList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    Timer timer("EventsList critical timer",80,true);
    bool bStatus = false;


    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success)
        {
            break;
        }

        if (eventsLimit>1000 || eventsLimit<0)
        {
            LOG_INFORMATION("User %lli tried to use incorrect events limit %lli!",userId,eventsLimit);
            eventsLimit = 1000;
        }

        if (context.user_info.expiration_date < time(NULL))
        {
            statusCode = status_payment_required;
            break;
        }

        if (reverse == false)
        {
            statusCode = EventManagerPgSql::listEventsForUser(userId,lastEventId,eventsLimit,eventsList);
        }
        else
        {
            if (lastEventId>0)
            {
                statusCode = EventManagerPgSql::listEventsForUserReverse(userId,lastEventId,eventsLimit,eventsList);
            }
            else
            {
                statusCode = EventManagerPgSql::listEventsForUserReverseLast(userId,eventsLimit,eventsList);
            }
        }

        if (statusCode != status_success)
        {
            break;
        }

        bStatus = true;
    }
    while (false);

    timer.prepare_total();
    if (timer.is_timed_out() || bStatus == false)
    {
        LOG_ABSOLUTE("EventsList function ended: userId [%lli] : session [%s], last event %lli, events number [%zi]", userId, context.session_id.c_str(), lastEventId ,eventsList.size());
        if (eventsList.empty() == false)
        {
            LOG_ABSOLUTE("EventsList function first event in the list is %lli type %i date %lli", eventsList[0].event_id, eventsList[0].event_type_v, eventsList[0].event_date);
        }
    }

    return statusCode;
}


rpc_status_code EventLogic::fileCreate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t fileSize, const std::string& fileName)
{
    std::string fileSizeStr = boost::lexical_cast<std::string>(fileSize);
    rpc_status_code status = createEvent(Event_FileCreate,user_id,login,device_id,workgroup_id,file_id,parent_id,"","",fileSizeStr,fileName);
    return status;
}


rpc_status_code EventLogic::fileDirectoryCreate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, const std::string& directoryName)
{
    rpc_status_code status = createEvent(Event_FileDirectoryCreate,user_id,login,device_id,workgroup_id,file_id,parent_id,"","","",directoryName);
    return status;
}


rpc_status_code EventLogic::fileDelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, const std::string& fileName, bool isDirectory)
{
    char isDirectoryStr[32];
    snprintf(isDirectoryStr,sizeof(isDirectoryStr),"%i",isDirectory);
    rpc_status_code status = createEvent(Event_FileDelete,user_id,login,device_id,workgroup_id,file_id,parent_id,"",isDirectoryStr,"",fileName);
    return status;
}



rpc_status_code EventLogic::fileRename(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, const std::string& fileNameOld, const std::string& fileNameNew, bool isDirectory)
{
    char isDirectoryStr[32];
    snprintf(isDirectoryStr,sizeof(isDirectoryStr),"%i",isDirectory);
    rpc_status_code status = createEvent(Event_FileRename,user_id,login,device_id,workgroup_id,file_id,parent_id,fileNameNew,isDirectoryStr,"",fileNameOld);
    return status;
}



rpc_status_code EventLogic::fileUpdate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t fileSize, const std::string& fileName)
{
    std::string fileSizeStr = boost::lexical_cast<std::string>(fileSize);
    rpc_status_code status = createEvent(Event_FileUpdate,user_id,login,device_id,workgroup_id,file_id,parent_id,"","",fileSizeStr,fileName);
    return status;
}



rpc_status_code EventLogic::fileUndelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t fileSize, const std::string& fileName)
{
    std::string fileSizeStr = boost::lexical_cast<std::string>(fileSize);
    rpc_status_code status = createEvent(Event_FileUndelete,user_id,login,device_id,workgroup_id,file_id,parent_id,"","",fileSizeStr,fileName);
    return status;
}



rpc_status_code EventLogic::folderCreate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderName)
{
    rpc_status_code status = createEvent(Event_WorkGroupCreate,user_id,login,device_id,workgroup_id,0,0,"","","",folderName);
    return status;
}



rpc_status_code EventLogic::folderDelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderName,  bool keep_data, int64_t hard_recipient_id)
{
    char keep_data_str[32];
    snprintf(keep_data_str,sizeof(keep_data_str),"%i", (int)keep_data);
    rpc_status_code status = createEvent(Event_WorkGroupDelete,user_id,login,device_id,workgroup_id,0,0,"","",keep_data_str,folderName,0,hard_recipient_id);
    return status;
}



rpc_status_code EventLogic::folderRename(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderNameOld, const std::string& folderNameNew)
{
    rpc_status_code status = createEvent(Event_WorkGroupRename,user_id,login,device_id,workgroup_id,0,0,folderNameNew,"","",folderNameOld);
    return status;
}


rpc_status_code EventLogic::folderMetadataUpdate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderName, const std::string& metadataNew)
{
    rpc_status_code status = createEvent(Event_WorkGroupMetadataUpdate,user_id,login,device_id,workgroup_id,0,0,metadataNew,"","",folderName);
    return status;
}

rpc_status_code EventLogic::folderInvite(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderName, const std::string& inviteId, int64_t accessMode, const std::string& inviteeUser, int64_t recipient_id)
{
    std::string accessModeStr = boost::lexical_cast<std::string>(accessMode);
    rpc_status_code status = createEvent(Event_WorkGroupInvite,user_id,login,device_id,workgroup_id,0,0,inviteeUser,inviteId,accessModeStr,folderName,recipient_id);
    return status;
}



rpc_status_code EventLogic::folderSubscribe(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderName, int64_t accessMode)
{
    std::string accessModeStr = boost::lexical_cast<std::string>(accessMode);
    rpc_status_code status = createEvent(Event_WorkGroupSubscribe,user_id,login,device_id,workgroup_id,0,0,"","",accessModeStr,folderName);
    return status;
}


rpc_status_code EventLogic::folderReject(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& recipientLogin, const std::string& folderName, int64_t recipient_id)
{
    rpc_status_code status = createEvent(Event_WorkGroupReject,user_id,login,device_id,workgroup_id,0,0,recipientLogin,"","",folderName, recipient_id);
    return status;
}


rpc_status_code EventLogic::folderUnsubscribe(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, bool keep_data, const std::string& recipientLogin, const std::string& folderName, int64_t recipient_id)
{
    char keep_data_str[32];
    snprintf(keep_data_str,sizeof(keep_data_str),"%i", (int)keep_data);
    rpc_status_code status = createEvent(Event_WorkGroupUnsubscribe,user_id,login,device_id,workgroup_id,0,0,recipientLogin,"",keep_data_str,folderName, recipient_id);
    return status;
}


rpc_status_code EventLogic::folderAccessUpdate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& targetUserEmail, int64_t accessMode, const std::string& folderName)
{
    std::string accessModeStr = boost::lexical_cast<std::string>(accessMode);
    rpc_status_code status = createEvent(Event_WorkGroupAccessUpdate,user_id,login,device_id,workgroup_id,0,0,targetUserEmail,"",accessModeStr,folderName);
    return status;
}


rpc_status_code EventLogic::folderUndelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, const std::string& folderName, int64_t hard_recipient_id)
{
    rpc_status_code status = createEvent(Event_WorkGroupUndelete,user_id,login,device_id,workgroup_id,0,0,"","","",folderName,0,hard_recipient_id);
    return status;
}


rpc_status_code EventLogic::topicCreate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t topicId, const std::string& topicBody)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    rpc_status_code status = createEvent(Event_TopicCreate,user_id,login,device_id,workgroup_id,file_id,parent_id,topicIdStr,topicBody,"","");
    return status;
}

rpc_status_code EventLogic::topicDelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t topicId, const std::string& topicBody)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    rpc_status_code status = createEvent(Event_TopicDelete,user_id,login,device_id,workgroup_id,file_id,parent_id,topicIdStr,topicBody,"","");
    return status;
}

rpc_status_code EventLogic::topicUndelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t topicId, const std::string& topicBody)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    rpc_status_code status = createEvent(Event_TopicUndelete,user_id,login,device_id,workgroup_id,file_id,parent_id,topicIdStr,topicBody,"","");
    return status;
}

rpc_status_code EventLogic::topicRename(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t topicId, const std::string& topicBodyNew)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    rpc_status_code status = createEvent(Event_TopicRename,user_id,login,device_id,workgroup_id,file_id,parent_id,topicIdStr,topicBodyNew,"","");
    return status;
}

rpc_status_code EventLogic::messageCreate(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t messageId, const std::string& messageBody, int64_t topicId, int64_t parentMesId)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    std::string messageIdStr = boost::lexical_cast<std::string>(messageId);
    std::string parentIdStr = boost::lexical_cast<std::string>(parentMesId);
    rpc_status_code status = createEvent(Event_MessageCreate,user_id,login,device_id,workgroup_id,file_id,parent_id,messageIdStr,messageBody,topicIdStr,parentIdStr);
    return status;
}

rpc_status_code EventLogic::messageDelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t messageId, const std::string& messageBody,  int64_t topicId, int64_t parentMesId)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    std::string messageIdStr = boost::lexical_cast<std::string>(messageId);
    std::string parentIdStr = boost::lexical_cast<std::string>(parentMesId);
    rpc_status_code status = createEvent(Event_MessageDelete,user_id,login,device_id,workgroup_id,file_id,parent_id,messageIdStr,messageBody,topicIdStr,parentIdStr);
    return status;
}

rpc_status_code EventLogic::messageUndelete(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t messageId, const std::string& messageBody,  int64_t topicId, int64_t parentMesId)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    std::string messageIdStr = boost::lexical_cast<std::string>(messageId);
    std::string parentIdStr = boost::lexical_cast<std::string>(parentMesId);
    rpc_status_code status = createEvent(Event_MessageUndelete,user_id,login,device_id,workgroup_id,file_id,parent_id,messageIdStr,messageBody,topicIdStr,parentIdStr);
    return status;
}

rpc_status_code EventLogic::messageEdit(int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, int64_t messageId, const std::string& messageBodyNew, int64_t topicId, int64_t parentMesId)
{
    std::string topicIdStr = boost::lexical_cast<std::string>(topicId);
    std::string messageIdStr = boost::lexical_cast<std::string>(messageId);
    std::string parentIdStr = boost::lexical_cast<std::string>(parentMesId);
    rpc_status_code status = createEvent(Event_MessageEdit,user_id,login,device_id,workgroup_id,file_id,parent_id,messageIdStr,messageBodyNew,topicIdStr,parentIdStr);
    return status;
}

rpc_status_code EventLogic::userInfoUpdate(int64_t user_id, const std::string& login, const std::string& device_id, const std::string& firstName, const std::string& lastName, const std::string& userPic, int64_t hard_recipient_id)
{
    rpc_status_code status = createEvent(Event_UserInfoUpdate,user_id,login,device_id,0,0,0,firstName,lastName,userPic,"",0,hard_recipient_id);
    return status;
}

rpc_status_code EventLogic::accPassChanged(int64_t user_id, const std::string& login, const std::string& device_id, int64_t hard_recipient_id)
{
    rpc_status_code status = createEvent(Event_AcctPassChanged,user_id,login,device_id,0,0,0,"","","","",0,hard_recipient_id);
    return status;
}

rpc_status_code EventLogic::createEvent(event_type eventType, int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId,
        int64_t parentId, const std::string& data1, const std::string& data2, const std::string& data3, const std::string& path, int64_t recipientId, int64_t hardRecipientId)
{
    rpc_status_code status = EventManagerPgSql::createEvent(eventType,userId,userName,deviceId,folderId,fileId,parentId,data1,data2,data3,path,recipientId,hardRecipientId);

    if (status == status_success)
    {
        if (hardRecipientId > 0)
        {
            EventNotifier::notify_event(hardRecipientId,eventType);
        }
        else
        {
            if (recipientId > 0)
            {
                EventNotifier::notify_event(recipientId,eventType);
            }
            if (folderId > 0)
            {
                UserIdList uids;
                status = WorkGroupManagerPgSql::list_invited_coworkers_ids(userId,folderId,uids);

                for(std::size_t i=0; i<uids.size(); i++)
                {
                    if (uids[i]!=recipientId)
                    {
                        EventNotifier::notify_event(uids[i],eventType);
                    }
                }
            }
        }
    }

    return status;
}

