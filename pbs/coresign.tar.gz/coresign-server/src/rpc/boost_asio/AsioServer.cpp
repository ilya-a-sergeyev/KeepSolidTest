/*
 * AsioServer.cpp
 *
 *  Created on: 23 янв. 2012
 *      Author: fireballdark
 */


#include "AsioServer.h"
#include <boost/thread.hpp>
#include <boost/bind.hpp>
#include <threadpool/boost/threadpool.hpp>
#include <sutil/logging.h>
#include "conf/Globals.h"

Asio_Server::Asio_Server(const std::string& address, int port, std::size_t thread_pool_size)
    : thread_pool_size_(thread_pool_size),
      acceptor_(Globals::get_globals().getIOService()),
      new_connection_(new Connection()),
      sig_connection(Globals::get_globals().getStopSignal().connect(boost::bind(&Asio_Server::handle_stop_signal,this,_1)))
{
    // Open the acceptor with the option to reuse the address (i.e. SO_REUSEADDR).
    boost::asio::ip::tcp::resolver resolver(Globals::get_globals().getIOService());
    std::stringstream ss;
    ss<<port;
    boost::asio::ip::tcp::resolver::query query(address, ss.str());
    boost::asio::ip::tcp::endpoint endpoint = *resolver.resolve(query);
    acceptor_.open(endpoint.protocol());
    acceptor_.set_option(boost::asio::ip::tcp::acceptor::reuse_address(true));
    acceptor_.set_option(boost::asio::ip::tcp::acceptor::keep_alive(true));
    acceptor_.bind(endpoint);
    acceptor_.listen();
    acceptor_.async_accept(new_connection_->socket(),
                           boost::bind(&Asio_Server::handle_accept, this,
                                       boost::asio::placeholders::error));

    LOG_INFORMATION("Bound on %s:%i",address.c_str(),port);
}

Asio_Server::~Asio_Server()
{
    sig_connection.disconnect();
    LOG_INFORMATION("Closing server.. WTFFFFFF???");
}

void Asio_Server::run()
{
    // Create a pool of threads to run all of the io_services.
    boost::threadpool::pool thread_pool(thread_pool_size_);

    boost::thread t(boost::bind(&Globals::runTimerIOService, &Globals::get_globals()));

    LOG_INFORMATION("Timer IO Service started");

    for (std::size_t i = 0; i < thread_pool_size_; ++i)
    {
        thread_pool.schedule(boost::bind(&Globals::runIOService, &Globals::get_globals()));
    }

    LOG_INFORMATION("Main IO Services started");

    t.join();

    LOG_INFORMATION("Timer IO Service stopped");

    thread_pool.wait();

    LOG_INFORMATION("Main IO Services stopped");
}

void Asio_Server::handle_stop_signal(int action)
{
    if (action != 0)
    {
        return;
    }

    boost::system::error_code err;
    acceptor_.close(err);
    new_connection_.reset();
    LOG_INFORMATION("Connection reset called with Shutdown");
}

void Asio_Server::handle_accept(const boost::system::error_code& e)
{
    if (Globals::get_globals().isIsStopped() || !new_connection_.get())
    {
        return;
    }

    LOG_INSANE("Connection Accepted");
    try
    {
        if (!e)
        {
            new_connection_->start();
            new_connection_.reset(new Connection());
            acceptor_.async_accept(new_connection_->socket(),
                                   boost::bind(&Asio_Server::handle_accept, this,
                                               boost::asio::placeholders::error));
        }
        else
        {
            LOG_INFORMATION("Error accepting connection %s",e.message().c_str());
        }
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Problem with connection %s",e.what());
    }
}

