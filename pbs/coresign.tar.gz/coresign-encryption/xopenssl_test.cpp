#include <string>
#include <iostream>
#include "xopenssl.h"
#include "xopenssl_test.h"

#include <util/logging.h>

typedef std::vector<std::string> StringsVector;

std::string sslStatus(xopenssl_status status)
{
    std::string retval;
    switch(status)
    {
        case XOPENSSL_UNKNOWN:              retval = "XOPENSSL_UNKNOWN";
            break;
        case XOPENSSL_OK:                   retval = "XOPENSSL_OK";
            break;
        case XOPENSSL_BAD_ARGUMENTS:        retval = "XOPENSSL_BAD_ARGUMENTS";
            break;
        case XOPENSSL_BAD_STREAM:           retval = "XOPENSSL_BAD_STREAM";
            break;
        case XOPENSSL_METADATA_ERROR:       retval = "XOPENSSL_METADATA_ERROR";
            break;
        case XOPENSSL_HASH_CHECK_ERROR:     retval = "XOPENSSL_HASH_CHECK_ERROR";
            break;
        case XOPENSSL_SIZE_MISMATCH:        retval = "XOPENSSL_SIZE_MISMATCH";
            break;
        case XOPENSSL_STREAM_ERROR:         retval = "XOPENSSL_STREAM_ERROR";
            break;
        case XOPENSSL_CRYPTO_ERR:           retval = "XOPENSSL_CRYPTO_ERR";
            break;
        default:                            retval = "I don't know about this code";
            break;
    }
    return retval;
}

int validate_sha256_hmac(const StringsVector& secrets)
{
    bool result = true;
#pragma omp parallel  shared (result)
#pragma omp for
    for (StringsVector::size_type i=0; i<secrets.size(); i++)
    {
        std::string signature = sha256_hmac_easy_sign(secrets[i]);
        bool verify = sha256_hmac_easy_verify(signature,secrets[i]);
        if (verify != true)
        {
            LOG_ERROR("SHA256 HMAC GOOD test Fail %lui",i);
            result = false;
            continue;
        }

        verify = sha256_hmac_easy_verify(signature,secrets[i]+" ");
        if (verify != false)
        {
            LOG_ERROR("SHA256 HMAC BAD test Fail %lu",i);
            result = false;
            continue;
        }
    }
    return result;
}

int validate_sha256_pbkdf2(const StringsVector& secrets)
{
    bool result = true;
#pragma omp parallel shared (result)
#pragma omp for
    for (StringsVector::size_type i=0; i<secrets.size(); i++)
    {
        std::string salt;
        std::string salted_hash = sha256_pbkdf2_password_generate(secrets[i],salt);

        bool verify = sha256_pbkdf2_verify(salted_hash,secrets[i],salt);
        if (verify != true)
        {
            LOG_ERROR("SHA256 PBKDF2 GOOD test Fail %lu",i);
            result = false;
            continue;
        }

        verify = sha256_pbkdf2_verify(salted_hash,secrets[i]+" ",salt);
        if (verify != false)
        {
            LOG_ERROR("SHA256 PBKDF BAD test Fail %lu",i);
            result = false;
            continue;
        }
    }
    return result;
}

int validate_aes256_string(const StringsVector& data, const StringsVector& secrets)
{
    bool result = true;
#pragma omp parallel shared (result)
#pragma omp for
    for (StringsVector::size_type i=0; i<secrets.size(); i++)
    {
        for (StringsVector::size_type j=0; j<data.size(); j++)
        {
            std::string encrypted = aes_easy_encrypt(data[j],secrets[i]);
            std::string decrypted = aes_easy_decrypt(encrypted,secrets[i]);

            if (decrypted.compare(data[j])!=0)
            {
                LOG_ERROR("AES256 GOOD test Fail %lu:%lu",i,j);
                result = false;
                continue;
            }

            std::string decrypted_bad = aes_easy_decrypt(encrypted,secrets[i]+" ");

            if (decrypted_bad.compare(data[j])==0)
            {
                LOG_ERROR("AES256 BAD test Fail %lu:%lu",i,j);
                result = false;
                continue;
            }

        }
    }
    return result;
}

int validate_rsa_keys(const StringsVector& data, const StringsVector& secrets)
{
    StringsVector private_keys;
    std::string public_key;
    bool result = rsa_generate_keys(secrets, private_keys, public_key);
    if (result == false)
    {
        LOG_ERROR("RSA Keys generate test Fail");
        return false;
    }

#pragma omp parallel for shared (result)
#pragma omp
    for (StringsVector::size_type i=0; i<secrets.size(); i++)
    {
        for (StringsVector::size_type j=0; j<data.size(); j++)
        {
            std::string encrypted;
            bool result = rsa_easy_encrypt(data[j], public_key, encrypted);
            if (result == false || encrypted.empty())
            {
                LOG_ERROR("RSA encode test Fail %lu:%lu",i,j);
                result = false;
                continue;
            }

            std::string decrypted1;
            result = rsa_easy_decrypt(encrypted, private_keys[i], secrets[i], decrypted1);
            if (result == false || decrypted1.empty())
            {
                LOG_ERROR("RSA decode test Fail %lu:%lu",i,j);
                result = false;
                continue;
            }

            std::string new_password="123456";
            std::string new_private_key;
            result = rsa_encode_private_keys(secrets[i],private_keys[i],new_password,new_private_key);
            if (result == false || new_private_key.empty())
            {
                LOG_ERROR("RSA reencode pkey test Fail %lu:%lu",i,j);
                result = false;
                continue;
            }

            std::string decrypted2;
            result = rsa_easy_decrypt(encrypted, new_private_key, new_password, decrypted2);
            if (result == false || decrypted2.empty())
            {
                LOG_ERROR("RSA decode test Fail %lu:%lu",i,j);
                result = false;
                continue;
            }

        }
    }
    return result;
}

bool test_file_aes_codec (const std::string& filesDir, const std::string& encFilePath, const std::string& rawFilePath, const std::string& pass)
{
    bool retval = 0;

    std::string              primary_file            = filesDir + rawFilePath;
    std::string              primary_enc_file        = filesDir + encFilePath;
    std::string              encrypted_file          = filesDir + "try_" + rawFilePath + "_enc";
    std::string              decrypted_file          = filesDir + "try_" + rawFilePath + "_dec";
    std::string              password                = pass;

    int situation_changer = 0;
    while(situation_changer <= 3)
    {
        int state = 0;
        do
        {
            remove(encrypted_file.c_str());
            remove(decrypted_file.c_str());

            FILE *in_stream, *out_stream;
            {
                //test current codec
                //LOG_INFORMATION("AES file codec test: test current codec");
                in_stream = fopen(primary_file.c_str(), "rb");
                out_stream = fopen(encrypted_file.c_str(), "wb+");
                if(in_stream == 0 || out_stream == 0)
                {
                    LOG_INFORMATION("AES file codec test: stream error\n");
                    //break;
                    state++;
                }
                std::string result_hash;
                xopenssl_status sts = aes_easy_encrypt(in_stream, password.c_str(), out_stream, result_hash);
                fclose(in_stream);
                fclose(out_stream);
                if(sts != XOPENSSL_OK)
                {
                    LOG_INFORMATION("AES file codec test: encripting FAILED\n status [%s]", sslStatus(sts).c_str());
                    //break;
                    state++;
                }
                if(situation_changer == 0)//!!! try wrong data after metadata
                {
                    std::ofstream outfile;

                    outfile.open(encrypted_file.c_str(), std::ios_base::binary | std::ios_base::app);
                    outfile << randomstring(20048);
                    outfile.close();
                }
                else if(situation_changer == 1)//!!! try wrong metadata
                {
                    std::ofstream outfile;
                    std::ifstream infile;

                    infile.open(encrypted_file.c_str(), std::ios_base::binary);
                    long fileSize = infile.tellg();
                    char *pBuff = new char[fileSize];
                    infile.read(pBuff, fileSize);
                    infile.close();

                    outfile.open(encrypted_file.c_str(), std::ios_base::binary);
                    outfile.write(pBuff, fileSize-2);
                    outfile.close();
                }
                else if(situation_changer == 2)//!!! try wrong file
                {
                    std::ofstream outfile;

                    outfile.open(encrypted_file.c_str(), std::ios_base::binary);
                    outfile << randomstring(20048);
                    outfile.close();
                }
                in_stream = fopen(encrypted_file.c_str(), "rb");
                std::string encript_hash = md5(in_stream);
                fclose(in_stream);
                int cmp = encript_hash.compare(result_hash);
                if(cmp != 0)
                {
                    LOG_INFORMATION("AES file codec test: current codec test FAILED\n");
                    //break;
                    state++;
                }


                in_stream = fopen(encrypted_file.c_str(), "rb");
                out_stream = fopen(decrypted_file.c_str(), "wb+");
                if(in_stream==0 || out_stream==0)
                {
                    LOG_INFORMATION("AES file codec test: opening stream FAILED\n");
                    //break;
                    state++;
                }
                sts = aes_easy_decrypt(in_stream, password.c_str(), out_stream);
                fclose(in_stream);
                fclose(out_stream);
                if(sts != XOPENSSL_OK)
                {
                    LOG_INFORMATION("AES file codec test: decripting FAILED\n status [%s]", sslStatus(sts).c_str());
                    //break;
                    state++;
                }


                //check identity of files
                in_stream = fopen(primary_file.c_str(), "rb");
                std::string primary_hash = md5(in_stream);
                fclose(in_stream);

                in_stream = fopen(decrypted_file.c_str(), "rb");
                std::string compare_hash = md5(in_stream);
                fclose(in_stream);

                cmp = primary_hash.compare(compare_hash);
                if(cmp != 0)
                {
                    LOG_INFORMATION("AES file codec test: current codec test FAILED\n");
                    //break;
                    state++;
                }
            }

            {
                //test current codec with old encoded files
                //LOG_INFORMATION("AES file codec test: test current codec with old encoded files");

                in_stream = fopen(primary_enc_file.c_str(), "rb");
                out_stream = fopen(decrypted_file.c_str(), "wb+");
                if(in_stream==0 || out_stream==0)
                {
                    LOG_INFORMATION("AES file codec test: stream error\n");
                    //break;
                    state++;
                }
                xopenssl_status sts = aes_easy_decrypt(in_stream, password.c_str(), out_stream);
                fclose(in_stream);
                fclose(out_stream);
                if(sts != XOPENSSL_OK)
                {
                    LOG_INFORMATION("AES file codec test: decripting old file FAILED\n status [%s]", sslStatus(sts).c_str());
                    //break;
                    state++;
                }


                //check identity of files
                in_stream = fopen(primary_file.c_str(), "rb");
                std::string primary_hash = md5(in_stream);
                fclose(in_stream);

                in_stream = fopen(decrypted_file.c_str(), "rb");
                std::string compare_hash = md5(in_stream);
                fclose(in_stream);

                int cmp = primary_hash.compare(compare_hash);
                if(cmp != 0)
                {
                    LOG_INFORMATION("AES file codec test: old file test FAILED\n");
                    //break;
                    state++;
                }
            }
            retval = (state == 0);
        } while(false);
        if(retval && situation_changer < 3)
        {
            retval = 0;
            break;
        }
        situation_changer ++;
    }

    return retval;
}

bool test_stream_aes_codec (const std::string& filesDir, const std::string& encFilePath, const std::string& rawFilePath, const std::string& pass)
{
    bool retval = 0;

    std::string              primary_file            = filesDir + rawFilePath;
    std::string              primary_enc_file        = filesDir + encFilePath;
    std::string              encrypted_file          = filesDir + "try_" + rawFilePath + "_enc";
    std::string              decrypted_file          = filesDir + "try_" + rawFilePath + "_dec";
    std::string              password                = pass;

    int situation_changer = 0;
    while(situation_changer <= 3)
    {
        int state = 0;
        do
        {
            remove(encrypted_file.c_str());
            remove(decrypted_file.c_str());

            std::ifstream in_stream;
            std::ofstream out_stream;
            {
                //test current codec
                //LOG_INFORMATION("AES file codec test: test current codec");
                in_stream.open(primary_file.c_str(), std::ios_base::binary);
                out_stream.open(encrypted_file.c_str(), std::ios_base::binary);
                if (!in_stream.good() || !out_stream.good())
                {
                    LOG_INFORMATION("AES stream codec test: stream error\n");
                    //break;
                    state++;
                }
                std::string result_hash;
                xopenssl_status sts = aes_easy_encrypt(in_stream, password.c_str(), out_stream, result_hash);
                in_stream.close();
                out_stream.close();
                if(sts != XOPENSSL_OK)
                {
                    LOG_INFORMATION("AES stream codec test: encripting FAILED\n status [%s]", sslStatus(sts).c_str());
                    //break;
                    state++;
                }
                if(situation_changer == 0)//!!! try wrong data after metadata
                {
                    std::ofstream outfile;

                    outfile.open(encrypted_file.c_str(), std::ios_base::binary | std::ios_base::app);
                    outfile << randomstring(20048);
                    outfile.close();
                }
                else if(situation_changer == 1)//!!! try wrong metadata
                {
                    std::ofstream outfile;
                    std::ifstream infile;

                    infile.open(encrypted_file.c_str(), std::ios_base::binary);
                    long fileSize = infile.tellg();
                    char *pBuff = new char[fileSize];
                    infile.read(pBuff, fileSize);
                    infile.close();

                    outfile.open(encrypted_file.c_str(), std::ios_base::binary);
                    outfile.write(pBuff, fileSize-2);
                    outfile.close();
                }
                else if(situation_changer == 2)//!!! try wrong file
                {
                    std::ofstream outfile;

                    outfile.open(encrypted_file.c_str(), std::ios_base::binary);
                    outfile << randomstring(20048);
                    outfile.close();
                }
                in_stream.open(encrypted_file.c_str(), std::ios_base::binary);
                std::string encript_hash = md5(in_stream);
                in_stream.close();
                int cmp = encript_hash.compare(result_hash);
                if(cmp != 0)
                {
                    LOG_INFORMATION("AES stream codec test: current codec test FAILED\n");
                    //break;
                    state++;
                }


                in_stream.open(encrypted_file.c_str(), std::ios_base::binary);
                out_stream.open(decrypted_file.c_str(), std::ios_base::binary);
                if (!in_stream.good() || !out_stream.good())
                {
                    LOG_INFORMATION("AES stream codec test: opening stream FAILED\n");
                    //break;
                    state++;
                }
                sts = aes_easy_decrypt(in_stream, password.c_str(), out_stream);
                in_stream.close();
                out_stream.close();
                if(sts != XOPENSSL_OK)
                {
                    LOG_INFORMATION("AES stream codec test: decripting FAILED\n status [%s]", sslStatus(sts).c_str());
                    //break;
                    state++;
                }


                //check identity of files
                in_stream.open(primary_file.c_str(), std::ios_base::binary);
                std::string primary_hash = md5(in_stream);
                in_stream.close();

                in_stream.open(decrypted_file.c_str(), std::ios_base::binary);
                std::string compare_hash = md5(in_stream);
                in_stream.close();

                cmp = primary_hash.compare(compare_hash);
                if(cmp != 0)
                {
                    LOG_INFORMATION("AES stream codec test: current codec test FAILED\n");
                    //break;
                    state++;
                }
            }

            {
                //test current codec with old encoded files
                //LOG_INFORMATION("AES file codec test: test current codec with old encoded files");

                in_stream.open(primary_enc_file.c_str(), std::ios_base::binary);
                out_stream.open(decrypted_file.c_str(), std::ios_base::binary);
                if (!in_stream.good() || !out_stream.good())
                {
                    LOG_INFORMATION("AES file codec test: stream error\n");
                    //break;
                    state++;
                }
                xopenssl_status sts = aes_easy_decrypt(in_stream, password.c_str(), out_stream);
                in_stream.close();
                out_stream.close();
                if(sts != XOPENSSL_OK)
                {
                    LOG_INFORMATION("AES file codec test: decripting old file FAILED\n status [%s]", sslStatus(sts).c_str());
                    //break;
                    state++;
                }


                //check identity of files
                in_stream.open(primary_file.c_str(), std::ios_base::binary);
                std::string primary_hash = md5(in_stream);
                in_stream.close();

                in_stream.open(decrypted_file.c_str(), std::ios_base::binary);
                std::string compare_hash = md5(in_stream);
                in_stream.close();

                int cmp = primary_hash.compare(compare_hash);
                if(cmp != 0)
                {
                    LOG_INFORMATION("AES file codec test: old file test FAILED\n");
                    //break;
                    state++;
                }
            }
            retval = (state == 0);

        } while(false);
        if(retval && situation_changer < 3)
        {
            retval = 0;
            break;
        }
        situation_changer ++;
    }
    return retval;
}

bool test_md5_file_hash (const std::string& filePath, const std::string& compareHashFile)
{
    bool retval = 0;
    do
    {
        std::ifstream hashFile(compareHashFile.c_str(), std::ios_base::binary);
        std::string compareHash;
        hashFile >> compareHash;

        FILE *in_stream = fopen(filePath.c_str(), "rb");
        std::string resultHash = md5(in_stream);
        if(resultHash.compare(compareHash)!=0)
        {
            LOG_INFORMATION("MD5 file hash: FAILED\n");
            break;
        }
        retval = 1;
    }while (false);

    return retval;
}

bool test_md5_stream_hash (const std::string& filePath, const std::string& compareHashFile)
{
    bool retval = 0;
    do
    {
        std::ifstream hashFile(compareHashFile.c_str(), std::ios_base::binary);
        std::string compareHash;
        hashFile >> compareHash;

        std::ifstream in_stream(filePath.c_str(), std::ios_base::binary);
        std::string resultHash = md5(in_stream);
        if(resultHash.compare(compareHash)!=0)
        {
            LOG_INFORMATION("MD5 stream hash: FAILED\n");
            break;
        }
        retval = 1;
    }while (false);

    return retval;
}

bool test_validate_keys()
{
    StringsVector data;
    for (int i=0; i<1; i++)
    {
        data.push_back("01234567891011121314151617");
        data.push_back("Goodbye, Cruel World!");
        data.push_back("Привет, людишки");
        data.push_back("0123456789101112131415161701234567891011121314151617012345678910111213141516170123456789101112131415161701234567891011121314151617");
        data.push_back("012345678910111\02131415161701234567891011121\0\3141516170123456789101112131415161701\t23456789101112131415161701\n234567891011121314151618");
    }

    bool result       = validate_sha256_hmac          (data);
    result           &= validate_sha256_pbkdf2        (data);
    result           &= validate_aes256_string        (data,data);
    result           &= validate_rsa_keys             (data,data);

    return result;
}

#include <fstream>
#include <string>
#include <cerrno>

std::string get_file_contents(const char *filename)
{
    std::ifstream in(filename, std::ios::in | std::ios::binary);
    if (in)
    {
        std::string contents;
        in.seekg(0, std::ios::end);
        contents.resize(in.tellg());
        in.seekg(0, std::ios::beg);
        in.read(&contents[0], contents.size());
        in.close();
        return(contents);
    }
    throw(errno);
}

void base64_test(int iter, int max_num)
{
    for (int i = 0; i< iter; i++)
    {
        int symbols     = llabs(random_int64_t()) % max_num;
        //LOG_INFORMATION("base64 on iteration [%d] length [%d]", i, symbols);

        auto str        = randomstring(symbols);
        auto str_enc    = base64_encodestring(str);
        auto str_dec    = base64_decodestring(str_enc);
        if (str.compare(str_dec) != 0)
        {
            LOG_INFORMATION("Problem base64 on iteration [%d] length [%d]", i, symbols);
            exit(-1);
        }
    }
}


bool xopenssl_test (const std::string& testDirPath)
//int main()
{
    openssl_init();

    base64_test(1024, 32);
    base64_test(65536, 8192);

    /*std::string encrypted_data_pack  = get_file_contents((testDirPath+"/encrypted_data_pack.txt").c_str());
    std::string private_key          = get_file_contents((testDirPath+"/private_key.txt").c_str());
    std::string private_key_password = get_file_contents((testDirPath+"/private_key_password.txt").c_str());

    std::string decrypted_data;
    bool is_ok = rsa_easy_decrypt(encrypted_data_pack, private_key, private_key_password, decrypted_data);

    return is_ok;*/

    bool result  =  test_md5_file_hash(testDirPath+"test_empty", testDirPath+"test_empty_hash");
    result      &=  test_md5_file_hash(testDirPath+"test_small", testDirPath+"test_small_hash");
    result      &=  test_md5_file_hash(testDirPath+"test_large", testDirPath+"test_large_hash");

    result      &=  test_md5_stream_hash(testDirPath+"test_empty", testDirPath+"test_empty_hash");
    result      &=  test_md5_stream_hash(testDirPath+"test_small", testDirPath+"test_small_hash");
    result      &=  test_md5_stream_hash(testDirPath+"test_large", testDirPath+"test_large_hash");

    if(result)//continue only if md5 test passed
    {
        static const std::string correct_pass = "1";
        std::vector<std::string> passwords;
        for(int i=0; i<0; i++)
        {
            passwords.push_back(randomstring());
        }
        passwords.push_back(correct_pass);

        for(int i=0; i < passwords.size(); i++)
        {
            result      &=  ((bool)passwords[i].compare(correct_pass) ^ test_file_aes_codec(testDirPath, "test_empty_enc", "test_empty", passwords[i]));//test with empty file
            result      &=  ((bool)passwords[i].compare(correct_pass) ^ test_file_aes_codec(testDirPath, "test_small_enc", "test_small", passwords[i]));//test with small file
            result      &=  ((bool)passwords[i].compare(correct_pass) ^ test_file_aes_codec(testDirPath, "test_large_enc", "test_large", passwords[i]));//test with large file

            result      &=  ((bool)passwords[i].compare(correct_pass) ^ test_stream_aes_codec(testDirPath, "test_empty_enc", "test_empty", passwords[i]));//test with empty file
            result      &=  ((bool)passwords[i].compare(correct_pass) ^ test_stream_aes_codec(testDirPath, "test_small_enc", "test_small", passwords[i]));//test with small file
            result      &=  ((bool)passwords[i].compare(correct_pass) ^ test_stream_aes_codec(testDirPath, "test_large_enc", "test_large", passwords[i]));//test with large file
        }
    }

    result      &= test_validate_keys();

    LOG_INFORMATION("OpenSSL test result: %s", result?"PASSED":"FAILED");

    return result;
}
