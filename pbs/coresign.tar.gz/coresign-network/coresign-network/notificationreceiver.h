﻿#pragma once

#include <string>
#include <memory>
#include <mutex>
#include "types/status_codes.h"

#include <network/NotificationTypes.hpp>

#ifdef NOTIFY_SYNC
class AsioNotificationTransportSync;
typedef AsioNotificationTransportSync AsioNotificationTransport;
#else
class AsioNotificationTransportAsync;
typedef AsioNotificationTransportAsync AsioNotificationTransport;
#endif

class NotificationReceiver
{
    public:
        NotificationReceiver                (const std::string& address, const std::string& port, const int64_t& serviceId);
        explicit NotificationReceiver       (const AddressesList& addresses, const int64_t& serviceId);
        virtual ~NotificationReceiver       ();

        rpc_status_code             subscribe   (const std::string& eventSessionId, const function_MessageCallback& callback, const function_ConnectionCallback& connection_cb);
        std::string                 get_port    () const {return mPort;}
        std::string                 get_address () const {return mAddress;}
        void                        stop        ();

        bool                        is_connected();

    private:
        void                        call        (const std::string& data_out, std::string &data_in);

        std::shared_ptr<AsioNotificationTransport>  pTransport;
        std::mutex                  mMutex;
        std::string                 mAddress;
        std::string                 mPort;
        AddressesList               mAddresses;
        bool                        mStopped;
        int64_t                     mServiceId;
};
