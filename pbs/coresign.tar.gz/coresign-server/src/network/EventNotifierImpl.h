/*
 * EventNotifierHelper.h
 *
 *  Created on: 1 feb 2012
 *      Author: fireballdark
 */

#pragma once

#include <zmq.hpp>


class EventNotifierImpl
{
public:
    EventNotifierImpl();
    bool notify_event(int64_t userId, int64_t eventType);
    void close();
    ~EventNotifierImpl();

private:
    zmq::socket_t   sender;
};





