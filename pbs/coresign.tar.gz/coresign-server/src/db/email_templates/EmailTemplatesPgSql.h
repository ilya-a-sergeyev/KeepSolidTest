/*
 * FolderInvitesPgSql.h
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#ifndef EMAILTEMPLATESPGSQL_H_
#define EMAILTEMPLATESPGSQL_H_

#include "types/status_codes.h"
#include "types/invitation.h"

class EmailTemplatesPgSql
{
public:
    static rpc_status_code     get_template     (int64_t userId, const std::string& templateName, std::string& sender, std::string& subject, std::string& text, std::string& html);
};

#endif /* EMAILTEMPLATESPGSQL_H_ */
