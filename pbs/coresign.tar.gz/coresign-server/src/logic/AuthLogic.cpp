/*
 * logic.cpp
 *
 *  Created on: 31 бер. 2011
 *      Author: fireball
 */

#include "logic/AuthLogic.h"

#include "encryption/xopenssl.h"

#include <sutil/logging.h>
#include <util/DataVerifier.h>
#include <sutil/MailerHelper.h>
#include <sutil/Timer.h>

#include "db/sessions/SessionManagerRedis.h"
#include "db/users/UserManagerPgSql.h"
#include "network/FirstFolderCreator.h"
#include "util/url_encode.h"

#include "logic/EventLogic.h"
#include "logic/HelperLogic.h"
#include "conf/DaemonParams.h"


const int rsa_key_length = 1024;
const int pbkdf2_cycles  = 4096;

/**
 * Method which is used for clients authentication
 * requires client's login and password, returns session id (unique string token)
 * Checks email for being correct, check login:password pair to exist and generates new
 * temporary session id.
 */

//rpc_status_code AuthLogic::login(RequestContext& context, const std::string& login, const std::string& password, LoginStatsExtended& loginStats,
//        std::string& sessionId, std::string& eventSessionId, RedirectInfo& redirectInfo)
//{
//    int64_t userId = -1;
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;

//    do
//    {
//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("Login function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        if (check_ip_address(loginStats.ip_address) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("Login function failed: ip_address [%s] is not valid ip address ", loginStats.ip_address.c_str());
//            break;
//        }

//        {
//            UserCredentials uc;
//            statusCode = AuthLogic::checkLoginPassword(login, password, uc);
//            userId = uc.user_id;
//        }

////        if (statusCode == status_user_not_activated)
////        {
////            statusCode = UserManagerPgSql::activateUser(login);
////        }

//        if (statusCode == status_success && userId > 0 )
//        {
//            statusCode = SessionManagerPgSql::create_session(userId, login, sessionId, eventSessionId, loginStats.device_id, context.ip_address);
//            loginStats.successful = true;
//            bStatus = true;
//        }

//        LoginStatsPgSql::create_stats(userId,context.ip_address,loginStats,sessionId);

//        /*TODO*/
//        //Get info from DB
//        redirectInfo.rpc_address = "rpc.v1.keepsolid.com";
//        redirectInfo.rpc_port = "443";
//        redirectInfo.notify_address = "notify.v1.keepsolid.com";
//        redirectInfo.notify_port = "443";
//    }
//    while (false);


//    if (bStatus)
//    {
//        LOG_ABSOLUTE("Login function ended: login [%s] : pass [%s] => userId [%lli] : session [%s]:[%s]", login.c_str(), password.c_str(), userId, sessionId.c_str(), eventSessionId.c_str());
//        if (sessionId.compare(eventSessionId)==0)
//        {
//            LOG_ERROR("Login got two same sessionIds!! session [%s]:[%s]", sessionId.c_str(), eventSessionId.c_str());
//        }
//    }
//    else
//    {
//        LOG_INFORMATION("Login function failed: login [%s] : pass [%s] ", login.c_str(), password.c_str());
//    }

//    return statusCode;
//}


/**
 * Creates new user in DB
 */

//rpc_status_code AuthLogic::createUser(RequestContext& context, const std::string& login, const std::string& email, const std::string& password,
//        const std::string& secretQuestion, const std::string& secretAnswer, const std::string& firstName, const std::string& lastName, bool licenseAccepted)
//{
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;

//    do
//    {
//        if (!licenseAccepted)
//        {
//            statusCode = status_agreement_unaccepted;
//            break;
//        }

//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("CreateUser function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        UserCredentials uc;
//        statusCode = UserManagerPgSql::getCredentialsByLogin(login,uc);

//        if (uc.user_id == 0 && statusCode == status_does_not_exist)
//        {
//            uc.login           = login;
//            uc.password        = password;
//            uc.secret_question = secretQuestion;
//            uc.secret_answer   = secretAnswer;
//            uc.license_accepted= licenseAccepted;
//            uc.is_dummy        = false;

//            statusCode = AuthLogic::createDummyUserWithCredentials(uc);

//            if (statusCode != status_success)
//            {
//                break;
//            }

//            statusCode = UserManagerPgSql::updateUserProfile(login,email,firstName,lastName,"");

//            if (statusCode != status_success)
//            {
//                break;
//            }
//        }
//        else if (uc.user_id>0 && uc.is_dummy)
//        {
//            statusCode = status_user_is_dummy;
//        }
//        else if (uc.user_id>0 && !uc.is_activated)
//        {
//            statusCode = status_user_not_activated;
//        }
//        else if (statusCode == status_success)
//        {
//            statusCode = status_login_exists;
//        }

//        if (statusCode!=status_success)
//        {
//            break;
//        }

//        {
//            int64_t companyId = -1;
//            statusCode = CompanyManagerPgSql::create_company(uc.user_id, uc.login, "Personal account "+uc.login, true, companyId);

//            if (statusCode != status_success)
//            {
//                LOG_INFORMATION("Could not create personal company for %s", uc.login.c_str());
//                break;
//            }

//            statusCode = CompanyManagerPgSql::create_user_in_company(uc.user_id, uc.login, companyId, 1, "Company creator");
//        }

//        if (statusCode == status_success)
//        {
//            FirstFolderCreator::create_first_folder(login,password,uc.public_key);
//        }

//        if (statusCode==status_success)
//        {
//            bStatus = true;
//        }
//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("CreateUser function ended: [%s] : [%s] : [%s]",login.c_str(),firstName.c_str(),lastName.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("CreateUser function failed: login [%s]", login.c_str());
//    }

//    return statusCode;
//}

//rpc_status_code AuthLogic::activateUser(RequestContext& context, const std::string& login, const std::string& oldPassword,
//        const std::string& newPassword, const std::string& secretQuestion, const std::string& secretAnswer, const std::string& firstName,
//        const std::string& lastName, bool licenseAccepted)
//{
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;

//    do
//    {
//        if (!licenseAccepted)
//        {
//            statusCode = status_agreement_unaccepted;
//            break;
//        }

//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("ActivateUser function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        UserCredentials uc;
//        statusCode = AuthLogic::checkLoginPassword(login, oldPassword, uc);

//        if(uc.user_id>0 && statusCode == status_user_is_dummy)
//        {
//            uc.password = newPassword;
//            uc.secret_question = secretQuestion;
//            uc.secret_answer = secretAnswer;
//            uc.is_dummy = false;
//            uc.license_accepted = licenseAccepted;
//            statusCode = updateUserCredentials(oldPassword, uc);

//            if (statusCode != status_success)
//            {
//                break;
//            }

//            statusCode = UserManagerPgSql::updateUserProfile(login,login,firstName,lastName,"");

//            if (statusCode != status_success)
//            {
//                break;
//            }

//        }
//        else if (uc.user_id > 0)
//        {
//            statusCode = status_already_exist;
//            break;
//        }

//        {
//            int64_t companyId = -1;
//            statusCode = CompanyManagerPgSql::create_company(uc.user_id, uc.login, "Personal account "+uc.login, true, companyId);

//            if (statusCode != status_success)
//            {
//                LOG_INFORMATION("Could not create personal company for %s", uc.login.c_str());
//                break;
//            }

//            statusCode = CompanyManagerPgSql::create_user_in_company(uc.user_id, uc.login, companyId, 1, "Company creator");
//        }

//        if (statusCode == status_success)
//        {
//            FirstFolderCreator::create_first_folder(login,newPassword,uc.public_key);
//        }

//        if (statusCode==status_success)
//        {
//            bStatus = true;
//        }
//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("ActivateUser function ended: [%s] : [%s] : [%s]",login.c_str(),firstName.c_str(),lastName.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("ActivateUser function failed: login [%s]", login.c_str());
//    }

//    return statusCode;
//}

//rpc_status_code AuthLogic::changePassword(RequestContext& context,
//        const std::string& login,
//        const std::string& oldPassword,
//        const std::string& newPassword)
//{
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;
//    int64_t userId = -1;
//    std::string deviceId;

//    do
//    {
//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("ChangePassword function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        statusCode = HelperLogic::checkSession(context, userId, deviceId);
//        if (statusCode != status_success || userId <= 0 )
//        {
//            statusCode = status_unauthorized;
//            break;
//        }

//        UserCredentials uc;

//        statusCode = AuthLogic::checkLoginPassword(login, oldPassword, uc);
//        if (statusCode != status_success)
//        {
//            break;
//        }

//        uc.password = newPassword;
//        statusCode = AuthLogic::updateUserCredentialsPasswordWithPassword(oldPassword, uc);
//        if (statusCode != status_success)
//        {
//            break;
//        }

//        statusCode = UserManagerPgSql::updateUserCredentials(uc);

//        if (statusCode!=status_success)
//        {
//            break;
//        }
//        bStatus = true;

//        UserInfo userInfo;
//        statusCode = UserManagerPgSql::getUserInfoByUserId(userId, userInfo);
//        EventLogic::accPassChanged(userId, userInfo.login, deviceId, userInfo.user_id);
//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("ChangePassword function ended: [%s]",login.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("ChangePassword function failed: login [%s] status %i", login.c_str(), statusCode);
//    }

//    return statusCode;
//}

//rpc_status_code AuthLogic::changeSecretQA (RequestContext& context,
//        const std::string& login,
//        const std::string& password,
//        const std::string& newSecretQuestion,
//        const std::string& newSecretAnswer)
//{
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;
//    int64_t userId = -1;
//    std::string deviceId;

//    do
//    {
//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("ChangeSecretQA function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        statusCode = HelperLogic::checkSession(context, userId, deviceId);
//        if (statusCode != status_success || userId <= 0 )
//        {
//            statusCode = status_unauthorized;
//            break;
//        }

//        UserCredentials uc;
//        statusCode = AuthLogic::checkLoginPassword(login,password,uc);

//        if (statusCode != status_success)
//        {
//            break;
//        }

//        uc.secret_question = newSecretQuestion;
//        uc.secret_answer   = newSecretAnswer;
//        statusCode = AuthLogic::updateUserCredentialsSecretAnswerWithPassword(password, uc);
//        if (statusCode != status_success)
//        {
//            break;
//        }

//        statusCode = UserManagerPgSql::updateUserCredentials(uc);

//        if (statusCode==status_success)
//        {
//            bStatus = true;
//        }
//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("ChangeSecretQA function ended: [%s]",login.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("ChangeSecretQA function failed: login [%s] status %i", login.c_str(), statusCode);
//    }

//    return statusCode;
//}

rpc_status_code AuthLogic::subscribeEvents(RequestContext& context,
                                           int64_t& userId)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        {
            SessionInfo session;
            statusCode = SessionManagerRedis::get_event_session(context.session_id, context.ip_address, session);

            UserInfo ui;
            statusCode = UserManagerPgSql::getUserInfoByLogin(session.username, ui);
            session.user_id = ui.user_id;
            userId = session.user_id;
        }
        if ( statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }
        bStatus = true;
    }
    while (false);

    if (bStatus)
    {
        LOG_ABSOLUTE("SubscribeEvents function ended: sessionId [%s] : userId [%lli] ", context.session_id.c_str(), userId);
    }
    else
    {
        LOG_INFORMATION("SubscribeEvents function failed: sessionId [%s] : userId [%lli] ", context.session_id.c_str(), userId);
    }

    return statusCode;
}

//rpc_status_code AuthLogic::forgotPassword(RequestContext& context, const std::string& login)
//{
//    int64_t userId = -1;
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;

//    do
//    {
//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("ForgotPassword function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        UserInfo ui;
//        statusCode = UserManagerPgSql::getUserInfoByLogin(login,ui);

//        if (statusCode != status_success)
//        {
//            break;
//        }

//        //salt_pk_password changes after every password change!
//        std::string complex_key = "forgotpassword_"+ui.salt_pk_password + "_" + daemon_params().getSecurityCodesKey();
//        std::string security_code = sha256_hmac_easy_sign(complex_key);

//        //Send e-mail

//        MailerHelper mail;
//        std::string subject = "Password recovery requested";

//        std::string message = "Hello, ";
//        message+= "Dear User!";
//        message+= "\n\n";
//        message+= "You requested password recovery.\n";
//        message+= "Please, follow this link to proceed:\n";
//        message+= "https://www.keepsolid.com/recovery?security_code="+url_encode(security_code)+"&login="+url_encode(login)+"\n";
//        message+= "Your security code is "+security_code+"\n";
//        message+= "\n";
//        message+= "\n ---\n Sincerely yours,\n\t\t File Storage service";

//        mail.get()->set_subject(subject).set_recepient(ui.login).set_text(message);
//        mail.send_non_block();

//        if (statusCode == status_success)
//        {
//            bStatus = true;
//        }

//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("ForgotPassword function ended: login [%s]", login.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("ForgotPassword function failed: login [%s]", login.c_str());
//    }

//    return statusCode;
//}


//rpc_status_code AuthLogic::getSecretQuestion(RequestContext& context, const std::string& login,
//        const std::string& securityCodeIn, std::string& secretQuestion, std::string& securityCodeOut)
//{
//    int64_t userId = -1;
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;

//    do
//    {
//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("GetSecretQuestion function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        UserInfo ui;
//        statusCode = UserManagerPgSql::getUserInfoByLogin(login,ui);

//        if (statusCode != status_success)
//        {
//            break;
//        }

//        {
//            //salt_pk_password changes after every password change!
//            std::string complex_key = "forgotpassword_"+ui.salt_pk_password + "_" + daemon_params().getSecurityCodesKey();
//            bool code_is_good = sha256_hmac_easy_verify(securityCodeIn, complex_key);
//            if (code_is_good == false)
//            {
//                statusCode = status_access_denied;
//                break;
//            }
//        }

//        //salt_pk_password changes after every password change!
//        std::string complex_key = "getsecretquestion_"+ui.salt_pk_password + "_" + daemon_params().getSecurityCodesKey();
//        securityCodeOut = sha256_hmac_easy_sign(complex_key);
//        secretQuestion  = ui.secret_question;

//        if (statusCode == status_success)
//        {
//            bStatus = true;
//        }

//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("GetSecretQuestion function ended: login [%s]", login.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("GetSecretQuestion function failed: login [%s]", login.c_str());
//    }

//    return statusCode;
//}

//rpc_status_code AuthLogic::recoverPassword (RequestContext& context, const std::string& login, const std::string& securityCode,
//        const std::string& secretAnswer, const std::string& newPassword)
//{
//    rpc_status_code statusCode = status_internal_error;
//    bool bStatus = false;
//    int64_t userId = -1;
//    std::string deviceId;

//    do
//    {
//        if (check_email(login) != EXIT_SUCCESS)
//        {
//            statusCode = status_bad_syntax;
//            LOG_ABSOLUTE("RecoverPassword function failed: login [%s] is not valid e-mail ", login.c_str());
//            break;
//        }

//        UserInfo ui;
//        statusCode = UserManagerPgSql::getUserInfoByLogin(login,ui);

//        if (statusCode != status_success)
//        {
//            break;
//        }

//        {
//            //salt_pk_password changes after every password change!
//            std::string complex_key = "getsecretquestion_"+ui.salt_pk_password + "_" + daemon_params().getSecurityCodesKey();
//            bool code_is_good = sha256_hmac_easy_verify(securityCode, complex_key);
//            if (code_is_good == false)
//            {
//                statusCode = status_access_denied;
//                break;
//            }
//        }

//        UserCredentials uc;

//        statusCode = AuthLogic::checkLoginPassword(login, secretAnswer, uc, true);
//        if (statusCode != status_success)
//        {
//            break;
//        }

//        uc.password = newPassword;
//        statusCode = AuthLogic::updateUserCredentialsPasswordWithSecretAnswer(secretAnswer, uc);
//        if (statusCode != status_success)
//        {
//            break;
//        }

//        statusCode = UserManagerPgSql::updateUserCredentials(uc);

//        if (statusCode!=status_success)
//        {
//            break;
//        }
//        bStatus = true;

//        UserInfo userInfo;
//        statusCode = UserManagerPgSql::getUserInfoByUserId(userId, userInfo);
//        EventLogic::accPassChanged(userId, userInfo.login, deviceId, userInfo.user_id);
//    }
//    while(false);

//    if (bStatus)
//    {
//        LOG_ABSOLUTE("RecoverPassword function ended: [%s]",login.c_str());
//    }
//    else
//    {
//        LOG_INFORMATION("RecoverPassword function failed: login [%s] status %i", login.c_str(), statusCode);
//    }

//    return statusCode;
//}

//rpc_status_code AuthLogic::logout(RequestContext& context)
//{
//    rpc_status_code statusCode = SessionManagerPgSql::remove_session(context.session_id);
//    return statusCode;
//}


rpc_status_code AuthLogic::createDummyUserWithCredentials(UserCredentials& uc)
{
    rpc_status_code statusCode = status_internal_error;

    do
    {
        std::string password_salted_pk;
        std::string original_password   = uc.password;

        uc.password        = sha256_pbkdf2_password_generate(original_password,uc.salt_password,pbkdf2_cycles);
        password_salted_pk = sha256_pbkdf2_password_generate(original_password,uc.salt_pk_password,pbkdf2_cycles);

        std::string answer_salted_pk;
        std::string original_answer     = uc.secret_answer;

        if (!original_answer.empty())
        {
            uc.secret_answer   = sha256_pbkdf2_password_generate(original_answer,uc.salt_answer,pbkdf2_cycles);
            answer_salted_pk   = sha256_pbkdf2_password_generate(original_answer,uc.salt_pk_answer,pbkdf2_cycles);
        }

        std::string public_key;
        std::vector<std::string> passwords, private_keys;
        passwords.push_back(password_salted_pk);
        if (!original_answer.empty())
        {
            passwords.push_back(answer_salted_pk);
        }

        if (!rsa_generate_keys(passwords,private_keys,public_key,rsa_key_length))
        {
            LOG_ERROR("Problem generating keys for user %s",uc.login.c_str());
            break;
        }

        LOG_INFORMATION("Generated %zi private keys",private_keys.size());

        if (public_key.empty() || private_keys[0].empty() || (!original_answer.empty() && private_keys[1].empty()))
        {
            LOG_ERROR("Keys for user %s are BROKEN!!!", uc.login.c_str());
            break;
        }

        uc.public_key          = public_key;
        uc.private_key         = private_keys[0];
        uc.private_key_answer  = original_answer.empty() ? "" : private_keys[1];

        statusCode = UserManagerPgSql::createDummyUser(uc);
    }
    while (false);

    return statusCode;
}

rpc_status_code AuthLogic::checkLoginPassword(const std::string& login, const std::string& password, UserCredentials& uc, bool checkSecretAnswer /*=false*/)
{
    rpc_status_code statusCode = status_internal_error;
    do
    {
        statusCode = UserManagerPgSql::getCredentialsByLogin(login, uc);
        if (statusCode != status_success)
        {
            LOG_ABSOLUTE("User %s does not exist?",login.c_str());
            statusCode = status_login_failure;
            break;
        }

        bool isGoodPassword = false;

        if (checkSecretAnswer == false)
        {
            isGoodPassword = sha256_pbkdf2_verify(uc.password, password, uc.salt_password);
        }
        else
        {
            isGoodPassword = sha256_pbkdf2_verify(uc.secret_answer, password, uc.salt_answer);
        }

        if (isGoodPassword == true)
        {
            statusCode = status_success;
            if (!uc.license_accepted)
            {
                LOG_ABSOLUTE("User %s agreement not accepted",login.c_str());
                statusCode = status_agreement_unaccepted;
            }
            if (!uc.is_activated)
            {
                LOG_ABSOLUTE("User %s not activated",login.c_str());
                statusCode = status_user_not_activated;
            }
            if (uc.is_dummy)
            {
                LOG_ABSOLUTE("User %s is dummy",login.c_str());
                statusCode = status_user_is_dummy;
            }
        }
        else
        {
            statusCode = status_login_failure;
        }
    }
    while (false);

    return statusCode;
}

rpc_status_code AuthLogic::updateUserCredentials(const std::string& oldPassword, UserCredentials& uc)
{
    rpc_status_code statusCode = status_internal_error;

    do
    {
        //Get derived key from user's OLD password
        std::string old_privateKey, old_password_salted_pk;
        old_privateKey = uc.private_key;
        old_password_salted_pk = sha256_pbkdf2_password_stretch(oldPassword,uc.salt_pk_password);

        //Generate new derived keys from user's NEW password
        std::string password_salted_pk;
        std::string original_password   = uc.password;
        uc.password        = sha256_pbkdf2_password_generate(original_password,uc.salt_password,pbkdf2_cycles);
        password_salted_pk = sha256_pbkdf2_password_generate(original_password,uc.salt_pk_password,pbkdf2_cycles);

        //Generate new derived keys from user's NEW Secret Answer
        std::string answer_salted_pk;
        std::string original_answer     = uc.secret_answer;
        uc.secret_answer   = sha256_pbkdf2_password_generate(original_answer,uc.salt_answer,pbkdf2_cycles);
        answer_salted_pk   = sha256_pbkdf2_password_generate(original_answer,uc.salt_pk_answer,pbkdf2_cycles);

        if (!rsa_encode_private_keys(old_password_salted_pk, old_privateKey, password_salted_pk, uc.private_key))
        {
            LOG_ERROR("Problem reencrypting private_keys for user %s", uc.login.c_str());
            break;
        }
        if (!rsa_encode_private_keys(old_password_salted_pk, old_privateKey, answer_salted_pk, uc.private_key_answer))
        {
            LOG_ERROR("Problem reencrypting private_keys for user %s", uc.login.c_str());
            break;
        }

        if (uc.private_key.empty() || uc.private_key_answer.empty())
        {
            LOG_ERROR("Got empty keys for user %lli %s", uc.user_id, uc.login.c_str());
            break;
        }

        statusCode = UserManagerPgSql::updateUserCredentials(uc);
    }
    while (false);

    return statusCode;
}

rpc_status_code AuthLogic::updateUserCredentialsPasswordWithPassword(const std::string& oldPassword, UserCredentials& uc)
{
    rpc_status_code statusCode = status_internal_error;

    do
    {
        //Get derived key from user's OLD password
        std::string old_privateKey, old_password_salted_pk;
        old_privateKey = uc.private_key;
        old_password_salted_pk = sha256_pbkdf2_password_stretch(oldPassword, uc.salt_pk_password);

        //Generate new derived keys from user's NEW password
        std::string password_salted_pk;
        std::string original_password   = uc.password;
        uc.password        = sha256_pbkdf2_password_generate(original_password, uc.salt_password,pbkdf2_cycles);
        password_salted_pk = sha256_pbkdf2_password_generate(original_password, uc.salt_pk_password,pbkdf2_cycles);

        if (!rsa_encode_private_keys(old_password_salted_pk, old_privateKey, password_salted_pk, uc.private_key))
        {
            LOG_ERROR("Problem reencrypting private_keys for user %s", uc.login.c_str());
            break;
        }

        if (uc.private_key.empty())
        {
            LOG_ERROR("Got empty keys for user %lli %s", uc.user_id, uc.login.c_str());
            break;
        }

        statusCode = status_success;
    }
    while (false);

    return statusCode;
}

rpc_status_code AuthLogic::updateUserCredentialsPasswordWithSecretAnswer(const std::string& secretAnswer, UserCredentials& uc)
{
    rpc_status_code statusCode = status_internal_error;

    do
    {
        //Get derived key from user's OLD secret answer
        std::string old_privateKey, old_answer_salted_pk;
        old_privateKey = uc.private_key_answer;
        old_answer_salted_pk = sha256_pbkdf2_password_stretch(secretAnswer, uc.salt_pk_answer);

        //Generate new derived keys from user's NEW password
        std::string password_salted_pk;
        std::string original_password   = uc.password;
        uc.password        = sha256_pbkdf2_password_generate(original_password, uc.salt_password,pbkdf2_cycles);
        password_salted_pk = sha256_pbkdf2_password_generate(original_password, uc.salt_pk_password,pbkdf2_cycles);

        if (!rsa_encode_private_keys(old_answer_salted_pk, old_privateKey, password_salted_pk, uc.private_key))
        {
            LOG_ERROR("Problem reencrypting private_keys for user %s", uc.login.c_str());
            break;
        }

        if (uc.private_key.empty())
        {
            LOG_ERROR("Got empty keys for user %lli %s", uc.user_id, uc.login.c_str());
            break;
        }

        statusCode = status_success;
    }
    while (false);

    return statusCode;
}

rpc_status_code AuthLogic::updateUserCredentialsSecretAnswerWithPassword(const std::string& oldPassword, UserCredentials& uc)
{
    rpc_status_code statusCode = status_internal_error;

    do
    {
        //Get derived key from user's OLD password
        std::string old_privateKey, old_password_salted_pk;
        old_privateKey = uc.private_key;
        old_password_salted_pk = sha256_pbkdf2_password_stretch(oldPassword, uc.salt_pk_password);

        //Generate new derived keys from user's NEW Secret Answer
        std::string answer_salted_pk;
        std::string original_answer     = uc.secret_answer;
        uc.secret_answer   = sha256_pbkdf2_password_generate(original_answer, uc.salt_answer,pbkdf2_cycles);
        answer_salted_pk   = sha256_pbkdf2_password_generate(original_answer, uc.salt_pk_answer,pbkdf2_cycles);

        if (!rsa_encode_private_keys(old_password_salted_pk, old_privateKey, answer_salted_pk, uc.private_key_answer))
        {
            LOG_ERROR("Problem reencrypting private_keys for user %s", uc.login.c_str());
            break;
        }

        if (uc.private_key_answer.empty())
        {
            LOG_ERROR("Got empty keys for user %lli %s", uc.user_id, uc.login.c_str());
            break;
        }

        statusCode = status_success;
    }
    while (false);

    return statusCode;
}
