/*
 * SimplexNotifications.cpp
 *
 *  Created on: Mar 26, 2014
 *      Author: fireballdark
 */

#include "SimplexNotificationSender.h"
#include <network/CurlUploaderLight.h>
#include <network/PrivateBridge.h>
#include "db/simplex_notif/SimplexNotificationsPgSql.h"
#include <util/logging.h>
#include <boost/lexical_cast.hpp>
#include <sutil/logging.h>
#include "conf/Globals.h"

bool SimplexNotificationSender::send_non_block(RequestContext context, SimplexNotification notification)
{
    auto f = [=]() {
        SimplexNotificationSender::send_block(context, notification);
    };
    Globals::get_globals().getThreadPoolSecondary().schedule(f);
    return true;
}

bool SimplexNotificationSender::send_block(RequestContext context, SimplexNotification notification)
{
    bool result = false;
    rpc_status_code statusCode = status_internal_error;

    do
    {
        KeyValueMap sx_params;
        std::string service_name;
        statusCode = SimplexNotificationsPgSql::get_params(notification.get_notification_name(), context.service_type, service_name, sx_params);

        if (statusCode != status_success)
        {
            LOG_INFORMATION("Bad search for notification [%s] service [%lli]", notification.get_notification_name().c_str(), context.service_type);
            break;
        }

        notification.set_service_name(service_name);
        notification.set_session(context.session_id);

        try
        {
            for (auto notif : sx_params)
            {
                std::string send_method = notif.first;
                LOG_INFORMATION("SEND METHOD IS [%s]", notif.first.c_str());

                std::string address     = notif.second["address"];
                std::string auth        = notif.second["auth"];
                std::string message_id  = notif.second[notification.get_notification_name()];

                KeyValue outer;
                KeyValue inner;
                bool gen_result = false;
                if (send_method.compare("email") == 0)
                {
                    notification.set_mail_id(message_id);
                    gen_result = notification.generate_email_notification(outer, inner);
                }
                else if (send_method.compare("social") == 0)
                {
                    notification.set_social_id(message_id);
                    gen_result = notification.generate_social_notification(outer, inner);
                }
                else if (send_method.compare("apple-push") == 0)
                {
                    notification.set_push_id(message_id);
                    gen_result = notification.generate_push_notification(outer, inner);
                }
                else
                {
                    LOG_ERROR("Unknown method [%s]", send_method.c_str());
                }

                if (gen_result == true)
                {
                    KeyValue params_packed;
                    result = PrivateBridge::packDataNormal(outer, inner, auth, params_packed);
                    if (result == false)
                    {
                        LOG_ERROR("Problem packing data for notif [%s]", notification.get_notification_name().c_str());
                        continue;
                    }

                    std::string response;
                    CurlUploaderLight::get_thread_local_ptr().set_check_ssl(false);
                    result = CurlUploaderLight::get_thread_local_ptr().post_request_base64(address, params_packed, response, "");
                    LOG_INFORMATION("Response for [%s] is [%s]", send_method.c_str(), response.c_str());
                }
            }

        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Could not get notification params for Simplex service [%lli], type [%s], error [%s]",
                    context.service_type, notification.get_notification_name().c_str(), e.what());
            break;
        }
    }
    while(false);

    return result;
}
