/*
 * FolderInvitesPgSql.cpp
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#include "EmailTemplatesPgSql.h"
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <sutil/logging.h>
#include "db/PgSqlHelper.h"


rpc_status_code EmailTemplatesPgSql::get_template(int64_t userId, const std::string& templateName, std::string& sender, std::string& subject, std::string& text, std::string& html)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getEmailTemplate"))
            {
                pg_connection->prepare  ("getEmailTemplate",
                                         "SELECT sender, subject, text, html FROM EmailTemplates "
                                         "WHERE templateName = $1 ORDER BY templateId DESC LIMIT 1;");
            }
            pqxx::work pg_transaction(*pg_connection, "getEmailTemplate");
            pqxx::result query_result = pg_transaction.prepared("getEmailTemplate")(templateName).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            sender       = query_result.begin()["sender"].as<std::string>();
            subject      = query_result.begin()["subject"].as<std::string>();
            text         = query_result.begin()["text"].as<std::string>();
            html         = query_result.begin()["html"].as<std::string>();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query email template data for template name %s err: %s",templateName.c_str(),e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}






