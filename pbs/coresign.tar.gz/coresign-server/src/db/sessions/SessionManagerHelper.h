#ifndef SESSIONMANAGERHELPER_H
#define SESSIONMANAGERHELPER_H

#include <db/RedisConnection.h>
#include "types/user_info.h"
#include "types/request_context.h"

bool convert_sessioninfo_db(Redis::redisMap& query_result, SessionInfo& session);

#endif // SESSIONMANAGERHELPER_H
