/*
 * EventManagerPgSql.cpp
 *
 *  Created on: May 19, 2011
 *      Author: fireball
 */

#include "EventManagerPgSql.h"
#include <sutil/logging.h>
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <cstdlib>
#include <cstdio>
#include "db/PgSqlHelper.h"


rpc_status_code EventManagerPgSql::listEventsForUser(int64_t user_id, int64_t lastEventId, int64_t eventsLimit, EventsList& eventsList)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getEventsInfoForUser"))
            {
                pg_connection->prepare  ("getEventsInfoForUser",
                                         "SELECT event_id, event_type, user_id, login, Events.workgroup_id, file_id, parent_id, EXTRACT(EPOCH FROM event_date) AS event_date_unix, event_date, data1, data2, data3, data4, device_id FROM Events "
                                         "WHERE event_id>=$2 AND ( recipient_id = $1 OR hard_recipient_id = $1 ) "
                                         "UNION "
                                         "SELECT event_id, event_type, user_id, login, Events.workgroup_id, file_id, parent_id, EXTRACT(EPOCH FROM event_date) AS event_date_unix, event_date, data1, data2, data3, data4, device_id FROM Events "
                                         "INNER JOIN  "
                                         "(SELECT workgroup_id, is_deleted FROM WorkGroupsAccess WHERE user_id=$1 AND invite_accepted=true AND is_deleted = false) AS dummytable ON dummytable.workgroup_id=Events.workgroup_id "
                                         "WHERE event_id>=$2 AND hard_recipient_id = 0 "
                                         "ORDER BY event_id ASC "
                                         "LIMIT $3;"
                                        );
            }

            pqxx::work pg_transaction(*pg_connection, "GetEventsInfoForUser");
            pqxx::result query_result = pg_transaction.prepared("getEventsInfoForUser")(user_id)(lastEventId+1)(eventsLimit).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                Event ev;
                ev.event_id    = iter["event_id"].as<int64_t>();
                ev.event_type_v  = (event_type)iter["event_type"].as<int>();
                ev.login   = iter["login"].is_null() ? "NULL" : iter["login"].as<std::string>();
                ev.workgroup_id   = iter["workgroup_id"].is_null() ? 0 : iter["workgroup_id"].as<int64_t>();
                ev.file_id     = iter["file_id"].is_null() ? 0 : iter["file_id"].as<int64_t>();
                ev.parent_id   = iter["parent_id"].is_null() ? 0 : iter["parent_id"].as<int64_t>();
                ev.event_date  = (int64_t)iter["event_date_unix"].as<double>();
                ev.event_date_str= iter["event_date"].as<std::string>();
                ev.data1      = iter["data1"].is_null() ? "NULL" : iter["data1"].as<std::string>();
                ev.data2      = iter["data2"].is_null() ? "NULL" : iter["data2"].as<std::string>();
                ev.data3      = iter["data3"].is_null() ? "NULL" : iter["data3"].as<std::string>();
                ev.path       = iter["data4"].is_null() ? "NULL" : iter["data4"].as<std::string>();
                ev.device_id   = iter["device_id"].is_null() ? "NULL" : iter["device_id"].as<std::string>();

                //LOG_ABSOLUTE("Event n%lli user %s folder %lli path %s device %s",ev.event_id,ev.login.c_str(),ev.workgroup_id,ev.path.c_str(),ev.device_id.c_str());

                eventsList.push_back(ev);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query events for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code EventManagerPgSql::listEventsForUserReverse(int64_t user_id, int64_t lastEventId, int64_t eventsLimit, EventsList& eventsList)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getEventsInfoForUserReverse"))
            {
                pg_connection->prepare  ("getEventsInfoForUserReverse",
                                         "SELECT event_id, event_type, user_id, login, Events.workgroup_id, file_id, parent_id, EXTRACT(EPOCH FROM event_date) AS event_date_unix, event_date, data1, data2, data3, data4, device_id FROM Events "
                                         "WHERE event_id<=$2 AND ( recipient_id = $1 OR hard_recipient_id = $1 ) "
                                         "UNION "
                                         "SELECT event_id, event_type, user_id, login, Events.workgroup_id, file_id, parent_id, EXTRACT(EPOCH FROM event_date) AS event_date_unix, event_date, data1, data2, data3, data4, device_id FROM Events "
                                         "INNER JOIN  "
                                         "(SELECT workgroup_id, is_deleted FROM WorkGroupsAccess WHERE user_id=$1 AND invite_accepted=true AND is_deleted = false) AS dummytable ON dummytable.workgroup_id=Events.workgroup_id "
                                         "WHERE event_id<=$2 AND hard_recipient_id = 0 "
                                         "ORDER BY event_id DESC "
                                         "LIMIT $3;"
                                        );
            }

            pqxx::work pg_transaction(*pg_connection, "GetEventsInfoForUserReverse");
            pqxx::result query_result = pg_transaction.prepared("getEventsInfoForUserReverse")(user_id)(lastEventId-1)(eventsLimit).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                Event ev;
                ev.event_id    = iter["event_id"].as<int64_t>();
                ev.event_type_v  = (event_type)iter["event_type"].as<int>();
                ev.login   = iter["login"].is_null() ? "NULL" : iter["login"].as<std::string>();
                ev.workgroup_id   = iter["workgroup_id"].is_null() ? 0 : iter["workgroup_id"].as<int64_t>();
                ev.file_id     = iter["file_id"].is_null() ? 0 : iter["file_id"].as<int64_t>();
                ev.parent_id   = iter["parent_id"].is_null() ? 0 : iter["parent_id"].as<int64_t>();
                ev.event_date  = (int64_t)iter["event_date_unix"].as<double>();
                ev.event_date_str= iter["event_date"].as<std::string>();
                ev.data1      = iter["data1"].is_null() ? "NULL" : iter["data1"].as<std::string>();
                ev.data2      = iter["data2"].is_null() ? "NULL" : iter["data2"].as<std::string>();
                ev.data3      = iter["data3"].is_null() ? "NULL" : iter["data3"].as<std::string>();
                ev.path       = iter["data4"].is_null() ? "NULL" : iter["data4"].as<std::string>();
                ev.device_id   = iter["device_id"].is_null() ? "NULL" : iter["device_id"].as<std::string>();

                //LOG_ABSOLUTE("Event n%lli user %s folder %lli path %s device %s",ev.event_id,ev.login.c_str(),ev.workgroup_id,ev.path.c_str(),ev.device_id.c_str());

                eventsList.push_back(ev);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query events for user %lli err: %s",user_id,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}


rpc_status_code EventManagerPgSql::listEventsForUserReverseLast(int64_t user_id, int64_t eventsLimit, EventsList& eventsList)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getEventsInfoForUserReverseLast"))
            {
                pg_connection->prepare  ("getEventsInfoForUserReverseLast",
                                         "SELECT event_id, event_type, user_id, login, Events.workgroup_id, file_id, parent_id, EXTRACT(EPOCH FROM event_date) AS event_date_unix, event_date, data1, data2, data3, data4, device_id FROM Events "
                                         "WHERE recipient_id = $1 OR hard_recipient_id = $1  "
                                         "UNION "
                                         "SELECT event_id, event_type, user_id, login, Events.workgroup_id, file_id, parent_id, EXTRACT(EPOCH FROM event_date) AS event_date_unix, event_date, data1, data2, data3, data4, device_id FROM Events "
                                         "INNER JOIN  "
                                         "(SELECT workgroup_id, is_deleted FROM WorkGroupsAccess WHERE user_id=$1 AND invite_accepted=true AND is_deleted = false) AS dummytable ON dummytable.workgroup_id=Events.workgroup_id "
                                         "WHERE hard_recipient_id = 0 "
                                         "ORDER BY event_id DESC "
                                         "LIMIT $2;"
                                        );
            }

            pqxx::work pg_transaction(*pg_connection, "GetEventsInfoForUserReverseLast");
            pqxx::result query_result = pg_transaction.prepared("getEventsInfoForUserReverseLast")(user_id)(eventsLimit).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                Event ev;
                ev.event_id    = iter["event_id"].as<int64_t>();
                ev.event_type_v  = (event_type)iter["event_type"].as<int>();
                ev.login   = iter["login"].is_null() ? "NULL" : iter["login"].as<std::string>();
                ev.workgroup_id   = iter["workgroup_id"].is_null() ? 0 : iter["workgroup_id"].as<int64_t>();
                ev.file_id     = iter["file_id"].is_null() ? 0 : iter["file_id"].as<int64_t>();
                ev.parent_id   = iter["parent_id"].is_null() ? 0 : iter["parent_id"].as<int64_t>();
                ev.event_date  = (int64_t)iter["event_date_unix"].as<double>();
                ev.event_date_str= iter["event_date"].as<std::string>();
                ev.data1      = iter["data1"].is_null() ? "NULL" : iter["data1"].as<std::string>();
                ev.data2      = iter["data2"].is_null() ? "NULL" : iter["data2"].as<std::string>();
                ev.data3      = iter["data3"].is_null() ? "NULL" : iter["data3"].as<std::string>();
                ev.path       = iter["data4"].is_null() ? "NULL" : iter["data4"].as<std::string>();
                ev.device_id   = iter["device_id"].is_null() ? "NULL" : iter["device_id"].as<std::string>();

                //LOG_ABSOLUTE("Event n%lli user %s folder %lli path %s device %s",ev.event_id,ev.login.c_str(),ev.workgroup_id,ev.path.c_str(),ev.device_id.c_str());

                eventsList.push_back(ev);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query events for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code EventManagerPgSql::createEvent(event_type event_type, int64_t user_id, const std::string& login, const std::string& device_id, int64_t workgroup_id, int64_t file_id, int64_t parent_id, const std::string& data1, const std::string& data2, const std::string& data3, const std::string& path, int64_t recipient_id/* = 0*/, int64_t hard_recipient_id/* = 0*/)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("createEvent"))
            {
                pg_connection->prepare  ("createEvent",
                                         "INSERT INTO Events(event_type, user_id, workgroup_id, file_id, parent_id, "
                                         "data1, data2, data3, data4, login, device_id, recipient_id, hard_recipient_id) "
                                         "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING event_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "createEvent");
            pqxx::result query_result = pg_transaction.prepared("createEvent")((int)event_type)(user_id)(workgroup_id)(file_id)(parent_id)(data1)(data2)(data3)(path)(login)(device_id)(recipient_id)(hard_recipient_id).exec();

            if (!query_result.size())
            {
                LOG_ERROR("Failure: trying to create event user %lli", user_id);
                break;
            }

            int64_t event_id;
            query_result.begin()["event_id"].to(event_id);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to create event for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}




