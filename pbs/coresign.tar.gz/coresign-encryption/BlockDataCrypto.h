/*
 * BlockFileCrypto.h
 *
 *  Created on: May 19, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>
#include <openssl/engine.h>
#include "xopenssl_types.h"
#include "KSFileSignature.h"

namespace KSD
{

class BlockDataEncrypt
{
public:
    explicit BlockDataEncrypt(bool need_result_hash);
    ~BlockDataEncrypt();

    //step one      - initialize encryption algo
    xopenssl_status init        ( const std::string& password );
    //step two      - iterate through all file contents
    xopenssl_status update      ( const unsigned char* buffer_in, int in_size, unsigned char* buffer_out, int& out_size );
    //step three    - get final encrypted data block
    xopenssl_status finalize    ( unsigned char* buffer_out, int& out_size );
    //step four     - get final file signature
    xopenssl_status signature   ( std::string& signature, std::string& result_hash );

private:
    EVP_CIPHER_CTX          _cipher_ctx;
    EVP_MD_CTX              _md_ctx_original;
    EVP_MD_CTX              _md_ctx_encrypted;

    uint64_t                _total_read;
    uint64_t                _total_wrote;

    bool                    _need_result_hash;

    KSD::KSFileSignature    _signature;
};

class BlockDataDecrypt
{
public:
    BlockDataDecrypt();
    ~BlockDataDecrypt();

    //step one      - initialize encryption algo
    xopenssl_status init        ( const std::string& password, const std::string& signature );
    //step two      - iterate through all file contents
    xopenssl_status update      ( const unsigned char* buffer_in, int in_size, unsigned char* buffer_out, int& out_size );
    //step three    - get final encrypted data block
    xopenssl_status finalize    ( unsigned char* buffer_out, int& out_size );

    const KSD::KSFileSignature& get_signature() {return _signature;}

private:
    EVP_CIPHER_CTX          _cipher_ctx;
    EVP_MD_CTX              _md_ctx_original;

    uint64_t                _total_read;
    uint64_t                _total_wrote;

    KSD::KSFileSignature    _signature;
};


} /* namespace KSD */
