/*
 * UserManagerHelper.h
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */

#ifndef USERMANAGERHELPER_H_
#define USERMANAGERHELPER_H_

#include <pqxx/result.hxx>
#include "types/user_info.h"

#define GET_USER_INFO " user_id, login, email, first_name, last_name, public_key, private_key, salt_pk_password, user_pic, secret_question, is_activated, is_dummy, license_accepted, is_tutorialated, EXTRACT(EPOCH FROM registration_date)::bigint AS registration_date, EXTRACT(EPOCH FROM expiration_date)::bigint AS expiration_date "

void convert_userinfo_db        (const pqxx::result::const_iterator& query_result, UserInfo& ui);


#define GET_USER_CREDENTIALS " user_id, login, password, salt_password, secret_question, secret_answer, salt_answer, public_key, private_key, private_key_answer, salt_pk_password, salt_pk_answer, is_activated, is_dummy, license_accepted, encrypted_external_password "

void convert_usercredentials_db (const pqxx::result::const_iterator& query_result, UserCredentials& ui);

#endif /* USERMANAGERHELPER_H_ */
