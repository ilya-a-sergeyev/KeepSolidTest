#pragma once

#include <cstdint>
#include <util/endian.h>

class TransportFlagsHelper
{
public:
    TransportFlagsHelper():
        _transport_size(0),
        _transport_flags(0)
    {
    }

    enum TransportFlags : int
    {
        no_flags_set    = 0x0,                                //

        use_ksv2_format = 0x1,      //  1       // 2^0        //support KeepSolid V2 protocol with signatures
        reserved2       = 0x2,      //  2       // 2^1
        reserved4       = 0x4,      //  4       // 2^2
        reserved8       = 0x8,      //  8       // 2^3

        reserved16      = 0x10,     //  16      // 2^4
        reserved32      = 0x20,     //  32      // 2^5
        reserved64      = 0x40,     //  64      // 2^6
        reserved128     = 0x80,     //  128     // 2^7

        reserved256     = 0x100,    //  256     // 2^8
        reserved512     = 0x200,    //  512     // 2^9
        reserved1024    = 0x400,    //  1024    // 2^10
        reserved2048    = 0x800,    //  2048    // 2^11
        reserved4096    = 0x1000,   //  4096    // 2^12

        reserved8192    = 0x2000,   //  8192    // 2^13
        reserved16384   = 0x4000,   //  16384   // 2^14
        reserved32768   = 0x8000,   //  32768   // 2^15
        reserved65535   = 0x10000,  //  65535   // 2^16

        reserved_big    = 0x0fffffff   //
    };

    void init_with_transport_data (const int64_t& data)
    {
        data = le64toh_p(data);
        _transport_size = (int32_t)data;
        _transport_flags = (int32_t)(data >> 32);
    }

    int64_t get_transport_data () const
    {
        int64_t transport = ((int64_t)_transport_size) | ((int64_t)_transport_flags) << 32;
        transport = htole64_p(transport);
        return transport;
    }

    int32_t get_size               () const  {return _transport_size;}
    bool    get_use_ksv2_format    () const  {return (_transport_flags&use_ksv2_format) != 0;}

    void    set_size               (int32_t size){_transport_size = size;}
    void    set_no_flags_set       ()  { _transport_flags=no_flags_set; }
    void    set_use_ksv2_format    (bool value)  {if (value) { _transport_flags|=use_ksv2_format; } else { _transport_flags&=~use_ksv2_format; }}

private:
    int32_t   _transport_size;
    int32_t   _transport_flags;
};
