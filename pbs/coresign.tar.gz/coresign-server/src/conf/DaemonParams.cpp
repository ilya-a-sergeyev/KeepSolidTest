/*
 * DaemonParams.cpp
 *
 *  Created on: 4 трав. 2011
 *      Author: fireball
 */

#include "DaemonParams.h"
#include "daemon_config.h"

DaemonParams&    daemon_params()
{
    return DaemonParams::get_daemon_params();
}

WorkerModel parse_worker_model(const char* worker_model)
{
    WorkerModel temp_worker = UNDEFINED_Worker;

    do
    {
        if (!worker_model)
        {
            break;
        }

        if (strncasecmp(worker_model,"Single_thread",13) == 0)
        {
            temp_worker = Single_Thread;
        }
        else if (strncasecmp(worker_model,"Pthreads",13) == 0)
        {
            temp_worker = Pthreads;
        }
        else if (strncasecmp(worker_model,"Processes",13) == 0)
        {
            temp_worker = Processes;
        }
    }
    while(false);

    if (temp_worker == UNDEFINED_Worker)
    {
        fprintf(stderr,"EvXML: Unknown worker model '%s'\n",worker_model);
    }
    else
    {
        fprintf(stderr,"Worker model %s\n", worker_model);
    }
    return temp_worker;
}

RPCVariant parse_rpc_variant(const char* rpc_variant)
{
    RPCVariant temp_rpc = UNDEFINED_RPC;

    do
    {
        if (!rpc_variant)
        {
            break;
        }

        if (strncasecmp(rpc_variant,"Echo",8) == 0)
        {
            temp_rpc = ECHO_TCP;
        }
        else if (strncasecmp(rpc_variant,"XMLRPC_HTTP",8) == 0)
        {
            temp_rpc = XMLRPC_HTTP;
        }
        else if (strncasecmp(rpc_variant,"XMLRPC_TCP",8) == 0)
        {
            temp_rpc = XMLRPC_TCP;
        }
        else if (strncasecmp(rpc_variant,"PROTOBUF_ZMQ",12) == 0)
        {
            temp_rpc = PROTOBUF_ZMQ;
        }
        else if (strncasecmp(rpc_variant,"PROTOBUF_ASIO",13) == 0)
        {
            temp_rpc = PROTOBUF_ASIO;
        }

    }
    while(false);

    if (temp_rpc == UNDEFINED_RPC)
    {
        fprintf(stderr,"EvXML: Unknown RPC variant '%s'\n",rpc_variant);
    }
    else
    {
        fprintf(stderr,"RPC variant %s\n", rpc_variant);
    }
    return temp_rpc;
}

DaemonParams::DaemonParams():
    confFilePath(DEFAULT_CONFIG_FILE),
    listenPort(-1),
    redirectPort(-1),
    notificationEmitPort(-1),
    notificationRegPort(-1),
    daemonize(-1),
    workerPoolSize(-1),
    maxWorkers(-1),
    emailEnabled(-1),
    amazonS3Expiration(-1),
    timersEnabled(-1),
    requestMaxSize(-1),
    connectionTimeout(-1)
{

}

int DaemonParams::initWithDefaults()
{
    logFilePath.    empty() ? logFilePath       = DEFAULT_LOGFILE_PATH      : logFilePath ;
    listenAddress.  empty() ? listenAddress     = DEFAULT_ADDRESS           : listenAddress;
    listenPort      == -1   ? listenPort        = DEFAULT_PORT              : listenPort;
    daemonize       == -1   ? daemonize         = DEFAULT_DAEMONIZE         : daemonize;
    workerPoolSize  == -1   ? workerPoolSize    = DEFAULT_WORKERS_POOL_SIZE : workerPoolSize;
    maxWorkers      == -1   ? maxWorkers        = DEFAULT_MAX_WORKERS       : maxWorkers;
    emailEnabled    == -1   ? emailEnabled      = DEFAULT_EMAIL_ENABLED     : emailEnabled;
    amazonS3Expiration== -1 ? amazonS3Expiration= DEFAULT_AMAZON_EXPIRATION : amazonS3Expiration;
    timersEnabled   == -1   ? timersEnabled     = DEFAULT_TIMERS_ENABLED    : timersEnabled;
    requestMaxSize  == -1   ? requestMaxSize    = DEFAULT_REQUEST_MAX_SIZE  : requestMaxSize;
    connectionTimeout== -1  ? connectionTimeout = DEFAULT_CONNECTION_TIMEOUT : connectionTimeout;

    return EXIT_SUCCESS;
}



void DaemonParams::setConfFilePath(const std::string& confFilePath)
{
    this->confFilePath = confFilePath;
}

void DaemonParams::setDaemonize(int daemonize)
{
    this->daemonize = daemonize;
}

void DaemonParams::setEmailEnabled(int email_enabled)
{
    this->emailEnabled = email_enabled;
}

void DaemonParams::setEmailClient(const std::string& email_client)
{
    this->emailClient = email_client;
}

void DaemonParams::setEmailSender(const std::string& email_sender)
{
    this->emailSender = email_sender;
}

void DaemonParams::setAmazonS3Expiration(int amazon_s3_expiration)
{
    this->amazonS3Expiration = amazon_s3_expiration;
}

void DaemonParams::setTimersEnabled(int timers_enabled)
{
    this->timersEnabled = timers_enabled;
}

void DaemonParams::setSecurityCodesKey (const std::string& security_codes)
{
    this->securityCodesKey = security_codes;
}

void DaemonParams::setRequestMaxSize(int requestMaxSize)
{
    this->requestMaxSize = requestMaxSize;
}

void DaemonParams::setConnectionTimeout(int connectionTimeout)
{
    this->connectionTimeout = connectionTimeout;
}

void DaemonParams::setListenAddress(const std::string& listenAddress)
{
    this->listenAddress = listenAddress;
}

void DaemonParams::setListenPort(int listenPort)
{
    this->listenPort = listenPort;
}

void DaemonParams::setRedirectAddress(const std::string& redirectAddress)
{
    this->redirectAddress = redirectAddress;
}

void DaemonParams::setRedirectPort(int redirectPort)
{
    this->redirectPort = redirectPort;
}

void DaemonParams::setNotificationEmitAddress(const std::string& notificationEmitAddress)
{
    this->notificationEmitAddress = notificationEmitAddress;
}

void DaemonParams::setNotificationEmitPort(int notificationEmitPort)
{
    this->notificationEmitPort = notificationEmitPort;
}

void DaemonParams::setNotificationRegAddress(const std::string& notificationRegAddress)
{
    this->notificationRegAddress = notificationRegAddress;
}

void DaemonParams::setNotificationRegPort(int notificationRegPort)
{
    this->notificationRegPort = notificationRegPort;
}

void DaemonParams::setLogFilePath(const std::string& logFilePath)
{
    this->logFilePath = logFilePath;
}

void DaemonParams::setMaxWorkers(int maxWorkers)
{
    this->maxWorkers = maxWorkers;
}

void DaemonParams::setProgramName(const std::string& programName)
{
    this->programName = programName;
}

void DaemonParams::setWorkerPoolSize(int workerPoolSize)
{
    this->workerPoolSize = workerPoolSize;
}



