#include "senderreceiver.h"
#include <util/logging.h>

#if defined(RPC_TRANSLATOR) || defined (FILE_LOADER)
#   define CGI_DEBUG
#   include <sutil/Timer.h>
#   include "../common_cgi/config.h"
#endif

#ifdef STATIC_SENDERRECEIVER
SenderReceiver& SenderReceiver::GetSenderReceiver()
{
    static SenderReceiver rpc(CgiConfig::get_config().get_server_address(),CgiConfig::get_config().get_server_port());
    return rpc;
}
#endif

SenderReceiver::SenderReceiver(const int64_t& serviceId)
    : pTransport()
    , mAddress()
    , mPort()
    , mServiceId(serviceId)
{
}

SenderReceiver::SenderReceiver(const std::string& address, const std::string& port, const int64_t& serviceId)
    : pTransport()
    , mAddress(address)
    , mPort(port)
    , mServiceId(serviceId)
{
    //LOG_INFORMATION("constructor, addr: '%s', port: '%s'", mAddress.c_str(), mPort.c_str());
    pTransport = std::make_shared<AsioRPCTransport>(mAddress,mPort);
    pTransport->start();
}

SenderReceiver::~SenderReceiver()
{
    //LOG_INFORMATION("destructor, addr: '%s', port: '%s'", mAddress.c_str(), mPort.c_str());
}

bool SenderReceiver::call(const google::protobuf::Message* message_params, google::protobuf::Message* message_result)
{
    bool bResult = false;
    std::string data_out;
    std::string data_in;
    rpc::Request request_struct;

    do
    {
        if (!process_request(&request_struct,message_params))
        {
            LOG_ERROR("Error processing request [%s]", message_params->GetDescriptor()->name().c_str());
            break;
        }
#ifdef CGI_DEBUG
        Timer t("SenderReceiver: call");
#endif
        request_struct.set_service_type(mServiceId);
#if defined(DEBUG) || defined(_DEBUG)
        request_struct.set_is_debug(true);
#endif
        try
        {
            request_struct.SerializeToString(&data_out);
        }
        catch (const std::exception& e)
        {
            LOG_INFORMATION("SenderReceiver: Problem serializing request %s",e.what());
            break;
        }

        {
            if (!pTransport)
            {
                LOG_ERROR("SenderReceiver: AsioTransport is not initialized!");
                break;
            }
            std::lock_guard<std::mutex> lock(mutex);

            OperationStatus called = OPSTATUS_UNDEFINED;
            int try_counter = 4;
            do
            {
                called = pTransport->call(data_out, data_in);
                if (called != OPSTATUS_OK)
                {
                    //LOG_INFORMATION("SenderReceiver: Could not readwrite data :(");
                    pTransport = std::make_shared<AsioRPCTransport>(mAddress, mPort);
                    pTransport->start();
                }
            }
            while(--try_counter > 0 && called != OPSTATUS_OK);

            if (called != OPSTATUS_OK)
            {
                break;
            }
        }

        rpc::Response response_struct;
        try
        {
            response_struct.ParseFromString(data_in);
        }
        catch (const std::exception& e)
        {
            LOG_INFORMATION("SenderReceiver: Problem parsing reply [%s]",e.what());
            break;
        }

#if defined(DEBUG) || defined(_DEBUG)
        LOG_INFORMATION("SenderReceiver: received response for [%s]:[%s] -> [%i]",
                        message_params->GetDescriptor()->name().c_str(),
                        response_struct.request_id().c_str(),
                        response_struct.error_code());
        for (int i=0; i< response_struct.error_message_size(); i++)
        {
            LOG_INFORMATION("SenderReceiver: received response [%i]:[%s]", i, response_struct.error_message(i).c_str());
        }
#endif

        try
        {
            bResult = process_response(&response_struct,message_result);
        }
        catch (const std::exception& e)
        {
            LOG_INFORMATION("SenderReceiver: Broken reply structure [%s]",e.what());
            break;
        }

    }
    while (false);

    return bResult;
}

void SenderReceiver::setConnectionParams(const std::string& url, const std::string& port)
{
    do
    {
        if (true == url.empty() || true == port.empty())
        {
            LOG_ERROR("Given url and port are empty!");
            break;
        }

        mAddress = url;
        mPort = port;
        if (!pTransport)
        {
            pTransport = std::make_shared<AsioRPCTransport>(mAddress, mPort);
            pTransport->start();
            break;
        }
        else
        {
            if (0 != mAddress.compare(pTransport->get_address()) || 0 != mPort.compare(pTransport->get_port()))
            {
                LOG_INFORMATION("Create new connection with follow params, url: %s, port: %s", mAddress.c_str(), mPort.c_str());
                pTransport = std::make_shared<AsioRPCTransport>(mAddress, mPort);
                pTransport->start();
                break;
            }
        }
    } while (false);
}

MessageType SenderReceiver::type_by_name(const std::string& name)
{
    switch (name.c_str()[0])
    {
    case 'A':
    {
        if (name.compare("ActivateUserRequest") == 0)
        {
            return RPC_ACTIVATE_USER;
        }
        if (name.compare("AccountStatsRequest") == 0)
        {
            return RPC_ACCOUNT_STATS;
        }
    }
    case 'L':
    {
        if (name.compare("LoginRequest") == 0)
        {
            return RPC_LOGIN;
        }
        else if (name.compare("LogoutRequest") == 0)
        {
            return RPC_LOGOUT;
        }
    }
    case 'C':
    {
        if (name.compare("CreateUserRequest") == 0)
        {
            return RPC_CREATE_USER;
        }
        else if (name.compare("ClientInfoRequest") == 0)
        {
            return RPC_CLIENT_INFO;
        }
        else if (name.compare("ChangePasswordRequest") == 0)
        {
            return RPC_CHANGE_PASSWORD;
        }
        else if (name.compare("ChangeSecretQARequest") == 0)
        {
            return RPC_CHANGE_SECRETQA;
        }
        else if (name.compare("CreateKeyPairRequest") == 0)
        {
            return RPC_CREATE_KEY_PAIR;
        }

        else if (name.compare("CompanyCreateRequest") == 0)
        {
            return RPC_COMPANY_CREATE;
        }
        else if (name.compare("CompanyDeleteRequest") == 0)
        {
            return RPC_COMPANY_DELETE;
        }
        else if (name.compare("CompanyGetInfoRequest") == 0)
        {
            return RPC_COMPANY_GET_INFO;
        }
        else if (name.compare("CompanySetInfoRequest") == 0)
        {
            return RPC_COMPANY_SET_INFO;
        }
        else if (name.compare("CompanyGetTariffRequest") == 0)
        {
            return RPC_COMPANY_GET_TARIFF;
        }
        else if (name.compare("CompanySetTariffRequest") == 0)
        {
            return RPC_COMPANY_SET_TARIFF;
        }
        else if (name.compare("CompanyInviteRequest") == 0)
        {
            return RPC_COMPANY_INVITE;
        }
        else if (name.compare("CompanyChangeRoleRequest") == 0)
        {
            return RPC_COMPANY_CHANGE_ROLE;
        }
        else if (name.compare("CompanyKickUserRequest") == 0)
        {
            return RPC_COMPANY_KICK_USER;
        }
        else if (name.compare("CompanyUsersListRequest") == 0)
        {
            return RPC_COMPANY_USERS_LIST;
        }
        else if (name.compare("CompanyRolesListRequest") == 0)
        {
            return RPC_COMPANY_ROLES_LIST;
        }
        else if (name.compare("CompaniesListRequest") == 0)
        {
            return RPC_COMPANIES_LIST;
        }
    }
    case 'E':
    {
        if (name.compare("EventsListRequest") == 0)
        {
            return RPC_EVENTS_LIST;
        }
    }
    case 'W':
    {
        if (name.compare("WorkGroupsListRequest") == 0)
        {
            return RPC_WORKGROUPS_LIST;
        }
        else if (name.compare("WorkGroupInfoRequest") == 0)
        {
            return RPC_WORKGROUP_INFO;
        }
        else if (name.compare("WorkGroupCoworkersListRequest") == 0)
        {
            return RPC_WORKGROUP_COWORKERS_LIST;
        }
        else if (name.compare("WorkGroupCoworkersAllRequest") == 0)
        {
            return RPC_WORKGROUP_COWORKERS_LIST_ALL;
        }
        else if (name.compare("WorkGroupCoworkersExtraRequest") == 0)
        {
            return RPC_WORKGROUP_COWORKERS_LIST_EXTRA;
        }
        else if (name.compare("WorkGroupCoworkersAllExRequest") == 0)
        {
            return RPC_WORKGROUP_COWORKERS_LIST_ALL_EX;
        }
        else if (name.compare("WorkGroupCreateRequest") == 0)
        {
            return RPC_WORKGROUP_CREATE;
        }
        else if (name.compare("WorkGroupDeleteRequest") == 0)
        {
            return RPC_WORKGROUP_DELETE;
        }
        else if (name.compare("WorkGroupRenameRequest") == 0)
        {
            return RPC_WORKGROUP_RENAME;
        }
        else if (name.compare("WorkGroupInviteRequest") == 0)
        {
            return RPC_WORKGROUP_INVITE;
        }
        else if (name.compare("WorkGroupInvitesListRequest") == 0)
        {
            return RPC_WORKGROUP_INVITES_LIST;
        }
        else if (name.compare("WorkGroupSubscribeRequest") == 0)
        {
            return RPC_WORKGROUP_SUBSCRIBE;
        }
        else if (name.compare("WorkGroupUnsubscribeRequest") == 0)
        {
            return RPC_WORKGROUP_UNSUBSCRIBE;
        }
        else if (name.compare("WorkGroupSetAccessRequest") == 0)
        {
            return RPC_WORKGROUP_SET_ACCESS;
        }
        else if (name.compare("WorkGroupKickUserRequest") == 0)
        {
            return RPC_WORKGROUP_KICK_USER;
        }
        else if (name.compare("WorkGroupUndeleteRequest") == 0)
        {
            return RPC_WORKGROUP_UNDELETE;
        }
        else if (name.compare("WorkGroupMetadataUpdateRequest") == 0)
        {
            return RPC_WORKGROUP_METADATA_UPDATE;
        }
    }
    case 'F':
    {
        if (name.compare("FilesListRequest") == 0)
        {
            return RPC_FILES_LIST;
        }
        else if (name.compare("FileSearchRequest") == 0)
        {
            return RPC_FILE_SEARCH;
        }
        else if (name.compare("FileUploadRequest") == 0)
        {
            return RPC_FILE_UPLOAD;
        }
        else if (name.compare("FileUploadApproveRequest") == 0)
        {
            return RPC_FILE_UPLOAD_APPROVE;
        }
        else if (name.compare("FileDownloadRequest") == 0)
        {
            return RPC_FILE_DOWNLOAD;
        }
        else if (name.compare("FileDirectoryCreateRequest") == 0)
        {
            return RPC_FILE_DIRECTORY_CREATE;
        }
        else if (name.compare("FileDeleteRequest") == 0)
        {
            return RPC_FILE_DELETE;
        }
        else if (name.compare("FileUndeleteRequest") == 0)
        {
            return RPC_FILE_UNDELETE;
        }
        else if (name.compare("FileRenameRequest") == 0)
        {
            return RPC_FILE_RENAME;
        }
        else if (name.compare("FileHistoryRequest") == 0)
        {
            return RPC_FILE_HISTORY;
        }
        else if (name.compare("FileInfoRequest") == 0)
        {
            return RPC_FILE_INFO;
        }
        else if (name.compare("FileDirectoryHierarchyRequest") == 0)
        {
            return RPC_FILE_DIRECTORY_HIERARCHY;
        }
        else if (name.compare("ForgotPasswordRequest") == 0)
        {
            return RPC_FORGOT_PASSWORD;
        }
    }
    case 'G':
    {
        if (name.compare("GetMyDataRequest") == 0)
        {
            return RPC_GET_MY_DATA;
        }
        else if (name.compare("GetSecretQuestionRequest") == 0)
        {
            return RPC_GET_SECRET_QUESTION;
        }
        else if (name.compare("GetKeyPairRequest") == 0)
        {
            return RPC_GET_KEY_PAIR;
        }
    }
    case 'M':
    {
        if (name.compare("MessageCreateRequest") == 0)
        {
            return RPC_MESSAGE_CREATE;
        }
        else if (name.compare("MessageDeleteRequest") == 0)
        {
            return RPC_MESSAGE_DELETE;
        }
        else if (name.compare("MessageUndeleteRequest") == 0)
        {
            return RPC_MESSAGE_UNDELETE;
        }
        else if (name.compare("MessageEditRequest") == 0)
        {
            return RPC_MESSAGE_EDIT;
        }
        else if (name.compare("MessagesListRequest") == 0)
        {
            return RPC_MESSAGES_LIST;
        }
    }
    case 'N':
    {
        if (name.compare("NotificationsSetRequest") == 0)
        {
            return RPC_NOTIFICATIONS_SET;
        }
        if (name.compare("NotificationsGetRequest") == 0)
        {
            return RPC_NOTIFICATIONS_GET;
        }
    }
    case 'R':
    {
        if (name.compare("RecoverPasswordRequest") == 0)
        {
            return RPC_RECOVER_PASSWORD;
        }
    }
    case 'S':
    {
        if (name.compare("SetMyDataRequest") == 0)
        {
            return RPC_SET_MY_DATA;
        }
        if (name.compare("ServerVersionRequest") == 0)
        {
            return RPC_SERVER_VERSION;
        }
        if (name.compare("ServerTimingStatsRequest") == 0)
        {
            return RPC_SERVER_TIMING_STATS;
        }
        if (name.compare("ServerUsersStatsRequest") == 0)
        {
            return RPC_SERVER_USERS_STATS;
        }
        if (name.compare("ServerWorkGroupsStatsRequest") == 0)
        {
            return RPC_SERVER_WORKGROUPS_STATS;
        }
        if (name.compare("ServerFilesStatsRequest") == 0)
        {
            return RPC_SERVER_FILES_STATS;
        }
        if (name.compare("ServerMessagesStatsRequest") == 0)
        {
            return RPC_SERVER_MESSAGES_STATS;
        }
    }
    case 'T':
    {
        if (name.compare("TopicCreateRequest") == 0)
        {
            return RPC_TOPIC_CREATE;
        }
        else if (name.compare("TopicDeleteRequest") == 0)
        {
            return RPC_TOPIC_DELETE;
        }
        else if (name.compare("TopicUndeleteRequest") == 0)
        {
            return RPC_TOPIC_UNDELETE;
        }
        else if (name.compare("TopicRenameRequest") == 0)
        {
            return RPC_TOPIC_RENAME;
        }
        else if (name.compare("TopicsListRequest") == 0)
        {
            return RPC_TOPICS_LIST;
        }
        else if (name.compare("TariffsListRequest") == 0)
        {
            return RPC_TARIFFS_LIST;
        }
    }
    case 'U':
    {
        if (name.compare("UserInfoRequest") == 0)
        {
            return RPC_USER_INFO;
        }

    }
    default:
    {
        LOG_ERROR("incorrect request name: %s", name.c_str());
        return RPC_UNKNOWN;
    }
    }
}

bool SenderReceiver::process_request (rpc::Request* request, const google::protobuf::Message* message)
{
    MessageType type = type_by_name (message->GetDescriptor()->name());
    request->set_message_type(type);

    switch (type)
    {
    case RPC_LOGIN:
    {
        request->mutable_login()->CopyFrom(*message);
        break;
    }
    case RPC_LOGOUT:
    {
        request->mutable_logout()->CopyFrom(*message);
        break;
    }
    case RPC_CREATE_USER:
    {
        request->mutable_create_user()->CopyFrom(*message);
        break;
    }
    case RPC_ACTIVATE_USER:
    {
        request->mutable_activate_user()->CopyFrom(*message);
        break;
    }
    case RPC_CHANGE_PASSWORD:
    {
        request->mutable_change_password()->CopyFrom(*message);
        break;
    }
    case RPC_CHANGE_SECRETQA:
    {
        request->mutable_change_secretqa()->CopyFrom(*message);
        break;
    }
    case RPC_ACCOUNT_STATS:
    {
        request->mutable_account_stats()->CopyFrom(*message);
        break;
    }
    case RPC_GET_MY_DATA:
    {
        request->mutable_get_my_data()->CopyFrom(*message);
        break;
    }
    case RPC_GET_SECRET_QUESTION:
    {
        request->mutable_get_secret_question()->CopyFrom(*message);
        break;
    }
    case RPC_FORGOT_PASSWORD:
    {
        request->mutable_forgot_password()->CopyFrom(*message);
        break;
    }
    case RPC_RECOVER_PASSWORD:
    {
        request->mutable_recover_password()->CopyFrom(*message);
        break;
    }
    case RPC_CREATE_KEY_PAIR:
    {
        request->mutable_create_key_pair()->CopyFrom(*message);
        break;
    }
    case RPC_GET_KEY_PAIR:
    {
        request->mutable_get_key_pair()->CopyFrom(*message);
        break;
    }
    case RPC_SET_MY_DATA:
    {
        request->mutable_set_my_data()->CopyFrom(*message);
        break;
    }
    case RPC_NOTIFICATIONS_SET:
    {
        request->mutable_notifications_set()->CopyFrom(*message);
        break;
    }
    case RPC_NOTIFICATIONS_GET:
    {
        request->mutable_notifications_get()->CopyFrom(*message);
        break;
    }
    case RPC_CLIENT_INFO:
    {
        request->mutable_client_info()->CopyFrom(*message);
        break;
    }
    case RPC_USER_INFO:
    {
        request->mutable_user_info()->CopyFrom(*message);
        break;
    }
    case RPC_TARIFFS_LIST:
    {
        request->mutable_tariffs_list()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUPS_LIST:
    {
        request->mutable_workgroups_list()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_UNDELETE:
    {
        request->mutable_workgroup_undelete()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_INFO:
    {
        request->mutable_workgroup_info()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST:
    {
        request->mutable_workgroup_coworkers_list()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST_ALL:
    {
        request->mutable_workgroup_coworkers_all()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST_EXTRA:
    {
        request->mutable_workgroup_coworkers_extra()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST_ALL_EX:
    {
        request->mutable_workgroup_coworkers_all_ex()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_CREATE:
    {
        request->mutable_workgroup_create()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_DELETE:
    {
        request->mutable_workgroup_delete()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_RENAME:
    {
        request->mutable_workgroup_rename()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_INVITE:
    {
        request->mutable_workgroup_invite()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_INVITES_LIST:
    {
        request->mutable_workgroup_invites_list()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_SUBSCRIBE:
    {
        request->mutable_workgroup_subscribe()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_UNSUBSCRIBE:
    {
        request->mutable_workgroup_unsubscribe()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_KICK_USER:
    {
        request->mutable_workgroup_kick_user()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_SET_ACCESS:
    {
        request->mutable_workgroup_set_access()->CopyFrom(*message);
        break;
    }
    case RPC_WORKGROUP_METADATA_UPDATE:
    {
        request->mutable_workgroup_metadata_update()->CopyFrom(*message);
        break;
    }
    case RPC_FILES_LIST:
    {
        request->mutable_files_list()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_SEARCH:
    {
        request->mutable_file_search()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_UPLOAD:
    {
        request->mutable_file_upload()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_UPLOAD_APPROVE:
    {
        request->mutable_file_upload_approve()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_DOWNLOAD:
    {
        request->mutable_file_download()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_DIRECTORY_CREATE:
    {
        request->mutable_file_directory_create()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_DELETE:
    {
        request->mutable_file_delete()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_UNDELETE:
    {
        request->mutable_file_undelete()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_RENAME:
    {
        request->mutable_file_rename()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_HISTORY:
    {
        request->mutable_file_history()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_INFO:
    {
        request->mutable_file_info()->CopyFrom(*message);
        break;
    }
    case RPC_FILE_DIRECTORY_HIERARCHY:
    {
        request->mutable_file_directory_hierarchy()->CopyFrom(*message);
        break;
    }
    case RPC_EVENTS_LIST:
    {
        request->mutable_events_list()->CopyFrom(*message);
        break;
    }
    case RPC_TOPIC_CREATE:
    {
        request->mutable_topic_create()->CopyFrom(*message);
        break;
    }
    case RPC_TOPIC_DELETE:
    {
        request->mutable_topic_delete()->CopyFrom(*message);
        break;
    }
    case RPC_TOPIC_UNDELETE:
    {
        request->mutable_topic_undelete()->CopyFrom(*message);
        break;
    }
    case RPC_TOPIC_RENAME:
    {
        request->mutable_topic_rename()->CopyFrom(*message);
        break;
    }
    case RPC_TOPICS_LIST:
    {
        request->mutable_topics_list()->CopyFrom(*message);
        break;
    }
    case RPC_MESSAGE_CREATE:
    {
        request->mutable_message_create()->CopyFrom(*message);
        break;
    }
    case RPC_MESSAGE_DELETE:
    {
        request->mutable_message_delete()->CopyFrom(*message);
        break;
    }
    case RPC_MESSAGE_UNDELETE:
    {
        request->mutable_message_undelete()->CopyFrom(*message);
        break;
    }
    case RPC_MESSAGE_EDIT:
    {
        request->mutable_message_edit()->CopyFrom(*message);
        break;
    }
    case RPC_MESSAGES_LIST:
    {
        request->mutable_messages_list()->CopyFrom(*message);
        break;
    }
    case RPC_SERVER_VERSION:
    {
        request->mutable_server_version()->CopyFrom(*message);
        break;
    }
    case RPC_SERVER_TIMING_STATS:
    {
        request->mutable_server_timing_stats()->CopyFrom(*message);
        break;
    }
    case RPC_SERVER_USERS_STATS:
    {
        request->mutable_server_users_stats()->CopyFrom(*message);
        break;
    }
    case RPC_SERVER_WORKGROUPS_STATS:
    {
        request->mutable_server_workgroups_stats()->CopyFrom(*message);
        break;
    }
    case RPC_SERVER_FILES_STATS:
    {
        request->mutable_server_files_stats()->CopyFrom(*message);
        break;
    }
    case RPC_SERVER_MESSAGES_STATS:
    {
        request->mutable_server_messages_stats()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_CREATE:
    {
        request->mutable_company_create()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_DELETE:
    {
        request->mutable_company_delete()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANIES_LIST:
    {
        request->mutable_companies_list()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_GET_INFO:
    {
        request->mutable_company_get_info()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_SET_INFO:
    {
        request->mutable_company_set_info()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_GET_TARIFF:
    {
        request->mutable_company_get_tariff()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_SET_TARIFF:
    {
        request->mutable_company_set_tariff()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_INVITE:
    {
        request->mutable_company_invite()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_CHANGE_ROLE:
    {
        request->mutable_company_change_role()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_KICK_USER:
    {
        request->mutable_company_kick_user()->CopyFrom(*message);
        break;
    }
    case RPC_COMPANY_ROLES_LIST:
    {
        request->mutable_company_roles_list()->CopyFrom(*message);
        break;
    }

    default:
    {
        LOG_INFORMATION("Oh noo, trouble's in processing request, message type %i", type);
        return false;
    }
    }

    return true;
}

bool SenderReceiver::process_response (const rpc::Response* response, google::protobuf::Message* message)
{
    switch (response->message_type())
    {
    case RPC_LOGIN:
    {
        message->CopyFrom(response->login());
        break;
    }
    case RPC_LOGOUT:
    {
        message->CopyFrom(response->logout());
        break;
    }
    case RPC_CREATE_USER:
    {
        message->CopyFrom(response->create_user());
        break;
    }
    case RPC_ACTIVATE_USER:
    {
        message->CopyFrom(response->activate_user());
        break;
    }
    case RPC_CHANGE_PASSWORD:
    {
        message->CopyFrom(response->change_password());
        break;
    }
    case RPC_CHANGE_SECRETQA:
    {
        message->CopyFrom(response->change_secretqa());
        break;
    }
    case RPC_ACCOUNT_STATS:
    {
        message->CopyFrom(response->account_stats());
        break;
    }
    case RPC_GET_SECRET_QUESTION:
    {
        message->CopyFrom(response->get_secret_question());
        break;
    }
    case RPC_FORGOT_PASSWORD:
    {
        message->CopyFrom(response->forgot_password());
        break;
    }
    case RPC_RECOVER_PASSWORD:
    {
        message->CopyFrom(response->recover_password());
        break;
    }
    case RPC_CREATE_KEY_PAIR:
    {
        message->CopyFrom(response->create_key_pair());
        break;
    }
    case RPC_GET_KEY_PAIR:
    {
        message->CopyFrom(response->get_key_pair());
        break;
    }
    case RPC_GET_MY_DATA:
    {
        message->CopyFrom(response->get_my_data());
        break;
    }
    case RPC_SET_MY_DATA:
    {
        message->CopyFrom(response->set_my_data());
        break;
    }
    case RPC_NOTIFICATIONS_SET:
    {
        message->CopyFrom(response->notifications_set());
        break;
    }
    case RPC_NOTIFICATIONS_GET:
    {
        message->CopyFrom(response->notifications_get());
        break;
    }
    case RPC_CLIENT_INFO:
    {
        message->CopyFrom(response->client_info());
        break;
    }
    case RPC_USER_INFO:
    {
        message->CopyFrom(response->user_info());
        break;
    }
    case RPC_TARIFFS_LIST:
    {
        message->CopyFrom(response->tariffs_list());
        break;
    }
    case RPC_WORKGROUPS_LIST:
    {
        message->CopyFrom(response->workgroups_list());
        break;
    }
    case RPC_WORKGROUP_INFO:
    {
        message->CopyFrom(response->workgroup_info());
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST:
    {
        message->CopyFrom(response->workgroup_coworkers_list());
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST_ALL:
    {
        message->CopyFrom(response->workgroup_coworkers_all());
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST_EXTRA:
    {
        message->CopyFrom(response->workgroup_coworkers_extra());
        break;
    }
    case RPC_WORKGROUP_COWORKERS_LIST_ALL_EX:
    {
        message->CopyFrom(response->workgroup_coworkers_all_ex());
        break;
    }
    case RPC_WORKGROUP_CREATE:
    {
        message->CopyFrom(response->workgroup_create());
        break;
    }
    case RPC_WORKGROUP_DELETE:
    {
        message->CopyFrom(response->workgroup_delete());
        break;
    }
    case RPC_WORKGROUP_UNDELETE:
    {
        message->CopyFrom(response->workgroup_undelete());
        break;
    }
    case RPC_WORKGROUP_RENAME:
    {
        message->CopyFrom(response->workgroup_rename());
        break;
    }
    case RPC_WORKGROUP_INVITE:
    {
        message->CopyFrom(response->workgroup_invite());
        break;
    }
    case RPC_WORKGROUP_INVITES_LIST:
    {
        message->CopyFrom(response->workgroup_invites_list());
        break;
    }
    case RPC_WORKGROUP_SUBSCRIBE:
    {
        message->CopyFrom(response->workgroup_subscribe());
        break;
    }
    case RPC_WORKGROUP_UNSUBSCRIBE:
    {
        message->CopyFrom(response->workgroup_unsubscribe());
        break;
    }
    case RPC_WORKGROUP_KICK_USER:
    {
        message->CopyFrom(response->workgroup_kick_user());
        break;
    }
    case RPC_WORKGROUP_SET_ACCESS:
    {
        message->CopyFrom(response->workgroup_set_access());
        break;
    }
    case RPC_WORKGROUP_METADATA_UPDATE:
    {
        message->CopyFrom(response->workgroup_metadata_update());
        break;
    }
    case RPC_FILES_LIST:
    {
        message->CopyFrom(response->files_list());
        break;
    }
    case RPC_FILE_SEARCH:
    {
        message->CopyFrom(response->file_search());
        break;
    }
    case RPC_FILE_DIRECTORY_HIERARCHY:
    {
        message->CopyFrom(response->file_directory_hierarchy());
        break;
    }
    case RPC_FILE_UPLOAD:
    {
        message->CopyFrom(response->file_upload());
        break;
    }
    case RPC_FILE_UPLOAD_APPROVE:
    {
        message->CopyFrom(response->file_upload_approve());
        break;
    }
    case RPC_FILE_DOWNLOAD:
    {
        message->CopyFrom(response->file_download());
        break;
    }
    case RPC_FILE_DIRECTORY_CREATE:
    {
        message->CopyFrom(response->file_directory_create());
        break;
    }
    case RPC_FILE_DELETE:
    {
        message->CopyFrom(response->file_delete());
        break;
    }
    case RPC_FILE_UNDELETE:
    {
        message->CopyFrom(response->file_undelete());
        break;
    }
    case RPC_FILE_RENAME:
    {
        message->CopyFrom(response->file_rename());
        break;
    }
    case RPC_FILE_HISTORY:
    {
        message->CopyFrom(response->file_history());
        break;
    }
    case RPC_FILE_INFO:
    {
        message->CopyFrom(response->file_info());
        break;
    }
    case RPC_EVENTS_LIST:
    {
        message->CopyFrom(response->events_list());
        break;
    }
    case RPC_TOPIC_CREATE:
    {
        message->CopyFrom(response->topic_create());
        break;
    }
    case RPC_TOPIC_DELETE:
    {
        message->CopyFrom(response->topic_delete());
        break;
    }
    case RPC_TOPIC_UNDELETE:
    {
        message->CopyFrom(response->topic_undelete());
        break;
    }
    case RPC_TOPIC_RENAME:
    {
        message->CopyFrom(response->topic_rename());
        break;
    }
    case RPC_TOPICS_LIST:
    {
        message->CopyFrom(response->topics_list());
        break;
    }
    case RPC_MESSAGE_CREATE:
    {
        message->CopyFrom(response->message_create());
        break;
    }
    case RPC_MESSAGE_DELETE:
    {
        message->CopyFrom(response->message_delete());
        break;
    }
    case RPC_MESSAGE_UNDELETE:
    {
        message->CopyFrom(response->message_undelete());
        break;
    }
    case RPC_MESSAGE_EDIT:
    {
        message->CopyFrom(response->message_edit());
        break;
    }
    case RPC_MESSAGES_LIST:
    {
        message->CopyFrom(response->messages_list());
        break;
    }
    case RPC_SERVER_VERSION:
    {
        message->CopyFrom(response->server_version());
        break;
    }
    case RPC_SERVER_TIMING_STATS:
    {
        message->CopyFrom(response->server_timing_stats());
        break;
    }
    case RPC_SERVER_USERS_STATS:
    {
        message->CopyFrom(response->server_users_stats());
        break;
    }
    case RPC_SERVER_WORKGROUPS_STATS:
    {
        message->CopyFrom(response->server_workgroups_stats());
        break;
    }
    case RPC_SERVER_FILES_STATS:
    {
        message->CopyFrom(response->server_files_stats());
        break;
    }
    case RPC_SERVER_MESSAGES_STATS:
    {
        message->CopyFrom(response->server_messages_stats());
        break;
    }
    case RPC_COMPANY_CREATE:
    {
        message->CopyFrom(response->company_create());
        break;
    }
    case RPC_COMPANY_DELETE:
    {
        message->CopyFrom(response->company_delete());
        break;
    }
    case RPC_COMPANIES_LIST:
    {
        message->CopyFrom(response->companies_list());
        break;
    }
    case RPC_COMPANY_GET_INFO:
    {
        message->CopyFrom(response->company_get_info());
        break;
    }
    case RPC_COMPANY_SET_INFO:
    {
        message->CopyFrom(response->company_set_info());
        break;
    }
    case RPC_COMPANY_GET_TARIFF:
    {
        message->CopyFrom(response->company_get_tariff());
        break;
    }
    case RPC_COMPANY_SET_TARIFF:
    {
        message->CopyFrom(response->company_set_tariff());
        break;
    }
    case RPC_COMPANY_INVITE:
    {
        message->CopyFrom(response->company_invite());
        break;
    }
    case RPC_COMPANY_CHANGE_ROLE:
    {
        message->CopyFrom(response->company_change_role());
        break;
    }
    case RPC_COMPANY_KICK_USER:
    {
        message->CopyFrom(response->company_kick_user());
        break;
    }
    case RPC_COMPANY_ROLES_LIST:
    {
        message->CopyFrom(response->company_roles_list());
        break;
    }

    default:
    {
        LOG_INFORMATION("Oh noo, trouble's in processing response, message type %i", response->message_type());
        return false;
    }
    }

    return true;
}
