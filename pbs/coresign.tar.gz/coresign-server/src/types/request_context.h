/*
 * request_context.h
 *
 *  Created on: Feb 5, 2014
 *      Author: fireballdark
 */

#ifndef REQUEST_CONTEXT_H_
#define REQUEST_CONTEXT_H_

#include <string>
#include <cstdint>
#include <vector>
#include "src/types/user_info.h"
#include <types/keyvalue.h>

struct SessionInfo
{
    SessionInfo():
        user_id(0),
        session_created(0),
        is_old(false),
        prolong_ttl(0)
    {}

    int64_t         user_id;
    int64_t         session_created;

    bool            is_old;
    int32_t         prolong_ttl;

    std::string     session_id;
    std::string     event_session_id;
    std::string     service;
    std::string     bundle_id;
    std::string     username;
    std::string     device_id;
    std::string     device_name;
    std::string     platform;
    std::string     version;
    std::string     ip_address;

    std::string     first_name;
    std::string     last_name;

    std::string     public_key;

    KeyValue        custom_params;
};

#define ADD_ERROR_MESSAGE(CTX, MSG) do{ if (CTX.is_debug) {CTX.add_error_message(MSG);} }while(false)

struct RequestContext
{
    RequestContext():
        service_type(0),
        is_debug(false),
        error_code(500)
    {}

    //Input
    int64_t         service_type;
    std::string     ip_address;
    bool            is_debug;

    //Processing
    std::string     session_id;
    SessionInfo     session_info;
    UserInfo        user_info;

    //Output
    std::string     request_id;
    int32_t         error_code;
    std::vector<std::string>     error_message;

    void add_error_message(const std::string& errmsg)
    {
        error_message.push_back(errmsg);
    }
};

#define   KeepSolidService 0
#define   ToDoChecklist    1

#endif /* REQUEST_CONTEXT_H_ */
