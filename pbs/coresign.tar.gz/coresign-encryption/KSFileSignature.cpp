/*
 * KSFileSignature.cpp
 *
 *  Created on: May 20, 2013
 *      Author: fireballdark
 */

#include "KSFileSignature.h"
#include <sstream>
#include <istream>
#include <cstdio>

#include <protobuf/fs/cpp/signature.pb.h>
#include "xopenssl.h"
#include "xopenssl_defines.h"
#include "util/logging.h"

#define KS_CURRENT_VERSION  KSD::KSFileSignature::KS_VERSION_V1

namespace KSD
{


xopenssl_status KSFileSignature::read_file_signature( std::istream& in_stream, std::string& signature )
{
    xopenssl_status result = XOPENSSL_UNKNOWN;

    if (!in_stream.good())
    {
        bool in = in_stream.fail();
        LOG_ERROR("OpenSSL read signature: Stream is bad [%i]", int(in));
        return XOPENSSL_BAD_STREAM;
    }

    do
    {
        int64_t encrypted_raw_data_size = -1;
        int offset = sizeof (encrypted_raw_data_size);       //READ ENCRYPTED DATA SIZE
        in_stream.seekg(-offset, std::ios::end);
        int64_t end_sig = in_stream.tellg();      //Get signature end position
        in_stream.read((char*)&encrypted_raw_data_size, sizeof(encrypted_raw_data_size));

        if(encrypted_raw_data_size > end_sig || encrypted_raw_data_size <= 0)
        {
            result = XOPENSSL_METADATA_ERROR;
            LOG_INFORMATION("OpenSSL read signature: data_size in header is bigger than file size [%lli]:[%lli]", encrypted_raw_data_size, end_sig);
            break;
        }

        in_stream.seekg(encrypted_raw_data_size, std::ios::beg);
        char ksd1_signature [sizeof(KSD1_SIGNATURE)-1] = {0};
        in_stream.read(ksd1_signature, sizeof(ksd1_signature));
        int64_t start_sig = in_stream.tellg();    //Get signature start position

        int compare_result = strncmp(ksd1_signature, KSD1_SIGNATURE, sizeof(KSD1_SIGNATURE)-1);
        if ( compare_result != 0 )
        {
            result = XOPENSSL_METADATA_ERROR;
            LOG_INFORMATION("OpenSSL read signature: got invalid data in header [%.8s]:[%.8s] - result [%i]", ksd1_signature, KSD1_SIGNATURE, compare_result);
            break;
        }

        char signature_char [KSD_SIGNATURE_LIMIT] = {0};
        int64_t need_read = (end_sig - start_sig) < sizeof(signature_char) ? (end_sig - start_sig) : sizeof(signature_char);
        in_stream.read(signature_char, need_read);

        int64_t real_read = in_stream.gcount();
        signature.assign(signature_char, real_read);

        result = XOPENSSL_OK;
    }
    while(false);

    in_stream.clear();
    in_stream.seekg(0, std::ios::beg);

    return result;
}

xopenssl_status KSFileSignature::read_file_signature( FILE* in_stream, std::string& signature )
{
    xopenssl_status result = XOPENSSL_UNKNOWN;

    if (in_stream == NULL || ferror(in_stream))
    {
        LOG_ERROR("OpenSSL AES decrypt: input [%lli] file is NULL or has error", (int64_t)in_stream);
        return XOPENSSL_BAD_STREAM;
    }

    do
    {
        int64_t encrypted_raw_data_size = -1;
        int offset = sizeof (encrypted_raw_data_size);       //READ ENCRYPTED DATA SIZE
        FSEEK64(in_stream, -offset, SEEK_END);
        int64_t end_sig = FTELL64(in_stream);          //Get signature end position
        size_t read_len = fread((char*)&encrypted_raw_data_size, sizeof(char), sizeof(encrypted_raw_data_size), in_stream);

        if (read_len != sizeof(encrypted_raw_data_size))
        {
            result = XOPENSSL_BAD_STREAM;
            LOG_INFORMATION("OpenSSL read signature: read less data than expected [%lu]:[%lu]", read_len, sizeof(encrypted_raw_data_size));
            break;
        }

        if(encrypted_raw_data_size > end_sig || encrypted_raw_data_size <= 0)
        {
            result = XOPENSSL_METADATA_ERROR;
            LOG_INFORMATION("OpenSSL read signature: data_size in header is bigger than file size [%lli]:[%lli]", encrypted_raw_data_size, end_sig);
            break;
        }

        FSEEK64(in_stream, encrypted_raw_data_size, SEEK_SET);
        char ksd1_signature [sizeof(KSD1_SIGNATURE)-1] = {0};
        read_len = fread(ksd1_signature, sizeof(char), sizeof(ksd1_signature), in_stream);
        if (read_len != sizeof(ksd1_signature))
        {
            result = XOPENSSL_BAD_STREAM;
            LOG_INFORMATION("OpenSSL read signature: read less data than expected [%lu]:[%lu]", read_len, sizeof(ksd1_signature));
            break;
        }
        int64_t start_sig = FTELL64(in_stream);    //Get signature start position

        int compare_result = strncmp(ksd1_signature, KSD1_SIGNATURE, sizeof(KSD1_SIGNATURE)-1);
        if ( compare_result != 0 )
        {
            result = XOPENSSL_METADATA_ERROR;
            LOG_INFORMATION("OpenSSL read signature: got invalid data in header [%.8s]:[%.8s] - result [%i]", ksd1_signature, KSD1_SIGNATURE, compare_result);
            break;
        }

        char signature_char [KSD_SIGNATURE_LIMIT] = {0};
        int64_t need_read = (end_sig - start_sig) < sizeof(signature_char) ? (end_sig - start_sig) : sizeof(signature_char);
        int64_t real_read = fread(signature_char, sizeof(char), need_read, in_stream);

        signature.assign(signature_char, real_read);

        result = XOPENSSL_OK;
    }
    while(false);

    FSEEK64(in_stream, 0, SEEK_SET);

    return result;
}

KSFileSignature::KSFileSignature():
                _version(KS_CURRENT_VERSION),
                _encrypted_raw_size(-1),
                _flags(0),
                _reserved1(0xDEADBEEF),
                _reserved2(0xDEADBEEF),
                _reserved3(0xDEADBEEF),
                _reserved4(0xDEADBEEF)
{
}

KSFileSignature::~KSFileSignature()
{
}

bool KSFileSignature::serialize_signature( const KSD::KSFileSignature& fs, std::string& result )
{
    bool status = false;

    do
    {
        try
        {

            if (fs._version == KS_VERSION_UNKNOWN || fs._version == KS_VERSION_ZERO)
            {
                //NOTHING TO DO
            }
            else if (fs._version == KS_VERSION_V1)
            {
                result.clear();

                result.append(KSD1_SIGNATURE);

                {
                    fs::FileSignature sign;
                    sign.set_version                (fs._version);
                    sign.set_initialization_vector  (fs._initialization_vector);
                    sign.set_original_raw_hash      (fs._original_raw_hash);
                    sign.set_encrypted_raw_size     (fs._encrypted_raw_size);
                    sign.set_flags                  (fs._flags);

                    std::string protosignature;
                    try
                    {
                        bool res = sign.SerializeToString(&protosignature);
                        if (res == false || protosignature.empty())
                        {
                            LOG_ERROR("KSFileSignature: false result in serialization");
                            break;
                        }
                    }
                    catch (const std::exception& e)
                    {
                        LOG_ERROR("KSFileSignature: exception serializing signature [%s]", e.what());
                        break;
                    }
                    result.append(protosignature);
                }

                result.append((const char *)&fs._encrypted_raw_size,sizeof(fs._encrypted_raw_size));

                status = true;
            }
            else
            {
                LOG_ERROR("KSFileSignature: Unsupported version when serializing signature: [%i]", fs._version);
            }
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("KSFileSignature: Problem serializing signature: [%s]", e.what());
        }
    }
    while(false);

    return status;
}

bool KSFileSignature::parse_signature(const std::string& signature, KSD::KSFileSignature& fs )
{
    bool status = false;

    do
    {
        try
        {
            fs::FileSignature sign;
            sign.ParseFromString(signature);

            fs.set_version(static_cast<KSD::KSFileSignature::KSFileVersion> (sign.has_version() ? sign.version() : KS_VERSION_UNKNOWN));

            if (fs.get_version() == KS_VERSION_V1)
            {
                fs.set_initialization_vector   (sign.initialization_vector());
                fs.set_original_raw_hash       (sign.original_raw_hash());
                fs.set_encrypted_raw_size      (sign.encrypted_raw_size());
                fs.set_flags                   (sign.flags());

                status = true;
            }
            else
            {
                LOG_ERROR("KSFileSignature: Unsupported version: [%i]", fs.get_version());
                break;
            }
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("KSFileSignature: Problem parsing signature: [%s]", e.what());
            break;
        }
    }
    while(false);

    return status;
}

KSFileSignature::KSFileVersion  KSFileSignature::parse_version(const std::string& version_signature) const
{
    if (version_signature.compare(KSD1_SIGNATURE) == 0)
    {
        return KS_VERSION_V1;
    }
    else if (version_signature.compare(KSD2_SIGNATURE) == 0)
    {
        return KS_VERSION_V2;
    }
    else
    {
        return KS_VERSION_ZERO;
    }
}

void KSFileSignature::set_original_raw_hash(const std::string& hash)
{
    _original_raw_hash  = hash;
    _original_hash      = digest_to_hex_string(hash);
}

void KSFileSignature::set_original_hash(const std::string& hash)
{
    _original_hash      = hash;
    _original_raw_hash  = hex_to_digest(hash);
}

KSFileSignature::KSFileVersion KSFileSignature::get_version() const
{
    return _version;
}

std::string KSFileSignature::get_original_raw_hash()
{
    if (_original_raw_hash.empty() && !_original_hash.empty())
    {
        _original_raw_hash  = hex_to_digest(_original_hash);
    }
    return _original_raw_hash;
}

std::string KSFileSignature::get_original_hash()
{
    if (_original_hash.empty() && !_original_raw_hash.empty())
    {
        _original_hash  = digest_to_hex_string(_original_raw_hash);
    }
    return _original_hash;
}

int64_t KSFileSignature::get_encrypted_raw_size() const
{
    return _encrypted_raw_size;
}

int64_t KSFileSignature::get_flags() const
{
    return _flags;
}

void KSFileSignature::set_version(KSFileSignature::KSFileVersion version)
{
    _version = version;
}

void KSFileSignature::set_encrypted_raw_size(const int64_t& encrypted_raw_size)
{
    _encrypted_raw_size = encrypted_raw_size;
}

void KSFileSignature::set_flags(const int64_t& flags)
{
    _flags = flags;
}

std::string KSFileSignature::get_initialization_vector() const
{
    return _initialization_vector;
}

void KSFileSignature::set_initialization_vector(const std::string& initialization_vector)
{
    _initialization_vector = initialization_vector;
}

} /* namespace KSD */
