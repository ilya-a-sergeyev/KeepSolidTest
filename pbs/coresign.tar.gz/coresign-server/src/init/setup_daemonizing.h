#ifndef SETUP_DAEMONIZING
#define SETUP_DAEMONIZING

int setup_daemonizing_params();

#endif
