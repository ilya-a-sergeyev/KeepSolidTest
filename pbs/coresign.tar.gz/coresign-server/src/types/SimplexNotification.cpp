/*
 * SimplexNotification.cpp
 *
 *  Created on: Apr 7, 2014
 *      Author: fireballdark
 */

#include "SimplexNotification.h"
#include <boost/lexical_cast.hpp>
#include <util/logging.h>
#include <util/DataVerifier.h>


bool SimplexNotification::generate_email_notification(KeyValue& data_outer, KeyValue& data_inner)
{
    if (_service_name.empty() || _recipient_login.empty() || _mail_id.empty() || check_email(_recipient_login) != EXIT_SUCCESS)
    {
        LOG_INFORMATION("Some fields for email are empty [%s]:[%s]:[%s]:[%s]",
                _service_name.c_str(), _notification_name.c_str(),
                _recipient_login.c_str(), _mail_id.c_str());
        return false;
    }

    data_outer["service"] = _service_name;
    data_outer["recipient"] = _recipient_login;
    data_outer["id"] = data_outer["message_id"] = _mail_id;

    data_inner = _params;

    return true;
}

bool SimplexNotification::generate_push_notification(KeyValue& data_outer, KeyValue& data_inner)
{
    if (_service_name.empty() || _recipient_login.empty() || _push_id.empty() || check_email(_recipient_login) != EXIT_SUCCESS)
    {
        LOG_INFORMATION("Some fields for apple-push are empty [%s]:[%s]:[%s]:[%s]",
                _service_name.c_str(), _notification_name.c_str(),
                _recipient_login.c_str(), _push_id.c_str());
        return false;
    }

    data_outer["service"] = _service_name;
    data_outer["username"] = _recipient_login;
    data_outer["type"] = data_outer["message_id"] = _push_id;
    data_outer["deviceuuid"] = "";

    data_inner = _params;

    return true;
}

bool SimplexNotification::generate_social_notification(KeyValue& data_outer, KeyValue& data_inner)
{
    if (_service_name.empty() || _session.empty() || _social_type.empty()
            || _social_token.empty() || _social_recipient.empty() || _social_id.empty())
    {
        LOG_INFORMATION("Some fields for social are empty [%s]:[%s]:[%s]:[%s]:[%s]:[%s]",
                _service_name.c_str(), _notification_name.c_str(),
                _social_type.c_str(), _social_token.c_str(),
                _social_recipient.c_str(), _social_id.c_str());
        return false;
    }

    data_outer["service"] = _service_name;
    data_outer["session"] = _session;
    data_outer["social_type"] = _social_type;
    data_outer["social_token"] = _social_token;
    data_outer["recipient_id"] = _social_recipient;
    data_outer["message_id"] = _social_id;

    data_inner = _params;

    return true;
}

void SimplexNotification::set_device_id(const std::string& device_id)
{
    this->_device_id = device_id;
}

void SimplexNotification::set_mail_id(const std::string& mail_id)
{
    this->_mail_id = mail_id;
}

void SimplexNotification::set_params(const KeyValue& params)
{
    this->_params = params;
}

void SimplexNotification::set_push_id(const std::string& push_id)
{
    this->_push_id = push_id;
}

void SimplexNotification::set_recipient_login(const std::string& recipient_login)
{
    this->_recipient_login = recipient_login;
}

void SimplexNotification::set_session(const std::string& session)
{
    this->_session = session;
}

void SimplexNotification::set_mail_id(int64_t mail_id)
{
    this->_mail_id = boost::lexical_cast<std::string>(mail_id);
}

void SimplexNotification::set_push_id(int64_t push_id)
{
    this->_push_id = boost::lexical_cast<std::string>(push_id);
}

void SimplexNotification::set_social_id(int64_t social_id)
{
    this->_social_id = boost::lexical_cast<std::string>(social_id);
}

void SimplexNotification::set_service_name(const std::string& service_name)
{
    this->_service_name = service_name;
}

void SimplexNotification::set_social_id(const std::string& social_id)
{
    this->_social_id = social_id;
}

void SimplexNotification::set_social_recipient(const std::string& social_recipient)
{
    this->_social_recipient = social_recipient;
}

void SimplexNotification::set_social_token(const std::string& social_token)
{
    this->_social_token = social_token;
}

void SimplexNotification::set_social_type(const std::string& social_type)
{
    this->_social_type = social_type;
}

void SimplexNotification::set_notification_name(const std::string& notification_name)
{
    this->_notification_name = notification_name;
}

const std::string& SimplexNotification::get_notification_name() const
{
    return _notification_name;
}

const std::string& SimplexNotification::get_service_name() const
{
    return _service_name;
}
