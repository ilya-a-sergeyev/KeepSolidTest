/*
 * UserManagerHelper.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */


#include "FolderInvitesHelper.h"
#include <pqxx/result.hxx>


void convert_inviteinfo_db(const pqxx::result::const_iterator& query_result, InviteInfo& ii)
{
    ii.invite_id            = query_result["invite_id"].as<std::string>();
    ii.inviter_login        = query_result["inviter_login"].as<std::string>();
    ii.inviter_id           = query_result["inviter_id"].as<int64_t>();
    ii.invitee_login        = query_result["invitee_login"].as<std::string>();
    ii.invitee_id           = query_result["invitee_id"].as<int64_t>();
    ii.workgroup_id         = query_result["workgroup_id"].as<int64_t>();
    ii.workgroup_name       = query_result["workgroup_name"].as<std::string>();
    ii.access_mode          = query_result["access_mode"].as<int64_t>();
    ii.key                  = query_result["encryption_key"].as<std::string>();
    ii.is_anonymous         = query_result["is_anonymous"].as<bool>();
    ii.service_type         = query_result["service_type"].as<int64_t>();
}
