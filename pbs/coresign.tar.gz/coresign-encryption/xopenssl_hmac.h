/*
 * xopenssl_hmac.h
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>

std::string sha1_hmac_raw           (const std::string& text, const std::string& secret);
std::string sha1_hmac               (const std::string& data, const std::string& secret);
std::string sha256_hmac_raw         (const std::string& data, const std::string& secret);
std::string sha256_hmac             (const std::string& data, const std::string& secret);
std::string sha256_hmac_easy_sign   (const std::string& secret);
bool        sha256_hmac_easy_verify (const std::string& data, const std::string& secret);
