/*
 * MailTemplate.h
 *
 *  Created on: Dec 20, 2012
 *      Author: fireballdark
 */

#ifndef MAILTEMPLATE_H_
#define MAILTEMPLATE_H_
#include "types/invitation.h"

class MailTemplate
{
public:
    static void invite_to_wg        (const InviteInfo& inviteInfo);
    static void invite_subscribe    (const InviteInfo& inviteInfo, bool acceptInvite);
    static void invite_new_user     (const std::string& inviter_fname, const std::string& inviter_lname,
                                     const std::string& inviter_login, const std::string& invitee_login,
                                     const std::string& invitee_pass);

//    void    add_file                (const std::string& userName, const std::string& userLogin, const std::string& creatorName, const std::string& creatorLogin, const std::string& workGroupName, const std::string& workGroupUrl, const std::string& fileName, int64_t fileSize);
//    void    discussion_mentioned    (const std::string& userName, const std::string& userLogin, const std::string& creatorName, const std::string& creatorLogin, const std::string& workGroupName, const std::string& workGroupUrl, const std::string& fileName, int64_t fileSize);
//
//private:
//    bool    load_template           (const std::string& name);
//    int     substitute_variable     (const std::string& variable, const std::string& value);
//    bool    is_ready                ();
};

#endif /* MAILTEMPLATE_H_ */
