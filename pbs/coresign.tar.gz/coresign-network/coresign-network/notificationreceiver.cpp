#include "notificationreceiver.h"

#ifdef NOTIFY_SYNC
#include "asionotificationtransportSync.h"
#else
#include "asionotificationtransportAsync.h"
#endif

#include <stdlib.h>     /* srand, rand */
#include <time.h>

#include <protobuf/util/cpp/subscribe_events.pb.h>

#include <util/logging.h>

NotificationReceiver::NotificationReceiver(const std::string& address, const std::string& port, const int64_t& serviceId):
    mAddress(address),
    mPort(port),
    mStopped(false),
    mServiceId(serviceId)
{
    if (mAddress.empty() || mPort.empty())
    {
        LOG_ERROR("NotificationReceiver: Constructed with empty address or port - [%s]:[%s]", mAddress.c_str(), mPort.c_str());
    }
}

NotificationReceiver::NotificationReceiver(const AddressesList& addresses, const int64_t& serviceId):
    mAddresses(addresses),
    mStopped(false),
    mServiceId(serviceId)
{
    if (mAddresses.empty())
    {
        LOG_ERROR("NotificationReceiver: Constructed with ZERO addresses to connect");
    }
}

NotificationReceiver::~NotificationReceiver()
{
    stop();
    pTransport.reset();
}

rpc_status_code NotificationReceiver::subscribe(const std::string& eventSessionId, const function_MessageCallback& callback, const function_ConnectionCallback& connection_cb)
{
    std::lock_guard<std::mutex> lock(mMutex);

    rpc_status_code result = status_unknown;
    std::string data_out;
    std::string data_in;

    mStopped = false;
    LOG_INFORMATION("NotificationReceiver: Trying to subscribe");

    do
    {
        rpc::SubscribeEventsRequest     request;
        request.set_session_id(eventSessionId);
        request.set_service_type(mServiceId);
        try
        {
            request.SerializeToString(&data_out);
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("NotificationReceiver: Problem serializing request [%s]",e.what());
            break;
        }

        call(data_out,data_in);

        LOG_INFORMATION("Wrote [%lu], read [%lu]",data_out.size(),data_in.size());

        rpc::SubscribeEventsResponse    response;
        try
        {
            response.ParseFromString(data_in);
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("NotificationReceiver: Problem parsing reply [%s]",e.what());
            break;
        }
        result = status_code_from_int(response.error_code());

        if (result != status_success)
        {
            LOG_INFORMATION("NotificationReceiver: Got status %i from server while subscribing for events",response.error_code());
            switch(result)
            {
                case status_unauthorized:
                {
                    connection_cb(OPSTATUS_SESSION_EXPIRED, false);
                    break;
                }
                case status_unknown:
                {
                    //Nothing to do
                    break;
                }
                default:
                {
                    connection_cb(OPSTATUS_ERROR, false);
                }
            }
        }
        else
        {
            pTransport->subscribe(callback, connection_cb, true);
            LOG_INFORMATION("NotificationReceiver: Subscribed OK");
        }

    } while (false);

    return result;
}

void NotificationReceiver::stop()
{
    mStopped = true;
    if (pTransport)
    {
        pTransport->stop();
    }
}

bool NotificationReceiver::is_connected()
{
    return (pTransport && pTransport->is_connected());
}

void NotificationReceiver::call(const std::string& data_out, std::string& data_in)
{
    bool bResult = false;
    bool first   = true;

    std::size_t address_counter = 0;

    //randomize servers load
    if ( !mAddresses.empty() )
    {
        srand(time(NULL));
        address_counter = rand() % mAddresses.size();
    }

    while (!bResult && !mStopped)
    {
        if (!first)
        {
            LOG_INFORMATION("NotificationReceiver: Second+ time OK");

            try
            {
                asio::io_service s;
                asio::deadline_timer timer(s,boost::posix_time::seconds(1));
                timer.wait();
            }
            catch (const std::exception& e)
            {
                LOG_ERROR("NotificationReceiver: Timer exception [%s]",e.what());
            }
        }

        if (!mAddresses.empty())
        {
            if (address_counter>=mAddresses.size())
            {
                address_counter=0; //zero the counter
            }

            mAddress    = mAddresses[address_counter].first;
            mPort       = mAddresses[address_counter].second;

            address_counter++;
        }

        LOG_INFORMATION("NotificationReceiver: Try connect to [%s]:[%s]",mAddress.c_str(), mPort.c_str());

        if (pTransport)
        {
            pTransport->stop();
        }
        pTransport = std::make_shared<AsioNotificationTransport>(mAddress, mPort);

        first = false;

        OperationStatus status = OPSTATUS_UNDEFINED;
        status = pTransport->write(data_out);

        if (status == OPSTATUS_OK)
        {
            //OK, do nothing
            LOG_INFORMATION("NotificationReceiver: Wrote OK [%i] data", status);
        }
        else if (status == OPSTATUS_ABORTED)
        {
            LOG_INFORMATION("NotificationReceiver: abort write");
            break;
        }
        else //errors, time-outs..
        {
            LOG_INFORMATION("NotificationReceiver: Error writing data [%i]", status);
            continue;
        }

        asio::error_code err;
        status = pTransport->read(err, data_in);

        if (status == OPSTATUS_OK && data_in.size() > 0)
        {
            //OK, do nothing
            LOG_INFORMATION("NotificationReceiver: Read OK [%i] data", status);
        }
        else if (status == OPSTATUS_ABORTED)
        {
            LOG_INFORMATION("NotificationReceiver: abort read");
            break;
        }
        else //errors, time-outs..
        {
            LOG_INFORMATION("NotificationReceiver: Error reading data [%i]", status);
            continue;
        }

        bResult = true;
    }
}
