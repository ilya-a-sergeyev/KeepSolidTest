/*
 * FirstFolderCreatorImpl.cpp
 *
 *  Created on: Feb 3, 2013
 *      Author: fireballdark
 */

#include "FirstFolderCreatorImpl.h"
#include "conf/Globals.h"
#include <exception>
#include <sutil/logging.h>
#include <protobuf/util/cpp/message_utility.pb.h>
#include <google/protobuf/message_lite.h>

using google::protobuf::MessageLite;

FirstFolderCreatorImpl::FirstFolderCreatorImpl():
    socket(*Globals::get_globals().getZMQContext(), ZMQ_PUSH)
{
    try
    {
        socket.connect("ipc://firstfolder");
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure connecting as FirstFolder worker: [%s]",e.what());
    }
}

bool FirstFolderCreatorImpl::create_first_folder(const std::string& userLogin,const std::string& password,const std::string& public_key)
{
    bool result = false;

    try
    {
        rpc::UserInfo userInfo;
        userInfo.set_useremail(userLogin);
        userInfo.set_password(password);
        userInfo.set_publickey(public_key);

        std::string serialized;
        userInfo.SerializeToString(&serialized);

        zmq::message_t message(serialized.size());
        memcpy((void*) message.data (), serialized.c_str(), serialized.size());
        result = socket.send(message);

        LOG_ABSOLUTE("FirstFolder message was sent for %s",userLogin.c_str());
    }
    catch(const std::exception& e)
    {
        LOG_ERROR("Got exception %s trying to send FirstFolder message for [%s]",e.what(),userLogin.c_str());
    }

    return result;
}

void FirstFolderCreatorImpl::close()
{
    try
    {
        socket.close();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure closing socket as FirstFolder worker [%s]",e.what());
    }
}

FirstFolderCreatorImpl::~FirstFolderCreatorImpl()
{
    try
    {
        socket.close();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure closing socket as FirstFolder worker [%s]",e.what());
    }
}

