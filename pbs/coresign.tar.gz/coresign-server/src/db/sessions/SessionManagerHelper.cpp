#include "SessionManagerHelper.h"
#include <boost/lexical_cast.hpp>
#include <util/logging.h>

bool convert_sessioninfo_db (Redis::redisMap& query_result, SessionInfo& session)
{
    bool result = false;

    do
    {
        try
        {
            if (query_result.empty())
            {
                LOG_INFORMATION("SessionInfo convert: empty input data");
                break;
            }

            std::string uid = query_result["userid"];
            if (uid.empty())
            {
                LOG_INFORMATION("SessionInfo convert: no user_id");
                break;
            }
            session.user_id         = boost::lexical_cast<decltype(session.user_id)>(uid);

            session.event_session_id= query_result["event_session"];
            session.device_id       = query_result["device_uuid"];
            session.device_name     = query_result["device_name"];
            session.platform        = query_result["platform"];
            session.service         = query_result["service"];
            session.bundle_id       = query_result["bundleid"];
            session.ip_address      = query_result["ip_address"];
            session.public_key      = query_result["pub_key"];

            std::string sc  = query_result["created"];
            if (sc.empty())
            {
                LOG_INFORMATION("SessionInfo convert: no session_created");
                break;
            }
            session.session_created = boost::lexical_cast<decltype(session.session_created)>(sc);
            session.username        = query_result["username"];
            session.version         = query_result["appversion"];

            std::string pr  = query_result["prolong"];
            if (pr.empty())
            {
                LOG_INFORMATION("SessionInfo convert: no prolong");
                break;
            }
            bool prolong            = boost::lexical_cast<decltype(prolong)>(pr);
            if (prolong == true)
            {
                std::string pt  = query_result["ttl"];
                if (sc.empty())
                {
                    LOG_INFORMATION("SessionInfo convert: no ttl");
                    break;
                }
                session.prolong_ttl     = boost::lexical_cast<decltype(session.prolong_ttl)>(pt);
            }

            result = true;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Exception parsing session [%s]", e.what());
            for (auto i : query_result)
            {
                LOG_INFORMATION("Redis KeyValue: [%s]:[%s]", i.first.c_str(), i.second.c_str());
            }
        }
    }
    while (false);

    return result;
}

