/*
 * ServerRpc.cpp
 *
 *  Created on: Apr 2, 2014
 *      Author: fireballdark
 */

#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "logic/AuthLogic.h"
#include "logic/MiscLogic.h"
#include "logic/UserLogic.h"
#include "types/structs_to_protobuf.h"
#include "logic/EventLogic.h"

#include <protobuf/server/cpp/msg_serv_outer.pb.h>
#include <protobuf/server/cpp/msg_serv_type.pb.h>
#include <protobuf/server/cpp/msg_serv_inner.pb.h>
#include "logic/WorkGroupLogic.h"

rpc_status_code_struct ProtobufZmqRpc::accountStatusNoSession(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("AccountStatusNoS");

    server_rpc::AccountStatusNoSessionRequest   input;
    server_rpc::AccountStatusNoSessionResponse*  output = response.mutable_account_status_no_session();
    response.set_message_type(server_rpc::SRPC_ACCOUNT_STATUS_NO_SESSION);

    do
    {
        if (request.has_account_status_no_session())
        {
            input = request.account_status_no_session();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("AccountStatusNoSession function called");
        std::string login     = input.login();

        if (!is_utf8_string(login))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("AccountStatusNoSession function called with [%s] service type [%d]", login.c_str(), context.service_type);

        AccountStats accountStats;
        resultStatus = UserLogic::accountStatsNoSession(context, login, accountStats);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_data_size       (accountStats.data_size);
        output->set_data_size_limit  (accountStats.limits.data_size_limit);

        output->set_login(context.session_info.username);
        output->set_account_status(accountStats.account_status);
        output->set_creation_date(accountStats.creation_date);
        output->set_expiration_date(accountStats.expiration_date);
        output->set_now_date(accountStats.now_date);
        output->set_is_first_login(accountStats.is_first_login);

        LOG_ABSOLUTE("AccountStatusNoSession put status [%s], creation [%lli], expiration [%lli], now [%lli], data_size [%lli], data_size_limit [%lli]",
                accountStats.account_status.c_str(), accountStats.creation_date,
                accountStats.expiration_date, accountStats.now_date,
                accountStats.data_size, accountStats.limits.data_size_limit);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("AccountStatusNoSession function ended with status [%i] [%s]",resultStatus.code, resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::accountStatus(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("AccountStatus");

    server_rpc::AccountStatusRequest   input;
    server_rpc::AccountStatusResponse*  output = response.mutable_account_status();
    response.set_message_type(server_rpc::SRPC_ACCOUNT_STATUS);

    do
    {
        if (request.has_account_status())
        {
            input = request.account_status();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("AccountStatus function called");
        std::string sessionId     = input.session_id();
        bool createIfNull = input.create_if_null();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        context.session_id = sessionId;
        LOG_ABSOLUTE("AccountStats function called with [%s] service type [%d]",sessionId.c_str(), context.service_type);


        AccountStats accountStats;
        resultStatus = UserLogic::accountStats(context, accountStats, false, true, createIfNull);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_data_size       (accountStats.data_size);
        output->set_data_size_limit  (accountStats.limits.data_size_limit);

        output->set_login(context.session_info.username);
        output->set_account_status(accountStats.account_status);
        output->set_creation_date(accountStats.creation_date);
        output->set_expiration_date(accountStats.expiration_date);
        output->set_now_date(accountStats.now_date);
        output->set_encrypted_password(accountStats.encrypted_password);
        output->set_is_first_login(accountStats.is_first_login);

        for (AddressesList::iterator i = accountStats.api_servers.begin() ; i!= accountStats.api_servers.end() ; i++)
        {
            server_rpc::ConnectionEndpoint* connectionEndpoint = output->add_api_servers();
            connectionEndpoint->set_address((*i).first);
            connectionEndpoint->set_port((*i).second);
        }

        for (AddressesList::iterator i = accountStats.notification_servers.begin() ; i!= accountStats.notification_servers.end() ; i++)
        {
            server_rpc::ConnectionEndpoint* connectionEndpoint = output->add_notification_servers();
            connectionEndpoint->set_address((*i).first);
            connectionEndpoint->set_port((*i).second);
        }

        LOG_ABSOLUTE("AccountStats put status [%s], creation [%lli], expiration [%lli], now [%lli], data_size [%lli], data_size_limit [%lli]",
                accountStats.account_status.c_str(), accountStats.creation_date,
                accountStats.expiration_date, accountStats.now_date,
                accountStats.data_size, accountStats.limits.data_size_limit);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("AccountStatus function ended with status [%i] [%s]",resultStatus.code, resultStatus.code_to_string().c_str());
    return resultStatus;
}


rpc_status_code_struct ProtobufZmqRpc::inviteAccept(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("InviteAccept");

    server_rpc::InviteAcceptRequest   input;
    server_rpc::InviteAcceptResponse*  output = response.mutable_invite_accept();
    response.set_message_type(server_rpc::SRPC_INVITE_ACCEPT);

    do
    {
        if (request.has_invite_accept())
        {
            input = request.invite_accept();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("InviteAccept function called");
        std::string sessionId     = input.session_id();
        std::string inviteId      = input.invite_id();
        std::string inviteeLogin  = input.invitee_login();

        if (!is_utf8_string(sessionId)
                || !is_utf8_string(inviteId)
                || !is_utf8_string(inviteeLogin))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        context.session_id = sessionId;
        LOG_ABSOLUTE("InviteAccept function called with [%s] service type [%d]", sessionId.c_str(), context.service_type);

        resultStatus = WorkGroupLogic::workgroupSubscribe(context, inviteId, true);

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("InviteAccept function ended with status [%i] [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::purchaseApply(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("PurchaseApply");

    server_rpc::PurchaseApplyRequest   input;
    server_rpc::PurchaseApplyResponse*  output = response.mutable_purchase_apply();
    response.set_message_type(server_rpc::SRPC_PURCHASE_APPLY);

    do
    {
        if (request.has_purchase_apply())
        {
            input = request.purchase_apply();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("PurchaseApply function called");
        PurchaseData purchaseInfo;
        convert_purchaseinfo(&input, purchaseInfo);

        if (!is_utf8_string(purchaseInfo.login)
                || !is_utf8_string(purchaseInfo.type)
                || !is_utf8_string(purchaseInfo.hash)
                || !is_utf8_string(purchaseInfo.name))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("PurchaseApply function called with [%s][%s] sandbox [%i] service type [%d]",
                purchaseInfo.login.c_str(), purchaseInfo.name.c_str(), purchaseInfo.sandbox, context.service_type);

        resultStatus = UserLogic::purchaseApply(context, purchaseInfo);

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("PurchaseApply function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::purchaseRefund(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("PurchaseRefund");

    server_rpc::PurchaseRefundRequest   input;
    server_rpc::PurchaseRefundResponse*  output = response.mutable_purchase_refund();
    response.set_message_type(server_rpc::SRPC_PURCHASE_REFUND);

    do
    {
        if (request.has_purchase_refund())
        {
            input = request.purchase_refund();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("PurchaseRefund function called");

        std::string login = input.login();
        std::string hash  = input.hash();

        if (!is_utf8_string(login)
                || !is_utf8_string(hash))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("PurchaseRefund function called for [%s] with [%s]",
                login.c_str(), hash.c_str());

        resultStatus = UserLogic::purchaseRefund(context, login, hash);

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("PurchaseRefund function ended with status [%i] [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}


rpc_status_code_struct ProtobufZmqRpc::userRemove(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("UserRemove");

    server_rpc::UserRemoveRequest   input;
    server_rpc::UserRemoveResponse*  output = response.mutable_user_remove();
    response.set_message_type(server_rpc::SRPC_USER_REMOVE);

    do
    {
        if (request.has_user_remove())
        {
            input = request.user_remove();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("UserRemove function called");

        std::string login = input.login();

        if (!is_utf8_string(login))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("UserRemove function called for [%s]", login.c_str());

        resultStatus = UserLogic::userRemove(context, login);

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("UserRemove function ended with status [%i] [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}


rpc_status_code_struct ProtobufZmqRpc::subscribeEvents (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("SubscribeEventsServer");

    server_rpc::SubscribeEventsServerRequest   input;
    server_rpc::SubscribeEventsServerResponse* output = response.mutable_subscribe_events();
    response.set_message_type(server_rpc::SRPC_SUBSCRIBE_EVENTS);

    do
    {
        if (request.has_subscribe_events())
        {
            input = request.subscribe_events();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("SubscribeEventsServer function called");
        std::string sessionId   = input.session_id();
        int64_t serviceType     = input.service_type();
        std::string ipAddress   = input.ip_address();

        if (!is_utf8_string(sessionId)
                || !is_utf8_string(ipAddress))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        context.session_id  = sessionId;
        context.service_type= serviceType;
        context.ip_address  = ipAddress;

        LOG_ABSOLUTE("SubscribeEventsServer function called with [%s] from [%s] service type [%d]", sessionId.c_str(), ipAddress.c_str(), context.service_type);

        int64_t userId = -1;
        resultStatus = AuthLogic::subscribeEvents(context, userId);
        output->set_user_id(userId);

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("SubscribeEventsServer function ended with status [%i] [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}


