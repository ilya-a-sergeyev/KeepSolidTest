/*
 * xopenssl_defines.h
 *
 *  Created on: May 20, 2013
 *      Author: fireballdark
 */

#pragma once

#define KSD1_SIGNATURE      "KSD10001"
#define KSD2_SIGNATURE      "KSD20002"
#define KSD_SIGNATURE_LIMIT 1024

#define RSA_KEY_LENGTH      512

#define XOPENSSL_OLD_FILE_ENCRYPTION_SUPPORT

#ifdef __unix
#define MD5_DIGEST_SIZE     EVP_MD_size(EVP_md5())
#define AES256_IV_SIZE      EVP_CIPHER_iv_length(EVP_aes_256_cbc())
#define AES256_BLOCK_SIZE   EVP_CIPHER_block_size(EVP_aes_256_cbc())
#define AES256_KEY_SIZE     EVP_CIPHER_key_length(EVP_aes_256_cbc())
#define RSA_KEY_SIZE        4096
#define IO_BLOCK_SIZE       8192
#endif

#ifdef __APPLE__
#define MD5_DIGEST_SIZE     EVP_MD_size(EVP_md5())
#define AES256_IV_SIZE      EVP_CIPHER_iv_length(EVP_aes_256_cbc())
#define AES256_BLOCK_SIZE   EVP_CIPHER_block_size(EVP_aes_256_cbc())
#define AES256_KEY_SIZE     EVP_CIPHER_key_length(EVP_aes_256_cbc())
#define RSA_KEY_SIZE        4096
#define IO_BLOCK_SIZE       8192
#endif

#ifdef __ANDROID__
#define MD5_DIGEST_SIZE     EVP_MD_size(EVP_md5())
#define AES256_IV_SIZE      EVP_CIPHER_iv_length(EVP_aes_256_cbc())
#define AES256_BLOCK_SIZE   EVP_CIPHER_block_size(EVP_aes_256_cbc())
#define AES256_KEY_SIZE     EVP_CIPHER_key_length(EVP_aes_256_cbc())
#define RSA_KEY_SIZE        4096
#define IO_BLOCK_SIZE       8192
#endif

#ifdef _WIN32
#define MD5_DIGEST_SIZE     16
#define AES256_IV_SIZE      16
#define AES256_BLOCK_SIZE   16
#define AES256_KEY_SIZE     32
#define RSA_KEY_SIZE        4096
#define IO_BLOCK_SIZE       8192
#endif

#include <openssl/e_os2.h>
#if defined (__ANDROID__)
    #define FTELL64(stream)                 ftello(stream)
    #define FSEEK64(stream, offset, whence) fseeko(stream, offset, whence)
#elif defined (OPENSSL_SYS_LINUX)
    #define FTELL64(stream)                 ftello64(stream)
    #define FSEEK64(stream, offset, whence) fseeko64(stream, offset, whence)
#elif defined (OPENSSL_SYS_MACOSX)
    #define FTELL64(stream)                 ftello(stream)
    #define FSEEK64(stream, offset, whence) fseeko(stream, offset, whence)
#elif defined (OPENSSL_SYS_IOS)
    #define FTELL64(stream)                 ftello(stream)
    #define FSEEK64(stream, offset, whence) fseeko(stream, offset, whence)
#elif defined (OPENSSL_SYS_WIN32)
    #define FTELL64(stream)                 _ftelli64(stream)
    #define FSEEK64(stream, offset, whence) _fseeki64(stream, offset, whence)
#endif


/******************************************************************************
 helpers
 ******************************************************************************/
#pragma mark- Helpers

//void show_openssl_errors(const std::string& message)
#define SHOW_OPENSSL_ERRORS( message ) \
{ \
    ERR_load_ERR_strings(); \
    char err_string[128]; \
    for (unsigned long errCode = ERR_get_error(); errCode>0; errCode = ERR_get_error()) \
    { \
        ERR_error_string_n(errCode, err_string, sizeof(err_string)); \
        LOG_ERROR("OpenSSL: %s %s", message, err_string); \
    } \
    ERR_free_strings(); \
}
