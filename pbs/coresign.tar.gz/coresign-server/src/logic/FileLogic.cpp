/*
 * logic.cpp
 *
 *  Created on: 31 бер. 2011
 *      Author: fireball
 */

#include "logic/FileLogic.h"

#include <encryption/xopenssl.h>

#include <util/get_time_string.h>
#include <sutil/logging.h>
#include <util/DataVerifier.h>
#include <sutil/MailerHelper.h>
#include <sutil/amazon_s3.h>

#include "db/tariffs/TariffManagerPgSql.h"
#include "db/users/UserManagerPgSql.h"
#include "db/files/FileManagerPgSql.h"
#include "db/folders/FolderManagerPgSql.h"
#include "logic/EventLogic.h"
#include "logic/HelperLogic.h"
#include "types/request_context.h"


rpc_status_code FileLogic::filesList(RequestContext& context, int filesFilter, int64_t folderId, int64_t parentId, FilesInfoList& filesList, int64_t& lastEventId)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder() || folderInfo.invite_accepted == false)
        {
            statusCode = status_access_denied;
            break;
        }

        if (parentId == -1)
        {
            if (filesFilter == 0)
            {
                statusCode = FileManagerPgSql::list_files(userId,false,folderId,filesList,lastEventId);
            }
            else if (filesFilter == 1)
            {
                statusCode = FileManagerPgSql::list_files(userId,true,folderId,filesList,lastEventId);
            }
            else if (filesFilter == 2)
            {
                statusCode = FileManagerPgSql::list_all_files(userId,folderId,filesList,lastEventId);
            }
        }
        else
        {
            //Check if directory exists
            if (parentId > 0)
            {
                FileInfo dirInfo;
                dirInfo.file_id = parentId;
                dirInfo.workgroup_id = folderId;
                statusCode = FileManagerPgSql::get_short_directory_info(userId,dirInfo);

                if (statusCode != status_success)
                {
                    break;
                }
            }

            if (filesFilter == 0)
            {
                statusCode = FileManagerPgSql::list_files_parent(userId,false,folderId,parentId,filesList,lastEventId);
            }
            else if (filesFilter == 1)
            {
                statusCode = FileManagerPgSql::list_files_parent(userId,true,folderId,parentId,filesList,lastEventId);
            }
            else if (filesFilter == 2)
            {
                statusCode = FileManagerPgSql::list_all_files_parent(userId,folderId,parentId,filesList,lastEventId);
            }
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("FilesList function ended: userId [%lli] : session [%s], files number [%zi]", userId, context.session_id.c_str(), filesList.size());
    }
    else
    {
        LOG_INFORMATION("FilesList function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}


rpc_status_code FileLogic::fileRename(RequestContext& context, int64_t folderId, int64_t fileId, const std::string& fileNameNew, int64_t& revision_ret)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;
    FileInfo fileInfo;

    do
    {
        if (check_file_name(fileNameNew)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("FileName [%s] is not valid for creation",fileNameNew.c_str());
            statusCode = status_bad_syntax;
            break;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        if (folderInfo.is_deleted == true)
        {
            statusCode = status_access_denied;
            break;
        }

        fileInfo.file_id = fileId;
        statusCode = FileManagerPgSql::get_approved_file_info(userId,fileInfo);
        if (statusCode != status_success )
        {
            break;
        }

        statusCode = FileManagerPgSql::rename_file(userId,folderId,fileId,fileInfo.revision,fileNameNew,revision_ret);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);
        EventLogic::fileRename(userId,userInfo.login,deviceId,folderId,fileId,fileInfo.parent_id,fileInfo.file_name,fileNameNew,fileInfo.is_directory);
        LOG_ABSOLUTE("FileRename function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("FileRename function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileDelete(RequestContext& context, int64_t folderId, int64_t fileId, int64_t revision, bool removeNow)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        KSD::AccessRightsHelper access_rights = HelperLogic::checkPermissions(userId,folderId,folderInfo);
        if (folderInfo.is_deleted == true || !access_rights.get_read_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        statusCode = fileDeleteRecursiveSafe(userId,deviceId,folderId,fileId,revision,removeNow,access_rights, true);


        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("FileDelete function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("FileDelete function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileDeleteRecursiveSafe(int64_t userId,  const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t revision, bool removeNow, const KSD::AccessRightsHelper& access_rights, bool isFirst /* = false*/)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;
    std::string fileName;
    FileInfo fileInfo_last;

    do
    {
        fileInfo_last.file_id = fileId;
        fileInfo_last.workgroup_id = folderId;
        statusCode = FileManagerPgSql::get_approved_file_info(userId,fileInfo_last);

        if (fileInfo_last.is_directory)
        {
            std::vector<int64_t> children;
            FileManagerPgSql::get_directory_children(userId,fileInfo_last.workgroup_id,fileInfo_last.file_id,children);
            for (unsigned int i=0; i<children.size(); i++)
            {
                fileDeleteRecursiveSafe(userId,deviceId,folderId,children[i],0,removeNow,access_rights);
            }
        }

        FileInfo fileInfo_deleted;
        if (revision>0)
        {
            fileInfo_deleted.file_id = fileId;
            fileInfo_deleted.revision = revision;
            statusCode = FileManagerPgSql::get_exact_file_info(userId,fileInfo_deleted);
        }
        else
        {
            fileInfo_deleted = fileInfo_last;
        }

        fileName = fileInfo_deleted.file_name;

        if (statusCode != status_success)
        {
            LOG_INFORMATION("No approved file found for file %lli:%lli in folder %lli",fileInfo_last.file_id,fileInfo_last.revision,fileInfo_last.workgroup_id);
            LOG_INFORMATION("No exact file found for file %lli:%lli in folder %lli",fileInfo_deleted.file_id,fileInfo_deleted.revision,fileInfo_deleted.workgroup_id);
            break;
        }

        if (removeNow == false)
        {
            if (!access_rights.get_write_folder())
            {
                statusCode = status_access_denied;
                break;
            }
            if (revision > 0)
            {
                statusCode = FileManagerPgSql::remove_file(userId,folderId,fileId,revision);
            }
            else
            {
                statusCode = FileManagerPgSql::remove_file(userId,folderId,fileId);
            }
        }
        else
        {
            if (!access_rights.get_delete_folder())
            {
                statusCode = status_access_denied;
                break;
            }
            if (revision > 0)
            {
                statusCode = FileManagerPgSql::remove_file_now(userId,folderId,fileId,revision);
            }
            else
            {
                statusCode = FileManagerPgSql::remove_file_now(userId,folderId,fileId);
            }
        }

        if (revision>0 && !fileInfo_last.is_directory)
        {
            FileManagerPgSql::remove_file_to_delete(userId,folderId,fileId,revision);
        }
        else
        {
            FileManagerPgSql::remove_file_to_delete(userId,folderId,fileId);
        }

        if (statusCode != status_success)
        {
            break;
        }

        if (fileInfo_last.revision == fileInfo_deleted.revision && !fileInfo_deleted.is_directory)
        {
            rpc_status_code statusCode = status_internal_error;
            statusCode = WorkGroupManagerPgSql::update_folder_size(userId,fileInfo_deleted.workgroup_id,fileInfo_deleted.size,0);
            statusCode = FileManagerPgSql::get_approved_file_info(userId,fileInfo_last);
            if (statusCode == status_success)
            {
                statusCode = WorkGroupManagerPgSql::update_folder_size(userId,fileInfo_last.workgroup_id,0,fileInfo_last.size);
            }
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);
        if (isFirst == true)
        {
            EventLogic::fileDelete(userId,userInfo.login,deviceId,folderId,fileId,fileInfo_last.parent_id,fileName,fileInfo_last.is_directory);
        }

        LOG_ABSOLUTE("fileDeleteRecursiveSafe function ended: userId [%lli]", userId);
    }
    else
    {
        LOG_INFORMATION("fileDeleteRecursiveSafe function failed: userId [%lli]", userId);
    }

    return statusCode;
}

rpc_status_code FileLogic::fileUndelete(RequestContext& context, int64_t folderId, int64_t fileId, int64_t revision)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        KSD::AccessRightsHelper access_rights = HelperLogic::checkPermissions(userId,folderId,folderInfo);
        if (folderInfo.is_deleted == true || !access_rights.get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        if (revision > 0)
        {
            statusCode = FileManagerPgSql::undelete_file(userId,folderId,fileId,revision);
        }
        else
        {
            statusCode = FileManagerPgSql::undelete_file(userId,folderId,fileId);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

        UserInfo userInfo;
        UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

        FileInfo fileInfo;
        fileInfo.workgroup_id = folderId;
        fileInfo.file_id = fileId;
        if (revision >0)
        {
            fileInfo.revision = revision;
            FileManagerPgSql::get_exact_file_info(userId,fileInfo);
        }
        else
        {
            FileManagerPgSql::get_approved_file_info(userId,fileInfo);
        }
        EventLogic::fileUndelete(userId,userInfo.login,deviceId,folderId,fileId,fileInfo.parent_id,fileInfo.size,fileInfo.file_name);

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("FileDelete function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("FileDelete function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileInfo(RequestContext& context, FileInfo& fileInfo)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,fileInfo.workgroup_id,folderInfo).get_read_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        statusCode = FileManagerPgSql::get_approved_file_info(userId,fileInfo);

        if (statusCode==status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("FileInfo function ended: userId [%lli] : session [%s], file %lli, name [%s]", userId, context.session_id.c_str(), fileInfo.file_id, fileInfo.file_name.c_str());
    }
    else
    {
        LOG_INFORMATION("FileInfo function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileDownload(RequestContext& context, FileInfo& fileInfo)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bstatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,fileInfo.workgroup_id,folderInfo).get_read_folder())
        {
            statusCode = status_access_denied;
            break;
        }
        /*if (folderInfo.isDeleted == true)
        {
            statusCode = status_access_denied;
            break;
        }*/

        if (fileInfo.file_id <= 0)
        {
            if (check_file_name(fileInfo.file_name)!=EXIT_SUCCESS)
            {
                LOG_INFORMATION("FileName [%s] is not valid for download",fileInfo.file_name.c_str());
                statusCode = status_bad_syntax;
                break;
            }

            statusCode = FileManagerPgSql::get_file_by_name(userId,fileInfo);
        }

        if (statusCode != status_success || fileInfo.file_id < 0 )
        {
            break;
        }

        if (fileInfo.revision)
        {
            statusCode = FileManagerPgSql::get_exact_file_info(userId, fileInfo);
        }
        else
        {
            statusCode = FileManagerPgSql::get_approved_file_info(userId, fileInfo);
        }


        if (statusCode == status_success)
        {
            bstatus = true;
        }

        amazon_s3_download(fileInfo.file_url,fileInfo.s3_url);
    }
    while (false);

    if (bstatus)
    {
        LOG_ABSOLUTE("FileDownload function ended: userId [%lli] : session [%s], fileName %s, fileId %lli", userId, context.session_id.c_str(), fileInfo.file_name.c_str(), fileInfo.file_id);
    }
    else
    {
        LOG_INFORMATION("FileDownload function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileUpload(RequestContext& context, FileInfo& fileInfo)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if (check_file_name(fileInfo.file_name)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("FileName [%s] is not valid for creation",fileInfo.file_name.c_str());
            statusCode = status_bad_syntax;
            break;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,fileInfo.workgroup_id,folderInfo).get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }
        if (folderInfo.is_deleted == true)
        {
            statusCode = status_access_denied;
            break;
        }

        if (fileInfo.parent_id < -1)
        {
            LOG_ERROR("FileUpload - parentId is less than -1 : %lli",fileInfo.parent_id);
            statusCode = status_bad_syntax;
            break;
        }
        //Check if directory exists
        if (fileInfo.parent_id > 0)
        {
            FileInfo dirInfo;
            dirInfo.file_id = fileInfo.parent_id;
            dirInfo.workgroup_id = fileInfo.workgroup_id;
            statusCode = FileManagerPgSql::get_short_directory_info(userId,dirInfo);

            if (statusCode != status_success)
            {
                LOG_INFORMATION("No such parent_id [%lli] to upload file into!", fileInfo.parent_id);
                std::stringstream str;
                str<<"No such parent_id [";
                str<<fileInfo.parent_id;
                str<<"] to upload file into!";
                ADD_ERROR_MESSAGE(context, str.str());
                break;
            }
        }

        do
        {
            bool isBlocked = false;
            statusCode = WorkGroupManagerPgSql::check_block_folder(userId,fileInfo.workgroup_id,isBlocked);
            if (!isBlocked)
            {
                statusCode = WorkGroupManagerPgSql::block_folder(userId,fileInfo.workgroup_id,true);
                break;
            }
            boost::asio::io_service io;
            boost::asio::deadline_timer timer(io,boost::posix_time::seconds(0.2));
        }
        while(1);

        FileInfo fileInfo_temp;
        fileInfo_temp.workgroup_id = fileInfo.workgroup_id;
        fileInfo_temp.file_name = fileInfo.file_name;
        fileInfo_temp.parent_id = fileInfo.parent_id;

        statusCode = FileManagerPgSql::get_file_by_name(userId,fileInfo_temp);
        fileInfo.file_id = fileInfo_temp.file_id;

        //if file already exists, return its fileId
        if (statusCode == status_success && fileInfo.file_id>0)
        {
            if (fileInfo.parent_id == fileInfo_temp.parent_id && fileInfo.size == fileInfo_temp.size && fileInfo.hash.compare(fileInfo_temp.hash) == 0)
            {
                statusCode = status_already_exist;
                fileInfo.file_url = fileInfo_temp.file_url;
                fileInfo.file_id = fileInfo_temp.file_id;
                fileInfo.revision = fileInfo_temp.revision;
                LOG_ABSOLUTE("FileUpload: trying to upload duplicate file %lli %lli - [%s-%lli] [%s-%lli]",fileInfo_temp.file_id,fileInfo_temp.revision,fileInfo_temp.hash.c_str(),fileInfo_temp.size,fileInfo.hash.c_str(),fileInfo.size);
                break;
            }
        }

        FileInfo oldFileInfo;
        oldFileInfo.file_id = fileInfo.file_id;
        oldFileInfo.workgroup_id = fileInfo.workgroup_id;
        statusCode = FileManagerPgSql::get_approved_file_info(userId, oldFileInfo);

        int64_t foldersSumSize=0;
        statusCode = WorkGroupManagerPgSql::get_folders_sum_size(userId,foldersSumSize);
        TariffLimits limits;
        statusCode = TariffManagerPgSql::get_user_limits(userId,limits);

        if ((foldersSumSize-oldFileInfo.size+fileInfo.size) > limits.data_size_limit)
        {
            statusCode = status_payment_required;
            LOG_ABSOLUTE("FileUpload: filesize exceeds user tariff quota, current size %lli, limit %lli, filesize -%lli +%lli", foldersSumSize, limits.data_size_limit, fileInfo.size, oldFileInfo.size);
            break;
        }

        if (statusCode == status_success)
        {
            statusCode = WorkGroupManagerPgSql::update_folder_size(userId,fileInfo.workgroup_id,oldFileInfo.size,fileInfo.size);
        }
        else
        {
            break;
        }

        std::stringstream ss;
        ss<<get_yearmonthday()<<"/";
        ss<<fileInfo.workgroup_id<<"/";
        ss<<fileInfo.size<<"_"<<fileInfo.hash<<"_"<<randomstring(8);
        fileInfo.file_url = ss.str();

        if (fileInfo.file_id>0)
        {
            fileInfo.is_approved = false;
            statusCode = FileManagerPgSql::create_file_rev(userId,fileInfo);
        }
        else
        {
            fileInfo.is_approved = false;
            statusCode = FileManagerPgSql::create_file(userId,fileInfo);
        }

        if (statusCode != status_success)
        {
            break;
        }

        FileManagerPgSql::create_file_to_delete(userId,fileInfo);

        if (statusCode != status_success)
        {
            statusCode = WorkGroupManagerPgSql::update_folder_size(userId,fileInfo.workgroup_id,fileInfo.size,0);
        }

        FileManagerPgSql::get_exact_file_info(userId,fileInfo);


    }
    while(false);

    WorkGroupManagerPgSql::block_folder(userId,fileInfo.workgroup_id,false);

    if (statusCode == status_success || statusCode == status_already_exist)
    {
        amazon_s3_upload(fileInfo.file_url, fileInfo.hash, fileInfo.s3_url);
        bStatus = true;
    }

    if (bStatus)
    {
        LOG_ABSOLUTE("FileUpload function ended: userId [%lli] : session [%s], fileName %s, fileId %lli", userId, context.session_id.c_str(), fileInfo.file_name.c_str(), fileInfo.file_id);
    }
    else
    {
        LOG_INFORMATION("FileUpload function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }



    return statusCode;
}

rpc_status_code FileLogic::fileUploadApprove(RequestContext& context, FileInfo& fileInfo)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,fileInfo.workgroup_id,folderInfo).get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }
        if(folderInfo.is_deleted == true)
        {
            statusCode = status_access_denied;
            break;
        }

        statusCode = FileManagerPgSql::get_exact_file_info(userId, fileInfo);

        FileInfo oldFileInfo;
        oldFileInfo.file_id = fileInfo.file_id;
        oldFileInfo.workgroup_id = fileInfo.workgroup_id;
        statusCode = FileManagerPgSql::get_approved_file_info(userId, oldFileInfo);

        if (statusCode != status_success && statusCode != status_does_not_exist)
        {
            break;
        }

        bool is_first = false;
        statusCode = FileManagerPgSql::approve_file(userId, fileInfo, is_first);

        if (statusCode != status_success)
        {
            break;
        }

        /*
        statusCode = FolderManagerPgSql::update_folder_size(userId,fileInfo.folderId,oldFileInfo.fileSize,fileInfo.fileSize);

        if (statusCode != status_success)
        {
            break;
        }
        */

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

        if (is_first == true)
        {
            EventLogic::fileCreate(userId,userInfo.login,deviceId,fileInfo.workgroup_id,fileInfo.file_id,fileInfo.parent_id,fileInfo.size,fileInfo.file_name);
        }
        else
        {
            EventLogic::fileUpdate(userId,userInfo.login,deviceId,fileInfo.workgroup_id,fileInfo.file_id,fileInfo.parent_id,fileInfo.size,fileInfo.file_name);
        }

        bStatus = true;
    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("FileUploadApprove function ended: userId [%lli] : session [%s], fileName %s, fileId %lli", userId, context.session_id.c_str(), fileInfo.file_name.c_str(), fileInfo.file_id);
    }
    else
    {
        LOG_INFORMATION("FileUploadApprove function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileDirectoryCreate(RequestContext& context, FileInfo& fileInfo)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if (check_file_name(fileInfo.file_name)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("FileDirectoryName [%s] is not valid for creation",fileInfo.file_name.c_str());
            statusCode = status_bad_syntax;
            break;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,fileInfo.workgroup_id,folderInfo).get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }
        if (folderInfo.is_deleted == true)
        {
            statusCode = status_access_denied;
            break;
        }

        if (fileInfo.parent_id < -1)
        {
            LOG_ERROR("FileDirectoryCreate - parentId is less than -1 : %lli",fileInfo.parent_id);
            statusCode = status_bad_syntax;
            break;
        }

        FileInfo fileInfo_temp;
        fileInfo_temp.workgroup_id = fileInfo.workgroup_id;
        fileInfo_temp.file_name = fileInfo.file_name;
        fileInfo_temp.parent_id = fileInfo.parent_id;

        statusCode = FileManagerPgSql::get_file_by_name(userId,fileInfo_temp);
        fileInfo.file_id = fileInfo_temp.file_id;

        //if file already exists, return its fileId
        if (statusCode == status_success && fileInfo.file_id>0)
        {
            if (fileInfo.parent_id == fileInfo_temp.parent_id)
            {
                statusCode = status_already_exist;
                fileInfo.file_url = fileInfo_temp.file_url;
                fileInfo.file_id = fileInfo_temp.file_id;
                fileInfo.revision = fileInfo_temp.revision;
                LOG_ABSOLUTE("FileDirectoryCreate: trying to upload duplicate file [%lli:%lli]",fileInfo_temp.file_id,fileInfo_temp.revision);
                break;
            }
        }

        fileInfo.is_directory = true;
        fileInfo.is_approved = true;
        statusCode = FileManagerPgSql::create_file(userId,fileInfo);

        if (statusCode != status_success)
        {
            break;
        }

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);
        if (statusCode != status_success)
		{
			break;
		}
        EventLogic::fileDirectoryCreate(userId,userInfo.login,deviceId,fileInfo.workgroup_id,fileInfo.file_id,fileInfo.parent_id,fileInfo.file_name);
        if (statusCode == status_success || statusCode == status_already_exist)
        {
            //amazon_s3_upload(fileInfo.fileUrl, fileInfo.fileHash, fileInfo.s3Url);
            bStatus = true;
        }

        statusCode = FileManagerPgSql::get_file_by_name(userId,fileInfo_temp);

        if (statusCode != status_success)
        {
        	break;
        }
        fileInfo.creation_date = fileInfo_temp.creation_date;
        fileInfo.creation_date_str = fileInfo_temp.creation_date_str;

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("FileDirectoryCreate function ended: userId [%lli] : session [%s], fileName %s, fileId %lli", userId, context.session_id.c_str(), fileInfo.file_name.c_str(), fileInfo.file_id);
    }
    else
    {
        LOG_INFORMATION("FileDirectoryCreate function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }



    return statusCode;
}


rpc_status_code FileLogic::fileDirectoryHierarchy(RequestContext& context, const FileInfo& fileInfo, FilesInfoList& filesInfoList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,fileInfo.workgroup_id,folderInfo).get_read_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        FileInfo fileInfo_copy = fileInfo;
        statusCode = FileManagerPgSql::get_approved_file_info(userId,fileInfo_copy);

        int64_t parentId = 0;
        if (fileInfo_copy.is_directory == true)
        {
            parentId = fileInfo_copy.file_id;
        }
        else
        {
            parentId = fileInfo_copy.parent_id;
        }

        do
        {
            FileInfo fileInfo_parent;
            fileInfo_parent.file_id = parentId;
            fileInfo_parent.workgroup_id = folderInfo.workgroup_id;
            statusCode = FileManagerPgSql::get_short_directory_info(userId,fileInfo_parent);
            if (statusCode!=status_success )
            {
                break;
            }
            parentId = fileInfo_parent.parent_id;
            filesInfoList.push_back(fileInfo_parent);
        }
        while (parentId>0);

        if (statusCode == status_does_not_exist || statusCode == status_success)
        {
            statusCode = status_success;
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("FileDirectoryHierarchy function ended: userId [%lli] : session [%s], files number [%zi]", userId, context.session_id.c_str(), filesInfoList.size());
    }
    else
    {
        LOG_INFORMATION("FileDirectoryHierarchy function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}


rpc_status_code FileLogic::fileSearch(RequestContext& context, int64_t folderId, const std::string& searchString, int64_t minSize, int64_t maxSize, FilesInfoList& filesInfoList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if (check_search_string(searchString)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("Name [%s] cannot be part of filename",searchString.c_str());
            return status_bad_syntax;
        }

        std::string normSearchString = normalize_search_string(searchString);
        LOG_ABSOLUTE("Name [%s] got after normalization",normSearchString.c_str());

        if (check_search_string(normSearchString)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("Name [%s] cannot be part of filename",normSearchString.c_str());
            return status_bad_syntax;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (folderId > 0)
        {
            WorkGroupInfo folderInfo;
            if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder() || (folderInfo.encryption_type!=enc_type_auto && folderInfo.encryption_type!=enc_type_none))
            {
                statusCode = status_access_denied;
                break;
            }
            if (minSize == -1 && maxSize == -1)
            {
                statusCode = FileManagerPgSql::search_file_in_folder(userId,folderId,normSearchString,filesInfoList);
            }
            else
            {
                /*TODO*/
                statusCode = status_not_implemented;
            }
        }
        else
        {
            if (minSize == -1 && maxSize == -1)
            {
                /*FoldersInfoList foldersList;
                int64_t lastEventId;
                statusCode = FolderManagerPgSql::list_folders(userId,false,foldersList,lastEventId);
                for (int i=0; i<foldersList.size(); i++)
                {
                    statusCode = FileManagerPgSql::search_file_in_folder(userId,foldersList[i].folderId,searchString,filesInfoList);
                }*/
                statusCode = FileManagerPgSql::search_file(userId,normSearchString,filesInfoList);
            }
            else
            {
                /*TODO*/
                statusCode = status_not_implemented;
            }
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("FileSearch function ended: userId [%lli] : session [%s], files number [%zi]", userId, context.session_id.c_str(), filesInfoList.size());
    }
    else
    {
        LOG_INFORMATION("FileSearch function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileHistory(RequestContext& context, int filesFilter, int64_t folderId, int64_t fileId, FilesInfoList& filesList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder())
        {
            statusCode = status_access_denied;
            break;
        }
        if(folderInfo.is_deleted == true)
        {
            statusCode = status_access_denied;
            break;
        }

        if (filesFilter == 0)
        {
            statusCode = FileManagerPgSql::get_history(userId,false,folderId,fileId,filesList);
        }
        else if (filesFilter == 1)
        {
            statusCode = FileManagerPgSql::get_history(userId,true,folderId,fileId,filesList);
        }
        else if (filesFilter == 2)
        {
            statusCode = FileManagerPgSql::get_full_history(userId,folderId,fileId,filesList);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("FileHistory function ended: userId [%lli] : session [%s], files number [%zi]", userId, context.session_id.c_str(), filesList.size());
    }
    else
    {
        LOG_INFORMATION("FileHistory function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code FileLogic::fileMove(RequestContext& context, int64_t folderId, int64_t fileId, int64_t newParentId)
{
    return status_not_implemented;
}
