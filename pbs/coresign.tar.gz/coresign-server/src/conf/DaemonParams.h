/*
 * DaemonParams.h
 *
 *  Created on: 4 трав. 2011
 *      Author: fireball
 */

#ifndef DAEMONPARAMS_H_
#define DAEMONPARAMS_H_
#include <string>
#include <sutil/LoggingData.h>

/// Contains RPC protocol variants
enum RPCVariant
{
    UNDEFINED_RPC = 0,
    ECHO_TCP,
    XMLRPC_HTTP,
    XMLRPC_TCP,
    PROTOBUF_ZMQ,
    PROTOBUF_ASIO
};

/// Contains variants of requests processing
enum WorkerModel
{
    UNDEFINED_Worker = 0,
    Single_Thread,
    Pthreads,
    Processes
};

class DaemonParams;

DaemonParams&  daemon_params();

WorkerModel parse_worker_model(const char* worker_model);

RPCVariant  parse_rpc_variant(const char* rpc_variant);

/**
 * Class which is the central storage of daemon's runtime parameters
 */
class DaemonParams
{
public:
    DaemonParams();
    ~DaemonParams() {};

    static DaemonParams&    get_daemon_params()
    {
        static DaemonParams singleton;
        return singleton;
    }

    int                     initWithDefaults    ();

    //Getters
    const std::string&      getProgramName      () const { return programName; };
    const std::string&      getConfFilePath     () const { return confFilePath; };
    const std::string&      getLogFilePath      () const { return logFilePath; };
    int                     getDaemonize        () const { return daemonize; };

    const std::string&      getListenAddress    () const { return listenAddress; };
    int                     getListenPort       () const { return listenPort; };
    const std::string&      getRedirectAddress  () const { return redirectAddress; };
    int                     getRedirectPort     () const { return redirectPort; };
    const std::string&      getNotificationEmitAddress  () const { return notificationEmitAddress; };
    int                     getNotificationEmitPort     () const { return notificationEmitPort; };
    const std::string&      getNotificationRegAddress  () const { return notificationRegAddress; };
    int                     getNotificationRegPort     () const { return notificationRegPort; };
    int                     getWorkerPoolSize   () const { return workerPoolSize; };
    int                     getMaxWorkers       () const { return maxWorkers; };
    int                     getRequestMaxSize   () const { return requestMaxSize; };
    int                     getConnectionTimeout() const { return connectionTimeout; };

    int                     getEmailEnabled     () const { return emailEnabled; };
    std::string             getEmailClient      () const { return emailClient; };
    std::string             getEmailSender      () const { return emailSender; };

    int                     getAmazonS3Expiration() const { return amazonS3Expiration; };
    int                     getTimersEnabled    () const { return timersEnabled; };
    std::string             getSecurityCodesKey () const { return securityCodesKey; };

    //Setters
    void                    setProgramName      (const std::string& programName);
    void                    setConfFilePath     (const std::string& confFilePath);
    void                    setLogFilePath      (const std::string& logFilePath);
    void                    setEmailVerbosity   (const std::string& emailVerbosity);
    void                    setEmailVerbosity   (Verbosity emailVerbosity);
    void                    setLogfileVerbosity (const std::string& logfileVerbosity);
    void                    setLogfileVerbosity (Verbosity logfileVerbosity);
    void                    setSyslogVerbosity  (const std::string& syslogVerbosity);
    void                    setSyslogVerbosity  (Verbosity syslogVerbosity);
    void                    setDaemonize        (int daemonize);

    void                    setListenAddress    (const std::string& listenAddress);
    void                    setListenPort       (int listenPort);
    void                    setServicePassword                  (const std::string&  servicePassword);
    void                    setRedirectAddress  (const std::string& redirectAddress);
    void                    setRedirectPort     (int redirectPort);
    void                    setNotificationEmitAddress  (const std::string& notificationEmitAddress);
    void                    setNotificationEmitPort     (int notificationEmitPort);
    void                    setNotificationRegAddress  (const std::string& notificationRegAddress);
    void                    setNotificationRegPort     (int notificationRegPort);

    void                    setWorkerPoolSize   (int workerPoolSize);
    void                    setMaxWorkers       (int maxWorkers);
    void                    setRequestMaxSize   (int requestMaxSize);
    void                    setConnectionTimeout(int connectionTimeout);

    void                    setEmailEnabled     (int email_enabled);
    void                    setEmailClient      (const std::string& email_client);
    void                    setEmailSender      (const std::string& email_sender);

    void                    setAmazonS3Expiration(int amazon_s3_expiration);
    void                    setTimersEnabled    (int timers_enabled);
    void                    setSecurityCodesKey (const std::string& security_codes);

private:
    std::string             programName;        ///< Name of THIS program
    std::string             confFilePath;       ///< Path where to search for config file
    std::string             logFilePath;        ///< Where to write log messages, special names like stdin or stderr can be used
    std::string             listenAddress;      ///< Network interface to listen on (use 0.0.0.0 for all interfaces)
    std::string             redirectAddress;    ///< Network interface to listen on (use 0.0.0.0 for all interfaces)
    std::string             notificationEmitAddress;
    std::string             notificationRegAddress;
    std::string             emailClient;
    std::string             emailSender;
    int                     listenPort;         ///< Network port to lister on (TCP usually)
    int                     redirectPort;       ///< Network port to lister on (TCP usually)
    int                     notificationEmitPort;   ///< Network port to lister on (TCP usually)
    int                     notificationRegPort;   ///< Network port to lister on (TCP usually)
    int                     daemonize;          ///< Whether program should deattach from stdin-stdout and current console session
    int                     workerPoolSize;
    int                     maxWorkers;
    int                     emailEnabled;
    int                     amazonS3Expiration;
    int                     timersEnabled;
    std::string             securityCodesKey;
    int                     requestMaxSize;
    int                     connectionTimeout;
};

#endif /* DAEMONPARAMS_H_ */
