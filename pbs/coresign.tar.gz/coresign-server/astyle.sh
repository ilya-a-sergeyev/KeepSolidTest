#!/bin/bash
astyle --style=allman -O -R -S -Q -Z -k1 -j "src/*.cpp" "src/*.h" "src/*.c"
find . -iname "*.orig" -delete
