#pragma once

#include <string>
#include <cstdio>
#include <iosfwd>

std::string md5_raw(const std::string& text);
std::string sha1_raw(const std::string& text);
std::string sha256_raw(const std::string& text);

std::string md5( std::istream& in_stream );
std::string md5( FILE* in_stream );
std::string md5( const std::string& text );

std::string sha256( std::istream& in_stream );
std::string sha256( FILE* in_stream );
std::string sha256( const std::string& text );
