/*
 * logic.h
 *
 *  Created on: 18 бер. 2011
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/invitation.h"
#include "types/file_folder_info.h"
#include "types/misc_info.h"
#include "types/user_info.h"
#include "types/request_context.h"


/**
 * Class that contains main logic of server:
 * determines which actions should be taken when performing RPC call
 */
class	WorkGroupLogic
{
public:
    static rpc_status_code    workgroupsList         (RequestContext& context, int foldersFilter, WorkGroupsInfoList& foldersInfoList, InviteInfoList& inviteInfoList, int64_t& lastEventId);
    static rpc_status_code    workgroupCoworkersList (RequestContext& context, int64_t folderId, UserLoginList& userEmails);
    static rpc_status_code    workgroupCoworkersExtra(RequestContext& context, int64_t folderId, UserWorkGroupInfoList& userFolderInfoList);
    static rpc_status_code    workgroupCoworkersAll  (RequestContext& context, int64_t folderId, UserLoginList& userEmails);
    static rpc_status_code    workgroupCoworkersAllEx(RequestContext& context, int64_t folderId, UserWorkGroupInfoList& userFolderInfoList);
    static rpc_status_code    workgroupKickUserMass  (RequestContext& context, int64_t folderId, const LoginForKickList& loginKickList, ReturnStatusList& returnStatusList);
    static rpc_status_code    workgroupCreate        (RequestContext& context, const WorkGroupInfo& folderInfo, WorkGroupInfo& folderInfoGet, int64_t& folderId);
    static rpc_status_code    workgroupDelete        (RequestContext& context, int64_t folderId, bool removeNow, bool keep_data);
    static rpc_status_code    workgroupRename        (RequestContext& context, int64_t folderId, const std::string& folderNameNew);
    static rpc_status_code    workgroupInviteMass    (RequestContext& context, int64_t folderId, const WorkGroupInvites& folderInvites, ReturnStatusList& returnStatusList);
    static rpc_status_code    workgroupSubscribe     (RequestContext& context, const std::string& inviteId, bool acceptInvite);
    static rpc_status_code    workgroupUnsubscribe   (RequestContext& context, int64_t folderId);
    static rpc_status_code    workgroupInvitesList   (RequestContext& context, int64_t folderId, InviteInfoList& inviteInfoList);
    static rpc_status_code    workgroupInfo          (RequestContext& context, int64_t folderId, WorkGroupInfo& folderInfo, InviteInfoList& inviteInfoList);
    static rpc_status_code    workgroupSetAccessMass (RequestContext& context, int64_t folderId, const WorkGroupInvites& folderInvites, ReturnStatusList& returnStatusList);
    static rpc_status_code    workgroupUndelete      (RequestContext& context, int64_t folderId);
    static rpc_status_code    workgroupMetadataUpdate(RequestContext& context, int64_t folderId, const std::string& metadata_new);


protected:
    static rpc_status_code    _workgroupKickUser      (RequestContext& context, const UserInfo& userInfo, const WorkGroupInfo& folderInfo, const LoginForKick& loginUserForKick);
    static rpc_status_code    _workgroupSetAccess     (RequestContext& context, const UserInfo& userInfo, const WorkGroupInfo& folderInfo, const std::string& targetUserEmail, int64_t accessRights);

    static rpc_status_code    _workgroupInvite        (RequestContext& context, const UserInfo& inviterUserInfo, const WorkGroupInfo& folderInfo, const WorkGroupInvite& folderInvite);
    static rpc_status_code    _workgroupInviteKS      (RequestContext& context, const UserInfo& inviterUserInfo, const WorkGroupInfo& folderInfo, const WorkGroupInvite& folderInvite);
    static rpc_status_code    _workgroupInviteSX      (RequestContext& context, const UserInfo& inviterUserInfo, const WorkGroupInfo& folderInfo, const WorkGroupInvite& folderInvite);

    static rpc_status_code    _workgroupShareWG       (RequestContext& context, InviteInfo& inviteInfo);

    static rpc_status_code    _workgroupCreateInvite  (RequestContext& context, const UserInfo& inviterUserInfo, const UserInfo& inviteeUserInfo, const WorkGroupInfo& folderInfo, const WorkGroupInvite& folderInvite, bool is_anonymous, InviteInfo& inviteInfo);
    static rpc_status_code    _workgroupAcceptInvite  (RequestContext& context, const UserInfo& userInfo, const InviteInfo& folderInvite);
    static rpc_status_code    _workgroupRejectInvite  (RequestContext& context, const UserInfo& userInfo, const InviteInfo& folderInvite);
};

