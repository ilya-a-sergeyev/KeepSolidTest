#include "conf/daemon_config.h"

void print_daemon_params()
{
    fprintf(stdout, "Config path = %s \n", daemon_params().getConfFilePath().c_str());
    fprintf(stdout, "Logfile path = %s \n", daemon_params().getLogFilePath().c_str());
    fprintf(stdout, "Listen on:  %s:%i \n", daemon_params().getListenAddress().c_str(), daemon_params().getListenPort());
    fprintf(stdout, "Redirect on:  %s:%i \n", daemon_params().getRedirectAddress().c_str(), daemon_params().getRedirectPort());
    fprintf(stdout, "Daemonize: %i\n",daemon_params().getDaemonize());
    fprintf(stdout, "Workers pool size %i\n",daemon_params().getWorkerPoolSize());
    fprintf(stdout, "Maximum workers %i\n",daemon_params().getMaxWorkers());
}

