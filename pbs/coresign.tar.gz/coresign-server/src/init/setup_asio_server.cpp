/*
 * setup_asio_server.cpp
 *
 *  Created on: 23 янв. 2012
 *      Author: fireballdark
 */

#include "setup_asio_server.h"
#include <signal.h>
#include <boost/thread.hpp>
#include "rpc/boost_asio/AsioServer.h"
#include <sutil/logging.h>
#include "conf/DaemonParams.h"

int setup_asio_server()
{

    // Block all signals for background thread.
    sigset_t new_mask;
    sigfillset(&new_mask);
    sigset_t old_mask;
    pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);

    try
    {
        Asio_Server s(daemon_params().getListenAddress(), daemon_params().getListenPort(), 2);
        boost::thread t(boost::bind(&Asio_Server::run, &s));

        // Restore previous signals.
        pthread_sigmask(SIG_SETMASK, &old_mask, 0);

        t.join();
        LOG_INFORMATION("Ended thread with AsioServer");
    }
    catch (const boost::bad_weak_ptr& e)
    {
        LOG_INFORMATION("Problem with ASIO server %s",e.what());
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Problem with ASIO server %s",e.what());
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}

