/*
 * FirstFolderCreator.h
 *
 *  Created on: 7 дек. 2011
 *      Author: fireballdark
 */

#pragma once

#include <string>

class FirstFolderCreator
{
public:
    static void    create_first_folder  (const std::string& userLogin,const std::string& password,const std::string& public_key);
    static void    close                ();
};
