/*
 * access_rights.cpp
 *
 *  Created on: Mar 18, 2013
 *      Author: fireballdark
 */

#include "access_rights.h"
#include <bitset>

namespace KSD
{

RegisteredAccessModes access_mode_to_registered(int64_t access_mode)
{
    RegisteredAccessModes ret;
    switch (access_mode)
    {
        case -1:
            ret = AdminAccess;
            break;
        case 0:
            ret = NoAccess;
            break;
        case read_folder | write_folder | delete_folder | share_folder | read_messages | write_messages:
            ret = FullAccess;
            break;
        case read_folder | read_messages:
            ret = ReadOnlyAccess;
            break;
        case read_folder | write_folder | read_messages | write_messages:
            ret = LimitedAccessNoSharing;
            break;
        case read_folder | write_folder | share_folder | read_messages | write_messages:
            ret = LimitedAccess;
            break;
        default:
            ret = Unknown;
    }

    return ret;
}

int64_t registered_to_access_mode(RegisteredAccessModes registered_access_mode)
{
    int64_t ret;
    switch (registered_access_mode)
    {
        case AdminAccess:
            ret = -1;
            break;
        case NoAccess:
            ret = 0;
            break;
        case FullAccess:
            ret = read_folder | write_folder | delete_folder | share_folder | read_messages | write_messages;
            break;
        case ReadOnlyAccess:
            ret = read_folder | read_messages;
            break;
        case LimitedAccessNoSharing:
            ret = read_folder | write_folder | read_messages | write_messages;
            break;
        case LimitedAccess:
            ret = read_folder | write_folder | share_folder | read_messages | write_messages;
            break;
        default:
            ret = 0;
    }
    
    return ret;
}

bool compare_access_rights(int64_t a, int64_t b)
{
    RegisteredAccessModes ram_a = access_mode_to_registered(a);
    RegisteredAccessModes ram_b = access_mode_to_registered(b);

    if (ram_a != Unknown && ram_b != Unknown)
        return ram_a < ram_b;

    std::bitset<64> bs_a(static_cast<uint64_t>(a));
    std::bitset<64> bs_b(static_cast<uint64_t>(b));

    return bs_a.count() < bs_b.count();
}

bool AccessRightsHelper::verify_access_mode()
{
    bool is_valid = false;

    RegisteredAccessModes mode = access_mode_to_registered(access_mode);
    if (mode!=Unknown)
    {
        is_valid = true;
    }

    return is_valid;
}

std::string AccessRightsHelper::access_mode_to_string()
{
    std::string ret;
    switch (access_mode_to_registered(access_mode))
    {
        case AdminAccess:
            ret = "Admin access";
            break;
        case NoAccess:
            ret = "No access";
            break;
        case FullAccess:
            ret = "Full user access";
            break;
        case ReadOnlyAccess:
            ret = "Read only user access";
            break;
        case LimitedAccessNoSharing:
            ret = "Limited user access (no sharing)";
            break;
        case LimitedAccess:
            ret = "Limited user access";
            break;
        case Unknown:
        default:
            ret = "Unknown user access";
    }

    return ret;
}


}
