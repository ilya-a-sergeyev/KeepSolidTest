/*
 * SimplexNotifications.h
 *
 *  Created on: Mar 26, 2014
 *      Author: fireballdark
 */

#ifndef SIMPLEXNOTIFICATIONS_H_
#define SIMPLEXNOTIFICATIONS_H_
#include <stdint.h>
#include <string>
#include <types/keyvalue.h>
#include "types/request_context.h"
#include "types/SimplexNotification.h"

class SimplexNotificationSender
{
public:
    static bool send_non_block (RequestContext context, SimplexNotification notification);
    static bool send_block     (RequestContext context, SimplexNotification notification);

private:
    bool send();
};

#endif /* SIMPLEXNOTIFICATIONS_H_ */
