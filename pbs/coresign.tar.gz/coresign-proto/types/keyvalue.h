/*
 * keyvalue.h
 *
 *  Created on: Apr 1, 2014
 *      Author: fireballdark
 */

#ifndef KEYVALUE_H_
#define KEYVALUE_H_

#include <string>
#include <map>

typedef std::map<std::string, std::string>  KeyValue;
typedef std::map<std::string, KeyValue>     KeyValueMap;

#endif /* KEYVALUE_H_ */
