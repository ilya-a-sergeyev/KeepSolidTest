/*
 * xopenssl_types.h
 *
 *  Created on: May 27, 2013
 *      Author: fireballdark
 */

#pragma once

enum xopenssl_status
{
    XOPENSSL_UNKNOWN            = -1,       //UNKNOWN ERROR
    XOPENSSL_OK                 = 0,        //Everything's OK
    XOPENSSL_BAD_ARGUMENTS      = 1,        //Bad input arguments
    XOPENSSL_BAD_STREAM         = 2,        //Streams are in error state or NULL or not associated with files
    XOPENSSL_METADATA_ERROR     = 4,        //No metadata when reading files or problem creating one
    XOPENSSL_HASH_CHECK_ERROR   = 8,        //Hash of decrypted file is wrong
    XOPENSSL_SIZE_MISMATCH      = 16,       //Size of encrypted file is wrong
    XOPENSSL_STREAM_ERROR       = 32,       //Problem in file operations
    XOPENSSL_CRYPTO_ERR         = 64,       //Problem encrypting/decrypting
    XOPENSSL_ALREADY_ENCRYPTED  = 128,      //File already encrypted
    XOPENSSL_INTERRUPTED        = 256
};
