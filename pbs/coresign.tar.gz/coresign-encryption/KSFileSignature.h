/*
 * KSFileSignature.h
 *
 *  Created on: May 20, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>
#include <iosfwd>
#include "xopenssl_types.h"

namespace KSD
{

class KSFileSignature
{
public:
    enum KSFileVersion
    {
        KS_VERSION_UNKNOWN        = -1,       //Problem determining file version
        KS_VERSION_ZERO           = 0,        //Old files without signature
        KS_VERSION_V1             = 1,        //First version of encrypted files with signature
        KS_VERSION_V2             = 2         //Second version UNUSED - WRITE CHANGELOG IF USED
    };

    KSFileSignature();
    ~KSFileSignature();

    static xopenssl_status          read_file_signature     (std::istream& in_stream, std::string& signature);
    static xopenssl_status          read_file_signature     (FILE* in_stream, std::string& signature);
    static bool                     serialize_signature     (const KSD::KSFileSignature& fs, std::string& result);
    static bool                     parse_signature         (const std::string& signature, KSD::KSFileSignature& fs);

    KSFileSignature::KSFileVersion  get_version             () const;
    std::string                     get_initialization_vector() const;
    std::string                     get_original_raw_hash   ();
    std::string                     get_original_hash       ();
    int64_t                         get_encrypted_raw_size  () const;
    int64_t                         get_flags               () const;

    void                            set_version             (KSFileSignature::KSFileVersion version);
    void                            set_initialization_vector(const std::string& initialization_vector);
    void                            set_original_raw_hash   (const std::string& hash);
    void                            set_original_hash       (const std::string& hash);
    void                            set_encrypted_raw_size  (const int64_t& encrypted_raw_size);
    void                            set_flags               (const int64_t& flags);

private:
    KSFileSignature::KSFileVersion  parse_version           (const std::string& version_signature) const;

    KSFileSignature::KSFileVersion  _version;                //File encryption version
    std::string                     _initialization_vector;  //IV for encryption/decryption in CBC mode
    std::string                     _original_raw_hash;      //Raw hash for non-encrypted file
    std::string                     _original_hash;          //Hex-encoded hash for non-encrypted file
    int64_t                         _encrypted_raw_size;     //File size of raw encrypted data without signature
    int64_t                         _flags;                  //Some useful flags
    int64_t                         _reserved1;              //
    int64_t                         _reserved2;              //
    int64_t                         _reserved3;              //
    int64_t                         _reserved4;              //
};


} /* namespace KSD */
