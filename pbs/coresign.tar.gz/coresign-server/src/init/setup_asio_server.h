/*
 * setup_asio_server.h
 *
 *  Created on: 23 янв. 2012
 *      Author: fireballdark
 */

#ifndef SETUP_ASIO_SERVER_H_
#define SETUP_ASIO_SERVER_H_


int setup_asio_server();


#endif /* SETUP_ASIO_SERVER_H_ */
