/*
 * WorkGroupInvitesPgSql.cpp
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#include "FolderInvitesPgSql.h"
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <sutil/logging.h>
#include "db/PgSqlHelper.h"
#include <encryption/xopenssl.h>
#include "FolderInvitesHelper.h"

rpc_status_code WorkGroupInvitesPgSql::create_invitation(
        const RequestContext& context,
        InviteInfo& inviteInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            inviteInfo.invite_id = randomstring();

            if (pgSqlHelper().register_prep_statement("createWorkGroupInvite"))
            {
                pg_connection->prepare  ("createWorkGroupInvite",
                                         "INSERT INTO WorkGroupsInvites "
                                         "(invite_id, inviter_id, inviter_login, invitee_id, invitee_login, "
                                         "workgroup_id, access_mode, encryption_key, workgroup_name, "
                                         "is_anonymous, service_type) "
                                         "VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11);");
            }
            pqxx::work pg_transaction(*pg_connection, "CreateWorkGroupInvite");
            pqxx::result query_result = pg_transaction.prepared("createWorkGroupInvite")(inviteInfo.invite_id)(inviteInfo.inviter_id)
                                                    (inviteInfo.inviter_login)(inviteInfo.invitee_id)(inviteInfo.invitee_login)
                                                    (inviteInfo.workgroup_id)(inviteInfo.access_mode)(inviteInfo.key)
                                                    (inviteInfo.workgroup_name)(inviteInfo.is_anonymous)(context.service_type).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_INFORMATION("Info: trying to create duplicate folder invite "
                    "for inviter [%lli] invitee [%lli] "
                    "and workgroup_id [%lli] "
                    "invite_id [%s] err: [%s]",
                    inviteInfo.inviter_id, inviteInfo.invitee_id,
                    inviteInfo.workgroup_id, inviteInfo.invite_id.c_str(), e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to create folder invite "
                    "for inviter [%lli] invitee [%lli] "
                    "and workgroup_id [%lli] "
                    "invite_id [%s] err: [%s]",
                    inviteInfo.inviter_id, inviteInfo.invitee_id,
                    inviteInfo.workgroup_id, inviteInfo.invite_id.c_str(), e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupInvitesPgSql::get_invitation(
        const RequestContext& context,
        const std::string& inviteId,
        InviteInfo& inviteInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getWorkGroupInviteById"))
            {
                pg_connection->prepare  ("getWorkGroupInviteById",
                                         "SELECT "
                                         GET_WORKGROUP_INVITE
                                         " FROM WorkGroupsInvites "
                                         "WHERE invite_id = $1 AND service_type = $2;");
            }
            pqxx::work pg_transaction(*pg_connection, "getWorkGroupInviteById");
            pqxx::result query_result = pg_transaction.prepared("getWorkGroupInviteById")
                    (inviteId)(context.service_type).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            convert_inviteinfo_db(query_result.begin(), inviteInfo);

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder invite "
                    "for invite_id [%s] err: [%s]",
                    inviteId.c_str(), e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupInvitesPgSql::get_invitations(
        const RequestContext& context,
        int64_t inviteeId,
        InviteInfosByWorkGroups& iibw)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllWorkGroupsInvitesTo"))
            {
                pg_connection->prepare  ("getAllWorkGroupsInvitesTo",
                                         "SELECT "
                                          GET_WORKGROUP_INVITE
                                         "FROM WorkGroupsInvites "
                                         "WHERE invitee_id = $1 AND service_type = $2;");
            }

            pqxx::work pg_transaction(*pg_connection, "getAllWorkGroupsInvitesTo");
            pqxx::result query_result = pg_transaction.prepared("getAllWorkGroupsInvitesTo")
                    (inviteeId)(context.service_type).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                InviteInfo ii;
                convert_inviteinfo_db(resi, ii);
                iibw.insert(InvitePair(ii.workgroup_id,ii));
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder invite "
                    "for userId [%lli] err: [%s]",
                    inviteeId, e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupInvitesPgSql::get_invitations(
        const RequestContext& context,
        const std::string& inviteeEmail,
        InviteInfosByWorkGroups& iibw)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllWorkGroupsInvitesByEmailTo"))
            {
                pg_connection->prepare  ("getAllWorkGroupsInvitesByEmailTo",
                                         "SELECT "
                                          GET_WORKGROUP_INVITE
                                         "FROM WorkGroupsInvites "
                                         "WHERE invitee_login = $1 AND service_type = $2;");
            }

            pqxx::work pg_transaction(*pg_connection, "getAllWorkGroupsInvitesByEmailTo");
            pqxx::result query_result = pg_transaction.prepared("getAllWorkGroupsInvitesByEmailTo")
                    (inviteeEmail)(context.service_type).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                InviteInfo ii;
                convert_inviteinfo_db(resi, ii);
                iibw.insert(InvitePair(ii.workgroup_id,ii));
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder invite "
                    "for userId [%s] err: [%s]",
                    inviteeEmail.c_str(), e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupInvitesPgSql::get_invitations(
        const RequestContext& context,
        int64_t inviteeId,
        int64_t workgroup_id,
        InviteInfoList& inviteInfoList)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getWorkGroupInvitesListToWG"))
            {
                pg_connection->prepare  ("getWorkGroupInvitesListToWG",
                                         "SELECT "
                                         GET_WORKGROUP_INVITE
                                         "FROM WorkGroupsInvites "
                                         "WHERE workgroup_id = $1 AND invitee_id = $2 AND service_type = $3;");
            }
            pqxx::work pg_transaction(*pg_connection, "getWorkGroupInvitesListToWG");
            pqxx::result query_result = pg_transaction.prepared("getWorkGroupInvitesListToWG")
                    (workgroup_id)(inviteeId)(context.service_type).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                InviteInfo ii;
                convert_inviteinfo_db(resi, ii);
                inviteInfoList.push_back(ii);
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder invite "
                    "for folder [%lli] err: [%s]",
                    workgroup_id, e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupInvitesPgSql::remove_invitation(
        const RequestContext& context,
        const std::string& invite_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteWorkGroupInviteById"))
            {
                pg_connection->prepare  ("deleteWorkGroupInviteById",
                                         "DELETE FROM WorkGroupsInvites "
                                         "WHERE invite_id = $1 AND service_type = $2 "
                                         "RETURNING invite_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "deleteWorkGroupInviteById");
            pqxx::result query_result = pg_transaction.prepared("deleteWorkGroupInviteById")
                    (invite_id)(context.service_type).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete folder invite "
                    "for invite_id [%s] err: [%s]",
                    invite_id.c_str(), e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupInvitesPgSql::remove_invitations(
        const RequestContext& context,
        int64_t inviteeId,
        int64_t workgroupId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteWorkGroupInvitesToWG"))
            {
                pg_connection->prepare  ("deleteWorkGroupInvitesToWG",
                                         "DELETE FROM WorkGroupsInvites "
                                         "WHERE invitee_id = $1 AND workgroup_id = $2 AND service_type = $3 "
                                         "RETURNING invite_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "deleteWorkGroupInvitesToWG");
            pqxx::result query_result = pg_transaction.prepared("deleteWorkGroupInvitesToWG")
                    (inviteeId)(workgroupId)(context.service_type).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete folder invite "
                    "for [%lli] folder [%lli] err: [%s]",
                    inviteeId, workgroupId, e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}


rpc_status_code WorkGroupInvitesPgSql::remove_invitations(
        const RequestContext& context,
        int64_t inviterId,
        int64_t inviteeId,
        int64_t workgroupId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteWorkGroupInvitesToFromWG"))
            {
                pg_connection->prepare  ("deleteWorkGroupInvitesToFromWG",
                                         "DELETE FROM WorkGroupsInvites "
                                         "WHERE workgroup_id = $1 AND inviter_id = $2 AND invitee_id = $3 AND service_type = $4 "
                                         "RETURNING invite_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "deleteWorkGroupInvitesToFromWG");
            pqxx::result query_result = pg_transaction.prepared("deleteWorkGroupInvitesToFromWG")
                    (workgroupId)(inviterId)(inviteeId)(context.service_type).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete folder invite "
                    "for [%lli]->[%lli] folder [%lli] err: [%s]",
                    inviterId, inviteeId, workgroupId, e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}



