/*
 * xopenssl_util.h
 *
 *  Created on: May 20, 2013
 *      Author: fireballdark
 */

#pragma once

#include <cstdint>
#include <string>
#include <vector>

std::string unite_lines             ( std::string text );
std::string __base64_string_format  ( std::string text );

void        random_seed             ();

std::string base64_encodestring     ( const std::string& text , bool unite);
std::string base64_decodestring     ( std::string text );

std::string randomstring            ( int len );
std::string random256bits           ();
int64_t     random_int64_t          ();

std::string unite_lines             ( std::string text );
std::string digest_to_hex_string    ( const unsigned char* digest, unsigned int len );
std::string hex_to_digest           ( const std::string& hex_digest );
std::string digest_to_hex_string    ( const std::string& digest );

std::string digest_to_x_hex_string  ( const std::string& string );

void        split_string            ( const std::string& str, const char delimiter, std::vector<std::string>& elements );
