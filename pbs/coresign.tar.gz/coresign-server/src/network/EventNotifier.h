/*
 * EventNotifier.h
 *
 *  Created on: 1 feb. 2011
 *      Author: fireballdark
 */

#pragma once

#include <cstdint>

class EventNotifier
{
public:
    static void    notify_event (int64_t userId, int64_t eventType);
    static void    close        ();
};

