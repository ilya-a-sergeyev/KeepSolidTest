#pragma once

#if defined(RPC_TRANSLATOR) || defined(FILE_LOADER)
#   define STATIC_SENDERRECEIVER
#endif

#include <stdint.h>
#include <memory>
#include <mutex>
#include <google/protobuf/message.h>
#include <google/protobuf/descriptor.h>
#include <protobuf/client/cpp/message.pb.h>
#include <network/AsioRPCTransport.h>

class SenderReceiver
{
    public:
#ifdef STATIC_SENDERRECEIVER
        static SenderReceiver& GetSenderReceiver();
#endif
        explicit SenderReceiver(const int64_t& serviceId);
        SenderReceiver(const std::string& address, const std::string& port, const int64_t& serviceId);
        SenderReceiver() = delete;
        SenderReceiver(const SenderReceiver&) = delete;
        SenderReceiver(SenderReceiver&&) = delete;
        SenderReceiver& operator=(const SenderReceiver&) = delete;
        SenderReceiver& operator=(SenderReceiver&&) = delete;
        ~SenderReceiver();

        bool call(const google::protobuf::Message* message_params, google::protobuf::Message* message_result);

        void setConnectionParams(const std::string& url, const std::string& port);
        std::string get_port()      const {return mPort;}
        std::string get_address ()  const {return mAddress;}

    private:
        MessageType     type_by_name    (const std::string& name);
        bool            process_request (rpc::Request* request, const google::protobuf::Message* message);
        bool            process_response(const rpc::Response* response, google::protobuf::Message* message);

        std::shared_ptr<AsioRPCTransport>  pTransport;
        std::string     mAddress;
        std::string     mPort;
        int64_t         mServiceId;

        std::mutex      mutex;
};
