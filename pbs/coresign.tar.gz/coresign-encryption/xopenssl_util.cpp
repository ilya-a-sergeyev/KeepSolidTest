#include <openssl/evp.h>
#include <openssl/engine.h>
/*
 * xopenssl_util.cpp
 *
 *  Created on: May 20, 2013
 *      Author: fireballdark
 */

#include <cstdlib>
#include <iomanip>
#include <cmath>
#include <sstream>
#include <algorithm>
#include "xopenssl_util.h"
#include <openssl/engine.h>
#include "xopenssl.h"
#include "xopenssl_defines.h"
#include "util/logging.h"

std::string unite_lines(std::string text)
{
    std::string str;
    char ch;
    size_t size = text.size();
    for (size_t i = 0; i < size; i++)
    {
        ch = text[i];
        if (ch != '\n' && ch != '\r')
        {
            str += ch;
        }
    }
    return str;
}

std::string __base64_string_format(std::string text)
{
    text = unite_lines(text);
    std::string str = "";
    std::string::size_type pos = 0;
    while (text.size() > 0)
    {
        pos = text.size();
        pos = pos > 64 ? 64 : pos;
        str += text.substr(0, pos) + "\n";
        text = text.substr(pos, std::string::npos);
    }
    return str;
}

void random_seed()
{
#ifndef DEBUG_XOPENSSL
    unsigned char random_buf[IO_BLOCK_SIZE];
#else
    unsigned char random_buf[IO_BLOCK_SIZE]={0};
#endif

    RAND_seed(random_buf, sizeof(random_buf));
}




/******************************************************************************
 base64
 ******************************************************************************/
#pragma mark- Base64
#define BASE64_PADDING_SIZE         2
#define BASE64_MIN_BUFFER_SIZE      2
#define BASE64_SYMBOLS_PER_NEWLINE  ((3*64.0)/4.0)
#define STRING_TERMINATOR           1
#define MAX(a,b)                ((a > b) ? (a) : (b))
std::string base64_encodestring(const std::string& text, bool unite)
{
    EVP_ENCODE_CTX ectx;
    size_t size = ceil ((4.0*text.size())/3.0)                      //33% BASE64 overhead
                  + ceil(((double)text.size())/BASE64_SYMBOLS_PER_NEWLINE)    //Newlines after each 64 symbols
                  + BASE64_PADDING_SIZE                             //Padding added
                  + STRING_TERMINATOR;                              //C string terminator

    unsigned char* out = (unsigned char*) calloc(MAX(size, BASE64_MIN_BUFFER_SIZE), sizeof(char));
    int outlen = 0;
    int tlen = 0;

    EVP_EncodeInit(&ectx);
    EVP_EncodeUpdate(&ectx, out, &outlen, (const unsigned char*) text.c_str(), (int) text.size());
    tlen += outlen;
    EVP_EncodeFinal(&ectx, out + tlen, &outlen);
    tlen += outlen;

    std::string str((char*) out, tlen);
    free(out);

    if (unite)
    {
        return unite_lines(str);
    }
    return str;
}

std::string base64_decodestring(std::string text)
{
    if (text.empty())
    {
        return "";
    }
    text = __base64_string_format(text); // silly, but required
    EVP_ENCODE_CTX ectx;
    size_t size = text.size();
    unsigned char* out = (unsigned char*) calloc(size, sizeof(char));
    int outlen = 0;
    int tlen = 0;

    EVP_DecodeInit(&ectx);
    EVP_DecodeUpdate(&ectx, out, &outlen, (const unsigned char*) text.c_str(), (int) text.size());
    tlen += outlen;
    EVP_DecodeFinal(&ectx, out + tlen, &outlen);
    tlen += outlen;

    std::string data((char*) out, tlen);
    free(out);

    return data;
}

/******************************************************************************
 randomness
 ******************************************************************************/
#pragma mark- Randomness

std::string randomstring(int len)
{
    if (len <= 0)
    {
        return "";
    }

    unsigned char* buf = (unsigned char*) calloc(len, sizeof(char));
    RAND_pseudo_bytes(buf, len);
    std::string temp((char*)buf,len);
    std::string str = base64_encodestring(temp, true);
    std::replace(str.begin(), str.end(), '/', '-');
    std::replace(str.begin(), str.end(), '+', '-');
    free(buf);
    return str.substr(0, len);
}

std::string random256bits()
{
    unsigned char buf[32];
    RAND_pseudo_bytes(buf, 32);
    return std::string((char*)buf, 32);
}

int64_t random_int64_t()
{
    int64_t result;
    RAND_pseudo_bytes((unsigned char*)&result, sizeof(int64_t));
    return result;
}

/******************************************************************************
 public utils
 ******************************************************************************/
std::string digest_to_hex_string(const unsigned char* digest, unsigned int len)
{
    std::stringstream ss;

    for (unsigned int i = 0; i < len; i++)
    {
        ss << std::setfill('0') << std::setw(2) << std::hex << (int) digest[i];
    }

    return ss.str();
}

std::string digest_to_hex_string(const std::string& digest)
{
    std::stringstream ss;

    for (unsigned int i = 0; i < digest.size(); i++)
    {
        ss << std::setfill('0') << std::setw(2) << std::hex << int( (unsigned char) digest.at(i) );
    }

    return ss.str();
}

std::string digest_to_x_hex_string(const std::string& digest)
{
    std::stringstream ss;

    for (unsigned int i = 0; i < digest.size(); i++)
    {
        ss << std::hex << std::showbase << (int) digest.at(i);
    }

    return ss.str();
}

unsigned char DecLookup[] =
{
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, // gap before first hex digit
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,1,2,3,4,5,6,7,8,9,       // 0123456789
    0,0,0,0,0,0,0,             // :;<=>?@ (gap)
    10,11,12,13,14,15,         // ABCDEF
    0,0,0,0,0,0,0,0,0,0,0,0,0, // GHIJKLMNOPQRS (gap)
    0,0,0,0,0,0,0,0,0,0,0,0,0, // TUVWXYZ[/]^_` (gap)
    10,11,12,13,14,15          // abcdef
};

std::string hex_to_digest(const std::string& hex_digest)
{
    if (hex_digest.size() % 2 != 0)
    {
        LOG_ERROR("Input is not correct hex-encoded data!");
        return "";
    }

    unsigned char* pSrc = (unsigned char*) hex_digest.c_str();
    size_t nSrcLen = hex_digest.length();

    unsigned char *res = (unsigned char*)calloc(hex_digest.size()/2+2, sizeof(unsigned char));
    const unsigned char* end = res + sizeof(unsigned char)*hex_digest.size()/2;
    unsigned char* pDest = res;

    for (size_t j = 0; j < nSrcLen && pDest < end; j += 2)
    {
        int d = DecLookup[*pSrc++] << 4;
        d |= DecLookup[*pSrc++];
        *pDest++ = (unsigned char) d;
    }

    std::string result((char*)res, pDest - res);
    free(res);
    return result;
}

void split_string(const std::string& str, const char delimiter, std::vector<std::string>& elements)
{
    std::stringstream string_stream(str);
    std::string element;
    while (std::getline(string_stream, element, delimiter))
    {
        elements.emplace_back(element);
    }
}
