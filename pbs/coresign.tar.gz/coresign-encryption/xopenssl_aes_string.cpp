/*
 * xopenssl_aes_string.cpp
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */


#include "xopenssl_aes_string.h"
#include <openssl/engine.h>
#include <openssl/evp.h>
#include "util/logging.h"
#include "xopenssl_defines.h"
#include "xopenssl_util.h"
#include "xopenssl_hash.h"


/******************************************************************************
 aes
 ******************************************************************************/
#pragma mark- AES

std::string aes_encrypt(const std::string& data, const std::string& password, std::string& iv)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: data is empty");
        return "";
    }
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: password is empty");
        return "";
    }

    random_seed();

    unsigned char iv_char[AES256_BLOCK_SIZE];
    RAND_bytes(iv_char, (int)sizeof(iv_char));
    iv.assign((const char*) iv_char, sizeof(iv_char));

    std::string key = sha256_raw(password);
    unsigned char* out = (unsigned char*) calloc((data.size() / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE, sizeof(char));
    int curr_len = 0;
    int total_len = 0;

    int result = 1; // 1 when OK

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);
    result &= EVP_EncryptInit( &ectx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv.c_str() );
    result &= EVP_EncryptUpdate( &ectx, out, &curr_len, (const unsigned char*)data.c_str(), (int)data.size() );
    total_len += curr_len;
    result &= EVP_EncryptFinal(&ectx, out + total_len, &curr_len);
    total_len += curr_len;
    EVP_CIPHER_CTX_cleanup(&ectx);

    std::string encrypted_data;

    if (result == 1)
    {
        encrypted_data.assign((const char*) out, total_len);
    }
    else
    {
        LOG_ERROR("OpenSSL AES encrypt: could not encrypt string");
        SHOW_OPENSSL_ERRORS("OpenSSL AES encrypt err");
    }

    free(out);

    return encrypted_data;
}

std::string aes_decrypt(const std::string& data, const std::string& password, const std::string& iv)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: data is empty");
        return "";
    }
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return "";
    }
    if (iv.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: iv is empty");
        return "";
    }

    std::string key = sha256_raw(password);
    unsigned char* out = (unsigned char*) calloc((data.size() / AES256_BLOCK_SIZE + 2) * AES256_BLOCK_SIZE, sizeof(char));
    int curr_len = 0;
    int total_len = 0;

    int result = 1; // 1 when OK

    EVP_CIPHER_CTX ectx;
    EVP_CIPHER_CTX_init(&ectx);
    result &= EVP_DecryptInit( &ectx, EVP_aes_256_cbc(), (const unsigned char*)key.c_str(), (const unsigned char*)iv.c_str() );
    result &= EVP_DecryptUpdate( &ectx, out, &curr_len, (const unsigned char*)data.c_str(), (int)data.size() );
    total_len += curr_len;
    result &= EVP_DecryptFinal(&ectx, out + total_len, &curr_len);
    total_len += curr_len;
    EVP_CIPHER_CTX_cleanup(&ectx);

    std::string decrypted_data;
    if (result == 1)
    {
        decrypted_data.assign((const char*) out, total_len);
    }
    else
    {
        LOG_ERROR("OpenSSL AES decrypt: could not decrypt string");
        SHOW_OPENSSL_ERRORS("OpenSSL AES decrypt err");
    }

    free(out);
    return decrypted_data;
}

std::string aes_easy_encrypt( const std::string& data, const std::string& password)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: data is empty");
        return "";
    }
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES encrypt: password is empty");
        return "";
    }


    std::string iv, encrypted_data, encrypted_full;
    encrypted_data = aes_encrypt(data, password, iv);
    encrypted_full = base64_encodestring(iv, true);
    encrypted_full += '$'; //delimiter
    encrypted_full += base64_encodestring(encrypted_data, true);
    return encrypted_full;
}

std::string aes_easy_decrypt( const std::string& data, const std::string& password)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: data is empty");
        return "";
    }
    if (password.empty())
    {
        LOG_ERROR("OpenSSL AES decrypt: password is empty");
        return "";
    }

    std::string::size_type pos_iv_end = 0;
    //find first delimiters
    pos_iv_end = data.find('$', 0);

    std::string iv = base64_decodestring(data.substr(0, pos_iv_end));
    std::string encrypted_data = base64_decodestring(data.substr(pos_iv_end + 1, std::string::npos));

    return aes_decrypt(encrypted_data, password, iv);
}
