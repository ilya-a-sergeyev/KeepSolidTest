/*
 * EventManagerPgSql.h
 *
 *  Created on: May 19, 2011
 *      Author: fireball
 */

#ifndef EVENTMANAGERPGSQL_H_
#define EVENTMANAGERPGSQL_H_

#include "types/event_types.h"
#include "types/status_codes.h"
#include "types/misc_info.h"

class EventManagerPgSql
{
public:
    static rpc_status_code     listEventsForUser            (int64_t userId, int64_t lastEventId, int64_t eventsLimit, EventsList& eventsList);
    static rpc_status_code     listEventsForUserReverse     (int64_t userId, int64_t lastEventId, int64_t eventsLimit, EventsList& eventsList);
    static rpc_status_code     listEventsForUserReverseLast (int64_t userId, int64_t eventsLimit, EventsList& eventsList);

    static rpc_status_code     createEvent         (event_type eventType, int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, const std::string& data1, const std::string& data2, const std::string& data3, const std::string& path, int64_t recipientId = 0, int64_t hardRecipientId = 0);
};

#endif /* EVENTMANAGERPGSQL_H_ */
