/*
 * ProtobufZmqRpc.cpp
 *
 *  Created on: Jun 8, 2011
 *      Author: fireball
 */

#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "protobuf/server/cpp/msg_serv_type.pb.h"

#include "logic/AuthLogic.h"
#include "logic/FileLogic.h"
#include "logic/WorkGroupLogic.h"
#include "logic/MiscLogic.h"
#include "logic/UserLogic.h"
#include "types/structs_to_protobuf.h"
#include <util/get_time_string.h>
#include <sutil/LoggingData.h>

#include <lz4.h>
#include <lz4hc.h>

int ProtobufZmqRpc::processData(const void* data_in, int data_in_size, std::string& data_out, const std::string& ipAddress)
{
    rpc::Request request;
    rpc::Response response;

    RequestContext context;
    context.ip_address      = ipAddress;
    context.request_id      = LoggingData::get_instance().get_thread_number();
    context.request_id      += LoggingData::get_instance().gen_request_id();

    try
    {
        request.ParseFromArray(data_in, data_in_size);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Exception parsing client [%s] request [%s]",ipAddress.c_str(),e.what());
        return -1;
    }

    if (!request.has_message_type())
    {
        LOG_ERROR("No message type detected");
        return -1;
    }

    rpc_status_code_struct result = status_unknown;
    context.service_type    = request.has_service_type()? request.service_type() : 0;
    context.is_debug        = request.has_is_debug()    ? request.is_debug() : false;

    result = callClientFunction(request, response, context);

    if (result == status_unknown)
    {
        response.set_message_type(RPC_UNKNOWN);
        result = status_not_implemented;
    }

    response.set_error_code(result.code);
    if (context.is_debug == true)
    {
        if (!result.error_message.empty())
        {
            response.add_error_message()->assign(result.error_message);
        }
        else
        {
            response.add_error_message()->assign(result.code_to_string());
        }
        response.set_request_id(context.request_id);
    }

    try
    {
        response.SerializeToString(&data_out);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Exception serializing client [%s] request [%s]",ipAddress.c_str(),e.what());
        return -1;
    }

    if (data_out.size() > 512 || data_in_size > 512)
    {
        std::vector<char> compressed_data;
        compressed_data.reserve(LZ4_compressBound(data_out.size()));
        int compressed_size = 0;
        {
            Timer t("LZ4 compression timer");
            compressed_size = LZ4_compress(data_out.c_str(), compressed_data.data(), data_out.size());
        }

        double size_economy = 1.0 - ((double) compressed_size) / data_out.size();

        if (size_economy > 0.16)
        {
            LOG_ABSOLUTE("Protobuf serialized data size is input:output [%i]:[%zi] compressed to [%i]:[%f] type [%i]",
                    data_in_size, data_out.size(),
                    compressed_size, size_economy,
                    request.message_type());
        }
        else
        {
            LOG_ABSOLUTE("Protobuf serialized data size is input:output [%i]:[%zi] type [%i]",
                    data_in_size, data_out.size(),
                    request.message_type());
        }
    }

    return context.session_info.user_id;
}

rpc_status_code_struct ProtobufZmqRpc::callClientFunction(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct result = status_unknown;
    switch (request.message_type())
    {
        case RPC_USER_INFO:
        {
            result = userInfo(request,response,context);
            break;
        }
        case RPC_ACCOUNT_STATS:
        {
            result = accountStats(request,response,context);
            break;
        }
        case RPC_GET_MY_DATA:
        {
            result = getMyData(request,response,context);
            break;
        }
        case RPC_SET_MY_DATA:
        {
            result = setMyData(request,response,context);
            break;
        }
        case RPC_NOTIFICATIONS_GET:
        {
            result = notificationsGet(request,response,context);
            break;
        }
        case RPC_NOTIFICATIONS_SET:
        {
            result = notificationsSet(request,response,context);
            break;
        }
        case RPC_WORKGROUPS_LIST:
        {
            result = workgroupsList(request,response,context);
            break;
        }
        case RPC_WORKGROUP_COWORKERS_LIST:
        {
            result = workgroupCoworkersList(request,response,context);
            break;
        }
        case RPC_WORKGROUP_COWORKERS_LIST_EXTRA:
        {
            result = workgroupCoworkersExtra(request,response,context);
            break;
        }
        case RPC_WORKGROUP_COWORKERS_LIST_ALL:
        {
            result = workgroupCoworkersAll(request,response,context);
            break;
        }
        case RPC_WORKGROUP_COWORKERS_LIST_ALL_EX:
        {
            result = workgroupCoworkersAllEx(request,response,context);
            break;
        }
        case RPC_WORKGROUP_KICK_USER:
        {
            result = workgroupKickUser(request,response,context);
            break;
        }
        case RPC_WORKGROUP_CREATE:
        {
            result = workgroupCreate(request,response,context);
            break;
        }
        case RPC_WORKGROUP_DELETE:
        {
            result = workgroupDelete(request,response,context);
            break;
        }
        case RPC_WORKGROUP_RENAME:
        {
            result = workgroupRename(request,response,context);
            break;
        }
        case RPC_WORKGROUP_INVITE:
        {
            result = workgroupInvite(request,response,context);
            break;
        }
        case RPC_WORKGROUP_SUBSCRIBE:
        {
            result = workgroupSubscribe(request,response,context);
            break;
        }
        case RPC_WORKGROUP_UNSUBSCRIBE:
        {
            result = workgroupUnsubscribe(request,response,context);
            break;
        }
        case RPC_WORKGROUP_INVITES_LIST:
        {
            result = workgroupInvitesList(request,response,context);
            break;
        }
        case RPC_WORKGROUP_INFO:
        {
            result = workgroupInfo(request,response,context);
            break;
        }
        case RPC_WORKGROUP_SET_ACCESS:
        {
            result = workgroupSetAccess(request,response,context);
            break;
        }
        case RPC_WORKGROUP_METADATA_UPDATE:
        {
            result = workgroupMetadataUpdate(request,response,context);
            break;
        }
        case RPC_WORKGROUP_UNDELETE:
        {
            result = workgroupUndelete(request,response,context);
            break;
        }
        case RPC_FILES_LIST:
        {
            result = filesList(request,response,context);
            break;
        }
        case RPC_FILE_DELETE:
        {
            result = fileDelete(request,response,context);
            break;
        }
        case RPC_FILE_RENAME:
        {
            result = fileRename(request,response,context);
            break;
        }
        case RPC_FILE_HISTORY:
        {
            result = fileHistory(request,response,context);
            break;
        }
        case RPC_FILE_INFO:
        {
            result = fileInfo(request,response,context);
            break;
        }
        case RPC_FILE_UPLOAD:
        {
            result = fileUpload(request,response,context);
            break;
        }
        case RPC_FILE_DIRECTORY_CREATE:
        {
            result = fileDirectoryCreate(request,response,context);
            break;
        }
        case RPC_FILE_UPLOAD_APPROVE:
        {
            result = fileUploadApprove(request,response,context);
            break;
        }
        case RPC_FILE_DOWNLOAD:
        {
            result = fileDownload(request,response,context);
            break;
        }
        case RPC_FILE_DIRECTORY_HIERARCHY:
        {
            result = fileDirectoryHierarchy(request,response,context);
            break;
        }
        case RPC_FILE_SEARCH:
        {
            result = fileSearch(request,response,context);
            break;
        }
        case RPC_FILE_UNDELETE:
        {
            result = fileUndelete(request,response,context);
            break;
        }
        case RPC_FILE_MOVE:
        {
            result = fileMove(request,response,context);
            break;
        }
        case RPC_EVENTS_LIST:
        {
            result = eventsList(request,response,context);
            break;
        }
        case RPC_CREATE_KEY_PAIR:
        {
            result = createKeyPair(request,response,context);
            break;
        }
        case RPC_GET_KEY_PAIR:
        {
            result = getKeyPair(request,response,context);
            break;
        }
        case RPC_SERVER_VERSION:
        {
            result = serverVersion(request,response,context);
            break;
        }
        case RPC_SERVER_TIMING_STATS:
        {
            result = serverTimingStats(request,response,context);
            break;
        }
        case RPC_SERVER_USERS_STATS:
        {
            result = serverUsersStats(request,response,context);
            break;
        }
        case RPC_SERVER_WORKGROUPS_STATS:
        {
            result = serverWorkGroupsStats(request,response,context);
            break;
        }
        case RPC_SERVER_FILES_STATS:
        {
            result = serverFilesStats(request,response,context);
            break;
        }
        case RPC_SERVER_MESSAGES_STATS:
        {
            result = serverMessagesStats(request,response,context);
            break;
        }
        case RPC_TARIFFS_LIST:
        {
            result = tariffsList(request,response,context);
            break;
        }
        case RPC_UNKNOWN:
        default:
        {
            break;
        }
    }
    return result;
}

int ProtobufZmqRpc::processDataServer(const void* data_in, int data_in_size, std::string& data_out)
{
    server_rpc::Request request;
    server_rpc::Response response;

    RequestContext context;
    context.ip_address      = "127.0.0.1";
    context.request_id      = LoggingData::get_instance().get_thread_number();
    context.request_id      += LoggingData::get_instance().gen_request_id();

    try
    {
        request.ParseFromArray(data_in, data_in_size);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Exception parsing client request [%s]",e.what());
        return EXIT_FAILURE;
    }

    if (!request.has_message_type())
    {
        LOG_ERROR("No message type detected");
        return EXIT_FAILURE;
    }

    rpc_status_code_struct result = status_unknown;
    context.service_type    = request.has_service_type()? request.service_type() : 0;
    context.is_debug        = request.has_is_debug()    ? request.is_debug() : false;

    result = callServerFunction(request, response, context);

    if (result == status_unknown)
    {
        response.set_message_type(server_rpc::SRPC_UNKNOWN);
        result = status_not_implemented;
    }

    response.set_error_code(result.code);
    if (context.is_debug == true)
    {
        if (!result.error_message.empty())
        {
            response.add_error_message()->assign(result.error_message);
        }
        else
        {
            response.add_error_message()->assign(result.code_to_string());
        }
        response.set_request_id(context.request_id);
    }

    try
    {
        response.SerializeToString(&data_out);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Exception serializing client request [%s]",e.what());
        return EXIT_FAILURE;
    }

    if (data_out.size() > 512 || data_in_size > 512)
    {
        LOG_ABSOLUTE("Protobuf serialized data size is input:output [%i]:[%zi] type [%i]", data_in_size, data_out.size(), request.message_type());
    }

    return EXIT_SUCCESS;
}

rpc_status_code_struct ProtobufZmqRpc::callServerFunction(const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct result = status_unknown;
    switch (request.message_type())
    {
        case server_rpc::SRPC_ACCOUNT_STATUS_NO_SESSION:
        {
            result = accountStatusNoSession(request,response,context);
            break;
        }
        case server_rpc::SRPC_ACCOUNT_STATUS:
        {
            result = accountStatus(request,response,context);
            break;
        }
        case server_rpc::SRPC_INVITE_ACCEPT:
        {
            result = inviteAccept(request,response,context);
            break;
        }
        case server_rpc::SRPC_PURCHASE_APPLY:
        {
            result = purchaseApply(request,response,context);
            break;
        }
        case server_rpc::SRPC_PURCHASE_REFUND:
        {
            result = purchaseRefund(request,response,context);
            break;
        }
        case server_rpc::SRPC_USER_REMOVE:
        {
            result = userRemove(request,response,context);
            break;
        }
        case server_rpc::SRPC_SUBSCRIBE_EVENTS:
        {
            result = subscribeEvents(request,response,context);
            break;
        }
        case server_rpc::SRPC_UNKNOWN:
        {
            break;
        }
    }
    return result;
}

