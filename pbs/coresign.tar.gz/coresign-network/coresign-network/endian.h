#pragma once

# if BYTE_ORDER == LITTLE_ENDIAN
#  define htobe16_p(x) __bswap_16_p (x)
#  define htole16_p(x) (x)
#  define be16toh_p(x) __bswap_16_p (x)
#  define le16toh_p(x) (x)

#  define htobe32_p(x) __bswap_32_p (x)
#  define htole32_p(x) (x)
#  define be32toh_p(x) __bswap_32_p (x)
#  define le32toh_p(x) (x)

#  define htobe64_p(x) __bswap_64_p (x)
#  define htole64_p(x) (x)
#  define be64toh_p(x) __bswap_64_p (x)
#  define le64toh_p(x) (x)
# elif BYTE_ORDER == BIG_ENDIAN
#  define htobe16_p(x) (x)
#  define htole16_p(x) __bswap_16_p (x)
#  define be16toh_p(x) (x)
#  define le16toh_p(x) __bswap_16_p (x)

#  define htobe32_p(x) (x)
#  define htole32_p(x) __bswap_32_p (x)
#  define be32toh_p(x) (x)
#  define le32toh_p(x) __bswap_32_p (x)

#  define htobe64_p(x) (x)
#  define htole64_p(x) __bswap_64_p (x)
#  define be64toh_p(x) (x)
#  define le64toh_p(x) __bswap_64_p (x)
# else
# error "Unknown endian"
# endif

#define __bswap_16_p(x) \
     ((unsigned short int) ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8)))

#define __bswap_32_p(x) \
     ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) |		      \
      (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24))

# define __bswap_64_p(x) \
     ((((x) & 0xff00000000000000ull) >> 56)				      \
      | (((x) & 0x00ff000000000000ull) >> 40)				      \
      | (((x) & 0x0000ff0000000000ull) >> 24)				      \
      | (((x) & 0x000000ff00000000ull) >> 8)				      \
      | (((x) & 0x00000000ff000000ull) << 8)				      \
      | (((x) & 0x0000000000ff0000ull) << 24)				      \
      | (((x) & 0x000000000000ff00ull) << 40)				      \
      | (((x) & 0x00000000000000ffull) << 56))

#define le64tohP(d) ( \
            ((u_int64_t)((unsigned char*)&d)[0]<<0) | \
            ((u_int64_t)((unsigned char*)&d)[1]<<8) | \
            ((u_int64_t)((unsigned char*)&d)[2]<<16) | \
            ((u_int64_t)((unsigned char*)&d)[3]<<24) | \
            ((u_int64_t)((unsigned char*)&d)[4]<<32) | \
            ((u_int64_t)((unsigned char*)&d)[5]<<40) | \
            ((u_int64_t)((unsigned char*)&d)[6]<<48) | \
            ((u_int64_t)((unsigned char*)&d)[7]<<56) \
            )

#define be64tohP(d) ( \
            ((u_int64_t)((unsigned char*)&d)[7]<<0) | \
            ((u_int64_t)((unsigned char*)&d)[6]<<8) | \
            ((u_int64_t)((unsigned char*)&d)[5]<<16) | \
            ((u_int64_t)((unsigned char*)&d)[4]<<24) | \
            ((u_int64_t)((unsigned char*)&d)[3]<<32) | \
            ((u_int64_t)((unsigned char*)&d)[2]<<40) | \
            ((u_int64_t)((unsigned char*)&d)[1]<<48) | \
            ((u_int64_t)((unsigned char*)&d)[0]<<56) \
            )


/*u_int64_t le64tohPFun(u_int64_t d)
{
    unsigned char* data = (unsigned char*)&d;
    return ((u_int64_t)data[0]<<0) |
            ((u_int64_t)data[1]<<8) |
            ((u_int64_t)data[2]<<16) |
            ((u_int64_t)data[3]<<24) |
            ((u_int64_t)data[4]<<32) |
            ((u_int64_t)data[5]<<40) |
            ((u_int64_t)data[6]<<48) |
            ((u_int64_t)data[7]<<56);
}

u_int64_t be64tohPFun(u_int64_t d)
{
    unsigned char* data = (unsigned char*)&d;
    return ((u_int64_t)data[7]<<0) |
            ((u_int64_t)data[6]<<8) |
            ((u_int64_t)data[5]<<16) |
            ((u_int64_t)data[4]<<24) |
            ((u_int64_t)data[3]<<32) |
            ((u_int64_t)data[2]<<40) |
            ((u_int64_t)data[1]<<48) |
            ((u_int64_t)data[0]<<56);
}*/
