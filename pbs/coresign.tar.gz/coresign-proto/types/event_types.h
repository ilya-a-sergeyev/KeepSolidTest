/*
 * event_types.h
 *
 *  Created on: May 20, 2011
 *      Author: fireball
 */

#ifndef EVENT_TYPES_H_
#define EVENT_TYPES_H_

//Event type 0 when coming from notification server - is just an empty ping
enum event_type : int
{
    // Custom fields meaning            data1               data2           data3           path
    Event_None                 = -1,    //  for client use
    Event_WorkGroupFirstEvent  = 0,     ////////////////////////////////////////////////////////////////////
    Event_WorkGroupInvite      = 1,     //  inviteeUser     inviteId        accessModeStr   folderName
    Event_WorkGroupCreate      = 2,     //  ""              ""              ""              folderName
    Event_WorkGroupRename      = 3,     //  folderNameNew   ""              ""              folderNameOld
    Event_WorkGroupDelete      = 4,     //  ""              ""              saveLocalData   folderName      ///saveLocalData can be "0" or "1"
    Event_WorkGroupSubscribe   = 5,     //  ""              ""              accessModeStr   folderName
    Event_WorkGroupUnsubscribe = 6,     //  unsubscribeUser ""              saveLocalData   folderName
    Event_WorkGroupReject      = 7,     //  rejectUser      ""              ""              folderName
    Event_WorkGroupAccessUpdate= 8,     //  targetUser      ""              accessModeStr   folderName
    Event_WorkGroupUndelete    = 9,     //  ""              ""              ""              folderName
    Event_WorkGroupMetadataUpdate = 10, //  metadataNew     type            ""              folderName
#ifdef DESKTOP_CLIENT
    Event_WorkGroupDownload    = 32,    //Local event ONLY. Used to initiate download folder's content
#endif
    Event_WorkGroupLastEvent,       ////////////////////////////////////////////////////////////////////
#ifdef DESKTOP_CLIENT
    Event_LocalRequestsBegin= 49,
    Event_RequestWorkgroups = 50,   // for local use ONLY.
    Event_RequestTopics     = 51,   // for local use ONLY.
    Event_RequestMessages   = 52,   // for local use ONLY.
    Event_LocalRequestsEnd  = 80,
#endif

    Event_FileFirstEvent    = 100,      ////////////////////////////////////////////////////////////////////
    Event_FileCreate        = 101,      //  ""              ""              fileSize        fileName
    Event_FileDelete        = 102,      //  ""              isDirectory     ""              fileName
    Event_FileRename        = 103,      //  fileNameNew     isDirectory     ""              fileNameOld
    Event_FileUpdate        = 104,      //  ""              isDirectory     ""              fileName
    Event_FileDirectoryCreate=105,      //  ""              ""              ""              fileName
    Event_FileUndelete      = 106,      //  ""              ""              fileSize        fileName
#ifdef DESKTOP_CLIENT
    Event_FileDownload              = 190,  //Local event ONLY. Used to request file from server
    Event_FileDirectoryDownload     = 191,  //Local event ONLY. Used to request directory from server
    Event_FileRevisionDownload      = 192,
    Event_FileCancelUploads         = 193,  //Local event ONLY. Use it to cancel all uploads currently in queue
    Event_FileCancelDownloads       = 194,  //Local event ONLY. Use it to cancel all kind of downloads currently in queue
#endif
    Event_FileLastEvent,                ////////////////////////////////////////////////////////////////////

    Event_TopicFirstEvent   = 200,      ////////////////////////////////////////////////////////////////////
    Event_TopicCreate       = 201,      //  topicId         topicBody       ""              ""
    Event_TopicDelete       = 202,      //  topicId         topicBody       ""              ""
    Event_TopicRename       = 203,      //  topicId         topicBodyNew    ""              ""
    Event_TopicUndelete     = 204,      //  topicId         topicBody       ""              ""
    Event_TopicLastEvent,               ////////////////////////////////////////////////////////////////////

    Event_MessageFirstEvent = 300,      ////////////////////////////////////////////////////////////////////
    Event_MessageCreate     = 301,      //  messageId       messageBody     topicId         parentId
    Event_MessageDelete     = 302,      //  messageId       messageBody     topicId         parentId
    Event_MessageEdit       = 303,      //  messageId       messageBody     topicId         parentId
    Event_MessageUndelete   = 304,      //  messageId       messageBody     topicId         parentId
    Event_MessageLastEvent,             ////////////////////////////////////////////////////////////////////


    Event_AccountFirstEvent = 400,
    Event_UserInfoUpdate    = 401,      //  firstName       lastName        userPic
    Event_AcctPassChanged   = 402,
#ifdef DESKTOP_CLIENT
    Event_UserPictureDownload= 450,     //Local event ONLY. Used to download user's picture
#endif
    Event_AccountLastEvent,

    Event_CompanyFirstEvent  = 500,     ////////////////////////////////////////////////////////////////////
    Event_CompanyInvite      = 501,     //  inviteeUser     inviteId        roleStr         companyName
    Event_CompanyCreate      = 502,     //  ""              ""              ""              companyName
    Event_CompanyInfoUpdate  = 503,     //  companyNameNew  ""              ""              companyNameOld
    Event_CompanyDelete      = 504,     //  ""              ""              ""              companyName
    Event_CompanySubscribe   = 505,     //  ""              ""              ""              companyName
    Event_CompanyUnsubscribe = 506,     //  unsubscribeUser ""              ""              companyName
    Event_CompanyReject      = 507,     //  rejectUser      ""              ""              companyName
    Event_CompanyRoleUpdate  = 508,     //  targetUser      ""              roleStr         companyName
    Event_CompanyUndelete    = 509,     //  ""              ""              ""              companyName
    Event_CompanyLastEvent              ////////////////////////////////////////////////////////////////////

#ifdef DESKTOP_CLIENT
    , Event_NOOP              = 900       //Used only for save last event ID without saving the event content
#endif
};

#endif /* EVENT_TYPES_H_ */
