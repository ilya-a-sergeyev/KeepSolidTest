﻿#pragma once

#include <string>
#include <vector>
#include <memory>
#include <Asio/asio/include/asio.hpp>
#include <mutex>
#include <condition_variable>

#include <network/NotificationTypes.hpp>

class AsioNotificationTransportAsync : public std::enable_shared_from_this<AsioNotificationTransportAsync>
{
    public:
        AsioNotificationTransportAsync(const std::string& address, const std::string& port);
        AsioNotificationTransportAsync() = delete;
        AsioNotificationTransportAsync(const AsioNotificationTransportAsync&) = delete;
        AsioNotificationTransportAsync(AsioNotificationTransportAsync&&) = delete;
        AsioNotificationTransportAsync& operator=(const AsioNotificationTransportAsync&) = delete;
        AsioNotificationTransportAsync& operator=(AsioNotificationTransportAsync&&) = delete;
        ~AsioNotificationTransportAsync();

        OperationStatus read                (asio::error_code& err, std::string& data_in);
        OperationStatus write               (const std::string& data_out);

        void            subscribe           (const function_MessageCallback& callback, const function_ConnectionCallback& connection_cb, bool start_service);
        void            stop                ();

        std::string get_port        () const {return _port;}
        std::string get_address     () const {return _address;}

        bool    is_connected        ();

    private:
        bool    connect             ();
        void    disconnect          ();
        void    schedule_ping       ();
        void    run_service         ();
        void    run_service_function();
        void    stop_service        ();

        void    start_timeout       ();
        void    stop_timeout        ();
        void    handle_timeout      (const asio::error_code& error);

        void    async_write_size        ();
        void    async_write_data        ();
        void    async_write_confirmation();
        void    async_read_size         ();
        void    async_read_data         ();
        std::size_t handle_read         (const asio::error_code& error, std::size_t bytes_transferred, int type);
        void        handle_write        (const asio::error_code& error, int type);

        void    operation_complete      (OperationStatus status);

        std::size_t handle_notification (const asio::error_code& error, std::size_t bytes_transferred);

        asio::io_service                _io_service;
        bool                            _is_service_running;
        asio::ip::tcp::socket           _socket;
        asio::deadline_timer            _timer;
        asio::strand                    _strand;

        function_MessageCallback        _callback;
        function_ConnectionCallback     _connection_cb;

        std::string                     _address;
        std::string                     _port;

        int64_t                         _data_in_size_planned;
        int64_t                         _data_in_size_real;
        int64_t                         _data_out_size;
        std::vector<char>               _data_in_vector;
        std::string                     _data_out;

        int32_t                         _timeout_ms;

        std::condition_variable         _condition_var;
        std::mutex                      _mutex;
        OperationStatus                 _operation_status;

        bool                            _waiting_notification;
};
