/*
 * xopenssl_pbkdf2.cpp
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */

#include <sstream>
#include "xopenssl_pbkdf2.h"
#include <openssl/engine.h>
#include <openssl/evp.h>
#include "xopenssl_defines.h"
#include "xopenssl_util.h"
#include "xopenssl.h"
#include "util/logging.h"

#pragma mark- PBKDF2


std::string sha256_pbkdf2_raw (const std::string& secret, const std::string& salt, int cycles)
{

    char result_cstr[AES256_KEY_SIZE];
    int res = PKCS5_PBKDF2_HMAC(secret.c_str(),(int)secret.length(),(const unsigned char*)salt.c_str(),(int)salt.length(),cycles,EVP_sha256(),AES256_KEY_SIZE,(unsigned char*)result_cstr);
    std::string result(result_cstr,AES256_KEY_SIZE);
    return result;
    #pragma unused (res)
}

std::string sha256_pbkdf2 (const std::string& secret, const std::string& salt, int cycles)
{
    return digest_to_hex_string(sha256_pbkdf2_raw(secret, salt, cycles));
}

std::string pbkdf2_by_salt (const std::string& secret, const std::string& salt)
{
    std::vector<std::string> exploded;

    split_string(salt, '$', exploded);

    if (exploded.size() != 3 || exploded[0].compare("sha256") != 0)
    {
        LOG_ERROR("OpenSSL pbkdf2_by_salt - [%s] is not valid (or not implemented) salt format!", salt.c_str());
        return "";
    }

    int cycles = -1;
    try
    {
        cycles = std::stoi(exploded[1]);
    }
    catch (std::exception&)
    {
        LOG_ERROR("OpenSSL verify pbkdf2_by_salt - %s is not valid int", exploded[1].c_str());
        return "";
    }

    return sha256_pbkdf2(secret, exploded[2], cycles);
}

std::string sha256_pbkdf2_password_generate  (const std::string& secret, std::string& salt_out, int cycles)
{
    random_seed();

    std::stringstream ss;
    ss<<"sha256"<<"$"<<((cycles > 0) ? cycles : MAGIC_SALT_ITERATIONS)<<"$"<<randomstring(MAGIC_LONG_RANDOM_DATA);
    salt_out = ss.str();

    std::string result = pbkdf2_by_salt(secret, salt_out);

    return result;
}

std::string sha256_pbkdf2_password_stretch  (const std::string& secret, const std::string& salt)
{
    std::string result = pbkdf2_by_salt(secret, salt);

    return result;
}

bool sha256_pbkdf2_verify    (const std::string& good_hash, const std::string& secret, const std::string& salt)
{
    std::string new_hash = sha256_pbkdf2_password_stretch(secret, salt);

    return (new_hash.compare(good_hash) == 0);
}
