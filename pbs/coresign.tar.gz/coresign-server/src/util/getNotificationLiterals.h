/*
 * getNotificationLiterals.h
 *
 *  Created on: 14 авг. 2012
 *      Author: fireballdark
 */

#ifndef GETNOTIFICATIONLITERALS_H_
#define GETNOTIFICATIONLITERALS_H_

const std::vector<std::string>& getNotifyLiterals();


#endif /* GETNOTIFICATIONLITERALS_H_ */
