/*
 * SimplexNotification.h
 *
 *  Created on: Apr 7, 2014
 *      Author: fireballdark
 */

#ifndef SIMPLEXNOTIFICATION_H_
#define SIMPLEXNOTIFICATION_H_
#include <types/keyvalue.h>

class SimplexNotification
{
public:
    SimplexNotification(const std::string& notification_name):
        _notification_name(notification_name)
    {}

    SimplexNotification(){}

    //Mailer
    bool generate_email_notification(KeyValue& data_outer, KeyValue& data_inner);

    //Inner
    void set_mail_id(const std::string& mail_id);
    void set_mail_id(int64_t mail_id);

    //Pusher
    void set_device_id(const std::string& device_id);
    bool generate_push_notification(KeyValue& data_outer, KeyValue& data_inner);

    //Inner
    void set_push_id(const std::string& push_id);
    void set_push_id(int64_t push_id);

    //Social
    void set_social_recipient(const std::string& social_recipient);
    void set_social_token(const std::string& social_token);
    void set_social_type(const std::string& social_type);
    bool generate_social_notification(KeyValue& data_outer, KeyValue& data_inner);

    //Inner
    void set_social_id(const std::string& social_id);
    void set_social_id(int64_t social_id);

    //Common
    void set_recipient_login(const std::string& recipient_login);

    void set_params(const KeyValue& params);
    void set_session(const std::string& session);
    void set_service_name(const std::string& service_name);
    void set_notification_name(const std::string& notification_name);

    const std::string& get_service_name() const;
    const std::string& get_notification_name() const;

protected:
    //Mailer
    std::string     _mail_id;

    //Social
    std::string     _social_type;
    std::string     _social_token;
    std::string     _social_recipient;
    std::string     _social_id;

    //Pusher
    std::string     _push_id;
    std::string     _device_id;

    //Common
    std::string     _recipient_login;
    KeyValue        _params;
    std::string     _session;
    std::string     _service_name;
    std::string     _notification_name;
};

#endif /* SIMPLEXNOTIFICATION_H_ */
