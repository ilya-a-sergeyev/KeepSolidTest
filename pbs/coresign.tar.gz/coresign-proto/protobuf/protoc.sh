#!/bin/bash

MYDIR=${0%/*}
cd $MYDIR

#Use md5sum by default, if it is not present - try md5
MD5SUM="md5sum"
if [ -z "`echo 123 | $MD5SUM 2>/dev/null`" ]; then
    MD5SUM="`whereis md5` -q"
fi

PROTOC="/usr/local/bin/protoc"
if [ ! -f $PROTOC ]; then
    PROTOC=`whereis -b protoc | awk '{print $2}'`
fi

cpp_compile(){
    CPATH="cpp"
    echo "Updated files $1"
    mkdir -p "$CPATH"
    $PROTOC --cpp_out=./"$CPATH" $1
}

erl_compile(){
    CPATH="erl"
    mkdir -p "$CPATH"
    FAILED=""
    for f in $1 ; do
        echo "Updated $f"
        piqi of-proto -I . $f
        piqic-erlang -C ./"$CPATH" -I . "$f".piqi 2>/dev/null
        if [ $? -ne 0 ]; then
            FAILED+=" $f.piqi"
        fi
    done
    for failed in $FAILED ; do
        piqic-erlang -C ./"$CPATH" -I . "$f".piqi
    done
}

clean_compile(){
    rm -rf */cpp
    rm -rf */erl
    rm -rf */*.ignore
}

compile_by_type(){
    TYPE=$1
    OLD_NAME=old_"$TYPE".ignore
    NEW_NAME=new_"$TYPE".ignore

    for directory in * ; do
        if [ -d "$directory" ]; then
            OLD=`pwd`
            cd "$directory"
            echo "Processing $TYPE $directory"

            if [ -f "$NEW_NAME" ]; then
                mv  "$NEW_NAME" "$OLD_NAME"
                $MD5SUM *.proto > "$NEW_NAME"
                CHANGED=`diff *_"$TYPE".ignore | awk '{print $3;}' | sort | grep -v '^[[:space:]]*$' | uniq | tr "\\n" " " | sed 's/.$//'`
            else
                $MD5SUM *.proto > "$NEW_NAME"
                CHANGED="*.proto"
            fi

            if [ ! -z "$CHANGED" ]; then
                if [ x"$TYPE" == x"cpp" ]; then
                    cpp_compile "$CHANGED"
                else
                    if [ x"$TYPE" == x"erl" ]; then
                        erl_compile "$CHANGED"
                    else
                        echo BAD TYPE "$TYPE"
                    fi
                fi
            fi

            cd "$OLD"
        fi
    done
}

TYPE="cpp"
if [ x"$1" != x"" ]; then
    TYPE="$1"
fi

echo Compiling for $TYPE

case "$TYPE" in
    clean) 
        clean_compile 
        ;;
    cpp)
        compile_by_type cpp 
        ;;
    erl)
        compile_by_type erl 
        ;;
    all)
        compile_by_type cpp
        compile_by_type erl 
        ;;
    *) 
        echo Unknown type $TYPE
        ;;
esac



