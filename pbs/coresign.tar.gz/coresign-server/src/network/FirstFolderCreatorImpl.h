/*
 * FirstFolderCreatorImpl.h
 *
 *  Created on: Feb 3, 2013
 *      Author: fireballdark
 */

#pragma once

#include <zmq.hpp>
#include <string>

class FirstFolderCreatorImpl
{
public:
    FirstFolderCreatorImpl  ();
    bool create_first_folder(const std::string& userLogin,const std::string& password,const std::string& public_key);
    void close              ();
    ~FirstFolderCreatorImpl ();

private:
    zmq::socket_t   socket;
};

