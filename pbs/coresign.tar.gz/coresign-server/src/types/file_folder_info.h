/*
 * file_folder_info.h
 *
 *  Created on: 29 квіт. 2011
 *      Author: fireball
 */

#ifndef FILE_FOLDER_INFO_H_
#define FILE_FOLDER_INFO_H_

#include <vector>
#include <string>
#include "types/folder_encryption_type.h"
#include <map>
#include "types/user_info.h"

struct WorkGroupInfo
{
    WorkGroupInfo():
        type(-1),
        is_deleted(false),
        invite_accepted(false),
        workgroup_id(0),
        creation_date(0),
        deletion_date(0),
        creator_id(0),
        access_mode(0),
        size(0),
        files_count(0),
        encryption_type(enc_type_unknown),
        encryption_algo(enc_algo_unknown)
    {
    }

    std::string         workgroup_name;
    std::string         description;
    int32_t             type;
    std::string         metadata;
    std::string         creator_login;
    std::string         key;
    std::string         key_signature;
    std::string         key_salt;
    bool                is_deleted;
    bool                invite_accepted;

    int64_t             workgroup_id;
    int64_t             creation_date;
    std::string         creation_date_str;
    int64_t             deletion_date;
    std::string         deletion_date_str;
    int64_t             creator_id;
    int64_t             access_mode;
    int64_t             size;

    int64_t             files_count;

    workgroup_enc_type  encryption_type;
    workgroup_enc_algo  encryption_algo;

    UserWorkGroupInfoList collaborators_list;
};

struct FileInfo
{
    FileInfo():
        file_id(0),
        workgroup_id(0),
        size(0),
        creation_date(0),
        deletion_date(0),
        revision(0),
        parent_id(0),
        is_deleted(false),
        is_approved(false),
        is_directory(false)
    {

    }

    std::string     file_name;   //including path
    std::string     hash;
    std::string     file_url;
    std::string     s3_url;
    std::string     policy;
    std::string     signature;
    std::string 	access_key;
    std::string     creator;

    int64_t         file_id;
    int64_t         workgroup_id;
    int64_t         size;
    int64_t         creation_date;
    std::string     creation_date_str;
    int64_t         deletion_date;
    std::string     deletion_date_str;
    int64_t         revision;
    int64_t         parent_id;

    bool            is_deleted;
    bool            is_approved;
    bool            is_directory;
};


struct WorkGroupInvite
{
    WorkGroupInvite():
        access_mode(0)
    {
    }

    int64_t             access_mode;
    std::string         invitee_login;
    std::string         key;
    std::string         social_type;
    std::string         social_id;
    std::string         social_token;
};

typedef std::vector<int64_t>        WorkGroupsList;
typedef std::vector<WorkGroupInfo>  WorkGroupsInfoList;
typedef std::vector<FileInfo>       FilesInfoList;

typedef std::map<int64_t,std::string> WorkGroupsKey;

typedef std::vector<WorkGroupInvite>  WorkGroupInvites;

#endif /* FILE_FOLDER_INFO_H_ */
