/*
 * Connection.cpp
 *
 *  Created on: 23 янв. 2012
 *      Author: fireballdark
 */

#include "Connection.h"
#include <boost/bind.hpp>
#include <boost/signals2/slot.hpp>
#include "conf/Globals.h"
#include <sutil/logging.h>
#include "rpc/protobuf/ProtobufZmqRpc.h"
#include "conf/DaemonParams.h"
#include "sutil/AtomicConnectionStats.h"
#include <types/transport_flags.h>

#define MESSAGE_MAX_SIZE        daemon_params().getRequestMaxSize()
#define MESSAGE_DEFAULT_SIZE    1024

Connection::Connection():
    _data_in_control_size(0),
    _data_in_size(0),
    _data_out_size(0),
    _data_keepalive_in(0),
    _data_keepalive_out(0),
    _state(Opened),
#ifndef SSL_DISABLED
    _socket(Globals::get_globals().getIOService(),Globals::get_globals().getSSLContext()),
#else
    _socket(Globals::get_globals().getIOService()),
#endif
    _timer(Globals::get_globals().getTimerIOService()),
//    connection_duration_("Connection unknown"),
    _strand(Globals::get_globals().getIOService()),
    _data_in_vector(MESSAGE_DEFAULT_SIZE),
    _stop_lock(),
    _sig_connection(),
    _is_ssl(false),
    _is_mature(false),
    _user_id(-1)
{
    char temp[16]= {0};
    snprintf(temp,sizeof(temp),"%4X",rand()%(1<<16));
    _connection_number.assign(temp,strnlen(temp,sizeof(temp)));

    add_connection_stack(Constructor,_state);
}

Connection::~Connection()
{
    add_connection_stack(Destructor,_state);

#ifndef SSL_DISABLED
    boost::system::error_code error;
    _socket.shutdown(error);
#endif

    LOG_INSANE("CON %s:%llu OMG, connection is dead! It's OK :)", _connection_number.c_str(), _data_keepalive_out);

    AtomicConnectionStats::destroy_connection();

    print_connection_stack();
}

SslSocket::lowest_layer_type& Connection::socket()
{
    return _socket.lowest_layer();
}

void Connection::start()
{
    AtomicConnectionStats::open_connection();

    try
    {
    	_sig_desc = ObjectSignalsProccessor::get_signal().connect(boost::bind(&Connection::handle_state_signal, this));
        _sig_connection = Globals::get_globals().getStopSignal().connect(
                boost::bind(&Connection::handle_stop_signal,this,_1));
        _stop_lock = boost::shared_lock<boost::shared_mutex>(Globals::get_globals().getGlobalStopMutex());
    }
    catch(const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception connecting signal or locking the lock [%s]",_connection_number.c_str(), _data_keepalive_out,e.what());
    }

    try
    {
        _connection_number +=" "+_socket.lowest_layer().remote_endpoint().address().to_string();
        _ip_address = _socket.lowest_layer().remote_endpoint().address().to_string();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception getting client's Address [%s]",_connection_number.c_str(), _data_keepalive_out,e.what());
    }

    add_connection_stack(Start, _state);

    work();
}

void Connection::work()
{
    if (Globals::get_globals().isIsStopped() && _state == Read_KeepAlive)
    {
        add_connection_stack(Handle_Stop_Signal,Close_Force);
    }

    switch (_state)
    {
        case Opened:
        {
            async_timeout_start();
            async_handshake();
            break;
        }
        case Read_Data_Size:
        {
            async_timeout_start();
            async_read_data_size();
            break;
        }
        case Read_Data:
        {
            async_timeout_start();
            async_read_data();
            break;
        }
        case Read_KeepAlive:
        {
            async_timeout_start();
            async_read_keepalive();
            break;
        }
        case Process_Data:
        {
            async_timeout_stop();
            Globals::get_globals().getThreadPoolProcessing().schedule(_strand.wrap(boost::bind(&Connection::processing, shared_from_this())));
            break;
        }
        case Write_Data_Size:
        {
            async_timeout_stop();
            async_write_data_size();
            break;
        }
        case Write_Data:
        {
            async_timeout_stop();
            async_write_data();
            break;
        }
        case Write_KeepAlive:
        {
            async_timeout_stop();
            async_write_keepalive();
            break;
        }
        case Shutdown:
        {
            async_timeout_start();
            async_shutdown();
            break;
        }
        case Error:
        case Close_Force:
        {
            async_timeout_stop();
            close();
            break;
        }
        case Closed:
        {
            async_timeout_stop();
            break;
        }
    }
}

void Connection::async_timeout_start()
{
    add_connection_stack(Async_Timeout_Start,_state);
    if (_is_mature)
    {
        _timer.expires_from_now(boost::posix_time::seconds(daemon_params().getConnectionTimeout()));
    }
    else
    {
        _timer.expires_from_now(boost::posix_time::seconds(16));
    }
    _timer.async_wait(_strand.wrap(boost::bind(&Connection::handle_timeout, shared_from_this(), boost::asio::placeholders::error)));
}

void Connection::async_timeout_stop()
{
    add_connection_stack(Async_Timeout_Stop,_state);
    _timer.cancel();
}

void Connection::handle_timeout(const boost::system::error_code& error)
{
    add_connection_stack(Handle_Timeout,_state);
    if (error != boost::asio::error::operation_aborted)
    {
        if (error)
        {
            LOG_INFORMATION("CON %s:%i Timeout handled with error %i : %s",_connection_number.c_str(), _data_keepalive_out,error.value(),error.message().c_str());
        }
        else
        {
            if (_state == Read_KeepAlive)
            {
                LOG_INSANE("CON %s:%i Closing timed out connection... OK",_connection_number.c_str(), _data_keepalive_out);
            }
            else
            {
                LOG_INSANE("CON %s:%i Closing timed out connection during state %i",_connection_number.c_str(), _data_keepalive_out,_state);
            }
        }
        add_connection_stack(Handle_Timeout,Error);
        work();
    }
}

void Connection::async_handshake()
{
    add_connection_stack(Async_Handshake,_state);
    try
    {
#ifndef SSL_DISABLED
        _socket.async_handshake(boost::asio::ssl::stream_base::server,
                                _strand.wrap(boost::bind(&Connection::handle_handshake, shared_from_this(),
                                             boost::asio::placeholders::error)));
#else
        handle_handshake(boost::system::error_code());
#endif
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception scheduling handshake %s",_connection_number.c_str(), _data_keepalive_out,e.what());
        add_connection_stack(Async_Handshake,Error);
    }
}

void Connection::handle_handshake(const boost::system::error_code& error)
{
    add_connection_stack(Handle_Handshake,_state);
    if (!error && _state!=Error)
    {
        AtomicConnectionStats::ssl_handshake_connection();
        _is_ssl=true;

        add_connection_stack(Handle_Handshake,Read_KeepAlive);
        LOG_INSANE("CON %s:%i Handshake with client OK",_connection_number.c_str(), _data_keepalive_out);
    }
    else
    {
        if ( !(error == boost::asio::error::timed_out || error == boost::asio::error::operation_aborted
                || error == boost::asio::error::eof || error.value() == /*EOF*/335544539 || error.value() == /*Wrong protocol version*/336130315) )
        {
            LOG_INFORMATION("CON %s:%i SSL handshake error %i : %s",_connection_number.c_str(), _data_keepalive_out,error.value(), error.message().c_str());
        }
        add_connection_stack(Handle_Handshake,Error);
    }

    work();
}

void Connection::async_read_data_size()
{
    add_connection_stack(Async_Read_Data_Size,_state);
    LOG_INSANE("Waiting for read %i", _state);

    try
    {
        boost::asio::async_read(_socket,boost::asio::buffer(&_data_in_size, sizeof(_data_in_size)),
                                _strand.wrap(boost::bind(&Connection::handle_read, shared_from_this(),
                                             boost::asio::placeholders::error,
                                             boost::asio::placeholders::bytes_transferred,
                                             0)));
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception scheduling read %s",_connection_number.c_str(), _data_keepalive_out,e.what());
        add_connection_stack(Async_Read_Data_Size,Error);
    }
}

void Connection::async_read_data()
{
    add_connection_stack(Async_Read_Data,_state);
    if (_data_in_size <=0 || _data_in_size > MESSAGE_MAX_SIZE)
    {
        LOG_INFORMATION("CON %s:%i Closing Connection because of wrong data_in_size %lli",_connection_number.c_str(), _data_keepalive_out,(long long int)_data_in_size);
        add_connection_stack(Async_Read_Data,Shutdown);
        work();
        return;
    }

    if (_data_in_vector.capacity() < _data_in_size)
    {
    	LOG_ABSOLUTE("CON %s:%i Had to resize buffer because of small data_in_size %lli:%lli",_connection_number.c_str(), _data_keepalive_out,(long long int)_data_in.capacity(),(long long int)_data_in_size);
    	_data_in_vector.resize((_data_in_size/32+1)*32);
    }

    try
    {
        boost::asio::async_read(_socket,boost::asio::buffer(_data_in_vector),
                                boost::asio::transfer_exactly(_data_in_control_size),
                                _strand.wrap(boost::bind(&Connection::handle_read, shared_from_this(),
                                             boost::asio::placeholders::error,
                                             boost::asio::placeholders::bytes_transferred,
                                             1)));
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception scheduling handshake %s",_connection_number.c_str(), _data_keepalive_out,e.what());
        add_connection_stack(Async_Read_Data,Error);
    }
}

void Connection::async_read_keepalive()
{
    add_connection_stack(Async_Read_KeepAlive,_state);
    LOG_INSANE("Waiting for read %i", _state);

    try
    {
        boost::asio::async_read(_socket,boost::asio::buffer(&_data_keepalive_in, sizeof(_data_keepalive_in)),
                                _strand.wrap(boost::bind(&Connection::handle_read, shared_from_this(),
                                             boost::asio::placeholders::error,
                                             boost::asio::placeholders::bytes_transferred,
                                             2)));
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception scheduling read %s",_connection_number.c_str(), _data_keepalive_out,e.what());
        add_connection_stack(Async_Read_KeepAlive,Error);
    }
}

std::size_t Connection::read_condition(const boost::system::error_code& error, std::size_t bytes_transferred)
{
    add_connection_stack(Read_Condition,_state);
    //LOG_INSANE("CON %s:%i Read %zi bytes",connection_number_.c_str(),bytes_transferred);

    if (error && error != boost::asio::error::eof  )
    {
        if (!(  error == boost::asio::error::connection_reset ||
                error == boost::asio::error::operation_aborted ||
                error == boost::asio::error::timed_out ))
        {
            LOG_ERROR("CON %s:%i Problem reading SSL data error %i : %s",_connection_number.c_str(), _data_keepalive_out,error.value(), error.message().c_str());
        }
        add_connection_stack(Read_Condition,Error);
        _data_in_control_size = 0;
    }

    if (_data_in_control_size > bytes_transferred)
    {
        _data_in_control_size -= bytes_transferred;
    }
    else
    {
        _data_in_control_size = 0;
    }

    return _data_in_control_size;
}

std::size_t Connection::handle_read(const boost::system::error_code& error, std::size_t bytes_transferred, int type)
{
    add_connection_stack(Handle_Read,_state);
    LOG_INSANE("CON %s:%i Did read %zi",_connection_number.c_str(), _data_keepalive_out, bytes_transferred);

    if (!error)
    {
        if (_state == Read_Data_Size && type == 0) //Read Data Size
        {
            TransportFlagsHelper flags;
            flags.init_with_transport_data(_data_in_size);
            _data_in_size = flags.get_size();
            _data_in_control_size = _data_in_size;
            add_connection_stack(Handle_Read,Read_Data);
        }
        else if (_state == Read_Data && type == 1) //Read Data
        {
            _data_in.append(_data_in_vector.data(), bytes_transferred);
            if (_data_in_control_size > bytes_transferred)
            {
                _data_in_control_size -= bytes_transferred;
                add_connection_stack(Handle_Read,Read_Data);
            }
            else
            {
                _data_in_control_size = 0;
                add_connection_stack(Handle_Read,Process_Data);
            }
        }
        else if (_state == Read_KeepAlive && type == 2)  // Read Keepalive
        {
            add_connection_stack(Handle_Read,Write_KeepAlive);
        }
        else if (_state == Shutdown)
        {
            LOG_INFORMATION("CON %s:%i Shutting down socket because of timeout. Bye-bye dear user!",_connection_number.c_str(), _data_keepalive_out);
        }
        else if (_state == Closed)
        {
            LOG_INFORMATION("CON %s:%i Trying to async HANDLE READ in Closed connection state",_connection_number.c_str(), _data_keepalive_out);
        }
        else
        {
            LOG_ERROR("CON %s:%i Trying to async HANDLE READ in wrong connection state %i",_connection_number.c_str(), _data_keepalive_out,_state);
            add_connection_stack(Handle_Read,Error);
        }
    }
    else if (error == boost::asio::error::shut_down || error == boost::asio::error::eof
             || error == boost::asio::error::timed_out || error == boost::asio::error::connection_reset
             || error == boost::asio::error::connection_aborted || error == boost::asio::error::broken_pipe
             || error == boost::asio::error::operation_aborted  || error == boost::asio::error::bad_descriptor
             || error.value() == 335544539)
    {
        add_connection_stack(Handle_Read,Shutdown);
        LOG_INSANE("CON %s:%i Connection is being closed (OK) because of error %i : %s",_connection_number.c_str(), _data_keepalive_out,error.value(),error.message().c_str());
    }
    else
    {
        LOG_ERROR("CON %s:%i Problem in reading data state %i error %i : %s",_connection_number.c_str(), _data_keepalive_out,_state,error.value(),error.message().c_str());
        add_connection_stack(Handle_Read,Error);
    }

    work();

    return bytes_transferred;
}

void Connection::processing()
{
    add_connection_stack(Processing,_state);

    _user_id = ProtobufZmqRpc::processData(_data_in.c_str(),std::min(_data_in_size, _data_in.size()),_data_out,_ip_address);

    if (_user_id >= 0)
    {
        if (_is_mature == false)
        {
            AtomicConnectionStats::mature_connection();
            _is_mature = true;
        }
        AtomicConnectionStats::make_ok_request();
    }
    else
    {
        AtomicConnectionStats::make_failed_request();
    }

    _data_in.clear();

    TransportFlagsHelper flags;
    flags.set_size(_data_out.size());
    //flags.set_use_ksv2_format(true);
    _data_out_size  = flags.get_transport_data();

    add_connection_stack(Processing,Write_Data_Size);

    work();
}

void Connection::async_write_data_size()
{
    add_connection_stack(Async_Write_Data_Size,_state);
    LOG_INSANE("CON %s:%i Writing data size %lli",_connection_number.c_str(), _data_keepalive_out, (long long int)_data_out_size);

    if (_state == Write_Data_Size)
    {
        boost::asio::async_write(_socket,boost::asio::buffer(&_data_out_size,sizeof(_data_out_size)),
                                 _strand.wrap(boost::bind(&Connection::handle_write, shared_from_this(),
                                              boost::asio::placeholders::error,
                                              0)));
    }
    else
    {
        LOG_ERROR("CON %s:%i Trying to async WRITE in wrong connection state %i",_connection_number.c_str(), _data_keepalive_out,_state);
        add_connection_stack(Async_Write_Data_Size,Error);
    }

}

void Connection::async_write_data()
{
    add_connection_stack(Async_Write_Data,_state);
    LOG_INSANE("CON %s:%i Writing data %zi",_connection_number.c_str(), _data_keepalive_out, _data_out.size());

    if (_state == Write_Data)
    {
        boost::asio::async_write(_socket, boost::asio::buffer(_data_out.c_str(),_data_out.size()),
                                 _strand.wrap(boost::bind(&Connection::handle_write, shared_from_this(),
                                              boost::asio::placeholders::error,
                                              1)));
    }
    else
    {
        LOG_ERROR("CON %s:%i Trying to async WRITE in wrong connection state %i",_connection_number.c_str(), _data_keepalive_out,_state);
        add_connection_stack(Async_Write_Data,Error);
    }

}

void Connection::async_write_keepalive()
{
    add_connection_stack(Async_Write_Keepalive,_state);
    LOG_INSANE("CON %s:%i Writing keepalive %lli", _connection_number.c_str(), _data_keepalive_out, (long long int)_data_keepalive_out);

    if (_data_keepalive_in != _data_keepalive_out)
    {
        LOG_INFORMATION("CON %s:%i Something's wrong, keepalives are not the same %lli:%lli", _connection_number.c_str(), _data_keepalive_out, (long long int)_data_keepalive_out, (long long int)_data_keepalive_in);
        add_connection_stack(Async_Write_Keepalive,Shutdown);
        work();
        return;
    }
    _data_keepalive_out++;

    if (_state == Write_KeepAlive)
    {
        boost::asio::async_write(_socket, boost::asio::buffer(&_data_keepalive_out,sizeof(_data_keepalive_out)),
                                 _strand.wrap(boost::bind(&Connection::handle_write, shared_from_this(),
                                              boost::asio::placeholders::error,
                                              2)));
    }
    else
    {
        LOG_ERROR("CON %s:%i Trying to async WRITE in wrong connection state %i",_connection_number.c_str(), _data_keepalive_out,_state);
        add_connection_stack(Async_Write_Keepalive,Error);
    }
}

void Connection::handle_write(const boost::system::error_code& e, int type)
{
    add_connection_stack(Handle_Write,_state);
    LOG_INSANE("CON %s:%i Handle write in state %i",_connection_number.c_str(), _data_keepalive_out, _state);

    if (!e)
    {
        if (_state == Write_Data_Size && type == 0)
        {
            add_connection_stack(Handle_Write,Write_Data);
        }
        else if (_state == Write_Data && type == 1)
        {
            _data_out.clear();
            add_connection_stack(Handle_Write,Read_KeepAlive);
        }
        else if (_state == Write_KeepAlive && type == 2)
        {
            add_connection_stack(Handle_Write,Read_Data_Size);
        }
        else if (_state == Closed)
        {
            LOG_INFORMATION("CON %s:%i Trying to async HANDLE WRITE in Closed connection state",_connection_number.c_str(), _data_keepalive_out);
        }
        else
        {
            LOG_ERROR("CON %s:%i Trying to async HANDLE WRITE in wrong connection state %i",_connection_number.c_str(), _data_keepalive_out,_state);
            add_connection_stack(Handle_Write,Error);
        }
    }
    else
    {
        if (e == boost::asio::error::shut_down || e == boost::asio::error::eof
                || e == boost::asio::error::timed_out || e == boost::asio::error::connection_reset
                || e == boost::asio::error::connection_aborted || e == boost::asio::error::broken_pipe
                || e == boost::asio::error::operation_aborted  || e == boost::asio::error::bad_descriptor
                || e.value() == 335544539)
        {
            LOG_INSANE("CON %s:%i Got (OK) error writing SSL %i : %s",_connection_number.c_str(), _data_keepalive_out,e.value(),e.message().c_str());
        }
        else
        {
            LOG_ERROR("CON %s:%i Got error writing SSL %i : %s",_connection_number.c_str(), _data_keepalive_out,e.value(),e.message().c_str());
        }
        add_connection_stack(Handle_Write,Error);
    }

    work();
}

void Connection::async_shutdown()
{
    add_connection_stack(Async_Shutdown,_state);
    LOG_INSANE("CON %s:%i Shutting down connection",_connection_number.c_str(), _data_keepalive_out);

    try
    {
#ifndef SSL_DISABLED
        _socket.async_shutdown(_strand.wrap(boost::bind(&Connection::handle_shutdown,shared_from_this(),boost::asio::placeholders::error)));
#else
        handle_shutdown(boost::system::error_code());
#endif
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("CON %s:%i Exception scheduling shutdown %s",_connection_number.c_str(), _data_keepalive_out,e.what());
        add_connection_stack(Async_Shutdown,Error);
    }
}

void Connection::handle_shutdown(const boost::system::error_code& e)
{
    add_connection_stack(Handle_Shutdown,_state);
    LOG_INSANE("CON %s:%i Handled shutdown %i",_connection_number.c_str(), _data_keepalive_out, _state);

    if (!e)
    {
        if (_state == Shutdown)
        {
            add_connection_stack(Handle_Shutdown,Closed);
        }
    }
    else
    {
        if ( ! (e == boost::asio::error::connection_reset   ||
                e == boost::asio::error::bad_descriptor     ||
                e == boost::asio::error::broken_pipe        ||
                e == boost::asio::error::eof                ||
                e == boost::asio::error::operation_aborted  ||
                e.value() == 335544539))
        {
            LOG_ERROR("CON %s:%i Got error shutting down SSL %i : %s",_connection_number.c_str(), _data_keepalive_out,e.value(), e.message().c_str());
        }
        add_connection_stack(Handle_Shutdown,Error);
    }

    close();

    work();
}

void Connection::close()
{
    add_connection_stack(Close,_state);
    LOG_INSANE("CON %s:%i Closing connection",_connection_number.c_str(), _data_keepalive_out);

    try
    {
        boost::system::error_code ignored_ec;
        _socket.lowest_layer().shutdown(boost::asio::ip::tcp::socket::shutdown_both, ignored_ec);
        _socket.lowest_layer().close();
    }
    catch(const std::exception& e)
    {
        LOG_INFORMATION("CON %s:%i Exception closing TCP connection %s",_connection_number.c_str(), _data_keepalive_out,e.what());
    }

    try
    {
        _sig_connection.disconnect();

        if (_stop_lock.owns_lock())
        {
            _stop_lock.unlock();
            _stop_lock.release();
        }
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Got exception signal or lock exception when closing connection - [%s]",e.what());
    }

    if (_is_ssl)
    {
        AtomicConnectionStats::close_ssl_connection();
        _is_ssl = false;
    }

    if (_is_mature)
    {
        AtomicConnectionStats::close_mature_connection();
        _is_mature = false;
    }

    add_connection_stack(Close,Closed);
}

void Connection::add_connection_stack(ConnectionStack element, ConnectionState state)
{
#ifdef CONNECTION_STACK
    if (connection_stack.size()>daemon_params().getConnectionStackSize())
    {
        connection_stack.pop_back();
    }
    connection_stack.push_front(element);

    if (connection_state.size()>daemon_params().getConnectionStackSize())
    {
        connection_state.pop_back();
    }
    connection_state.push_front(state);
#endif

    _state = state;
}

description_type Connection::handle_state_signal()
{
    description_type description;
    description["ip_address"] = _ip_address;
    std::stringstream state, is_ssl, queue;
    state << _state;
    description["state"]            = state.str();
    is_ssl << this->_is_ssl;
    description["is_ssl"]          = is_ssl.str();
    return description;
}

void Connection::handle_stop_signal(int action)
{
    if (action == 0)
    {
        if ( (_state >= Opened && _state <= Read_KeepAlive) || _state == Closed)
        {
            LOG_ABSOLUTE("CON %s:%i Stop signal got in state %i",_connection_number.c_str(), _data_keepalive_out, _state);
            add_connection_stack(Handle_Stop_Signal,Close_Force);
            work();
        }
    }
    else if (action == 1)
    {
        LOG_INFORMATION("CON %s:%i Connection is in state [%i] user_id [%lli] div/di/do size [%li:%li:%li]",_connection_number.c_str(), _data_keepalive_out,
                _state, _user_id, _data_in_vector.size(), _data_in.capacity(), _data_out.capacity());
    }
}

void Connection::print_connection_stack()
{
#ifdef CONNECTION_STACK
    std::stringstream ss0;
    ss0<<"Stack: ";
    for (std::deque<ConnectionStack>::iterator it = connection_stack.begin(); it!= connection_stack.end(); it++)
    {
        ss0<<std::setw(2)<<*it<<"<-";
    }

    LOG_INSANE("CON %s:%i %s",_connection_number.c_str(), _data_keepalive_out,ss0.str().c_str());

    std::stringstream ss1;
    ss1<<"State: ";
    for (std::deque<ConnectionState>::iterator it = connection_state.begin(); it!= connection_state.end(); it++)
    {
        ss1<<std::setw(2)<<*it<<"<-";
    }

    LOG_INSANE("CON %s:%i %s",_connection_number.c_str(), _data_keepalive_out,ss1.str().c_str());
#endif
}


