/*
 * Globals.h
 *
 *  Created on: Jun 6, 2011
 *      Author: fireball
 */

#ifndef GLOBALS_H_
#define GLOBALS_H_
#include <queue>
#include <pthread.h>
#include <cstdio>
#include <zmq.hpp>
#include <string>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/thread/shared_mutex.hpp>
#include <boost/signals2.hpp>
#include <threadpool/boost/threadpool.hpp>

typedef boost::signals2::signal<void (int)>  stop_signal_type;

class Globals
{
public:
    Globals();
    ~Globals();


    static Globals&    get_globals()
    {
        static Globals singleton;
        return singleton;
    }

    FILE*                           getLogFile() const;
    zmq::context_t*                 getZMQContext();
    boost::asio::io_service&        getIOService();
    boost::asio::io_service&        getTimerIOService();
    boost::asio::ssl::context&      getSSLContext();
    boost::shared_ptr<boost::asio::ssl::context>    getSSLContextPtr();
    boost::threadpool::pool&        getThreadPoolProcessing();
    boost::threadpool::pool&        getThreadPoolSecondary();
    boost::shared_mutex&            getGlobalStopMutex();
    stop_signal_type&               getStopSignal();

    bool                            isIsStopped() const;
    void                            setIsStopped(bool isStopped);

    void                            stopZMQContext();
    void                            setLogFile(FILE* log_file);

    void                            runIOService();
    void                            runTimerIOService();

private:
    zmq::context_t*         zmq_context;
    boost::asio::io_service io_service;
    boost::asio::io_service timer_io_service;
    boost::asio::ssl::context ssl_context;
    boost::threadpool::pool thread_pool_processing;
    boost::threadpool::pool thread_pool_secondary;
    boost::shared_mutex     global_stop_mutex;

    stop_signal_type        stop_signal;

    bool                    is_stopped;
};

#endif /* GLOBALS_H_ */
