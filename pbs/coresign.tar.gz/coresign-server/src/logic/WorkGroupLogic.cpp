/*
 * logic.cpp
 *
 *  Created on: 31 бер. 2011
 *      Author: fireball
 */

#include "logic/WorkGroupLogic.h"

#include <sutil/logging.h>
#include <util/DataVerifier.h>
#include <sutil/MailerHelper.h>

#include "db/tariffs/TariffManagerPgSql.h"
#include "db/users/UserManagerPgSql.h"
#include "db/folders/FolderManagerPgSql.h"
#include "db/folder_invites/FolderInvitesPgSql.h"
#include "db/files/FileManagerPgSql.h"

#include "logic/EventLogic.h"
#include "logic/HelperLogic.h"
#include "MailTemplate.h"
#include "util/SimplexNotificationSender.h"
#include "logic/UserLogic.h"
#include <boost/lexical_cast.hpp>

rpc_status_code WorkGroupLogic::workgroupsList(RequestContext& context,
        int foldersFilter,
        WorkGroupsInfoList& foldersInfoList,
        InviteInfoList& inviteInfoList,
        int64_t& lastEventId)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;

    statusCode = HelperLogic::checkSession(context, userId, deviceId);

    if (statusCode == status_success && userId > 0 )
    {
        UserWorkGroupInfoMultiMap uwgimm;
        std::map<int64_t,int64_t> count;

        if (foldersFilter == 0)
        {
            statusCode = WorkGroupManagerPgSql::list_folders(userId, false, foldersInfoList, lastEventId);
            statusCode = WorkGroupManagerPgSql::list_all_coworkers_for_wgs(userId, false, uwgimm);
            statusCode = FileManagerPgSql::count_files_for_wgs(userId, false, count);
        }
        else if (foldersFilter == 1)
        {
            statusCode = WorkGroupManagerPgSql::list_folders(userId, true, foldersInfoList, lastEventId);
            statusCode = WorkGroupManagerPgSql::list_all_coworkers_for_wgs(userId, true, uwgimm);
            statusCode = FileManagerPgSql::count_files_for_wgs(userId, true, count);
        }
        else if (foldersFilter == 2)
        {
            statusCode = WorkGroupManagerPgSql::list_all_folders(userId, foldersInfoList, lastEventId);
            statusCode = WorkGroupManagerPgSql::list_all_coworkers_for_wgs_all(userId, uwgimm);
            statusCode = FileManagerPgSql::count_files_for_wgs_all(userId, count);
        }

        InviteInfosByWorkGroups iibw;
        statusCode = WorkGroupInvitesPgSql::get_invitations(context, userId, iibw);

        for(auto& wgi : foldersInfoList)
        {
            KSD::AccessRightsHelper rights(wgi.access_mode);
            if (rights.get_read_folder() == true)
            {
                std::pair<UserWorkGroupInfoMultiMap::const_iterator, UserWorkGroupInfoMultiMap::const_iterator> res;
                res = uwgimm.equal_range(wgi.workgroup_id);
                for (UserWorkGroupInfoMultiMap::const_iterator it = res.first; it != res.second; it++)
                {
                    wgi.collaborators_list.push_back((*it).second);
                }
                std::map<int64_t,int64_t>::const_iterator ci = count.find(wgi.workgroup_id);
                if (ci != count.end())
                {
                    wgi.files_count = (*ci).second;
                }
            }
        }

        inviteInfoList = filter_out_max_rights_invites(iibw);

        LOG_ABSOLUTE("WorkGroupsList function ended: userId [%lli] : session [%s], folders number [%zi] collabs [%zi]", userId,
                context.session_id.c_str(), foldersInfoList.size(), uwgimm.size());
    }
    else
    {
        statusCode = status_unauthorized;
        LOG_INFORMATION("WorkGroupsList function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupCoworkersList(
        RequestContext& context,
        int64_t folderId,
        UserLoginList& userEmails)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        {
            WorkGroupInfo folderInfo;
            if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder())
            {
                statusCode = status_access_denied;
                break;
            }

            statusCode = WorkGroupManagerPgSql::list_folder_coworkers(userId,folderId,userEmails);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupCoworkersList function ended: userId [%lli] : session [%s], coworkers number [%zi]", userId, context.session_id.c_str(), userEmails.size());
    }
    else
    {
        LOG_INFORMATION("WorkGroupCoworkersList function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupCoworkersAll(
        RequestContext& context,
        int64_t folderId,
        UserLoginList& userEmails)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (folderId<=0)
        {
            statusCode = WorkGroupManagerPgSql::list_all_coworkers(userId,userEmails);
        }
        else
        {
            WorkGroupInfo folderInfo;
            if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder())
            {
                statusCode = status_access_denied;
                break;
            }

            statusCode = WorkGroupManagerPgSql::list_all_coworkers(userId,folderId,userEmails);
        }


        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupCoworkersAll function ended: userId [%lli] : session [%s], coworkers number [%zi]", userId, context.session_id.c_str(), userEmails.size());
    }
    else
    {
        LOG_INFORMATION("WorkGroupCoworkersAll function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupCoworkersAllEx(
        RequestContext& context,
        int64_t folderId,
        UserWorkGroupInfoList& userFolderInfoList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (folderId<=0)
        {
            statusCode = WorkGroupManagerPgSql::list_all_coworkers_ex(userId,userFolderInfoList);
        }
        else
        {
            WorkGroupInfo folderInfo;
            if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder())
            {
                statusCode = status_access_denied;
                break;
            }

            statusCode = WorkGroupManagerPgSql::list_all_coworkers_ex(userId,folderId,userFolderInfoList);
        }


        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupCoworkersAllEx function ended: userId [%lli] : session [%s], coworkers number [%zi]", userId, context.session_id.c_str(), userFolderInfoList.size());
    }
    else
    {
        LOG_INFORMATION("WorkGroupCoworkersAllEx function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupCoworkersExtra(
        RequestContext& context,
        int64_t folderId,
        UserWorkGroupInfoList& userFolderInfoList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        {
            WorkGroupInfo folderInfo;
            if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_read_folder())
            {
                statusCode = status_access_denied;
                break;
            }

            statusCode = WorkGroupManagerPgSql::list_folder_coworkers_extra(userId,folderId,userFolderInfoList);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupCoworkersExtra function ended: userId [%lli] : session [%s], coworkers number [%zi]", userId, context.session_id.c_str(), userFolderInfoList.size());
    }
    else
    {
        LOG_INFORMATION("WorkGroupCoworkersExtra function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupKickUserMass(
        RequestContext& context,
        int64_t folderId,
        const LoginForKickList& loginKickList,
        ReturnStatusList& returnStatusList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }


        WorkGroupInfo folderInfo;

        if (!HelperLogic::checkIsShared(userId,folderId,folderInfo))
        {
            LOG_INFORMATION("Sorry, you do not have this folder shared");
            statusCode = status_access_denied;
            break;
        }

        //        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_share_folder())
        //        {
        //            statusCode = status_access_denied;
        //            break;
        //        }

        if (folderInfo.workgroup_id <= 0 || folderInfo.is_deleted == true || statusCode != status_success)
        {
            LOG_ABSOLUTE("No folder was found");
            //statusCode = status_does_not_exist;
            break;
        }

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

        if (statusCode != status_success || userInfo.login.empty() )
        {
            LOG_ABSOLUTE("No user was found");
            break;
        }

        for (LoginForKickList::const_iterator iter = loginKickList.begin(); iter!=loginKickList.end(); iter++)
        {
            rpc_status_code status = WorkGroupLogic::_workgroupKickUser(context,userInfo,folderInfo,(*iter));
            ReturnStatus rs;
            rs.login = (*iter).first;
            rs.returnStatus = status;
            returnStatusList.push_back(rs);

            if (status == status_success)
            {
                statusCode = status;
            }
        }
    }
    while (false);

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupCreate(
        RequestContext& context,
        const WorkGroupInfo& folderInfo,
        WorkGroupInfo& folderInfoGet,
        int64_t& folderId)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do {

        if (check_directory_name(folderInfo.workgroup_name)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("WorkGroupName [%s] is not valid for creation",folderInfo.workgroup_name.c_str());
            statusCode = status_bad_syntax;
            break;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if ((folderInfo.encryption_type == enc_type_auto || folderInfo.encryption_type == enc_type_pass || folderInfo.encryption_type == enc_type_file) && folderInfo.key.empty())
        {
            LOG_INFORMATION("WorkGroups with encryption should contain Key");
            statusCode = status_bad_syntax;
            break;
        }

        if ((folderInfo.encryption_type == enc_type_pass || folderInfo.encryption_type == enc_type_file) && (folderInfo.key_signature.empty() || folderInfo.key_salt.empty()))
        {
            LOG_INFORMATION("WorkGroups with PASS or FILE encryption should contain KeySig and KeySalt");
            statusCode = status_bad_syntax;
            break;
        }

        if ((folderInfo.encryption_type == enc_type_auto || folderInfo.encryption_type == enc_type_none) && (!folderInfo.key_signature.empty() || !folderInfo.key_salt.empty()))
        {
            LOG_INFORMATION("WorkGroups with AUTO or NONE encryption should NOT contain KeySig and KeySalt");
            statusCode = status_bad_syntax;
            break;
        }

        UserInfo userInfo = context.user_info;

        statusCode = WorkGroupManagerPgSql::create_folder(userId, userInfo.login, folderInfo, folderId);

        if (statusCode != status_success)
        {
            LOG_INFORMATION("Could not create folder [%s]",folderInfo.workgroup_name.c_str());
            break;
        }

        EventLogic::folderCreate(userId,userInfo.login,deviceId,folderId,folderInfo.workgroup_name);

        bStatus = true;

        statusCode = WorkGroupManagerPgSql::get_folder_info(userId,folderId,folderInfoGet);
        if (statusCode != status_success)
        {
            LOG_INFORMATION("WorkGroupInfo: can`t get folder info");
            break;
        }
    }
    while(false);

    if(bStatus)
    {

        LOG_ABSOLUTE("WorkGroupCreate function ended: userId [%lli] : session [%s], folderId [%lli]", userId, context.session_id.c_str(), folderId);
    }
    else
    {
        LOG_INFORMATION("WorkGroupCreate function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupDelete(
        RequestContext& context,
        int64_t folderId,
        bool removeNow,
        bool keep_data)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;
    WorkGroupInfo folderInfo;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_kill_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        UserIdList userIds;
        WorkGroupManagerPgSql::list_all_coworkers_ids(userId,folderId,userIds);

        if (removeNow == false)
        {
            statusCode = WorkGroupManagerPgSql::remove_folder(userId,folderId);
        }
        else
        {
            statusCode = WorkGroupManagerPgSql::remove_folder_now(userId,folderId);
            FileManagerPgSql::remove_file_to_delete(userId,folderId);
        }

        if (statusCode != status_success)
        {
            break;
        }

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

        for (unsigned int i=0; i<userIds.size(); i++)
        {
            EventLogic::folderDelete(userId,userInfo.login,deviceId,folderId,folderInfo.workgroup_name, keep_data,userIds[i]);
        }

        bStatus = true;

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupDelete function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupDelete function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}



rpc_status_code WorkGroupLogic::workgroupRename(
        RequestContext& context,
        int64_t folderId,
        const std::string& folderNameNew)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    WorkGroupInfo folderInfo;

    do
    {
        if (check_directory_name(folderNameNew)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("WorkGroupName [%s] is not valid for creation",folderNameNew.c_str());
            statusCode = status_bad_syntax;
            break;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        statusCode = WorkGroupManagerPgSql::rename_folder(userId,folderId,folderNameNew);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);
        EventLogic::folderRename(userId,userInfo.login,deviceId,folderId,folderInfo.workgroup_name,folderNameNew);
        LOG_ABSOLUTE("WorkGroupRename function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupRename function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupInviteMass(
        RequestContext& context,
        int64_t folderId,
        const WorkGroupInvites& folderInvites,
        ReturnStatusList& returnStatusList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }


        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_share_folder())
        {
            LOG_INFORMATION("You don't have permission to share WG [%lli]", folderId);
            ADD_ERROR_MESSAGE(context, "You don't have permission to share WG");
            statusCode = status_access_denied;
            break;
        }

        if (folderInfo.workgroup_id <= 0 || folderInfo.is_deleted == true || statusCode != status_success)
        {
            LOG_ABSOLUTE("No folder was found");
            //statusCode = status_does_not_exist;
            break;
        }

        UserInfo inviterUserInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,inviterUserInfo);

        if (statusCode != status_success || inviterUserInfo.login.empty() )
        {
            LOG_ABSOLUTE("No inviter was found");
            break;
        }

        for (WorkGroupInvites::const_iterator iter = folderInvites.begin(); iter!=folderInvites.end(); iter++)
        {
            rpc_status_code status = WorkGroupLogic::_workgroupInvite(context,inviterUserInfo,folderInfo,(*iter));
            ReturnStatus rs;
            rs.login = (*iter).invitee_login;
            rs.returnStatus = status;
            returnStatusList.push_back(rs);

            LOG_ABSOLUTE("WorkGroupInviteMass: [%s] is inviting [%s] to [%i]:[%s]", inviterUserInfo.login.c_str(), (*iter).invitee_login.c_str(), folderInfo.workgroup_id, folderInfo.workgroup_name.c_str());

            if (status == status_success)
            {
                statusCode = status;
            }
        }
    }
    while (false);

    return statusCode;

}

rpc_status_code WorkGroupLogic::workgroupSubscribe(
        RequestContext& context,
        const std::string& inviteId,
        bool acceptInvite)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if (inviteId.empty())
        {
            LOG_INFORMATION("InviteId is empty, so it's not valid");
            ADD_ERROR_MESSAGE(context, "InviteId is empty, so it's not valid");
            statusCode = status_bad_syntax;
            break;
        }

        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        InviteInfo inviteInfo;
        statusCode = WorkGroupInvitesPgSql::get_invitation(context, inviteId, inviteInfo);

        if (statusCode != status_success || inviteInfo.workgroup_id<=0 )
        {
            LOG_ABSOLUTE("Could not get invite [%s]",inviteInfo.invite_id.c_str());
            ADD_ERROR_MESSAGE(context, "Could not get invite ["+inviteInfo.invite_id+"]");
            break;
        }

        WorkGroupInfo folderInfo;
        bool isShared = HelperLogic::checkIsShared(userId, inviteInfo.workgroup_id, folderInfo);
        if (isShared == true && folderInfo.access_mode != KSD::AccessRights::no_access)
        {
            statusCode = status_already_exist;
            LOG_ABSOLUTE("Invitee already has this workgroup shared");
            ADD_ERROR_MESSAGE(context, "Invitee ["+inviteInfo.invitee_login+"] already has this workgroup shared");
            statusCode = WorkGroupInvitesPgSql::remove_invitations(context, userId, inviteInfo.workgroup_id);
            break;
        }

        if (inviteInfo.is_anonymous == false && inviteInfo.invitee_id != userId)
        {
            statusCode = status_access_denied;
            LOG_ABSOLUTE("Trying to accept someone else's invite!");
            ADD_ERROR_MESSAGE(context, "Trying to accept someone else's invite!");
            break;
        }

        if (inviteInfo.is_anonymous == true && acceptInvite == true)
        {
            inviteInfo.invitee_id = context.session_info.user_id;
            inviteInfo.invitee_login = context.session_info.username;
            statusCode = _workgroupShareWG(context, inviteInfo);
        }

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId, userInfo);
        inviteInfo.set_inviter_name(userInfo.first_name, userInfo.last_name);

        if (acceptInvite)
        {
            statusCode = _workgroupAcceptInvite(context, userInfo, inviteInfo);
        }
        else
        {
            statusCode = _workgroupRejectInvite(context, userInfo, inviteInfo);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupSubscribe function ended: userId [%lli] : session [%s] inviteId [%s]", userId, context.session_id.c_str(), inviteId.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupSubscribe function failed: userId [%lli] : session [%s] inviteId [%s]", userId, context.session_id.c_str(), inviteId.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupUnsubscribe(
        RequestContext& context,
        int64_t folderId)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;
    WorkGroupInfo folderInfo;
    UserInfo userInfo;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (!HelperLogic::checkIsShared(userId,folderId,folderInfo))
        {
            statusCode = status_access_denied;
            break;
        }

        UserWorkGroupInfoList userEmails;
        //statusCode = WorkGroupManagerPgSql::list_folder_coworkers(userId,folderId,userEmails);
        statusCode = WorkGroupManagerPgSql::list_folder_coworkers_extra(userId,folderId,userEmails);

        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

        //if (userEmails.size()>1)
        if (folderInfo.creator_login.compare(userInfo.login)!=0)
        {
            statusCode = WorkGroupManagerPgSql::unsubscribe_folder(userId,folderId);
        }
        else
        {
            LOG_INFORMATION("Sorry, owner can't unsubscribe, use delete ;)");
            statusCode = status_already_exist;
        }

        if (statusCode == status_success)
        {
            LOG_ABSOLUTE("WorkGroupUnsubscribe: User [%s] unsubscribed from folder [%lli]",userInfo.login.c_str(), folderId);
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        EventLogic::folderUnsubscribe(userId,userInfo.login,deviceId,folderId, false,userInfo.login,folderInfo.workgroup_name,userInfo.user_id);
        LOG_ABSOLUTE("WorkGroupUnsubscribe function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupUnsubscribe function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupInvitesList(
        RequestContext& context,
        int64_t folderId,
        InviteInfoList& inviteInfoList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkIsShared(userId,folderId,folderInfo))
        {
            statusCode = status_access_denied;
            break;
        }

        statusCode = WorkGroupInvitesPgSql::get_invitations(context, userId, folderId, inviteInfoList);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupInvitesList function ended: userId [%lli] : session [%s], invites number [%zi]", userId, context.session_id.c_str(), inviteInfoList.size());
    }
    else
    {
        LOG_INFORMATION("WorkGroupInvitesList function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupInfo(
        RequestContext& context,
        int64_t folderId,
        WorkGroupInfo& folderInfo,
        InviteInfoList& inviteInfoList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (!HelperLogic::checkIsShared(userId,folderId,folderInfo))
        {
            statusCode = status_access_denied;
            LOG_INFORMATION("WorkGroupInfo:access denied: folderId[%lld]", folderId);
            break;
        }

        {
            KSD::AccessRightsHelper rights(folderInfo.access_mode);
            if (rights.get_read_folder() == true)
            {
                statusCode = WorkGroupManagerPgSql::list_folder_coworkers_extra(userId,folderInfo.workgroup_id,folderInfo.collaborators_list);
                statusCode = FileManagerPgSql::count_files(userId, folderInfo.workgroup_id, folderInfo.files_count);
            }
        }

        InviteInfoList iil;
        statusCode = WorkGroupInvitesPgSql::get_invitations(context, userId, folderId, iil);

        LOG_ABSOLUTE("WorkGroupInfo: got %zi invites",iil.size());

        inviteInfoList = get_max_rights_invite(iil);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupInfo function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupInfo function failed: userId [%lli] : session [%s] : statusCode[%d]", userId, context.session_id.c_str(), statusCode);
    }

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupSetAccessMass(
        RequestContext& context,
        int64_t folderId,
        const WorkGroupInvites& folderInvites,
        ReturnStatusList& returnStatusList)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }


        WorkGroupInfo folderInfo;
        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_control_access())
        {
            LOG_INFORMATION("Can't set access rights if got no control_access rights");
            statusCode = status_access_denied;
            break;
        }

        if (folderInfo.workgroup_id <= 0 || folderInfo.is_deleted == true || statusCode != status_success)
        {
            LOG_ABSOLUTE("No folder was found");
            //statusCode = status_does_not_exist;
            break;
        }

        UserInfo inviterUserInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,inviterUserInfo);

        if (statusCode != status_success || inviterUserInfo.login.empty() )
        {
            LOG_ABSOLUTE("No user was found");
            break;
        }

        for (WorkGroupInvites::const_iterator iter = folderInvites.begin(); iter!=folderInvites.end(); iter++)
        {
            rpc_status_code status = WorkGroupLogic::_workgroupSetAccess(context,inviterUserInfo,folderInfo,(*iter).invitee_login,(*iter).access_mode);
            ReturnStatus rs;
            rs.login = (*iter).invitee_login;
            rs.returnStatus = status;
            returnStatusList.push_back(rs);

            if (status == status_success)
            {
                statusCode = status;
            }
        }
    }
    while (false);

    return statusCode;
}


rpc_status_code WorkGroupLogic::workgroupUndelete(
        RequestContext& context,
        int64_t folderId)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;
    WorkGroupInfo folderInfo;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_kill_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        //        UserIdList userIds;
        //        WorkGroupManagerPgSql::list_all_coworkers_ids(userId,folderId,userIds);

        statusCode = WorkGroupManagerPgSql::undelete_folder(userId,folderId);

        if (statusCode != status_success)
        {
            break;
        }

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

        //        for (unsigned int i=0; i<userIds.size(); i++)
        //        {
        //            EventLogic::folderUndelete(userId,userInfo.login,deviceId,folderId,folderInfo.workgroup_name,userIds[i]);
        //        }

        EventLogic::folderUndelete(userId,userInfo.login,deviceId,folderId,folderInfo.workgroup_name,0);

        bStatus = true;

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupUndelete function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupDelete function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::workgroupMetadataUpdate(
        RequestContext& context,
        int64_t folderId,
        const std::string& metadata_new)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    WorkGroupInfo folderInfo;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        if (!HelperLogic::checkPermissions(userId,folderId,folderInfo).get_write_folder())
        {
            statusCode = status_access_denied;
            break;
        }

        statusCode = WorkGroupManagerPgSql::metadata_update(userId,folderId,metadata_new);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);
        EventLogic::folderMetadataUpdate(userId,userInfo.login,deviceId,folderId,folderInfo.workgroup_name,metadata_new);
        LOG_ABSOLUTE("WorkGroupMetadataUpdate function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupMetadataUpdate function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupKickUser(
        RequestContext& context,
        const UserInfo& userInfo,
        const WorkGroupInfo& folderInfo,
        const LoginForKick& loginUserForKick)
{
    int64_t userId = userInfo.user_id;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;
    //if user is using folder, he should be kicked
    //if user has not accepted invite, he is forced to reject subscription

    do
    {
        UserInfo kickedUser;
        WorkGroupInfo folderInfoForKicked;

        //Get users and folder info
        {
            statusCode = UserManagerPgSql::getUserInfoByLogin(loginUserForKick.first,kickedUser);

            if (statusCode!= status_success || kickedUser.user_id<=0)
            {
                LOG_INFORMATION("WorkGroupKickUser: kicked user [%s] not found",loginUserForKick.first.c_str());
                statusCode = status_access_denied;
                break;
            }

            statusCode = WorkGroupManagerPgSql::get_folder_info(kickedUser.user_id,folderInfo.workgroup_id,folderInfoForKicked);

            if (statusCode != status_success)
            {
                LOG_INFORMATION("Sorry, can't kick - folder does not exist or not owned by user");
                break;
            }

        }

        //sanity checks
        {
            //You can't kick yourself, use UnSubscribe"
            if (loginUserForKick.first.compare(userInfo.login)==0)
            {
                LOG_INFORMATION("You can't kick [%s] yourself, use UnSubscribe",userInfo.login.c_str());
                statusCode = status_access_denied;
                break;
            }

            //You can't kick folder owner
            if (folderInfo.creator_login.compare(loginUserForKick.first)==0)
            {
                LOG_INFORMATION("You can't kick folder owner");
                statusCode = status_access_denied;
                break;
            }
        }

        if (folderInfoForKicked.invite_accepted)
        {
            //then we'll kick him
            if (!KSD::AccessRightsHelper(folderInfo.access_mode).get_kick_user())
            {
                LOG_INFORMATION("Sorry, you do not have kick_user rights on this folder");
                statusCode = status_access_denied;
                break;
            }
            statusCode = WorkGroupManagerPgSql::unsubscribe_folder(kickedUser.user_id,folderInfo.workgroup_id);

            if (statusCode != status_success)
            {
                break;
            }

            LOG_ABSOLUTE("WorkGroupKickUser: User [%s] kicked [%s] from folder [%lli]",userInfo.login.c_str(), loginUserForKick.first.c_str(),folderInfo.workgroup_id);
            rpc_status_code statusCode_ = EventLogic::folderUnsubscribe(userId,userInfo.login,context.session_info.device_id,folderInfo.workgroup_id, loginUserForKick.second,loginUserForKick.first,folderInfo.workgroup_name,kickedUser.user_id);

            if (statusCode_ != status_success)
            {
                LOG_INFORMATION("Could not create WorkGroupUnsubscribe event");
            }

            LOG_INFORMATION("WorkGroupKickUser: [%s] kicked [%s] from folder [%lli] : [%s]",userInfo.login.c_str(),kickedUser.login.c_str(),folderInfo.workgroup_id,folderInfo.workgroup_name.c_str());

        }
        //remove all invites for user
        else if (KSD::AccessRightsHelper(folderInfo.access_mode).get_kick_user())
        {
            statusCode = WorkGroupInvitesPgSql::remove_invitations(context, kickedUser.user_id, folderInfo.workgroup_id);

            if (statusCode != status_success)
            {
                break;
            }

            statusCode = WorkGroupManagerPgSql::unsubscribe_folder(kickedUser.user_id,folderInfo.workgroup_id);

            if (statusCode != status_success)
            {
                break;
            }

            rpc_status_code statusCode_ = EventLogic::folderReject(userId,userInfo.login,context.session_info.device_id,folderInfo.workgroup_id,loginUserForKick.first,folderInfo.workgroup_name,kickedUser.user_id);

            if (statusCode_ != status_success)
            {
                LOG_INFORMATION("Could not create WorkGroupReject event");
            }

            LOG_INFORMATION("WorkGroupKickUser: [%s] destroyed all invites for [%s] from folder [%lli] : [%s]",userInfo.login.c_str(),kickedUser.login.c_str(),folderInfo.workgroup_id,folderInfo.workgroup_name.c_str());
        }
        //we'll try to remove just one invite
        else
        {
            statusCode = WorkGroupInvitesPgSql::remove_invitations(context, userId, kickedUser.user_id, folderInfo.workgroup_id);

            if (statusCode != status_success)
            {
                break;
            }

            InviteInfoList inviteinfolist;
            statusCode = WorkGroupInvitesPgSql::get_invitations(context, kickedUser.user_id, folderInfo.workgroup_id, inviteinfolist);

            if (statusCode != status_success)
            {
                break;
            }

            //if there are NO invites available, remove folder completely
            if (inviteinfolist.empty())
            {
                statusCode = WorkGroupManagerPgSql::unsubscribe_folder(kickedUser.user_id,folderInfo.workgroup_id);

                if (statusCode != status_success)
                {
                    break;
                }

                rpc_status_code statusCode_ = EventLogic::folderReject(userId,userInfo.login,context.session_info.device_id,folderInfo.workgroup_id,loginUserForKick.first,folderInfo.workgroup_name,kickedUser.user_id);

                if (statusCode_ != status_success)
                {
                    LOG_INFORMATION("Could not create WorkGroupReject event");
                }
            }

            LOG_INFORMATION("WorkGroupKickUser: [%s] destroyed own invites for [%s] from folder [%lli] : [%s]",userInfo.login.c_str(),kickedUser.login.c_str(),folderInfo.workgroup_id,folderInfo.workgroup_name.c_str());

        }

        bStatus = true;

    }
    while (false);


    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupKickUser function ended: userId [%lli]", userId);
    }
    else
    {
        LOG_INFORMATION("WorkGroupKickUser function failed: userId [%lli]", userId);
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupSetAccess(
        RequestContext& context,
        const UserInfo& userInfo,
        const WorkGroupInfo& folderInfo,
        const std::string& targetUserEmail,
        int64_t accessRights)
{
    int64_t userId = userInfo.user_id;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        KSD::AccessRightsHelper access_rights(folderInfo.access_mode);

        if (folderInfo.creator_login.compare(targetUserEmail)==0)
        {
            LOG_INFORMATION("Can't set access rights for folder owner");
            statusCode = status_access_denied;
            break;
        }

        UserInfo targetUser;
        statusCode = UserManagerPgSql::getUserInfoByLogin(targetUserEmail,targetUser);

        if (statusCode!= status_success || targetUser.user_id<=0)
        {
            LOG_INFORMATION("WorkGroupSetAccess: target user [%s] not found",targetUserEmail.c_str());
            statusCode = status_access_denied;
            break;
        }

        accessRights = accessRights & folderInfo.access_mode; // can set only rights you have

        statusCode = WorkGroupManagerPgSql::set_access_rights(targetUser.user_id,folderInfo.workgroup_id,accessRights);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while (false);


    if (bStatus)
    {
        EventLogic::folderAccessUpdate(userId,userInfo.login,context.session_info.device_id,folderInfo.workgroup_id,targetUserEmail,accessRights,folderInfo.workgroup_name);
        LOG_ABSOLUTE("WorkGroupSetAccess function ended: userId [%lli]", userInfo.user_id);
    }
    else
    {
        LOG_INFORMATION("WorkGroupSetAccess function failed: userId [%lli]", userInfo.user_id);
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupInvite(
        RequestContext& context,
        const UserInfo& inviterUserInfo,
        const WorkGroupInfo& folderInfo,
        const WorkGroupInvite& folderInvite)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {

        if (inviterUserInfo.login.compare(folderInvite.invitee_login) == 0)
        {
            LOG_INFORMATION("Beware, [%s]! You should not invite yourself!",inviterUserInfo.login.c_str());
            ADD_ERROR_MESSAGE(context, "Beware, ["+inviterUserInfo.login+"]! You should not invite yourself!");
            statusCode = status_already_exist;
            break;
        }

        if (context.service_type == KeepSolidService)
        {
            statusCode = _workgroupInviteKS(context, inviterUserInfo, folderInfo, folderInvite);
        }
        else
        {
            statusCode = _workgroupInviteSX(context, inviterUserInfo, folderInfo, folderInvite);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupInvite function ended: userId [%lli] : folder [%lli] invitee [%s]", inviterUserInfo.user_id, folderInfo.workgroup_id, folderInvite.invitee_login.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupInvite function failed:[%s] : userId [%lli] : folder [%lli] invitee [%s]", status_code_to_string(statusCode).c_str(), inviterUserInfo.user_id, folderInfo.workgroup_id, folderInvite.invitee_login.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupInviteKS(
        RequestContext& context,
        const UserInfo& inviterUserInfo,
        const WorkGroupInfo& folderInfo,
        const WorkGroupInvite& folderInvite)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if (check_email(folderInvite.invitee_login)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("Login [%s] is not valid e-mail ",folderInvite.invitee_login.c_str());
            ADD_ERROR_MESSAGE(context, "Login ["+folderInvite.invitee_login+"] is not valid e-mail");
            statusCode = status_bad_syntax;
            break;
        }

        UserInfo inviteeUserInfo;
        statusCode = UserManagerPgSql::getUserInfoByLogin(folderInvite.invitee_login,inviteeUserInfo);

        if (statusCode != status_success)
        {
            LOG_ABSOLUTE("Normal or Dummy invitee user [%s] not found", folderInvite.invitee_login.c_str());
            ADD_ERROR_MESSAGE(context, "Normal or Dummy invitee login ["+folderInvite.invitee_login+"] not found");
            break;
        }

        WorkGroupInfo inviteeFolderInfo;
        bool isShared = HelperLogic::checkIsShared(inviteeUserInfo.user_id, folderInfo.workgroup_id, inviteeFolderInfo);
        if (isShared == true && inviteeFolderInfo.access_mode != KSD::AccessRights::no_access)
        {
            statusCode = status_already_exist;
            LOG_ABSOLUTE("Invitee already has this workgroup shared");
            ADD_ERROR_MESSAGE(context, "Invitee ["+inviterUserInfo.login+"] already has this workgroup shared");
            statusCode = WorkGroupInvitesPgSql::remove_invitations(context, inviterUserInfo.user_id, folderInfo.workgroup_id);
            break;
        }

        InviteInfo inviteInfo;
        statusCode = _workgroupCreateInvite(context, inviterUserInfo, inviteeUserInfo, folderInfo, folderInvite, false, inviteInfo);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupInviteKS function ended: userId [%lli] : folder [%lli] invitee [%s]", inviterUserInfo.user_id, folderInfo.workgroup_id, folderInvite.invitee_login.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupInviteKS function failed:[%s] : userId [%lli] : folder [%lli] invitee [%s]", status_code_to_string(statusCode).c_str(), inviterUserInfo.user_id, folderInfo.workgroup_id, folderInvite.invitee_login.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupInviteSX(
        RequestContext& context,
        const UserInfo& inviterUserInfo,
        const WorkGroupInfo& folderInfo,
        const WorkGroupInvite& folderInvite)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        if (check_social_id(folderInvite.invitee_login)!=EXIT_SUCCESS)
        {
            LOG_INFORMATION("Login [%s] is not valid socialId ",folderInvite.invitee_login.c_str());
            ADD_ERROR_MESSAGE(context, "Login ["+folderInvite.invitee_login+"] is not valid socialId");
            statusCode = status_bad_syntax;
            break;
        }


        UserInfo inviteeUserInfo;
        inviteeUserInfo.login = folderInvite.invitee_login;
        statusCode = UserLogic::userInfoSX(context, inviteeUserInfo);

        InviteInfo inviteInfo;
        if (statusCode == status_success)
        {
            WorkGroupInfo inviteeFolderInfo;
            bool isShared = HelperLogic::checkIsShared(inviteeUserInfo.user_id, folderInfo.workgroup_id, inviteeFolderInfo);
            if (isShared == true && inviteeFolderInfo.access_mode != KSD::AccessRights::no_access)
            {
                statusCode = status_already_exist;
                LOG_ABSOLUTE("Invitee already has this workgroup shared");
                ADD_ERROR_MESSAGE(context, "Invitee ["+inviterUserInfo.login+"] already has this workgroup shared");
                statusCode = WorkGroupInvitesPgSql::remove_invitations(context, inviterUserInfo.user_id, folderInfo.workgroup_id);
                break;
            }

            statusCode = _workgroupCreateInvite(context, inviterUserInfo, inviteeUserInfo, folderInfo, folderInvite, false, inviteInfo);
            if (statusCode != status_success)
            {
                break;
            }
            statusCode = _workgroupAcceptInvite(context, inviteeUserInfo, inviteInfo);

        }
        else if (statusCode == status_does_not_exist)
        {
            statusCode = _workgroupCreateInvite(context, inviterUserInfo, inviteeUserInfo, folderInfo, folderInvite, true, inviteInfo);
        }
        else
        {
            LOG_ABSOLUTE("Error searching for social id [%s]", folderInvite.invitee_login.c_str());
            ADD_ERROR_MESSAGE(context, "Error searching for social id ["+folderInvite.invitee_login+"]");
            break;
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupInviteSX function ended: userId [%lli] : folder [%lli] invitee [%s]", inviterUserInfo.user_id, folderInfo.workgroup_id, folderInvite.invitee_login.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupInviteSX function failed:[%s] : userId [%lli] : folder [%lli] invitee [%s]", status_code_to_string(statusCode).c_str(), inviterUserInfo.user_id, folderInfo.workgroup_id, folderInvite.invitee_login.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupShareWG(
        RequestContext& context,
        InviteInfo& inviteInfo)
{
    rpc_status_code statusCode = status_internal_error;

    do
    {
        WorkGroupInfo inviteeFolderInfo;
        bool isShared = HelperLogic::checkIsShared(inviteInfo.invitee_id,
                inviteInfo.workgroup_id,
                inviteeFolderInfo);
        if ( isShared == false )
        {
            statusCode = WorkGroupManagerPgSql::share_folder(inviteInfo.inviter_id,
                    inviteInfo.workgroup_id, inviteInfo.invitee_id, inviteInfo.invitee_login);
            LOG_ABSOLUTE("Shared folder [%lli] for user %lli", inviteInfo.workgroup_id, inviteInfo.invitee_id);

            if (statusCode == status_already_exist)
            {
                LOG_ABSOLUTE("Double inviting user to the same folder, folder is already shared");
                break;
            }

            if (statusCode != status_success)
            {
                LOG_ABSOLUTE("Could not pre-share folder");
                break;
            }
        }
        else    //if already shared
        {
            LOG_INFORMATION("Invitee already has this workgroup shared");
            statusCode = status_already_exist;
            break;
        }

        statusCode = EventLogic::folderInvite(inviteInfo.inviter_id,inviteInfo.inviter_login,
                context.session_info.device_id,inviteInfo.workgroup_id,inviteInfo.workgroup_name,
                inviteInfo.invite_id,inviteInfo.access_mode,inviteInfo.invitee_login,inviteInfo.invitee_id);
    }
    while(false);

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupCreateInvite(
        RequestContext& context,
        const UserInfo& inviterUserInfo,
        const UserInfo& inviteeUserInfo,
        const WorkGroupInfo& folderInfo,
        const WorkGroupInvite& folderInvite,
        bool is_anonymous,
        InviteInfo& inviteInfo)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        LOG_INFORMATION("SOCIAL DATA [%s][%s][%s]", folderInvite.social_id.c_str(), folderInvite.social_token.c_str(), folderInvite.social_type.c_str());

        inviteInfo.inviter_login = inviterUserInfo.login;
        inviteInfo.set_inviter_name(inviterUserInfo.first_name, inviterUserInfo.last_name);
        inviteInfo.inviter_id = inviterUserInfo.user_id;

        inviteInfo.invitee_login = inviteeUserInfo.login;   //empty if anonymous == true
        inviteInfo.set_invitee_name(inviteeUserInfo.first_name, inviteeUserInfo.last_name); //empty if anonymous == true
        inviteInfo.invitee_id = inviteeUserInfo.user_id;

        inviteInfo.workgroup_id = folderInfo.workgroup_id;
        inviteInfo.workgroup_name = folderInfo.workgroup_name;

        inviteInfo.key = folderInvite.key;
        inviteInfo.is_anonymous = is_anonymous;
        inviteInfo.access_mode = folderInvite.access_mode & folderInfo.access_mode; //user can only share flags he already has

        statusCode = WorkGroupInvitesPgSql::create_invitation(context,inviteInfo);

        if (statusCode == status_already_exist)
        {
            LOG_ABSOLUTE("Double inviting user to the same folder, invite already exist");
            ADD_ERROR_MESSAGE(context, "Double inviting user ["+folderInvite.invitee_login+"] to the same folder, invite already exist");
            break;
        }

        if (statusCode != status_success)
        {
            LOG_ABSOLUTE("Could not create invite");
            ADD_ERROR_MESSAGE(context, "Error creating invite to ["+folderInvite.invitee_login+"]");
            break;
        }

        if (inviteInfo.is_anonymous == false)
        {
            statusCode = _workgroupShareWG(context, inviteInfo);
        }

        if (context.service_type == KeepSolidService)
        {
            MailTemplate::invite_to_wg(inviteInfo);
        }
        else
        {
            KeyValue inner;
            inner["owner"] = inviteInfo.inviter_login;
            inner["name"] = folderInfo.description;
            inner["workgroup_id"] = boost::lexical_cast<std::string>(folderInfo.workgroup_id);
            inner["url"] = "https://my.simplexsolutionsinc.com/invite/checklist/" + inviteInfo.invite_id;

            SimplexNotification notification;

            if (inviteInfo.is_anonymous == true)
            {
                notification.set_notification_name("invite_service");
                notification.set_social_type(folderInvite.social_type);
                notification.set_social_token(folderInvite.social_token);
                notification.set_social_recipient(folderInvite.social_id);
            }
            else
            {
                notification.set_notification_name("invite_wg");
            }
            notification.set_recipient_login(inviteeUserInfo.login);


            notification.set_params(inner);
            SimplexNotificationSender::send_non_block(context, notification);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }
    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupCreateInvite function ended: "
                "folder [%lli] [%lli]->[%lli] [%s]->[%s]",
                folderInfo.workgroup_id, inviteInfo.inviter_id, inviteInfo.invitee_id,
                inviteInfo.inviter_login.c_str(), inviteInfo.invitee_login.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupCreateInvite function failed:"
                "[%s]: "
                "folder [%lli] [%lli]->[%lli] [%s]->[%s]",
                status_code_to_string(statusCode).c_str(),
                folderInfo.workgroup_id, inviteInfo.inviter_id, inviteInfo.invitee_id,
                inviteInfo.inviter_login.c_str(), inviteInfo.invitee_login.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupAcceptInvite(
        RequestContext& context,
        const UserInfo& userInfo,
        const InviteInfo& inviteInfo)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = WorkGroupManagerPgSql::subscribe_folder(inviteInfo.invitee_id,
                inviteInfo.workgroup_id, inviteInfo.access_mode, inviteInfo.key);

        if (statusCode != status_success )
        {
            LOG_ABSOLUTE("Could not accept invite");
            break;
        }

        rpc_status_code statusCode_ = EventLogic::folderSubscribe(inviteInfo.invitee_id,
                userInfo.login, context.session_info.device_id,
                inviteInfo.workgroup_id, inviteInfo.workgroup_name,
                inviteInfo.access_mode);
        if (statusCode_ != status_success)
        {
            LOG_INFORMATION("Could not create WorkGroupSubscribe event");
            break;
        }

        if (inviteInfo.is_anonymous == true)
        {
            WorkGroupInvitesPgSql::remove_invitation(context, inviteInfo.invite_id);
        }
        else
        {
            WorkGroupInvitesPgSql::remove_invitations(context, inviteInfo.invitee_id, inviteInfo.workgroup_id);
        }

        if (context.service_type == KeepSolidService)
        {
            MailTemplate::invite_subscribe(inviteInfo, true);
        }

        bStatus = true;
        //Simplex
        /*TODO*/
    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupAcceptInvite function ended: "
                "folder [%lli] [%lli]->[%lli] [%s]->[%s]",
                inviteInfo.workgroup_id, inviteInfo.inviter_id, inviteInfo.invitee_id,
                inviteInfo.inviter_login.c_str(), inviteInfo.invitee_login.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupAcceptInvite function failed: "
                "[%s]: "
                "folder [%lli] [%lli]->[%lli] [%s]->[%s]",
                status_code_to_string(statusCode).c_str(),
                inviteInfo.workgroup_id, inviteInfo.inviter_id, inviteInfo.invitee_id,
                inviteInfo.inviter_login.c_str(), inviteInfo.invitee_login.c_str());
    }

    return statusCode;
}

rpc_status_code WorkGroupLogic::_workgroupRejectInvite(
        RequestContext& context,
        const UserInfo& userInfo,
        const InviteInfo& inviteInfo)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = WorkGroupManagerPgSql::unsubscribe_folder(context.session_info.user_id,
                inviteInfo.workgroup_id);

        if (statusCode != status_success )
        {
            LOG_ABSOLUTE("Could not reject invite");
            break;
        }

        rpc_status_code statusCode_ = EventLogic::folderReject(context.session_info.user_id,
                userInfo.login, context.session_info.device_id,
                inviteInfo.workgroup_id, userInfo.login,
                inviteInfo.workgroup_name, userInfo.user_id);
        if (statusCode_ != status_success)
        {
            LOG_INFORMATION("Could not create WorkGroupReject event");
            break;
        }

        MailTemplate::invite_subscribe(inviteInfo, false);

        bStatus = true;
        //Simplex
        /*TODO*/
    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("WorkGroupRejectInvite function ended: "
                "folder [%lli] [%lli]->[%lli] [%s]->[%s]",
                inviteInfo.workgroup_id, inviteInfo.inviter_id, inviteInfo.invitee_id,
                inviteInfo.inviter_login.c_str(), inviteInfo.invitee_login.c_str());
    }
    else
    {
        LOG_INFORMATION("WorkGroupRejectInvite function failed: "
                "[%s]: "
                "folder [%lli] [%lli]->[%lli] [%s]->[%s]",
                status_code_to_string(statusCode).c_str(),
                inviteInfo.workgroup_id, inviteInfo.inviter_id, inviteInfo.invitee_id,
                inviteInfo.inviter_login.c_str(), inviteInfo.invitee_login.c_str());
    }

    return statusCode;
}
