/*
 * logic.cpp
 *
 *  Created on: 31 бер. 2011
 *      Author: fireball
 */

#include "logic/HelperLogic.h"

#include <sutil/logging.h>
#include "util/DataVerifier.h"

#include "db/sessions/SessionManagerRedis.h"
#include "db/users/UserManagerPgSql.h"
#include "db/folders/FolderManagerPgSql.h"

KSD::AccessRightsHelper HelperLogic::checkPermissions(int64_t userId, int64_t folderId, WorkGroupInfo& folderInfo)
{
    rpc_status_code statusCode = status_internal_error;

    statusCode = WorkGroupManagerPgSql::get_folder_info(userId,folderId,folderInfo);

    if (statusCode != status_success)
    {
        folderInfo.access_mode = 0;
        LOG_INFORMATION("Permissions check failed: userId [%lli] : folderId [%lli]", userId, folderId);
    }

    KSD::AccessRightsHelper rights(folderInfo.access_mode);
    return rights;
}

bool HelperLogic::checkIsShared(int64_t userId, int64_t folderId, WorkGroupInfo& folderInfo)
{
    rpc_status_code statusCode = status_internal_error;
    bool folderIsShared = false;

    statusCode = WorkGroupManagerPgSql::get_folder_info(userId,folderId,folderInfo);

    if (statusCode == status_success)
    {
        folderIsShared = true;
    }

    return folderIsShared;
}

rpc_status_code HelperLogic::checkSession(RequestContext& context, int64_t& userId, std::string& deviceId)
{
    rpc_status_code statusCode = HelperLogic::checkSession(context);
    userId      = context.session_info.user_id;
    deviceId    = context.session_info.device_id;

    return statusCode;
}

rpc_status_code HelperLogic::checkSession(RequestContext& context)
{
    SessionInfo session;
    rpc_status_code statusCode = status_internal_error;

    statusCode = SessionManagerRedis::get_session(context.session_id, context.ip_address, session);

    if (statusCode == status_success)
    {
        UserInfo ui;
        UserManagerPgSql::getUserInfoByLogin(session.username, ui);
        session.user_id = ui.user_id;
        if (ui.user_id)
        {
            context.user_info = ui;
        }
    }

    if ( statusCode == status_success )
    {
        context.session_info = session;
        if (session.user_id <= 0)
        {
            statusCode = status_unauthorized;
        }

        if (context.session_info.is_old == true)
        {
            SessionManagerRedis::update_session(session);
        }
    }
    else
    {
        LOG_INFORMATION("Session [%s] was not found", context.session_id.c_str());
    }

    return statusCode;
}
