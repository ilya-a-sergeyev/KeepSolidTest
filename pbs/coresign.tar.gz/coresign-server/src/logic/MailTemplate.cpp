/*
 * MailTemplate.cpp
 *
 *  Created on: Dec 20, 2012
 *      Author: fireballdark
 */

#include "MailTemplate.h"
#include <sutil/MailerHelper.h>

void MailTemplate::invite_to_wg(const InviteInfo& inviteInfo)
{
    MailerHelper mail;
    std::string subject = "New invite for you! \"";
    subject+= inviteInfo.workgroup_name;
    subject+= "\" was shared.";

    std::string message = "Hello, ";
    message+= inviteInfo.invitee_name;
    message+= "\n\n";
    message+= "You were invited to use folder \"";
    message+= inviteInfo.workgroup_name;
    message+= "\" by  ";
    message+= inviteInfo.inviter_name;
    message+= " ( ";
    message+= inviteInfo.inviter_login;
    message+= " ) \n";

    message+= "Your invitation id is " + inviteInfo.invite_id;
    message+= "\n ---\n Sincerely yours,\n\t\t File Storage service";

    mail.get()->set_subject(subject).set_recepient(inviteInfo.invitee_login).set_text(message);
    mail.send_non_block();
}

void MailTemplate::invite_subscribe(const InviteInfo& inviteInfo, bool acceptInvite)
{
    MailerHelper mail;
    std::string subject = "Your invite for ";
    subject+= inviteInfo.workgroup_name;
    subject+= " was ";
    subject+= acceptInvite ? "accepted " : "rejected ";

    std::string message = "Hello, ";
    message+= inviteInfo.inviter_name;
    message+= "\n\n";
    message+= "Your invite for folder ";
    message+= inviteInfo.workgroup_name;
    message+= " was successfully ";
    message+= acceptInvite ? "accepted " : "rejected ";
    message+= "by ";
    message+= inviteInfo.invitee_login;
    message+= "\n ---\n Sincerely yours,\n\t\t File Storage service";

    mail.get()->set_subject(subject).set_recepient(inviteInfo.inviter_login).set_text(message);
    mail.send_non_block();
}

void MailTemplate::invite_new_user(const std::string& inviter_fname, const std::string& inviter_lname, const std::string& inviter_login, const std::string& invitee_login, const std::string& invitee_pass)
{
    MailerHelper mail;
    std::string subject = "You were invited to KeepSolid!";
    std::string inviter_name;
    if (!inviter_fname.empty() && !inviter_lname.empty())
    {
        inviter_name=" ";
    }
    inviter_name = inviter_fname + inviter_name + inviter_lname;
    if (!inviter_name.empty())
    {
        subject+= " by ";
        subject+= inviter_name;
    }


    std::string message = "Hello, ";
    message+= "Dear User!";
    message+= "\n\n";
    message+= "You were invited to use KeepSolid! service by ";
    message+= inviter_name;
    message+= " ( ";
    message+= inviter_login;
    message+= " ) \n";
    message+= "Your login is: ";
    message+= invitee_login;
    message+= "\n";
    message+= "Your password is: " ;
    message+= invitee_login;
    message+= "\n";
    message+= "\n";
    message+= "Please change your password at first login \n\n";
    message+= "\n ---\n Sincerely yours,\n\t\t File Storage service";

    mail.get()->set_subject(subject).set_recepient(invitee_login).set_text(message);
    mail.send_non_block();
}
