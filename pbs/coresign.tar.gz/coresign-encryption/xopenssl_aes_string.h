/*
 * xopenssl_aes_string.h
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>

std::string aes_encrypt(const std::string& data, const std::string& password, std::string& iv);
std::string aes_decrypt(const std::string& data, const std::string& password, const std::string& iv);
std::string aes_easy_encrypt( const std::string& data, const std::string& password);
std::string aes_easy_decrypt( const std::string& data, const std::string& password);
