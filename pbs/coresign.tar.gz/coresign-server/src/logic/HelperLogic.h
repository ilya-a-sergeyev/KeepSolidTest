/*
 * logic.h
 *
 *  Created on: 18 бер. 2011
 *      Author: fireball
 */

#pragma once

#include "types/status_codes.h"
#include "types/file_folder_info.h"
#include "types/access_rights.h"
#include "types/request_context.h"

/**
 * Class that contains main logic of server:
 * determines which actions should be taken when performing RPC call
 */
class	HelperLogic
{
public:
//Helper functions
    static rpc_status_code          fileDeleteRecursiveSafe(int64_t userId,  const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t revision, bool removeNow, const KSD::AccessRightsHelper& access_rights, bool isFirst = false);
    static KSD::AccessRightsHelper  checkPermissions    (int64_t userId, int64_t folderId, WorkGroupInfo& folderInfo);
    static bool                     checkIsShared       (int64_t userId, int64_t folderId, WorkGroupInfo& folderInfo);
    static rpc_status_code          checkSession        (RequestContext& context, int64_t& userId, std::string& deviceId);
    static rpc_status_code          checkSession        (RequestContext& context);
};

