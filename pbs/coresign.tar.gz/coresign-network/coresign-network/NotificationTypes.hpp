﻿#pragma once

#include <stdint.h>
#include <vector>
#include <utility>
#include <functional>

enum OperationStatus
{
    OPSTATUS_UNDEFINED       = -1,
    OPSTATUS_OK              = 0,
    OPSTATUS_ABORTED         = 1,
    OPSTATUS_ERROR           = 2,
    OPSTATUS_TIMEDOUT        = 3,
    OPSTATUS_SESSION_EXPIRED = 4    //rpc session is not valid
};

typedef std::pair<std::string, std::string> AddressPortPair;
typedef std::vector<AddressPortPair> AddressesList;

typedef std::function<void (const std::string&)>     function_MessageCallback;
typedef std::function<void (OperationStatus, bool)>  function_ConnectionCallback;
