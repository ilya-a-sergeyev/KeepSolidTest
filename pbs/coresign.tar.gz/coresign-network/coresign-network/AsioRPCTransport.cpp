#include "AsioRPCTransport.h"

#include <thread>
#include <functional>
#include <util/logging.h>
#include <types/transport_flags.h>

#ifdef DEBUG_FUNCTION
  #undef DEBUG_FUNCTION
#endif
#define DEBUG_FUNCTION

class ContextSingleton
{
public:
    ContextSingleton()
        : _io_service(2),
          _ssl_context(_io_service,
                       asio::ssl::context::tlsv1_client)
    {
        run_service();
    }

    asio::io_service&        GetIOService() { return _io_service; }
    asio::ssl::context&      GetSSLContext(){ return _ssl_context; }

    void run_service()
    {
        std::lock_guard<std::mutex> lock(_mutex);
        if (!_is_service_running)
        {
            _is_service_running = true;
            std::thread t1(std::bind(&ContextSingleton::run_service_function, this));
        }
    }

    void run_service_function()
    {
        asio::error_code err;
        asio::io_service::work work(_io_service);
        _io_service.run(err);
        _io_service.reset();
        _is_service_running = false;

        LOG_INFORMATION("IO Service stopped with err [%s]",err.message().c_str());
    }

    void stop_service()
    {
        _io_service.stop();
    }

private:
    asio::io_service     _io_service;
    asio::ssl::context   _ssl_context;
    std::mutex                  _mutex;
    bool                        _is_service_running;
};

ContextSingleton& GetContextSinglton()
{
    static ContextSingleton ctxSingle;
    return ctxSingle;
}


#define REQUEST_TIMEOUT     30000
#define MAX_DATA_IN         16000000
#define MAX_DATA_OUT        16000000

AsioRPCTransport::AsioRPCTransport(const std::string &address, const std::string &port):
    _state(Opened),
    _socket(GetContextSinglton().GetIOService(), GetContextSinglton().GetSSLContext()),
    _timer(GetContextSinglton().GetIOService()),
    _strand(GetContextSinglton().GetIOService()),
    _resolver(GetContextSinglton().GetIOService()),
    _address(address),
    _port(port),
    _data_in_size_planned_current(-1),
    _data_in_size_planned(-1),
    _data_in_size_real_current(-1),
    _data_in_size_real(-1),
    _data_out_size(-1),
    _data_keepalive(0),
    _timeout_ms(REQUEST_TIMEOUT),
    _is_ok(false),
    _operation_status(OPSTATUS_UNDEFINED)
{
    //LOG_INFORMATION("READY TO LAUNCH! State is [%lli]", _state);
}

AsioRPCTransport::~AsioRPCTransport()
{
    asio::error_code ignored_ec;
    _resolver.cancel();
    _timer.cancel();
    _socket.lowest_layer().close(ignored_ec);
    //LOG_INFORMATION("ENEMY TRANSPORT DESTROYED! State is [%lli]", _state);
}


void AsioRPCTransport::work()
{
    switch (_state)
    {
        case Opened:
        {
            //NOOP
            break;
        }
        case Resolve:
        {
            async_timeout_start();
            async_resolve();
            break;
        }
        case Connect:
        {
            async_timeout_start();
            async_connect();
            break;
        }
        case Handshake:
        {
            async_timeout_start();
            async_handshake();
            break;
        }
        case Write_Data_Size:
        {
            async_timeout_stop();
            async_write_size();
            break;
        }
        case Write_Data:
        {
            async_timeout_stop();
            async_write_data();
            break;
        }
        case Write_KeepAlive:
        {
            async_timeout_stop();
            async_write_keepalive();
            break;
        }
        case Read_Data_Size:
        {
            async_timeout_start();
            async_read_size();
            break;
        }
        case Read_Data:
        {
            async_timeout_start();
            async_read_data();
            break;
        }
        case Read_KeepAlive:
        {
            async_timeout_start();
            async_read_keepalive();
            break;
        }
        case Waiting_Request:
        {
            async_timeout_stop();
            //NOOP
            break;
        }
        case Shutdown:
        {
            async_timeout_start();
            //async_shutdown();
            break;
        }
        case Error:
        case Close_Force:
        {
            async_timeout_stop();
            close();
            break;
        }
        case Closed:
        {
            async_timeout_stop();
            //NOOP
            break;
        }
    }
}

void AsioRPCTransport::execute_command(ConnectionState new_state)
{
    _state = new_state;
    work();

    switch (new_state)
    {
        case Waiting_Request:
        {
            operation_complete(OPSTATUS_OK);
            break;
        }
        case Error:
        {
            operation_complete(OPSTATUS_ERROR);
            break;
        }
        case Close_Force:
        {
            operation_complete(OPSTATUS_TIMEDOUT);
            break;
        }
        case Closed:
        {
            operation_complete(OPSTATUS_ABORTED);
            break;
        }
        default:
        {
            //NOOP;
        }
    }
}

void AsioRPCTransport::wait_for_operation(std::unique_lock<std::mutex>& lock)
{
    _operation_status = OPSTATUS_UNDEFINED;
    while(_operation_status == OPSTATUS_UNDEFINED)
    {
        _condition_var.wait(lock);
    }
}

OperationStatus AsioRPCTransport::start()
{
    do
    {
        std::unique_lock<std::mutex> lock(_mutex);

        if (_state != Opened)
        {
            _operation_status = OPSTATUS_ERROR;
            break;
        }

        execute_command(Resolve);

        wait_for_operation(lock);

        if (_operation_status != OPSTATUS_OK)
        {
            break;
        }
    }
    while(false);

    return _operation_status;
}

OperationStatus AsioRPCTransport::call(const std::string& data_out, std::string& data_in)
{
    do
    {
        std::unique_lock<std::mutex> lock(_mutex);

        if (_state != Waiting_Request)
        {
            LOG_ERROR("Bad Transport state [%i] for call", _state);
            _operation_status = OPSTATUS_ERROR;
            break;
        }

        if (data_out.size() <= 0 || data_out.size() >= MAX_DATA_OUT)
        {
            LOG_ERROR("Bad data size for transfer [%li]", data_out.size());
            _operation_status = OPSTATUS_ERROR;
            break;
        }

        TransportFlagsHelper flags;
        flags.set_size(data_out.size());
        //flags.set_use_ksv2_format(true);
        _data_out       = data_out;
        _data_out_size  = flags.get_transport_data();

        execute_command(Write_KeepAlive);

        wait_for_operation(lock);

        if (_operation_status != OPSTATUS_OK)
        {
            break;
        }

        data_in = _data_in;
    }
    while(false);

    return _operation_status;
}

bool AsioRPCTransport::is_connected()
{
    return _socket.lowest_layer().is_open() ;
}

void AsioRPCTransport::close()
{
    asio::error_code ignored_ec;

    _resolver.cancel();
    _socket.lowest_layer().shutdown(asio::ip::tcp::socket::shutdown_both, ignored_ec);
    _socket.lowest_layer().cancel(ignored_ec);

    LOG_INFORMATION("AsioRPCTransport: Disconnected OK");
}

void AsioRPCTransport::async_timeout_start()
{
    _timer.expires_from_now(boost::posix_time::milliseconds(_timeout_ms));
    _timer.async_wait(
                _strand.wrap(
                    std::bind(
                      &AsioRPCTransport::handle_timeout,
                      shared_from_this(),
                       asio::placeholders::error
                       )
                    )
                );
}

void AsioRPCTransport::async_timeout_stop()
{
    _timer.cancel();
}

void AsioRPCTransport::handle_timeout(const asio::error_code& error)
{
    if (error == asio::error::operation_aborted)
    {
        return;
    }

    if (error)
    {
        LOG_ERROR("AsioRPCTransport: Timeout handled with error [%i] : [%s]",error.value(),error.message().c_str());
    }
    else
    {
        LOG_INFORMATION("AsioRPCTransport: Connection timed-out!");
    }
    execute_command(Close_Force);
}

void AsioRPCTransport::async_resolve()
{
    asio::ip::tcp::resolver::query query(_address,_port);
    _resolver.async_resolve(query,
                           _strand.wrap(
                               std::bind(
                                   &AsioRPCTransport::handle_resolve,
                                   shared_from_this(),
                                   asio::placeholders::error,
                                   asio::placeholders::iterator)));
}

void AsioRPCTransport::handle_resolve(const asio::error_code& error, asio::ip::tcp::resolver::iterator iterator)
{
    if (error == asio::error::operation_aborted)
    {
        return;
    }

    if (error)
    {
        LOG_ERROR("AsioRPCTransport: could not resolve [%s][%s] because of [%s]", _address.c_str(), _port.c_str(), error.message().c_str());
        execute_command(Error);
    }
    else
    {
        asio::ip::tcp::resolver::iterator end;
        asio::ip::tcp::resolver::iterator it = iterator;

        for (;it != end; it++)
        {
            asio::ip::tcp::endpoint endpoint = *it;
            LOG_INFORMATION("FOUND OK to [%s:%i]", endpoint.address().to_string().c_str(), endpoint.port());
        }

        if (iterator == end)
        {
            LOG_ERROR("AsioRPCTransport: no endpoints found");
            execute_command(Error);
        }
        else
        {
            _endpoints = iterator;
            execute_command(Connect);
        }
    }
}

void AsioRPCTransport::async_connect()
{
    asio::ip::tcp::resolver::iterator end;
    asio::async_connect(_socket.lowest_layer(),
                               _endpoints,
                               end,
                               _strand.wrap(
                                   std::bind(
                                       &AsioRPCTransport::handle_connect,
                                       shared_from_this(),
                                       asio::placeholders::error,
                                       asio::placeholders::iterator)));

}

void AsioRPCTransport::handle_connect(const asio::error_code& error, asio::ip::tcp::resolver::iterator iterator)
{
    if (error == asio::error::operation_aborted)
    {
        return;
    }

    if (error)
    {
        LOG_ERROR("AsioRPCTransport: could not connect [%s][%s] because of [%s]", _address.c_str(), _port.c_str(), error.message().c_str());
        execute_command(Error);
    }
    else
    {
        asio::ip::tcp::resolver::iterator end;
        if (iterator != end)
        {
            asio::ip::tcp::endpoint endpoint = *iterator;
            LOG_INFORMATION("Connected OK to [%s:%i]", endpoint.address().to_string().c_str(), endpoint.port());
        }
        asio::socket_base::keep_alive opt1(true);
        _socket.lowest_layer().set_option(opt1);
        asio::socket_base::linger opt2(true, 10);
        _socket.lowest_layer().set_option(opt2);

        execute_command(Handshake);
    }
}

void AsioRPCTransport::async_handshake()
{
#ifndef SSL_DISABLED
        _socket.async_handshake(asio::ssl::stream_base::client,
                                _strand.wrap(
                                    std::bind(
                                        &AsioRPCTransport::handle_handshake,
                                        shared_from_this(),
                                        asio::placeholders::error)));
#else
        handle_handshake(asio::error_code());
#endif
}

void AsioRPCTransport::handle_handshake(const asio::error_code& error)
{
    if (error == asio::error::operation_aborted)
    {
        return;
    }

    if (error)
    {
        LOG_ERROR("AsioRPCTransport: could not handshake [%s][%s] because of [%s]", _address.c_str(), _port.c_str(), error.message().c_str());
        execute_command(Error);
    }
    else
    {
        execute_command(Waiting_Request);
    }
}


void AsioRPCTransport::async_write_size()
{
    DEBUG_FUNCTION;

    //LOG_INFORMATION("WRITING [0][8][%lli]", _data_out_size);
    asio::async_write(_socket,
                             asio::buffer(&_data_out_size, sizeof(_data_out_size)),
                             _strand.wrap(
                                std::bind(&AsioRPCTransport::handle_write,
                                             shared_from_this(),
                                             asio::placeholders::error,
                                             0)
                                 )
                             );
}

void AsioRPCTransport::async_write_data()
{
    DEBUG_FUNCTION;

    //LOG_INFORMATION("WRITING [1][%lli][%lli]", _data_out.size(), _data_out_size);
    asio::async_write(_socket,
                             asio::buffer(_data_out.c_str(), _data_out.size()),
                             _strand.wrap(
                                std::bind(&AsioRPCTransport::handle_write,
                                             shared_from_this(),
                                             asio::placeholders::error,
                                             1)
                                 )
                             );
}

void AsioRPCTransport::async_write_keepalive()
{
    DEBUG_FUNCTION;

    //LOG_INFORMATION("WRITING [2][8][%lli]", _data_keepalive);
    asio::async_write(_socket,
                             asio::buffer(&_data_keepalive, sizeof(_data_keepalive)),
                             _strand.wrap(
                                std::bind(&AsioRPCTransport::handle_write,
                                             shared_from_this(),
                                             asio::placeholders::error,
                                             2)
                                 )
                             );
}

void AsioRPCTransport::handle_write(const asio::error_code& error, int type)
{
    DEBUG_FUNCTION;
    //LOG_INFORMATION("WROTE [%lli]", type);

    if (error == asio::error::operation_aborted)
    {
        return;
    }

    if (error.value() == asio::errc::success)
    {
        if (type == 0)  //we are handling write_size
        {
            execute_command(Write_Data);
        }
        else if (type == 1) // we are handling write_data
        {
            execute_command(Read_KeepAlive);
        }
        else if (type == 2) // we are handling write_keepalive
        {
            execute_command(Write_Data_Size);
        }
    }
    else if (error.value() == asio::errc::interrupted
             || error.value() == asio::errc::operation_canceled
             || error == asio::error::operation_aborted)
    {
        execute_command(Close_Force);
        LOG_INFORMATION("AsioRPCTransport: operation canceled type [%i] [%s]", type, error.message().c_str());
    }
    else
    {
        execute_command(Error);
        LOG_ERROR("AsioRPCTransport: Problem writing data type [%i] [%s]", type, error.message().c_str());
    }
}

void AsioRPCTransport::async_read_size()
{
    DEBUG_FUNCTION;

    //LOG_INFORMATION("READING [0][8]");
    asio::async_read(_socket, asio::buffer(&_data_in_size_planned,sizeof(_data_in_size_planned)),
                            _strand.wrap(
                                std::bind(&AsioRPCTransport::handle_read,
                                            shared_from_this(),
                                            asio::placeholders::error,
                                            asio::placeholders::bytes_transferred,
                                            0)
                                )
                            );
}

void AsioRPCTransport::async_read_data()
{
    DEBUG_FUNCTION;


    //LOG_INFORMATION("READING [1][%lli]", _data_in_size_planned_current);
    if (_data_in_vector.capacity() < _data_in_size_planned_current)
    {
        _data_in_vector.resize((_data_in_size_planned_current/64+2)*64);
    }
    asio::async_read(_socket, asio::buffer(_data_in_vector),
                            asio::transfer_exactly(_data_in_size_planned_current),
                            _strand.wrap(
                                std::bind(&AsioRPCTransport::handle_read,
                                            shared_from_this(),
                                            asio::placeholders::error,
                                            asio::placeholders::bytes_transferred,
                                            1)
                                )
                            );
}

void AsioRPCTransport::async_read_keepalive()
{
    DEBUG_FUNCTION;

    //LOG_INFORMATION("READING [2][8]");
    asio::async_read(_socket, asio::buffer(&_data_keepalive,sizeof(_data_keepalive)),
                            _strand.wrap(
                                std::bind(&AsioRPCTransport::handle_read,
                                            shared_from_this(),
                                            asio::placeholders::error,
                                            asio::placeholders::bytes_transferred,
                                            2)
                                )
                            );
}

std::size_t AsioRPCTransport::handle_read(const asio::error_code& error, std::size_t bytes_transferred, int type)
{
    DEBUG_FUNCTION;

    if (error == asio::error::operation_aborted)
    {
        return bytes_transferred;
    }

    //LOG_INFORMATION("READ [%lli][%lli]", type, bytes_transferred);
    if (error.value() == asio::errc::success)
    {
        if (type == 0)  //we are handling read_size
        {
            TransportFlagsHelper flags;
            flags.init_with_transport_data(_data_in_size_planned);
            _data_in_size_planned = flags.get_size();
            if (_data_in_size_planned > 0 && _data_in_size_planned < MAX_DATA_IN)
            {
                _data_in_size_planned_current = _data_in_size_planned;
                _data_in_size_real = 0;
                _data_in.clear();
                async_read_data();
            }
            else
            {
                LOG_ERROR("AsioRPCTransport: Problem reading data size [%s] or it is invalid [%lli]", error.message().c_str(), _data_in_size_planned);
                execute_command(Error);
            }
            //LOG_INFORMATION("READSI [%lli]", _data_in_size_planned);
        }
        else if (type == 1) // we are handling read_data
        {
            _data_in_size_real_current = bytes_transferred;

            if (_data_in_size_real_current > 0)
            {
                _data_in.append(_data_in_vector.data(), _data_in_size_real_current);
                _data_in_size_real+=_data_in_size_real_current;
                _data_in_size_planned_current=_data_in_size_planned - _data_in_size_real;
            }

            if (_data_in_size_planned_current <=0 || _data_in_size_planned_current > MAX_DATA_IN)
            {
                execute_command(Waiting_Request);
            }
            else
            {
                execute_command(Read_Data);
            }
        }
        else if (type == 2)  //we are handling read_keepalive
        {
            execute_command(Read_Data_Size);
            //LOG_INFORMATION("READKA [%lli]", _data_keepalive);
        }
    }
    else if (error.value() == asio::errc::interrupted
             || error.value() == asio::errc::operation_canceled
             || error == asio::error::operation_aborted)
    {
        LOG_INFORMATION("AsioRPCTransport: operation canceled type [%i] [%s]", type, error.message().c_str());
        execute_command(Close_Force);
    }
    else
    {
        LOG_ERROR("AsioRPCTransport: Problem reading type [%i] [%s]", type, error.message().c_str());
        execute_command(Error);
    }

    return bytes_transferred;
}

void AsioRPCTransport::operation_complete(OperationStatus status)
{
    DEBUG_FUNCTION;

    {
        std::lock_guard<std::mutex> lock(_mutex);
        _operation_status=status;
    }
    _condition_var.notify_one();
}



