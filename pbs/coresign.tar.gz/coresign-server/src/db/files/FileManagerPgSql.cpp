/*
 * FileManagerPgSql.cpp
 *
 *  Created on: 29 квіт. 2011
 *      Author: fireball
 */

#include "FileManagerPgSql.h"
#include <sutil/logging.h>
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <cstdlib>
#include "db/PgSqlHelper.h"


rpc_status_code FileManagerPgSql::list_files(int64_t user_id, bool showDeleted, int64_t workgroup_id, FilesInfoList& filesInfo, int64_t& lastEventId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFilesInfo"))
            {
                pg_connection->prepare  ("getFilesInfo",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id, f.workgroup_id, f.file_name, "
                                         "EXTRACT(EPOCH FROM f.creation_date) AS creation_dateUnix, f.creation_date, f.size, f.hash, "
                                         "f.revision, f.is_deleted, f.is_approved, EXTRACT(EPOCH FROM f.deletion_date) AS deletion_dateUnix, "
                                         "f.deletion_date, f.parent_id, f.is_directory FROM Files AS f INNER JOIN "
                                         "(SELECT file_id, MAX(revision) AS rev FROM Files WHERE workgroup_id=$1 AND is_deleted=$2 "
                                         "AND is_approved=true GROUP BY file_id) AS ff ON (f.file_id = ff.file_id AND f.revision=ff.rev);");
            }
            if (pgSqlHelper().register_prep_statement("getLastEventIdforFolder"))
            {
                pg_connection->prepare  ("getLastEventIdforFolder",
                                         "SELECT event_id FROM Events WHERE workgroup_id=$1 ORDER BY event_id DESC LIMIT 1;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFilesInfo");

            pqxx::result query_result_event_id = pg_transaction.prepared("getLastEventIdforFolder")(workgroup_id).exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["event_id"].to(lastEventId);
            }

            pqxx::result query_result = pg_transaction.prepared("getFilesInfo")(workgroup_id)(showDeleted).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files for user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::list_all_files(int64_t user_id, int64_t workgroup_id, FilesInfoList& filesInfo, int64_t& lastEventId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllFilesInfo"))
            {
                pg_connection->prepare  ("getAllFilesInfo",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id, f.workgroup_id, f.file_name, "
                                         "EXTRACT(EPOCH FROM f.creation_date) AS creation_dateUnix, f.creation_date, f.size, f.hash, "
                                         "f.revision, f.is_deleted, f.is_approved, EXTRACT(EPOCH FROM f.deletion_date) AS deletion_dateUnix, "
                                         "f.deletion_date, f.parent_id, f.is_directory FROM Files AS f "
                                         "INNER JOIN (SELECT file_id, MAX(revision) AS rev FROM Files WHERE workgroup_id=$1 "
                                         "AND is_approved=true GROUP BY file_id) AS ff ON (f.file_id = ff.file_id AND f.revision=ff.rev);");
            }
            if (pgSqlHelper().register_prep_statement("getLastEventIdforFolder"))
            {
                pg_connection->prepare  ("getLastEventIdforFolder",
                                         "SELECT event_id FROM Events WHERE workgroup_id=$1 ORDER BY event_id DESC LIMIT 1;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFilesInfo");

            pqxx::result query_result_event_id = pg_transaction.prepared("getLastEventIdforFolder")(workgroup_id).exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["event_id"].to(lastEventId);
            }

            pqxx::result query_result = pg_transaction.prepared("getAllFilesInfo")(workgroup_id).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files for user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::list_files_parent(int64_t user_id, bool showDeleted, int64_t workgroup_id, int64_t parent_id, FilesInfoList& filesInfo, int64_t& lastEventId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFilesInfoParent"))
            {
                pg_connection->prepare  ("getFilesInfoParent",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id, f.workgroup_id, f.file_name, "
                                         "EXTRACT(EPOCH FROM f.creation_date) AS creation_dateUnix, f.creation_date, f.size, f.hash, "
                                         "f.revision, f.is_deleted, f.is_approved, EXTRACT(EPOCH FROM f.deletion_date) AS deletion_dateUnix, "
                                         "f.deletion_date, f.parent_id, f.is_directory FROM Files AS f INNER JOIN "
                                         "(SELECT file_id, MAX(revision) AS rev FROM Files WHERE workgroup_id=$1 AND is_deleted=$2 AND "
                                         "is_approved=true AND parent_id=$3 GROUP BY file_id) AS ff "
                                         "ON (f.file_id = ff.file_id AND f.revision=ff.rev);");
            }
            if (pgSqlHelper().register_prep_statement("getLastEventIdforFolder"))
            {
                pg_connection->prepare  ("getLastEventIdforFolder",
                                         "SELECT event_id FROM Events WHERE workgroup_id=$1 ORDER BY event_id DESC LIMIT 1;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFilesInfoParent");

            pqxx::result query_result_event_id = pg_transaction.prepared("getLastEventIdforFolder")(workgroup_id).exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["event_id"].to(lastEventId);
            }

            pqxx::result query_result = pg_transaction.prepared("getFilesInfoParent")(workgroup_id)(showDeleted)(parent_id).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files for user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::list_all_files_parent(int64_t user_id, int64_t workgroup_id, int64_t parent_id, FilesInfoList& filesInfo, int64_t& lastEventId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllFilesInfoParent"))
            {
                pg_connection->prepare  ("getAllFilesInfoParent",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id, f.workgroup_id, f.file_name, "
                                         "EXTRACT(EPOCH FROM f.creation_date) AS creation_dateUnix, f.creation_date, f.size, f.hash, "
                                         "f.revision, f.is_deleted, f.is_approved, EXTRACT(EPOCH FROM f.deletion_date) AS deletion_dateUnix, "
                                         "f.deletion_date, f.parent_id, f.is_directory FROM Files AS f "
                                         "INNER JOIN (SELECT file_id, MAX(revision) AS rev FROM Files "
                                         "WHERE workgroup_id=$1 AND is_approved=true AND parent_id = $2 GROUP BY file_id) AS ff "
                                         "ON (f.file_id = ff.file_id AND f.revision=ff.rev);");
            }
            if (pgSqlHelper().register_prep_statement("getLastEventIdforFolder"))
            {
                pg_connection->prepare  ("getLastEventIdforFolder",
                                         "SELECT event_id FROM Events WHERE workgroup_id=$1 ORDER BY event_id DESC LIMIT 1;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFilesInfoParent");

            pqxx::result query_result_event_id = pg_transaction.prepared("getLastEventIdforFolder")(workgroup_id).exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["event_id"].to(lastEventId);
            }

            pqxx::result query_result = pg_transaction.prepared("getAllFilesInfoParent")(workgroup_id)(parent_id).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files for user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::get_files_info(int64_t user_id, FilesInfoList& filesInfoList)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            for (FilesInfoList::iterator iter = filesInfoList.begin(); iter!=filesInfoList.end() ; iter++)
            {
                if (pgSqlHelper().register_prep_statement("getFilesInfoMore"))
                {
                    pg_connection->prepare  ("getFilesInfoMore",
                                             "SELECT file_name, workgroup_id, EXTRACT(EPOCH FROM creation_date) AS creation_dateUnix, "
                                             "creation_date, size, hash, storage_path, revision, is_deleted, is_approved, "
                                             "EXTRACT(EPOCH FROM deletion_date) AS deletion_dateUnix, deletion_date FROM Files "
                                             "WHERE file_id=$1 ORDER BY revision DESC LIMIT 1;");
                    //"SELECT file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash, storage_path, f.revision FROM Files AS ff INNER JOIN ( SELECT revision, file_id FROM Files WHERE file_id=1) AS f ON f.revision=ff.revision and f.fileid=ff.fileid;";
                }
                pqxx::work pg_transaction(*pg_connection, "GetFilesInfoMore");
                pqxx::result query_result = pg_transaction.prepared("getFilesInfoMore")((*iter).file_id).exec();

                if (!query_result.size())
                {
                    LOG_ERROR("Failure: trying to file info for file %lli",(*iter).file_id);
                    returnStatus = status_does_not_exist;
                    break;
                }

                query_result.begin()["file_name"].to((*iter).file_name);
                query_result.begin()["workgroup_id"].to((*iter).workgroup_id);
                double creation_date = 0;
                query_result.begin()["creation_dateUnix"].to(creation_date);
                (*iter).creation_date = (int64_t) creation_date;
                double deletion_date = 0;
                if (!query_result.begin()["deletion_dateUnix"].is_null())
                {
                    query_result.begin()["deletion_dateUnix"].to(deletion_date);
                }
                (*iter).deletion_date = (int64_t) deletion_date;
                query_result.begin()["creation_date"].to((*iter).creation_date_str);
                if (!query_result.begin()["deletion_date"].is_null())
                {
                    query_result.begin()["deletion_date"].to((*iter).deletion_date_str);
                }
                query_result.begin()["hash"].to((*iter).hash);
                query_result.begin()["size"].to((*iter).size);
                query_result.begin()["storage_path"].to((*iter).file_url);
                query_result.begin()["revision"].to((*iter).revision);
                query_result.begin()["is_deleted"].to((*iter).is_deleted);
                query_result.begin()["is_approved"].to((*iter).is_approved);
                query_result.begin()["is_directory"].to((*iter).is_directory);
                query_result.begin()["parent_id"].to((*iter).parent_id);

                pg_transaction.commit();

            }

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files info for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::get_approved_file_info(int64_t user_id, FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFileInfo"))
            {
                pg_connection->prepare  ("getFileInfo",
                                         "SELECT file_name, workgroup_id, EXTRACT(EPOCH FROM creation_date) AS creation_dateUnix, "
                                         "creation_date, is_deleted, is_approved, workgroup_id, size, hash, storage_path, revision, "
                                         "EXTRACT(EPOCH FROM deletion_date) AS deletion_dateUnix, deletion_date, is_directory, parent_id "
                                         "FROM Files WHERE file_id=$1 AND is_approved=true AND is_deleted = false "
                                         "ORDER BY revision DESC LIMIT 1;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFileInfo");
            pqxx::result query_result = pg_transaction.prepared("getFileInfo")(fileInfo.file_id).exec();

            if (!query_result.size())
            {
                LOG_ABSOLUTE("File info for file %lli: does not exist",fileInfo.file_id);
                returnStatus = status_does_not_exist;
                break;
            }

            query_result.begin()["file_name"].to(fileInfo.file_name);
            query_result.begin()["workgroup_id"].to(fileInfo.workgroup_id);
            double creation_date = 0;
            query_result.begin()["creation_dateUnix"].to(creation_date);
            fileInfo.creation_date = (int64_t) creation_date;
            double deletion_date = 0;
            if (!query_result.begin()["deletion_dateUnix"].is_null())
            {
                query_result.begin()["deletion_dateUnix"].to(deletion_date);
            }
            fileInfo.deletion_date = (int64_t) deletion_date;
            query_result.begin()["creation_date"].to(fileInfo.creation_date_str);
            if (!query_result.begin()["deletion_date"].is_null())
            {
                query_result.begin()["deletion_date"].to(fileInfo.deletion_date_str);
            }
            query_result.begin()["storage_path"] .to(fileInfo.file_url);
            query_result.begin()["hash"].to(fileInfo.hash);
            query_result.begin()["size"].to(fileInfo.size);
            query_result.begin()["workgroup_id"].to(fileInfo.workgroup_id);
            query_result.begin()["revision"].to(fileInfo.revision);
            query_result.begin()["is_deleted"].to(fileInfo.is_deleted);
            query_result.begin()["is_approved"].to(fileInfo.is_approved);
            query_result.begin()["is_directory"].to(fileInfo.is_directory);
            query_result.begin()["parent_id"].to(fileInfo.parent_id);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query file info for file %lli user %lli err: %s",fileInfo.file_id,user_id,e.what());
            break;
        }
        LOG_ABSOLUTE("Info: got info for file %lli : name %s folder %lli s3 %s",fileInfo.file_id,fileInfo.file_name.c_str(),fileInfo.workgroup_id,fileInfo.file_url.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::get_short_directory_info(int64_t user_id, FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getShortDirInfo"))
            {
                pg_connection->prepare  ("getShortDirInfo",
                                         "SELECT file_name, is_deleted, parent_id FROM Files "
                                         "WHERE file_id=$1 AND workgroup_id=$2 AND is_directory=true;");
            }
            pqxx::work pg_transaction(*pg_connection, "getShortDirInfo");
            pqxx::result query_result = pg_transaction.prepared("getShortDirInfo")(fileInfo.file_id)(fileInfo.workgroup_id).exec();

            if (!query_result.size())
            {
                LOG_ABSOLUTE("Dir info for file_id %lli: does not exist",fileInfo.file_id);
                returnStatus = status_does_not_exist;
                break;
            }

            query_result.begin()["file_name"].to(fileInfo.file_name);
            query_result.begin()["is_deleted"].to(fileInfo.is_deleted);
            query_result.begin()["parent_id"].to(fileInfo.parent_id);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query directory info for directory %lli user %lli err: %s",fileInfo.file_id,user_id,e.what());
            break;
        }
        LOG_ABSOLUTE("Info: got info for directory %lli : name %s folder %lli s3 %s",fileInfo.file_id,fileInfo.file_name.c_str(),fileInfo.workgroup_id,fileInfo.file_url.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::get_exact_file_info(int64_t user_id, FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getExactFileInfo"))
            {
                pg_connection->prepare  ("getExactFileInfo",
                                         "SELECT file_name, EXTRACT(EPOCH FROM creation_date) AS creation_dateUnix, creation_date, "
                                         "workgroup_id, size, hash, storage_path, revision, is_approved, is_deleted, "
                                         "EXTRACT(EPOCH FROM deletion_date) AS deletion_dateUnix, deletion_date, is_directory, parent_id "
                                         "FROM Files WHERE file_id=$1 AND revision=$2;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetExactFileInfo");
            pqxx::result query_result = pg_transaction.prepared("getExactFileInfo")(fileInfo.file_id)(fileInfo.revision).exec();

            if (!query_result.size())
            {
                LOG_INFORMATION("Failure: trying to file info for file %lli",fileInfo.file_id);
                returnStatus = status_does_not_exist;
                break;
            }

            query_result.begin()["file_name"].to(fileInfo.file_name);
            query_result.begin()["workgroup_id"].to(fileInfo.workgroup_id);
            double creation_date = 0;
            query_result.begin()["creation_dateUnix"].to(creation_date);
            fileInfo.creation_date = (int64_t) creation_date;
            double deletion_date = 0;
            if (!query_result.begin()["deletion_dateUnix"].is_null())
            {
                query_result.begin()["deletion_dateUnix"].to(deletion_date);
            }
            fileInfo.deletion_date = (int64_t) deletion_date;
            query_result.begin()["creation_date"].to(fileInfo.creation_date_str);
            if (!query_result.begin()["deletion_date"].is_null())
            {
                query_result.begin()["deletion_date"].to(fileInfo.deletion_date_str);
            }
            query_result.begin()["storage_path"] .to(fileInfo.file_url);
            query_result.begin()["hash"].to(fileInfo.hash);
            query_result.begin()["size"].to(fileInfo.size);
            query_result.begin()["workgroup_id"].to(fileInfo.workgroup_id);
            query_result.begin()["revision"].to(fileInfo.revision);
            query_result.begin()["is_deleted"].to(fileInfo.is_deleted);
            query_result.begin()["is_approved"].to(fileInfo.is_approved);
            query_result.begin()["is_directory"].to(fileInfo.is_directory);
            query_result.begin()["parent_id"].to(fileInfo.parent_id);


            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query file info for file %lli user %lli err: %s",fileInfo.file_id,user_id,e.what());
            break;
        }
        LOG_ABSOLUTE("Info: got info for file %lli : name %s folder %lli s3 %s",fileInfo.file_id,fileInfo.file_name.c_str(),fileInfo.workgroup_id,fileInfo.file_url.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::create_file(int64_t user_id,  FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "CreateFile");

            if (pgSqlHelper().register_prep_statement("createFile"))
            {
                pg_connection->prepare  ("createFile",
                                         "INSERT INTO Files(file_name, workgroup_id, hash, size, storage_path, is_approved, creator_id, "
                                         "parent_id, is_directory, is_first) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true) "
                                         "RETURNING file_id, revision, EXTRACT(EPOCH FROM creation_date) AS creation_date;");
            }

            pqxx::result query_result = pg_transaction.prepared("createFile")(fileInfo.file_name)(fileInfo.workgroup_id)(fileInfo.hash)(fileInfo.size)(fileInfo.file_url)(fileInfo.is_approved)(user_id)(fileInfo.parent_id)(fileInfo.is_directory).exec();

            if (!query_result.size())
            {
                LOG_ERROR("Failure: trying to create hash %s size %lli for user %lli",fileInfo.hash.c_str(), fileInfo.size, user_id);
                break;
            }

            query_result.begin()["file_id"].to(fileInfo.file_id);
            query_result.begin()["revision"].to(fileInfo.revision);
            double creation_date = 0;
            query_result.begin()["creation_date"].to(creation_date);
            fileInfo.creation_date = (int64_t) creation_date;

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            returnStatus = status_already_exist;
            LOG_ERROR("Info: trying to create duplicate hash %s size %lli file_name %s err: %s",fileInfo.hash.c_str(),fileInfo.size,fileInfo.file_name.c_str(),e.what());
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to create hash %s size %lli file_name %s err: %s",fileInfo.hash.c_str(),fileInfo.size,fileInfo.file_name.c_str(),e.base().what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::create_file_rev(int64_t user_id,  FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "CreateFileRev");

            if (pgSqlHelper().register_prep_statement("createFileRev"))
            {
                pg_connection->prepare  ("createFileRev",
                                         "INSERT INTO Files(file_id, file_name, workgroup_id, hash, size, storage_path, is_approved, "
                                         "creator_id, parent_id, is_directory, is_first) VALUES ($1 , $2, $3, $4, $5, $6, $7, $8, $9, $10, "
                                         "false) RETURNING file_id, revision, EXTRACT(EPOCH FROM creation_date) AS creation_date;");
            }

            pqxx::result query_result = pg_transaction.prepared("createFileRev")(fileInfo.file_id)(fileInfo.file_name)(fileInfo.workgroup_id)(fileInfo.hash)(fileInfo.size)(fileInfo.file_url)(fileInfo.is_approved)(user_id)(fileInfo.parent_id)(fileInfo.is_directory).exec();

            if (!query_result.size())
            {
                LOG_ERROR("Failure: trying to create hash %s size %lli for user %lli",fileInfo.hash.c_str(), fileInfo.size, user_id);
                break;
            }

            query_result.begin()["file_id"].to(fileInfo.file_id);
            query_result.begin()["revision"].to(fileInfo.revision);
            double creation_date = 0;
            query_result.begin()["creation_date"].to(creation_date);
            fileInfo.creation_date = (int64_t) creation_date;

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            returnStatus = status_already_exist;
            LOG_ERROR("Info: trying to create duplicate hash %s size %lli file_name %s err: %s",fileInfo.hash.c_str(),fileInfo.size,fileInfo.file_name.c_str(),e.what());
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to create hash %s size %lli file_name %s err: %s",fileInfo.hash.c_str(),fileInfo.size,fileInfo.file_name.c_str(),e.base().what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::remove_file(int64_t user_id, int64_t workgroup_id, int64_t file_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteFile"))
            {
                pg_connection->prepare  ("deleteFile",
                                         "UPDATE Files SET is_deleted = true, deletion_date = NOW() "
                                         "WHERE workgroup_id=$1 AND file_id=$2 AND is_deleted = false RETURNING is_deleted;");
            }
            pqxx::work pg_transaction(*pg_connection, "DeleteFile");
            pqxx::result query_result = pg_transaction.prepared("deleteFile")(workgroup_id)(file_id).exec();

            if (query_result.empty())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete file %lli for user %lli err: %s",file_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::undelete_file(int64_t user_id, int64_t workgroup_id, int64_t file_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("UndeleteFile"))
            {
                pg_connection->prepare  ("UndeleteFile",
                                         "UPDATE Files SET is_deleted = false, deletion_date = NOW() "
                                         "WHERE workgroup_id=$1 AND file_id=$2 AND is_deleted = true RETURNING is_deleted;");
            }
            pqxx::work pg_transaction(*pg_connection, "UndeleteFile");
            pqxx::result query_result = pg_transaction.prepared("UndeleteFile")(workgroup_id)(file_id).exec();

            if (query_result.empty())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to undelete file %lli for user %lli err: %s",file_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}



rpc_status_code FileManagerPgSql::remove_file_now(int64_t user_id, int64_t workgroup_id, int64_t file_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteFileNow"))
            {
                pg_connection->prepare  ("deleteFileNow",
                                         "DELETE FROM Files WHERE workgroup_id=$1 AND file_id=$2 RETURNING is_deleted;");
            }
            pqxx::work pg_transaction(*pg_connection, "DeleteFileNow");
            pqxx::result query_result = pg_transaction.prepared("deleteFileNow")(workgroup_id)(file_id).exec();

            if (query_result.empty())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete folder %lli for user %lli err: %s",file_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::remove_file(int64_t user_id, int64_t workgroup_id, int64_t file_id, int64_t revision)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteFileRev"))
            {
                pg_connection->prepare  ("deleteFileRev",
                                         "UPDATE Files SET is_deleted = true, deletion_date = NOW() "
                                         "WHERE workgroup_id=$1 AND file_id=$2 AND revision=$3 AND is_deleted=false RETURNING is_deleted;");
            }
            pqxx::work pg_transaction(*pg_connection, "DeleteFileRev");
            pqxx::result query_result = pg_transaction.prepared("deleteFileRev")(workgroup_id)(file_id)(revision).exec();

            if (query_result.empty())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete file %lli for user %lli err: %s",file_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::undelete_file(int64_t user_id, int64_t workgroup_id, int64_t file_id, int64_t revision)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("UndeleteFileRev"))
            {
                pg_connection->prepare  ("UndeleteFileRev",
                                         "UPDATE Files SET is_deleted = false, deletion_date = NULL "
                                         "WHERE workgroup_id=$1 AND file_id=$2 AND revision=$3 AND is_deleted=true RETURNING is_deleted;");
            }
            pqxx::work pg_transaction(*pg_connection, "UndeleteFileRev");
            pqxx::result query_result = pg_transaction.prepared("UndeleteFileRev")(workgroup_id)(file_id)(revision).exec();

            if (query_result.empty())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to undelete file %lli for user %lli err: %s",file_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::remove_file_now(int64_t user_id, int64_t workgroup_id, int64_t file_id, int64_t revision)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("deleteFileRevNow"))
            {
                pg_connection->prepare  ("deleteFileRevNow",
                                         "DELETE FROM Files WHERE workgroup_id=$1 AND file_id=$2 AND revision=$3 RETURNING is_deleted;");
            }
            pqxx::work pg_transaction(*pg_connection, "DeleteFileRevNow");
            pqxx::result query_result = pg_transaction.prepared("deleteFileRevNow")(workgroup_id)(file_id)(revision).exec();

            if (query_result.empty())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete file %lli for user %lli err: %s",file_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code FileManagerPgSql::approve_file(int64_t user_id, const FileInfo& fileInfo, bool& is_first)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "ApproveFile");

            if (pgSqlHelper().register_prep_statement("ApproveFile"))
            {
                pg_connection->prepare  ("ApproveFile",
                                         "UPDATE Files SET is_approved=$4 WHERE file_id=$1 AND revision=$2 AND workgroup_id=$3 "
                                         "RETURNING is_first;");
            }

            pqxx::result query_result = pg_transaction.prepared("ApproveFile")(fileInfo.file_id)(fileInfo.revision)(fileInfo.workgroup_id)(true).exec();

            if (!query_result.size())
            {
                LOG_ERROR("Failure: trying to create hash %s size %lli for user %lli",fileInfo.hash.c_str(), fileInfo.size, user_id);
                break;
            }

            query_result.begin()["is_first"].to(is_first);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to approve file_id %lli-%lli err: %s",fileInfo.file_id,fileInfo.revision,e.base().what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::rename_file(int64_t user_id, int64_t workgroup_id, int64_t file_id, int64_t revision, const std::string& file_nameNew, int64_t& revision_ret)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            /*if (pgSqlHelper().register_prep_statement("RenameFile"))
            {
                pg_connection->prepare  ("RenameFile",
                                         "UPDATE Files SET file_name=$3 WHERE file_id=$1 and revision = $2;");
            }

            pqxx::work pg_transaction(*pg_connection, "RenameFile");

            pqxx::result query_result = pg_transaction.prepared("RenameFile")(file_id)(revision)(file_nameNew).exec();*/

            pqxx::work pg_transaction(*pg_connection, "RenameFile");

            std::stringstream query;

            query<<"INSERT INTO Files (file_id, file_name, workgroup_id, hash, size, storage_path, is_deleted, is_approved, deletion_date, creator_id, parent_id, is_directory, latest_version) ";
            query<<" select file_id, ";
            query<<"'"<<pg_transaction.esc(file_nameNew)<<"'";
            query<<", workgroup_id, hash, size, storage_path, is_deleted, is_approved, deletion_date, ";
            query<< user_id;
            query<<", parent_id, is_directory, true ";
            query<<" FROM Files WHERE ";
            query<<" workgroup_id = " << workgroup_id;
            query<<" AND file_id = " << file_id;
            query<<" AND revision = " << revision;
            query<<" RETURNING revision;";

            pqxx::result query_result = pg_transaction.exec(query);

            //LOG_INFORMATION("Rename query is [%s]", query.str().c_str());

            if (!query_result.size())
            {
                LOG_ABSOLUTE("No file found for workgroup_id %lli file_id %lli revision %lli", workgroup_id, file_id, revision);
                returnStatus = status_does_not_exist;
                break;
            }

            query_result.begin()["revision"].to(revision_ret);

            std::stringstream query1;

            query1<<"UPDATE Files SET latest_version = false ";
            query1<<"WHERE workgroup_id = ";
            query1<<workgroup_id;
            query1<<" AND file_id = ";
            query1<<file_id;
            query1<<" AND revision = ";
            query1<<revision;
            query1<<" ; \n";

            pg_transaction.exec(query1);

            pg_transaction.commit();

            returnStatus = status_success;

        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to rename file_id %lli err: %s",file_id,e.base().what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::get_history(int64_t user_id, bool showDeleted, int64_t workgroup_id, int64_t file_id, FilesInfoList& filesInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFileHistory"))
            {
                pg_connection->prepare  ("getFileHistory",
                                         "SELECT file_id, workgroup_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_dateUnix, "
                                         "creation_date, size, hash, revision, is_deleted, is_approved, "
                                         "EXTRACT(EPOCH FROM deletion_date  AT TIME ZONE 'GMT') AS deletion_dateUnix, deletion_date, "
                                         "parent_id, is_directory, login FROM Files INNER JOIN Users "
                                         "ON Files.creator_id = Users.user_id WHERE file_id = $1 AND workgroup_id = $2 AND is_deleted = $3;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFileHistory");

            pqxx::result query_result = pg_transaction.prepared("getFileHistory")(file_id)(workgroup_id)(showDeleted).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date = 0;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                iter["login"].to(fi.creator);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files history for user %lli in file %lli err: %s",user_id,file_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::get_full_history(int64_t user_id, int64_t workgroup_id, int64_t file_id, FilesInfoList& filesInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFullFileHistory"))
            {
                pg_connection->prepare  ("getFullFileHistory",
                                         "SELECT file_id, workgroup_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_dateUnix, "
                                         "creation_date, size, hash, revision, is_deleted, is_approved, "
                                         "EXTRACT(EPOCH FROM deletion_date  AT TIME ZONE 'GMT') AS deletion_dateUnix, deletion_date, "
                                         "parent_id, is_directory, login FROM Files INNER JOIN Users ON Files.creator_id = Users.user_id "
                                         "WHERE file_id = $1 AND workgroup_id = $2;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFullFileHistory");

            pqxx::result query_result = pg_transaction.prepared("getFullFileHistory")(file_id)(workgroup_id).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date = 0;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                iter["login"].to(fi.creator);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files history for user %lli in file %lli err: %s",user_id,file_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::create_file_to_delete(int64_t user_id, FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "CreateFileToDelete");

            if (pgSqlHelper().register_prep_statement("createFileToDelete"))
            {
                pg_connection->prepare  ("createFileToDelete",
                                         "INSERT INTO FilesToDelete(file_id, revision, workgroup_id, storage_path) VALUES ($1, $2, $3, $4);");
            }

            pqxx::result query_result = pg_transaction.prepared("createFileToDelete")(fileInfo.file_id)(fileInfo.revision)(fileInfo.workgroup_id)(fileInfo.file_url).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to create files for deletion user %lli in folder %lli err: %s",user_id,fileInfo.file_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::remove_file_to_delete(int64_t user_id, int64_t workgroup_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "PrepareFileToDelete1");

            if (pgSqlHelper().register_prep_statement("prepareFileToDelete1"))
            {
                pg_connection->prepare  ("prepareFileToDelete1",
                                         "UPDATE FilesToDelete SET is_deleted=true AND deletion_date=NOW() WHERE workgroup_id=$1;");
            }

            pqxx::result query_result = pg_transaction.prepared("prepareFileToDelete1")(workgroup_id).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to create files for deletion user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::remove_file_to_delete(int64_t user_id, int64_t workgroup_id, int64_t file_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "PrepareFileToDelete2");

            if (pgSqlHelper().register_prep_statement("prepareFileToDelete2"))
            {
                pg_connection->prepare  ("prepareFileToDelete2",
                                         "UPDATE FilesToDelete SET is_deleted=true AND deletion_date=NOW() "
                                         "WHERE workgroup_id=$1 AND file_id=$2;");
            }

            pqxx::result query_result = pg_transaction.prepared("prepareFileToDelete2")(workgroup_id)(file_id).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to create files for deletion user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::remove_file_to_delete(int64_t user_id, int64_t workgroup_id, int64_t file_id, int64_t revision)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "PrepareFileToDelete3");

            if (pgSqlHelper().register_prep_statement("prepareFileToDelete3"))
            {
                pg_connection->prepare  ("prepareFileToDelete3",
                                         "UPDATE FilesToDelete SET is_deleted=true AND deletion_date=NOW() "
                                         "WHERE workgroup_id=$1 AND file_id=$2 AND revision=$3;");
            }

            pqxx::result query_result = pg_transaction.prepared("prepareFileToDelete3")(workgroup_id)(file_id)(revision).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to create files for deletion user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::get_file_by_name(int64_t user_id,
        FileInfo& fileInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "GetFileByName");

            if (pgSqlHelper().register_prep_statement("getFileByName"))
            {
                pg_connection->prepare  ("getFileByName",
                                         "SELECT file_id, workgroup_id, revision, file_name, "
                                         "EXTRACT(EPOCH FROM creation_date) AS creation_date, workgroup_id, size, hash, storage_path, "
                                         "revision, is_approved, is_deleted, EXTRACT(EPOCH FROM deletion_date) AS deletion_date, "
                                         "is_directory, parent_id FROM Files WHERE workgroup_id=$1 AND file_name=$2 AND is_deleted=false "
                                         "AND parent_id=$3 ORDER BY revision DESC LIMIT 1;");
            }
            pqxx::result query_result = pg_transaction.prepared("getFileByName")(fileInfo.workgroup_id)(fileInfo.file_name)(fileInfo.parent_id).exec();

            if (!query_result.size())
            {
                LOG_ABSOLUTE("No file found for file_name %s and workgroup_id %lli", fileInfo.file_name.c_str(), fileInfo.workgroup_id);
                returnStatus = status_does_not_exist;
                break;
            }

            query_result.begin()["file_id"].to(fileInfo.file_id);
            query_result.begin()["revision"].to(fileInfo.revision);
            query_result.begin()["workgroup_id"].to(fileInfo.workgroup_id);
            double creation_date;
            query_result.begin()["creation_date"].to(creation_date);
            fileInfo.creation_date = (int64_t) creation_date;
            double deletion_date = 0;
            if (!query_result.begin()["deletion_date"].is_null())
            {
                query_result.begin()["deletion_date"].to(deletion_date);
            }
            fileInfo.deletion_date = (int64_t) deletion_date;
            query_result.begin()["storage_path"] .to(fileInfo.file_url);
            query_result.begin()["hash"].to(fileInfo.hash);
            query_result.begin()["size"].to(fileInfo.size);
            query_result.begin()["revision"].to(fileInfo.revision);
            query_result.begin()["is_deleted"].to(fileInfo.is_deleted);
            query_result.begin()["is_approved"].to(fileInfo.is_approved);
            query_result.begin()["is_directory"].to(fileInfo.is_directory);
            query_result.begin()["parent_id"].to(fileInfo.parent_id);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to check workgroup_id %lli file_name %s err: %s",fileInfo.workgroup_id, fileInfo.file_name.c_str(), e.what());
            break;
        }
        LOG_ABSOLUTE("Info: got file_id %lli for file_name %s and workgroup_id %lli",fileInfo.file_id, fileInfo.file_name.c_str(), fileInfo.workgroup_id);
    }
    while (false);

    return returnStatus;
}

/*int FileManagerPgSql::get_fileid_by_hash(const std::string& hash, int64_t size, int64_t& file_id)
{
    int returnStatus = EXIT_FAILURE;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "GetFileByHash");

            if (pgSqlHelper().register_prep_statement("getFileByHash"))
            {
                pg_connection->prepare  ("getFileByHash",
                                         "SELECT file_id FROM Files WHERE hash=$1 AND size=$2;");
            }
            pqxx::result query_result = pg_transaction.prepared("getFileByHash")(hash)(size).exec();

            if (!query_result.size())
            {
                LOG_INFORMATION("Info: trying to check hash %s size %lli",hash.c_str(), size);
                break;
            }

            query_result.begin()["file_id"].to(file_id);

            pg_transaction.commit();

            returnStatus = EXIT_SUCCESS;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to check hash %s size %lli err: %s",hash.c_str(),size,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
 }*/

rpc_status_code FileManagerPgSql::get_directory_children(int64_t user_id,
        int64_t workgroup_id, int64_t parent_id,
        std::vector<int64_t>& children)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getDirectoryChildren"))
            {
                pg_connection->prepare  ("getDirectoryChildren",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id FROM Files AS f INNER JOIN (SELECT file_id, MAX(revision) AS rev "
                                         "FROM Files WHERE workgroup_id=$1 AND parent_id = $2 AND is_deleted=false GROUP BY file_id) "
                                         "AS ff ON (f.file_id = ff.file_id AND f.revision=ff.rev);");
            }

            pqxx::work pg_transaction(*pg_connection, "getDirectoryChildren");

            pqxx::result query_result = pg_transaction.prepared("getDirectoryChildren")(workgroup_id)(parent_id).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                children.push_back(iter["file_id"].as<int64_t>());
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query children for user %lli in folder %lli parent_id %lli err: %s",user_id,workgroup_id,parent_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::search_file_in_folder(int64_t user_id, int64_t workgroup_id, const std::string& searchString, FilesInfoList& filesInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("searchFileInFolder"))
            {
                pg_connection->prepare  ("searchFileInFolder",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id, f.workgroup_id, f.file_name, "
                                         "EXTRACT(EPOCH FROM f.creation_date) AS creation_dateUnix, f.creation_date, f.size, f.hash, "
                                         "f.revision, f.is_deleted, f.is_approved, EXTRACT(EPOCH FROM f.deletion_date) AS deletion_dateUnix, "
                                         "f.deletion_date, f.is_directory, f.parent_id FROM Files AS f "
                                         "INNER JOIN (SELECT file_id, MAX(revision) AS rev FROM Files WHERE workgroup_id=$1 "
                                         "AND is_approved=true GROUP BY file_id) AS ff ON (f.file_id = ff.file_id AND f.revision=ff.rev) "
                                         "WHERE lower(f.file_name) LIKE lower('%' || $2 || '%');");
            }
            pqxx::work pg_transaction(*pg_connection, "searchFileInFolder");

            pqxx::result query_result = pg_transaction.prepared("searchFileInFolder")(workgroup_id)(searchString).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date = 0;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files for user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::search_file(int64_t user_id, const std::string& searchString, FilesInfoList& filesInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("searchFile"))
            {
                pg_connection->prepare  ("searchFile",
                                         //"SELECT file_id, file_name, EXTRACT(EPOCH FROM creation_date) AS creation_date, size, hash FROM Files WHERE file_id IN (SELECT MAX(file_id) FROM Files WHERE workgroup_id=$1 AND is_deleted=false AND is_approved=true GROUP BY file_name);")
                                         "SELECT f.file_id, f.workgroup_id, f.file_name, EXTRACT(EPOCH FROM f.creation_date) AS creation_dateUnix, f.creation_date, f.size, f.hash, "
                                         "f.revision, f.is_deleted, f.is_approved, EXTRACT(EPOCH FROM f.deletion_date) AS deletion_dateUnix, f.deletion_date, f.is_directory, f.parent_id "
                                         "FROM Files AS f INNER JOIN (SELECT file_id, MAX(revision) AS rev FROM Files "
                                         "INNER JOIN ( SELECT WorkGroupsAccess.workgroup_id FROM WorkGroupsAccess "
                                         "INNER JOIN WorkGroups ON WorkGroups.workgroup_id=WorkGroupsAccess.workgroup_id "
                                         "WHERE WorkGroupsAccess.user_id=$1 AND WorkGroupsAccess.invite_accepted=true "
                                         "AND WorkGroupsAccess.is_deleted=false AND WorkGroups.is_deleted=false AND "
                                         "(WorkGroups.encryption_type=0 OR WorkGroups.encryption_type=3)) AS fa "
                                         "ON fa.workgroup_id=Files.workgroup_id "
                                         "WHERE is_approved=true GROUP BY file_id) AS ff ON (f.file_id = ff.file_id AND f.revision=ff.rev) "
                                         "WHERE lower(f.file_name) LIKE lower('%' || $2 || '%');");
            }
            pqxx::work pg_transaction(*pg_connection, "searchFile");

            pqxx::result query_result = pg_transaction.prepared("searchFile")(user_id)(searchString).exec();

            for (pqxx::result::const_iterator iter= query_result.begin() ; iter!=query_result.end(); iter++ )
            {
                FileInfo fi;
                iter["file_id"].to(fi.file_id);
                iter["workgroup_id"].to(fi.workgroup_id);
                iter["file_name"].to(fi.file_name);
                double date = 0;
                iter["creation_dateUnix"].to(date);
                fi.creation_date = date; //losing microseconds
                double date1 = 0;
                if (!iter["deletion_dateUnix"].is_null())
                {
                    iter["deletion_dateUnix"].to(date1);
                }
                fi.deletion_date = date1; //losing microseconds
                iter["creation_date"].to(fi.creation_date_str);
                if (!iter["deletion_date"].is_null())
                {
                    iter["deletion_date"].to(fi.deletion_date_str);
                }
                iter["size"].to(fi.size);
                iter["hash"].to(fi.hash);
                iter["revision"].to(fi.revision);
                iter["is_deleted"].to(fi.is_deleted);
                iter["is_approved"].to(fi.is_approved);
                iter["is_directory"].to(fi.is_directory);
                iter["parent_id"].to(fi.parent_id);
                filesInfo.push_back(fi);
            }

            pg_transaction.commit();

            //returnStatus = get_files_info(user_id,filesInfo);
            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;

}

rpc_status_code FileManagerPgSql::count_files(int64_t user_id, int64_t workgroup_id, int64_t& count)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFilesCount"))
            {
                pg_connection->prepare  ("getFilesCount",
                                         "SELECT count(*) as count FROM ( select file_id FROM Files WHERE workgroup_id=$1 "
                                         "AND is_deleted=false GROUP BY file_id) as f;");
            }
            pqxx::work pg_transaction(*pg_connection, "getFilesCount");

            pqxx::result query_result_event_id = pg_transaction.prepared("getFilesCount")(workgroup_id).exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["count"].to(count);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query files count for user %lli in folder %lli err: %s",user_id,workgroup_id,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code FileManagerPgSql::count_files_for_wgs(int64_t user_id, bool showDeletedWgs, std::map<int64_t, int64_t>& count)
{
    rpc_status_code returnStatus = status_internal_error;

     do
     {
         pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
         if (!pg_connection)
         {
             break;
         }

         try
         {
             if (pgSqlHelper().register_prep_statement("getFilesCountForWgs"))
             {
                 pg_connection->prepare  ("getFilesCountForWgs",
                         "SELECT count(distinct file_id), f.workgroup_id FROM Files as f "
                         "INNER JOIN WorkGroupsAccess as wga "
                         "ON f.workgroup_id = wga.workgroup_id "
                         "WHERE user_id = $1 "
                         "AND wga.is_deleted = $2 "
                         "AND invite_accepted = true "
                         "AND f.is_deleted=false "
                         "GROUP BY f.workgroup_id "
                         "order by workgroup_id ");
             }

             pqxx::work pg_transaction(*pg_connection, "getFilesCountForWgs");
             pqxx::result query_result = pg_transaction.prepared("getFilesCountForWgs")(user_id)(showDeletedWgs).exec();

             for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
             {
                 std::pair<int64_t, int64_t> item;
                 resi["workgroup_id"].  to(item.first);
                 resi["count"].         to(item.second);
                 count.insert(item);
             }

             pg_transaction.commit();

             returnStatus = status_success;
         }
         catch (const std::exception& e)
         {
             LOG_ERROR("Failure: trying to query folder files count for user %lli err: %s",user_id,e.what());
             break;
         }
         //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
     }
     while (false);

     return returnStatus;
}

rpc_status_code FileManagerPgSql::count_files_for_wgs_all(int64_t user_id, std::map<int64_t, int64_t>& count)
{
    rpc_status_code returnStatus = status_internal_error;

     do
     {
         pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
         if (!pg_connection)
         {
             break;
         }

         try
         {
             if (pgSqlHelper().register_prep_statement("getFilesCountForWgsAll"))
             {
                 pg_connection->prepare  ("getFilesCountForWgsAll",
                         "SELECT count(distinct file_id), f.workgroup_id FROM Files as f "
                         "INNER JOIN WorkGroupsAccess as wga "
                         "ON f.workgroup_id = wga.workgroup_id "
                         "WHERE user_id = $1 "
                         "AND invite_accepted = true "
                         "AND f.is_deleted=false "
                         "GROUP BY f.workgroup_id "
                         "order by workgroup_id ");
             }

             pqxx::work pg_transaction(*pg_connection, "getFilesCountForWgsAll");
             pqxx::result query_result = pg_transaction.prepared("getFilesCountForWgsAll")(user_id).exec();

             for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
             {
                 std::pair<int64_t, int64_t> item;
                 resi["workgroup_id"].  to(item.first);
                 resi["count"].         to(item.second);
                 count.insert(item);
             }

             pg_transaction.commit();

             returnStatus = status_success;
         }
         catch (const std::exception& e)
         {
             LOG_ERROR("Failure: trying to query folder files count for user %lli err: %s",user_id,e.what());
             break;
         }
         //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
     }
     while (false);

     return returnStatus;
}
