/*
 * structs_to_protobuf.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */
#include "structs_to_protobuf.h"
#include <sutil/logging.h>


void convert_workgroupinfo(const WorkGroupInfo& wgi, rpc::WorkGroupInfo* wgip)
{
    wgip->set_workgroup_id              (wgi.workgroup_id);
    wgip->set_workgroup_name            (wgi.workgroup_name);
    wgip->set_description               (wgi.description);
    wgip->set_workgroup_type            (wgi.type);
    wgip->set_workgroup_metadata        (wgi.metadata);
    wgip->set_creator_login             (wgi.creator_login);
    wgip->set_access_mode               (wgi.access_mode);
    wgip->set_creation_date             (wgi.creation_date);
    wgip->set_deletion_date             (wgi.deletion_date);
    wgip->set_creation_date_str         (wgi.creation_date_str);
    wgip->set_deletion_date_str         (wgi.deletion_date_str);
    wgip->set_size                      (wgi.size);
    wgip->set_invite_accepted           (wgi.invite_accepted);
    wgip->set_key                       (wgi.key);
    wgip->set_encryption_type           (wgi.encryption_type);
    wgip->set_encryption_algo           (wgi.encryption_algo);
    wgip->set_key_signature             (wgi.key_signature);
    wgip->set_key_salt                  (wgi.key_salt);
    wgip->set_is_deleted                (wgi.is_deleted);

    wgip->set_files_count               (wgi.files_count);

    for (auto uwgi : wgi.collaborators_list)
    {
        rpc::CoworkerUserInfo* coworkerInfo = wgip->add_coworkers_list();
        convert_coworkerinfo(uwgi,coworkerInfo);
    }
}

void convert_coworkerinfo(const UserWorkGroupInfo& uwgi, rpc::CoworkerUserInfo* cuip)
{
    cuip->set_user_login           (uwgi.login);
    cuip->set_first_name           (uwgi.first_name);
    cuip->set_last_name            (uwgi.last_name);
    cuip->set_user_pic             (uwgi.user_pic);
    cuip->set_invite_accepted      (uwgi.invite_accepted);
    cuip->set_access_mode          (uwgi.access_mode);
    cuip->set_is_dummy             (uwgi.is_dummy);
}

void convert_inviteinfo(const InviteInfo& ii, rpc::WorkGroupInvite* wgi)
{
    wgi->set_workgroup_id               (ii.workgroup_id);
    wgi->set_workgroup_name             (ii.workgroup_name);
    wgi->set_access_mode                (ii.access_mode);
    wgi->set_inviter_login              (ii.inviter_login);
    wgi->set_invitee_login              (ii.invitee_login);
    wgi->set_invite_id                  (ii.invite_id);
}

void convert_fileinfo(const FileInfo& fi, rpc::FileInfo* fip)
{
    fip->set_file_id                    (fi.file_id);
    fip->set_workgroup_id               (fi.workgroup_id);
    fip->set_size                       (fi.size);
    fip->set_creation_date              (fi.creation_date);
    fip->set_deletion_date              (fi.deletion_date);
    fip->set_creation_date_str          (fi.creation_date_str);
    fip->set_deletion_date_str          (fi.deletion_date_str);
    fip->set_file_name                  (fi.file_name);
    fip->set_hash                       (fi.hash);
    fip->set_revision                   (fi.revision);
    fip->set_parent_id                  (fi.parent_id);
    fip->set_is_directory               (fi.is_directory);
    fip->set_creator_login              (fi.creator);
    fip->set_is_deleted                 (fi.is_deleted);
}

void convert_topicinfo(const TopicInfo& ti, rpc::TopicsListResponse_TopicInfo* tip)
{
    tip->set_topic_id                   (ti.topic_id);
    tip->set_topic_body                 (ti.topic_body);
    tip->set_topic_date                 (ti.creation_date);
    tip->set_topic_date_str             (ti.creation_date_str);
    tip->set_workgroup_id               (ti.workgroup_id);
    tip->set_file_id                    (ti.file_id);
    tip->set_revision                   (ti.revision);
    tip->set_creator_login              (ti.creator_login);
}

void convert_messageinfo(const MessageInfo& mi, rpc::MessagesListResponse_MessageInfo* mip)
{
    mip->set_message_id                 (mi.message_id);
    mip->set_message_body               (mi.message_body);
    mip->set_message_date               (mi.creation_date);
    mip->set_message_date_str           (mi.creation_date_str);
    mip->set_parent_id                  (mi.parent_id);
    mip->set_creator_login              (mi.login);
    mip->set_topic_id                   (mi.topic_id);
    mip->set_revision                   (mi.revision);
}

void convert_accountstats(const LoginStats& as, rpc::LoginStats* lsp)
{
    lsp->set_device_id                  (as.device_id);
    lsp->set_device_name                (as.device_name);
    lsp->set_ip_address                 (as.ip_address);
    lsp->set_login_date                 (as.login_date);
    lsp->set_platform                   (as.platform);
    lsp->set_login_date_str             (as.login_date_str);
    lsp->set_successful                 (as.successful);
}

void convert_purchaseinfo(const server_rpc::PurchaseApplyRequest* par, PurchaseData& pd)
{
    pd.hash     = par->hash();
    pd.login    = par->login();
    pd.name     = par->name();
    pd.type     = par->type();
    pd.sandbox  = par->sandbox();
    pd.purchase_date = par->purchase_date();
    pd.overwrite = par->overwrite();
    for (int i=0; i < par->infos_size(); i++)
    {
        PurchaseInfo pi;
        pi.count = par->infos(i).count();
        pi.event = par->infos(i).event();
        pi.type  = par->infos(i).type();
        pd.infos.push_back(pi);
    }
}
