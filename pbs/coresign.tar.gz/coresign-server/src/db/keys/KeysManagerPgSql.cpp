/*
 * FolderInvitesPgSql.cpp
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#include "KeysManagerPgSql.h"
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <sutil/logging.h>
#include "db/PgSqlHelper.h"


#define KEY_TIMEOUT_MINUTES "10 MINUTES"


rpc_status_code KeysManagerPgSql::create_key(int64_t user_id, const std::string& key_id, const std::string& public_key, const std::string& private_key)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("createKey"))
            {
                pg_connection->prepare  ("createKey",
                                         "INSERT INTO KeyPairs(user_id, key_id, public_key, private_key) VALUES ($1, $2, $3, $4);");
            }
            pqxx::work pg_transaction(*pg_connection, "createKey");
            pqxx::result query_result = pg_transaction.prepared("createKey")(user_id)(key_id)(public_key)(private_key).exec();

            pg_transaction.commit();
            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate key_id by user %lli key_id %s err: %s",user_id,key_id.c_str(),e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Info: trying to create key_id by user %lli key_id %s err: %s",user_id,key_id.c_str(),e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code KeysManagerPgSql::get_key(const std::string& key_id, std::string& public_key, std::string& private_key)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getKey"))
            {
                pg_connection->prepare  ("getKey",
                                         "SELECT public_key, private_key, creation_date, EXTRACT(EPOCH FROM (creation_date)) AS creation "
                                         "FROM KeyPairs WHERE key_id = $1 AND (NOW() - creation_date) < $2;");
            }

            pqxx::work pg_transaction(*pg_connection, "getKey");
            pqxx::result query_result = pg_transaction.prepared("getKey")(key_id)(KEY_TIMEOUT_MINUTES).exec();

            if (query_result.empty())
            {
                LOG_INFORMATION("No valid key %s found", key_id.c_str());
                returnStatus = status_does_not_exist;
                break;
            }

            public_key = query_result.begin()["public_key"].as<std::string>();
            private_key = query_result.begin()["private_key"].as<std::string>();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query key by id %s err: %s",key_id.c_str(),e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}
