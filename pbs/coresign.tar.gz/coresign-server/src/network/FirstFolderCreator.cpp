/*
 * FirstFolderCreator.cpp
 *
 *  Created on: 7 дек. 2011
 *      Author: fireballdark
 */

#include "FirstFolderCreator.h"
#include "FirstFolderCreatorImpl.h"
#include <boost/thread.hpp>
#include "threadpool/boost/threadpool/pool.hpp"

boost::thread_specific_ptr<FirstFolderCreatorImpl> ffc;

class FFCWrapper
{
public:
    static boost::threadpool::pool& getThreadPool()
    {
        static boost::threadpool::pool pool(1);
        return pool;
    };

    static void create_first_folder_wrapper(const std::string& userLogin,const std::string& password,const std::string& public_key)
    {
        if (ffc.get() == NULL)
        {
            ffc.reset(new FirstFolderCreatorImpl());
        }
        ffc.get()->create_first_folder(userLogin,password,public_key);
    };

    static void close_wrapper()
    {
        if (ffc.get() == NULL)
        {
            return;
        }
        ffc.get()->close();
    };
};


void    FirstFolderCreator::create_first_folder(const std::string& userLogin,const std::string& password,const std::string& public_key)
{
    FFCWrapper::getThreadPool().schedule(boost::bind(&FFCWrapper::create_first_folder_wrapper,userLogin,password,public_key));
}

void    FirstFolderCreator::close()
{
    FFCWrapper::getThreadPool().schedule(boost::bind(&FFCWrapper::close_wrapper));
    FFCWrapper::getThreadPool().wait();
}
