#include <vector>
#include <string>
/*
 * getNotificationLiterals.cpp

 *
 *  Created on: 14 авг. 2012
 *      Author: fireballdark
 */


#include "getNotificationLiterals.h"

const std::vector<std::string>& getNotifyLiterals()
{
    static std::vector<std::string> notifyLiterals;

    if (notifyLiterals.empty())
    {
        notifyLiterals.push_back("news");
        notifyLiterals.push_back("outofstorage");
        notifyLiterals.push_back("beginnertips");
        notifyLiterals.push_back("cabinetactivity");
        notifyLiterals.push_back("newinvites");
        notifyLiterals.push_back("newdiscussions");
        notifyLiterals.push_back("newfiles");
    }
    return notifyLiterals;
}
