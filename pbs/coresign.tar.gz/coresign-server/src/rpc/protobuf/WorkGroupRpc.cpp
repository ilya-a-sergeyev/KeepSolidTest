/*
 * WorkGroupRpc.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */


#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "logic/WorkGroupLogic.h"
#include "types/structs_to_protobuf.h"



rpc_status_code_struct ProtobufZmqRpc::workgroupsList(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupsList");

    rpc::WorkGroupsListRequest   input;
    rpc::WorkGroupsListResponse*  output = response.mutable_workgroups_list();
    response.set_message_type(RPC_WORKGROUPS_LIST);

    do
    {
        if (request.has_workgroups_list())
        {
            input = request.workgroups_list();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_filter())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        rpc::Filter workgroupsFilter         = input.filter();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupsList function called with [%s] filter %i", sessionId.c_str(), workgroupsFilter);

        WorkGroupsInfoList  workgroupsInfoList;
        InviteInfoList      inviteInfoList;
        int64_t   lastEventId = -1;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupsList(context, (int)workgroupsFilter, workgroupsInfoList, inviteInfoList, lastEventId);


        if (resultStatus != status_success)
        {
            break;
        }

        LOG_ABSOLUTE("WorkGroupsList got %zi workgroups and %zi invites", workgroupsInfoList.size(), inviteInfoList.size());

        for (WorkGroupsInfoList::iterator i = workgroupsInfoList.begin() ; i!= workgroupsInfoList.end() ; i++)
        {
            rpc::WorkGroupInfo* workgroupInfo = output->add_workgroup_info_list();
            convert_workgroupinfo(*i,workgroupInfo);
        }

        for (InviteInfoList::iterator i = inviteInfoList.begin() ; i!= inviteInfoList.end() ; i++)
        {
            rpc::WorkGroupInvite* workgroupInvite = output->add_invite_list();
            convert_inviteinfo(*i,workgroupInvite);
        }

        output->set_last_event_id(lastEventId);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupsList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupInfo(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupInfo");

    rpc::WorkGroupInfoRequest   input;
    rpc::WorkGroupInfoResponse*  output = response.mutable_workgroup_info();
    response.set_message_type(RPC_WORKGROUP_INFO);

    do
    {
        if (request.has_workgroup_info())
        {
            input = request.workgroup_info();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id    = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupInfo function called with [%s] for %lli", sessionId.c_str(), workgroup_id);

        WorkGroupInfo   workgroupInfo_;
        InviteInfoList  inviteInfoList;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupInfo(context, workgroup_id, workgroupInfo_, inviteInfoList);
        if (resultStatus != status_success)
        {
            break;
        }

        rpc::WorkGroupInfo* workgroupInfo = output->mutable_workgroup_info();
        convert_workgroupinfo(workgroupInfo_,workgroupInfo);

        for (InviteInfoList::iterator i = inviteInfoList.begin() ; i!= inviteInfoList.end() ; i++)
        {
            rpc::WorkGroupInvite* workgroupInvite = output->mutable_invite_info();
            convert_inviteinfo(*i,workgroupInvite);
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupInfo function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupCoworkersList(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupCoworkersList");

    rpc::WorkGroupCoworkersListRequest   input;
    rpc::WorkGroupCoworkersListResponse* output = response.mutable_workgroup_coworkers_list();
    response.set_message_type(RPC_WORKGROUP_COWORKERS_LIST);

    do
    {
        if (request.has_workgroup_coworkers_list())
        {
            input = request.workgroup_coworkers_list();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id        = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupCoworkersList function called with [%s] and workgroup %lli", sessionId.c_str(), workgroup_id);

        UserLoginList userEmails;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupCoworkersList(context, workgroup_id, userEmails);

        if (resultStatus != status_success)
        {
            break;
        }

        for (UserLoginList::iterator i = userEmails.begin() ; i!= userEmails.end() ; i++)
        {
            rpc::WorkGroupCoworkersListResponse_UserInfo* userinfo = output->add_user_info_list();
            userinfo->set_user_login           ((*i));
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupCoworkersList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupCoworkersExtra(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupCoworkersExtra");

    rpc::WorkGroupCoworkersExtraRequest   input;
    rpc::WorkGroupCoworkersExtraResponse* output = response.mutable_workgroup_coworkers_extra();
    response.set_message_type(RPC_WORKGROUP_COWORKERS_LIST_EXTRA);

    do
    {
        if (request.has_workgroup_coworkers_extra())
        {
            input = request.workgroup_coworkers_extra();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id            = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupCoworkersExtra function called with [%s] and workgroup %lli", sessionId.c_str(), workgroup_id);

        UserWorkGroupInfoList userWorkGroupInfo;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupCoworkersExtra(context, workgroup_id, userWorkGroupInfo);

        if (resultStatus != status_success)
        {
            break;
        }

        for (UserWorkGroupInfoList::iterator i = userWorkGroupInfo.begin() ; i!= userWorkGroupInfo.end() ; i++)
        {
            rpc::WorkGroupCoworkersExtraResponse_UserInfo* userinfo = output->add_user_info_list();
            userinfo->set_user_login           ((*i).login);
            userinfo->set_first_name           ((*i).first_name);
            userinfo->set_last_name            ((*i).last_name);
            userinfo->set_user_pic             ((*i).user_pic);
            userinfo->set_invite_accepted      ((*i).invite_accepted);
            userinfo->set_access_mode        ((*i).access_mode);
            userinfo->set_is_dummy             ((*i).is_dummy);
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupCoworkersExtra function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupCoworkersAll(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupCoworkersAll");

    rpc::WorkGroupCoworkersAllRequest   input;
    rpc::WorkGroupCoworkersAllResponse* output = response.mutable_workgroup_coworkers_all();
    response.set_message_type(RPC_WORKGROUP_COWORKERS_LIST_ALL);

    do
    {
        if (request.has_workgroup_coworkers_all())
        {
            input = request.workgroup_coworkers_all();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_exclude_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id            = input.workgroup_exclude_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupCoworkersAll function called with [%s] and workgroup %lli", sessionId.c_str(), workgroup_id);

        UserLoginList userEmails;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupCoworkersAll(context, workgroup_id, userEmails);

        if (resultStatus != status_success)
        {
            break;
        }

        for (UserLoginList::iterator i = userEmails.begin() ; i!= userEmails.end() ; i++)
        {
            rpc::WorkGroupCoworkersAllResponse_UserInfo* userinfo = output->add_user_info_list();
            userinfo->set_user_login           ((*i));
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupCoworkersAll function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupCoworkersAllEx(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupCoworkersAllEx");

    rpc::WorkGroupCoworkersAllExRequest   input;
    rpc::WorkGroupCoworkersAllExResponse* output = response.mutable_workgroup_coworkers_all_ex();
    response.set_message_type(RPC_WORKGROUP_COWORKERS_LIST_ALL_EX);

    do
    {
        if (request.has_workgroup_coworkers_all_ex())
        {
            input = request.workgroup_coworkers_all_ex();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_exclude_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id        = input.workgroup_exclude_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupCoworkersAllEx function called with [%s] and workgroup %lli", sessionId.c_str(), workgroup_id);

        UserWorkGroupInfoList userWorkGroupInfo;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupCoworkersAllEx(context, workgroup_id, userWorkGroupInfo);

        if (resultStatus != status_success)
        {
            break;
        }

        for (UserWorkGroupInfoList::iterator i = userWorkGroupInfo.begin() ; i!= userWorkGroupInfo.end() ; i++)
        {
            rpc::WorkGroupCoworkersAllExResponse_UserInfo* userinfo = output->add_user_info_list();
            userinfo->set_user_login           ((*i).login);
            userinfo->set_first_name           ((*i).first_name);
            userinfo->set_last_name            ((*i).last_name);
            userinfo->set_user_pic             ((*i).user_pic);
            userinfo->set_is_dummy             ((*i).is_dummy);
            userinfo->set_public_key           ((*i).public_key);
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupCoworkersAllEx function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupKickUser(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupKickUser");

    rpc::WorkGroupKickUserRequest   input;
    rpc::WorkGroupKickUserResponse* output = response.mutable_workgroup_kick_user();
    response.set_message_type(RPC_WORKGROUP_KICK_USER);

    do
    {
        if (request.has_workgroup_kick_user())
        {
            input = request.workgroup_kick_user();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id        = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupKickUser function called with [%s] for workgroup %lli", sessionId.c_str(), workgroup_id);


        LoginForKickList kickEmailList;

        if (input.user_logins_size() > 0)
        {
            for (int i=0; i< input.user_logins_size(); i++)
            {
            	//TODO:
            	//unused parameter keep_local_data on  input.user_logins!!!
                std::string email = input.user_logins(i).user_login();
                boost::algorithm::to_lower(email);
                if (!is_utf8_string(email))
                {
                    resultStatus = status_invalid_utf8;
                    break;
                }

                LOG_ABSOLUTE("WorkGroupKickUser function called for workgroup %lli with kicked user %s", workgroup_id, email.c_str());
                LoginForKick kickEmail(email, input.user_logins(i).keep_local_data());
                kickEmailList.push_back(kickEmail);
            }
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        ReturnStatusList returnStatusList;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupKickUserMass(context, workgroup_id, kickEmailList, returnStatusList);

        for (ReturnStatusList::iterator i = returnStatusList.begin(); i!=returnStatusList.end(); i++)
        {
            rpc::PerUserStatus* status = output->add_status_codes();
            status->set_login       ((*i).login);
            status->set_error_code   ((*i).returnStatus);
        }

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupKickUser function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupCreate(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupCreate");

    rpc::WorkGroupCreateRequest   input;
    rpc::WorkGroupCreateResponse*  output = response.mutable_workgroup_create();
    response.set_message_type(RPC_WORKGROUP_CREATE);

    do
    {
        if (request.has_workgroup_create())
        {
            input = request.workgroup_create();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_name()
                || !input.has_description() || !input.has_key())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();

        WorkGroupInfo workgroupInfoPut, workgroupInfoGet;
        workgroupInfoPut.workgroup_name      = input.workgroup_name();
        workgroupInfoPut.description      = input.description();
        workgroupInfoPut.key   = input.key();
        workgroupInfoPut.key_signature = input.key_signature();
        workgroupInfoPut.key_salt = input.key_salt();
        workgroupInfoPut.encryption_type  = (workgroup_enc_type)input.encryption_type();
        workgroupInfoPut.encryption_algo  = (workgroup_enc_algo)input.encryption_algo();
        workgroupInfoPut.access_mode      = -1;    //for creator
        workgroupInfoPut.type                   = input.has_workgroup_type() ? input.workgroup_type() : -1;
        workgroupInfoPut.metadata               = input.has_workgroup_metadata() ? input.workgroup_metadata() : "";

        if (!is_utf8_string(sessionId) || !is_utf8_string(workgroupInfoPut.workgroup_name) || !is_utf8_string(workgroupInfoPut.description)
                || !is_utf8_string(workgroupInfoPut.key) || !is_utf8_string(workgroupInfoPut.key_signature) || !is_utf8_string(workgroupInfoPut.key_salt))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupCreate function called with [%s] : [%s], key [%s]:[%s], enctype %i encalgo %i",
        		workgroupInfoPut.workgroup_name.c_str(),
        		workgroupInfoPut.description.c_str(), workgroupInfoPut.key.empty()?"EMPTY":"FULL",
        				workgroupInfoPut.key_signature.empty()?"EMPTY":"FULL", workgroupInfoPut.encryption_type, workgroupInfoPut.encryption_algo);

        int64_t workgroup_id = -1;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupCreate(context, workgroupInfoPut, workgroupInfoGet, workgroup_id);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_workgroup_id(workgroup_id);
        output->set_creation_date(workgroupInfoGet.creation_date);
        output->set_creation_date_str(workgroupInfoGet.creation_date_str);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupCreate function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupDelete(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupDelete");

    rpc::WorkGroupDeleteRequest   input;
    rpc::WorkGroupDeleteResponse*  output = response.mutable_workgroup_delete();
    response.set_message_type(RPC_WORKGROUP_DELETE);

    do
    {
        if (request.has_workgroup_delete())
        {
            input = request.workgroup_delete();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id() || !input.has_delete_now())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id    = input.workgroup_id();
        bool            deleteNow       = input.delete_now();
        bool            keep_data       = input.keep_local_data();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupDelete function called for workgroup %lli with param %s", workgroup_id, deleteNow ? "YES" : "NO");
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupDelete(context, workgroup_id, deleteNow, keep_data);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupDelete function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupUndelete(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupUndelete");

    rpc::WorkGroupUndeleteRequest   input;
    rpc::WorkGroupUndeleteResponse*  output = response.mutable_workgroup_undelete();
    response.set_message_type(RPC_WORKGROUP_UNDELETE);

    do
    {
        if (request.has_workgroup_undelete())
        {
            input = request.workgroup_undelete();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id        = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupUndelete function called for workgroup %lli", workgroup_id);
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupUndelete(context, workgroup_id);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupUndelete function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupRename(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupRename");

    rpc::WorkGroupRenameRequest   input;
    rpc::WorkGroupRenameResponse*  output = response.mutable_workgroup_rename();
    response.set_message_type(RPC_WORKGROUP_RENAME);

    do
    {
        if (request.has_workgroup_rename())
        {
            input = request.workgroup_rename();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id() || !input.has_workgroup_name_new())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id        = input.workgroup_id();
        std::string     workgroupNameNew   = input.workgroup_name_new();

        if (!is_utf8_string(sessionId) || !is_utf8_string(workgroupNameNew))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        if (workgroupNameNew.empty())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string workgroupNameNew_hex = digest_to_x_hex_string(workgroupNameNew);
        LOG_ABSOLUTE("WorkGroupRename function called for workgroup %lli with sizes name [%zi]:[%zi]", workgroup_id, workgroupNameNew.size(), workgroupNameNew_hex.size());
        LOG_ABSOLUTE("WorkGroupRename function called for workgroup %lli with name [%s]:[%s]", workgroup_id, workgroupNameNew.c_str(), workgroupNameNew_hex.c_str());
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupRename(context, workgroup_id, workgroupNameNew);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupRename function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupInvite(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupInvite");

    rpc::WorkGroupInviteRequest   input;
    rpc::WorkGroupInviteResponse*  output = response.mutable_workgroup_invite();
    response.set_message_type(RPC_WORKGROUP_INVITE);

    do
    {
        if (request.has_workgroup_invite())
        {
            input = request.workgroup_invite();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id        = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        WorkGroupInvites workgroupInvites;

        if (input.invites_size() > 0)
        {
            for (int i=0; i< input.invites_size(); i++)
            {
                WorkGroupInvite fi;
                fi.access_mode      = input.invites(i).access_mode();
                fi.invitee_login    = input.invites(i).invitee_login();
                fi.key              = input.invites(i).key();
                fi.social_id        = input.invites(i).social_id();
                fi.social_type      = input.invites(i).social_type();
                fi.social_token     = input.invites(i).social_token();

                boost::algorithm::to_lower(fi.invitee_login);
                if (!is_utf8_string(fi.invitee_login) || !is_utf8_string(fi.key))
                {
                    resultStatus = status_invalid_utf8;
                    break;
                }

                LOG_ABSOLUTE("WorkGroupInvite function called for workgroup %lli with new invitee %s accessMode %lli key %s", workgroup_id, fi.invitee_login.c_str(), fi.access_mode, fi.key.empty()?"EMPTY":"FULL");
                workgroupInvites.push_back(fi);
            }
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        ReturnStatusList returnStatusList;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupInviteMass(context, workgroup_id, workgroupInvites, returnStatusList);

        for (ReturnStatusList::iterator i = returnStatusList.begin(); i!=returnStatusList.end(); i++)
        {
            rpc::PerUserStatus* status = output->add_status_codes();
            status->set_login       ((*i).login);
            status->set_error_code   ((*i).returnStatus);
        }

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupInvite function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupSubscribe(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupSubscribe");

    rpc::WorkGroupSubscribeRequest   input;
    rpc::WorkGroupSubscribeResponse*  output = response.mutable_workgroup_subscribe();
    response.set_message_type(RPC_WORKGROUP_SUBSCRIBE);

    do
    {
        if (request.has_workgroup_subscribe())
        {
            input = request.workgroup_subscribe();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_invite_id() || !input.has_accept_invite())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        std::string     inviteId        = input.invite_id();
        bool            acceptInvite    = input.accept_invite();

        if (!is_utf8_string(sessionId) || !is_utf8_string(inviteId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupSubscribe function called with [%s], invitation %s was accepted: %s", sessionId.c_str(), inviteId.c_str(), acceptInvite ? "YES" : "NO");
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupSubscribe(context, inviteId, acceptInvite);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupSubscribe function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupUnsubscribe(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupUnsubscribe");

    rpc::WorkGroupUnsubscribeRequest   input;
    rpc::WorkGroupUnsubscribeResponse*  output = response.mutable_workgroup_unsubscribe();
    response.set_message_type(RPC_WORKGROUP_UNSUBSCRIBE);

    do
    {
        if (request.has_workgroup_unsubscribe())
        {
            input = request.workgroup_unsubscribe();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id        = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupUnsubscribe function called with [%s], workgroup %lli", sessionId.c_str(), workgroup_id);
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupUnsubscribe(context, workgroup_id);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupUnsubscribe function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupSetAccess(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupSetAccess");

    rpc::WorkGroupSetAccessRequest   input;
    rpc::WorkGroupSetAccessResponse*  output = response.mutable_workgroup_set_access();
    response.set_message_type(RPC_WORKGROUP_SET_ACCESS);

    do
    {
        if (request.has_workgroup_set_access())
        {
            input = request.workgroup_set_access();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();
        int64_t  workgroup_id           = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        WorkGroupInvites workgroupInvites;
        if (input.accesses_size() > 0)
        {
            for (int i=0; i< input.accesses_size(); i++)
            {
                WorkGroupInvite fi;
                fi.access_mode     = input.accesses(i).access_mode();
                fi.invitee_login     = input.accesses(i).login();

                boost::algorithm::to_lower(fi.invitee_login);
                if (!is_utf8_string(fi.invitee_login))
                {
                    resultStatus = status_invalid_utf8;
                    break;
                }

                LOG_ABSOLUTE("WorkGroupSetAccess function called for workgroup %lli with email %s accessMode %lli", workgroup_id, fi.invitee_login.c_str(), fi.access_mode);
                workgroupInvites.push_back(fi);
            }
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        ReturnStatusList returnStatusList;

        LOG_ABSOLUTE("WorkGroupSetAccess function called with [%s] workgroup %lli", sessionId.c_str(), workgroup_id);
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupSetAccessMass(context,workgroup_id,workgroupInvites,returnStatusList);

        for (ReturnStatusList::iterator i = returnStatusList.begin(); i!=returnStatusList.end(); i++)
        {
            rpc::PerUserStatus* status = output->add_status_codes();
            status->set_login       ((*i).login);
            status->set_error_code   ((*i).returnStatus);
        }

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupSetAccess function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::workgroupInvitesList(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupInvitesList");

    rpc::WorkGroupInvitesListRequest   input;
    rpc::WorkGroupInvitesListResponse*  output = response.mutable_workgroup_invites_list();
    response.set_message_type(RPC_WORKGROUP_INVITES_LIST);

    do
    {
        if (request.has_workgroup_invites_list())
        {
            input = request.workgroup_invites_list();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id            = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupInvitesList function called with [%s] for workgroup %lli", sessionId.c_str(), workgroup_id);

        InviteInfoList inviteInfoList;
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupInvitesList(context, workgroup_id, inviteInfoList);

        if (resultStatus != status_success)
        {
            break;
        }

        for (InviteInfoList::iterator i = inviteInfoList.begin() ; i!= inviteInfoList.end() ; i++)
        {
            rpc::WorkGroupInvite* workgroupInvite = output->add_invites_list();
            convert_inviteinfo(*i,workgroupInvite);
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupInvitesList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}


rpc_status_code_struct ProtobufZmqRpc::workgroupMetadataUpdate(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("WorkGroupMetadataUpdate");

    rpc::WorkGroupMetadataUpdateRequest   input;
    rpc::WorkGroupMetadataUpdateResponse*  output = response.mutable_workgroup_metadata_update();
    response.set_message_type(RPC_WORKGROUP_METADATA_UPDATE);

    do
    {
        if (request.has_workgroup_metadata_update())
        {
            input = request.workgroup_metadata_update();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_workgroup_metadata_new())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId           = input.session_id();
        int64_t workgroup_id      = input.workgroup_id();
        std::string metadata_new        = input.workgroup_metadata_new();

        if (!is_utf8_string(sessionId) || !is_utf8_string(metadata_new))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("WorkGroupMetadataUpdate function called with [%s] for workgroup %lli metadata [%s]", sessionId.c_str(), workgroup_id, metadata_new.c_str());
        context.session_id = sessionId;
        resultStatus = WorkGroupLogic::workgroupMetadataUpdate(context, workgroup_id, metadata_new);

        if (resultStatus != status_success)
        {
            break;
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("WorkGroupMetadataUpdate function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}


