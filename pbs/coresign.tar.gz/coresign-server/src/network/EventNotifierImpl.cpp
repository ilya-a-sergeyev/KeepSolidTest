/*
 * EventNotifierImpl.cpp
 *
 *  Created on: Feb 3, 2013
 *      Author: fireballdark
 */

#include "EventNotifierImpl.h"
#include <sstream>
#include <protobuf/util/cpp/transport_frame.pb.h>
#include <sutil/logging.h>
#include "conf/Globals.h"
#include "conf/DaemonParams.h"



EventNotifierImpl::EventNotifierImpl():
    sender(*Globals::get_globals().getZMQContext(), ZMQ_PUB)
{
    std::string url = "tcp://*";
    int port = DaemonParams::get_daemon_params().getNotificationEmitPort();

    std::stringstream ss;
    ss<<url<<":"<<port;
    try
    {
        sender.bind(ss.str().c_str());
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure connecting as EventNotifier server [%s: %s]",ss.str().c_str(),e.what());
    }
}

bool EventNotifierImpl::notify_event(int64_t userId, int64_t eventType)
{
    bool result = false;

    try
    {
        rpc::TransportFrame notification;
        notification.set_recipient_id(userId);
        notification.set_data_enc(&eventType,sizeof(eventType));

        std::string serialized;
        notification.SerializeToString(&serialized);

        zmq::message_t message(serialized.size());
        memcpy((void*) message.data (), serialized.c_str(), serialized.size());
        result = sender.send(message);

        LOG_ABSOLUTE("Notification message [%lli:%lli] was sent.", userId, eventType);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Got exception [%s] trying to send EventNotifier message [%lli:%lli]", e.what(), userId, eventType);
    }

    return result;
}

void EventNotifierImpl::close()
{
    try
    {
        sender.close();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure closing socket as EventNotifier server [%s]",e.what());
    }
}

EventNotifierImpl::~EventNotifierImpl()
{
    try
    {
        sender.close();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure closing socket as EventNotifier server [%s]",e.what());
    }
}
