#pragma once

#include <curl/curl.h>
#include <curl/easy.h>
#include <string>
#include <map>
#include <types/keyvalue.h>

class CurlUploaderLight
{
public:
    //Data type
    //Methods section
    explicit CurlUploaderLight(const std::string& certificateFolder, bool verifyCerts = true);
    CurlUploaderLight() = delete;
    CurlUploaderLight(const CurlUploaderLight&) = delete;
    CurlUploaderLight(CurlUploaderLight&&) = delete;
    CurlUploaderLight& operator=(const CurlUploaderLight&) = delete;
    CurlUploaderLight& operator=(CurlUploaderLight&&) = delete;
    virtual ~CurlUploaderLight();

    static CurlUploaderLight& get_thread_local_ptr();

    CURLcode            set_timeout         (int sec);
    void                set_check_ssl       (bool check_ssl);

    CURLcode            upload_file         (const std::string& fileName, const std::string& uploadUrl, const std::string& fileHash);
    CURLcode            download_file       (const std::string& save_fileName, const std::string& downloadUrl);

    /**
    *   @brief                      Upload file using HTTP POST request to server
    *   @param  fileName            Path to the file to upload
    *   @param  serverUrl           Address server for uploading
    *   @param  params              Map of required POST fields.
    *                               Example: "sid":"2oK9RoTxT54YPVyS97ZEMGfm06dYGpK6UIckrAFGQHLxGg_zRRVA3d+1WEH23MdL"
    *   @param  uploaded_file_url   Returned url of uploaded file if operation was successful
    *   @return                     TRUE if operation was successful, otherwise FALSE
    **/
    CURLcode            upload_file         (const std::string& fileName, const std::string& serverUrl, const KeyValue& params, std::string& uploaded_file_url);
    CURLcode            post_request        (const std::string& serverUrl, const KeyValue& params, std::string& result, const std::string& basic_auth = "");
    CURLcode            post_request_base64 (const std::string& serverUrl, const KeyValue& params, std::string& result, const std::string& basic_auth = "");
    CURLcode            get_request         (const std::string& serverUrl, const KeyValue& params, std::string& result, const std::string& basic_auth = "");
    CURLcode            get_file            (const std::string& serverUrl, const KeyValue& params, const std::string& save_fileName, const std::string& basic_auth = "");

    std::string         getSertificateFolder() const { return m_CertificateFolder; }

private:
    //Methods section
    static size_t                 upload_write_data    (void *data, size_t size, size_t nmemb, void *destination);
    static size_t                 upload_header_data   (void *data, size_t size, size_t nmemb, void *destination);
    static size_t                 upload_read_file     (void *data, size_t size, size_t nmemb, void *file);
    static size_t                 download_write_file  (void *data, size_t size, size_t nmemb, void *file);
    static size_t                 download_write_data  (void *data, size_t size, size_t nmemb, void *destination);
    void                          clean_data           ();
    void                          prepare_upload       ();
    void                          prepare_download     ();

    static int                    upload_progress      (void*, double, double, double ultotal, double ulnow);
    static int                    download_progress    (void*, double dltotal, double dlnow, double, double);

    static int                    handle_trace         (CURL *handle, curl_infotype type, char *data, size_t size, void *userp);

    //Members section
    CURL*                         curl_obj;
    std::string                   reply_data;
    std::string                   header_data;
    static bool                   bCurlInitialized;
    struct curl_httppost*         formpost;
    struct curl_httppost*         lastptr;
    std::string                   m_CertificateFolder;
    char                          mErrorBuffer[CURL_ERROR_SIZE];

    std::string                   m_curFileName;

    double                        m_Ultotal;
    double                        m_Ulnow;
    double                        m_Dltotal;
    double                        m_Dlnow;
};
