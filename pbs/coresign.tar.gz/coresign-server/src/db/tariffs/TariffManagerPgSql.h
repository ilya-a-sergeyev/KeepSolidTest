/*
 * TariffManagerPgSql.h
 *
 *  Created on: 6 апр. 2012
 *      Author: fireballdark
 */

#ifndef TARIFFMANAGERPGSQL_H_
#define TARIFFMANAGERPGSQL_H_

#include "types/user_info.h"
#include "types/status_codes.h"

class TariffManagerPgSql
{
public:
    static rpc_status_code     get_user_limits         (int64_t userId, TariffLimits& userLimits);
};

#endif /* TARIFFMANAGERPGSQL_H_ */
