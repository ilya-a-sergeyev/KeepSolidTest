/*
 * FileManagerPgSql.h
 *
 *  Created on: 29 квіт. 2011
 *      Author: fireball
 */

#ifndef FILEMANAGERPGSQL_H_
#define FILEMANAGERPGSQL_H_

#include "types/file_folder_info.h"
#include "types/status_codes.h"

class FileManagerPgSql
{
public:
    static rpc_status_code     list_files           (int64_t user_id, bool showDeleted, int64_t workgroup_id, FilesInfoList& filesInfo, int64_t& lastEventId);
    static rpc_status_code     list_all_files       (int64_t user_id, int64_t workgroup_id, FilesInfoList& filesInfo, int64_t& lastEventId);
    static rpc_status_code     list_files_parent    (int64_t user_id, bool showDeleted, int64_t workgroup_id, int64_t parentId, FilesInfoList& filesInfo, int64_t& lastEventId);
    static rpc_status_code     list_all_files_parent(int64_t user_id, int64_t workgroup_id, int64_t parentId, FilesInfoList& filesInfo, int64_t& lastEventId);
    static rpc_status_code     get_history          (int64_t user_id, bool showDeleted, int64_t workgroup_id, int64_t fileId, FilesInfoList& filesInfo);
    static rpc_status_code     get_full_history     (int64_t user_id, int64_t workgroup_id, int64_t fileId, FilesInfoList& filesInfo);
    static rpc_status_code     get_files_info       (int64_t user_id, FilesInfoList& filesInfo);
    static rpc_status_code     get_approved_file_info(int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     get_short_directory_info(int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     get_exact_file_info  (int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     create_file          (int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     create_file_rev      (int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     create_file_to_delete(int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     rename_file          (int64_t user_id, int64_t workgroup_id, int64_t fileId, int64_t revision, const std::string& fileNamenew, int64_t& revision_ret);
    static rpc_status_code     approve_file         (int64_t user_id, const FileInfo& fileInfo, bool& is_first);
    static rpc_status_code     remove_file          (int64_t user_id, int64_t workgroup_id, int64_t fileId);
    static rpc_status_code     remove_file_now      (int64_t user_id, int64_t workgroup_id, int64_t fileId);
    static rpc_status_code     remove_file          (int64_t user_id, int64_t workgroup_id, int64_t fileId, int64_t revision);
    static rpc_status_code     remove_file_now      (int64_t user_id, int64_t workgroup_id, int64_t fileId, int64_t revision);
    static rpc_status_code     remove_file_to_delete(int64_t user_id, int64_t workgroup_id);
    static rpc_status_code     remove_file_to_delete(int64_t user_id, int64_t workgroup_id, int64_t fileId);
    static rpc_status_code     remove_file_to_delete(int64_t user_id, int64_t workgroup_id, int64_t fileId, int64_t revision);
    static rpc_status_code     undelete_file        (int64_t user_id, int64_t workgroup_id, int64_t fileId);
    static rpc_status_code     undelete_file        (int64_t user_id, int64_t workgroup_id, int64_t fileId, int64_t revision);
    static rpc_status_code     get_file_by_name     (int64_t user_id, FileInfo& fileInfo);
    static rpc_status_code     get_directory_children(int64_t user_id, int64_t workgroup_id, int64_t fileId, std::vector<int64_t>& children);
    static rpc_status_code     search_file_in_folder(int64_t user_id, int64_t workgroup_id, const std::string& searchString, FilesInfoList& filesInfo);
    static rpc_status_code     search_file          (int64_t user_id, const std::string& searchString, FilesInfoList& filesInfo);

    static rpc_status_code     count_files          (int64_t user_id, int64_t workgroup_id, int64_t& count);
    static rpc_status_code     count_files_for_wgs  (int64_t user_id, bool showDeletedWgs, std::map<int64_t,int64_t>& count);
    static rpc_status_code     count_files_for_wgs_all  (int64_t user_id, std::map<int64_t,int64_t>& count);

    static int                 get_fileid_by_hash   (const std::string& fileHash, int64_t fileSize, int64_t& fileId);
};

#endif /* FILEMANAGERPGSQL_H_ */
