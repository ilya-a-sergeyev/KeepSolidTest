/*
 * FolderManagerPgSql.cpp
 *
 *  Created on: 28 квіт. 2011
 *      Author: fireball
 */

#include "FolderManagerPgSql.h"
#include <sutil/logging.h>
#include <pqxx/transaction.hxx>
#include <pqxx/result.hxx>
#include <pqxx/prepared_statement.hxx>
#include <exception>
#include <cstdlib>
#include "db/PgSqlHelper.h"

rpc_status_code WorkGroupManagerPgSql::share_folder(int64_t user_id, int64_t workgroup_id, int64_t recipientId, const std::string& recipientEmail)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {

            if (pgSqlHelper().register_prep_statement("shareFolder"))
            {
                pg_connection->prepare  ("shareFolder",
                                         "INSERT INTO WorkGroupsAccess(user_id, login, workgroup_id, access_mode, invite_accepted, "
                                         "encryption_key ) VALUES ($1, $2, $3, $4, $5, '') RETURNING workgroup_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "ShareFolder");
            pqxx::result query_result = pg_transaction.prepared("shareFolder")(recipientId)(recipientEmail)(workgroup_id)(0)(false).exec();

            if (!query_result.size())
            {
                LOG_ERROR("Failure: trying to share folder %lli for user %lli",workgroup_id, user_id);
                break;
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate folder %lli for user %lli err: %s",workgroup_id,recipientId,e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to create folder %lli for user %lli err: %s",workgroup_id,recipientId,e.base().what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::create_folder(int64_t user_id, const std::string& login, const WorkGroupInfo& folderInfo, int64_t& workgroup_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {

            if (pgSqlHelper().register_prep_statement("createFolder"))
            {
                pg_connection->prepare  ("createFolder",
                                         "INSERT INTO WorkGroups(creator_id, creator_login, workgroup_name, description, encryption_type, "
                                         "encryption_algo, key_signature, key_salt, type, metadata) VALUES "
                                         "($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING workgroup_id;");
            }
            pqxx::work pg_transaction(*pg_connection, "CreateFolder");
            pqxx::result query_result = pg_transaction.prepared("createFolder")(user_id)(login)(folderInfo.workgroup_name)(folderInfo.description)
                    ((int)folderInfo.encryption_type)((int)folderInfo.encryption_algo)(folderInfo.key_signature)(folderInfo.key_salt)
                    (folderInfo.type)(folderInfo.metadata).exec();

            if (!query_result.size())
            {
                LOG_ERROR("Failure: trying to create folder %s for user %lli",folderInfo.workgroup_name.c_str(), user_id);
                break;
            }

            query_result.begin()["workgroup_id"].to(workgroup_id);

            //std::string query_new = "INSERT INTO WorkGroupsAccess(user_id, workgroup_id, readFiles, changeFiles, createFiles, deleteFiles, shareFolder, unshareFolder, copyFolder, removeFolder ) VALUES ($1 , $2 , true, true, true, true, true, true, true, true) RETURNING workgroup_id;";
            if (pgSqlHelper().register_prep_statement("createFolderAccess"))
            {
                pg_connection->prepare  ("createFolderAccess",
                                         "INSERT INTO WorkGroupsAccess(user_id, login, workgroup_id, access_mode, invite_accepted, "
                                         "encryption_key ) VALUES ($1 , $2 , $3, $4, $5, $6);");
            }
            pg_transaction.prepared("createFolderAccess")(user_id)(login)(workgroup_id)(folderInfo.access_mode)(true)(folderInfo.key).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate folder %s for user %lli err: %s",folderInfo.workgroup_name.c_str(),user_id,e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const pqxx::pqxx_exception& e)
        {
            LOG_ERROR("Failure: trying to create folder %s for user %lli err: %s",folderInfo.workgroup_name.c_str(),user_id,e.base().what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::remove_folder(int64_t user_id, int64_t workgroup_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "DeleteFolder");

            std::stringstream query;
            query<<"UPDATE WorkGroups SET is_deleted = true, deletion_date = NOW() WHERE workgroup_id= ";
            query<<workgroup_id;
            query<<"; ";
            query<<"UPDATE WorkGroupsAccess SET is_deleted = true WHERE workgroup_id=";
            query<<workgroup_id;
            query<<"; ";

            pg_transaction.exec(query);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::remove_folder_now(int64_t user_id, int64_t workgroup_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "DeleteFolderNow");

            if (pgSqlHelper().register_prep_statement("deleteFolderAccessNow"))
            {
                pg_connection->prepare  ("deleteFolderAccessNow",
                                         "DELETE FROM WorkGroupsAccess WHERE workgroup_id=$1;");
            }
            pg_transaction.prepared("deleteFolderAccessNow")(workgroup_id).exec();

            if (pgSqlHelper().register_prep_statement("deleteFolderNow"))
            {
                pg_connection->prepare  ("deleteFolderNow",
                                         "DELETE FROM WorkGroups WHERE workgroup_id=$1;");
            }

            pg_transaction.prepared("deleteFolderNow")(workgroup_id).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to delete folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::undelete_folder(int64_t user_id, int64_t workgroup_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            pqxx::work pg_transaction(*pg_connection, "UndeleteFolder");

            std::stringstream query;
            query<<"UPDATE WorkGroups SET is_deleted = false, deletion_date = NULL WHERE workgroup_id= ";
            query<<workgroup_id;
            query<<" AND is_deleted = true; ";
            query<<"UPDATE WorkGroupsAccess SET is_deleted = false WHERE workgroup_id=";
            query<<workgroup_id;
            query<<" AND is_deleted = true; ";

            pg_transaction.exec(query);

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to undelete folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::rename_folder(int64_t user_id, int64_t workgroup_id, const std::string& folderNameNew)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("renameFolder"))
            {
                pg_connection->prepare  ("renameFolder",
                                         "UPDATE WorkGroups SET workgroup_name = $2 WHERE workgroup_id=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "RenameFolder");
            pqxx::result query_result = pg_transaction.prepared("renameFolder")(workgroup_id)(folderNameNew).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate folder %s for user %lli err: %s",folderNameNew.c_str(),user_id,e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to rename folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_folder_coworkers(int64_t user_id, int64_t workgroup_id, UserLoginList& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFolderCoworkers"))
            {
                pg_connection->prepare  ("getFolderCoworkers",
                                         "SELECT login FROM WorkGroupsAccess WHERE workgroup_id = $1 GROUP BY login ORDER BY login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getFolderCoworkers");
            pqxx::result query_result = pg_transaction.prepared("getFolderCoworkers")(workgroup_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                userEmails.push_back(resi["login"].as<std::string>());
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_folder_coworkers_extra(int64_t user_id, int64_t workgroup_id, UserWorkGroupInfoList& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFolderCoworkersExtra"))
            {
                pg_connection->prepare  ("getFolderCoworkersExtra",
                                         "SELECT Users.user_id, WorkGroupsAccess.login, invite_accepted, is_dummy, first_name, "
                                         "last_name, access_mode, user_pic FROM WorkGroupsAccess INNER JOIN Users "
                                         "ON WorkGroupsAccess.user_id = Users.user_id WHERE workgroup_id = $1 "
                                         "ORDER BY WorkGroupsAccess.login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getFolderCoworkersExtra");
            pqxx::result query_result = pg_transaction.prepared("getFolderCoworkersExtra")(workgroup_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                UserWorkGroupInfo ufi;
                resi["user_id"].        to(ufi.user_id);
                resi["login"].          to(ufi.login);
                resi["first_name"].     to(ufi.first_name);
                resi["last_name"].      to(ufi.last_name);
                resi["is_dummy"].       to(ufi.is_dummy);
                resi["invite_accepted"].to(ufi.invite_accepted);
                resi["access_mode"].    to(ufi.access_mode);
                resi["user_pic"].       to(ufi.user_pic);
                userEmails.push_back(ufi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers_ex(int64_t user_id, int64_t exceptFolderId, UserWorkGroupInfoList& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllCoworkersExtraExcept"))
            {
                pg_connection->prepare  ("getAllCoworkersExtraExcept",
                                         "SELECT Users.user_id, Users.login, is_dummy, first_name, last_name, user_pic, public_key FROM Users INNER JOIN "
                                         "(SELECT user_id FROM WorkGroupsAccess INNER JOIN (SELECT workgroup_id "
                                         "FROM WorkGroupsAccess WHERE user_id = $1) AS ff ON WorkGroupsAccess.workgroup_id = ff.workgroup_id "
                                         "GROUP BY user_id "
                                         "EXCEPT "
                                         "SELECT user_id FROM WorkGroupsAccess WHERE workgroup_id = $2) AS fa "
                                         "ON fa.user_id=Users.user_id ORDER BY Users.login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getAllCoworkersExtraExcept");
            pqxx::result query_result = pg_transaction.prepared("getAllCoworkersExtraExcept")(user_id)(exceptFolderId).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                UserWorkGroupInfo ufi;
                resi["user_id"].     to(ufi.user_id);
                resi["login"].      to(ufi.login);
                resi["first_name"].  to(ufi.first_name);
                resi["last_name"].   to(ufi.last_name);
                resi["is_dummy"].    to(ufi.is_dummy);
                resi["user_pic"].    to(ufi.user_pic);
                resi["public_key"].  to(ufi.public_key);
                userEmails.push_back(ufi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query extra coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers_ex(int64_t user_id, UserWorkGroupInfoList& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllCoworkersExtra"))
            {
                pg_connection->prepare  ("getAllCoworkersExtra",
                                         "SELECT Users.user_id, Users.login, is_dummy, first_name, last_name, user_pic, public_key "
                                         "FROM Users INNER JOIN "
                                         "(SELECT user_id FROM WorkGroupsAccess INNER JOIN "
                                         "(SELECT workgroup_id FROM WorkGroupsAccess WHERE user_id = $1) "
                                         "AS ff ON WorkGroupsAccess.workgroup_id = ff.workgroup_id  GROUP BY user_id) AS fa "
                                         "ON fa.user_id=Users.user_id ORDER BY Users.login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getAllCoworkersExtra");
            pqxx::result query_result = pg_transaction.prepared("getAllCoworkersExtra")(user_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                UserWorkGroupInfo ufi;
                resi["user_id"].     to(ufi.user_id);
                resi["login"].      to(ufi.login);
                resi["first_name"].  to(ufi.first_name);
                resi["last_name"].   to(ufi.last_name);
                resi["is_dummy"].    to(ufi.is_dummy);
                resi["user_pic"].    to(ufi.user_pic);
                resi["public_key"].  to(ufi.public_key);
                userEmails.push_back(ufi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to extra folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers(int64_t user_id, UserLoginList& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllCoworkers"))
            {
                pg_connection->prepare  ("getAllCoworkers",
                                         "SELECT login FROM WorkGroupsAccess INNER JOIN "
                                         "(SELECT workgroup_id FROM WorkGroupsAccess WHERE user_id = $1) AS ff "
                                         "ON WorkGroupsAccess.workgroup_id = ff.workgroup_id GROUP BY login ORDER BY login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getFolderCoworkers");
            pqxx::result query_result = pg_transaction.prepared("getAllCoworkers")(user_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                userEmails.push_back(resi["login"].as<std::string>());
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers(int64_t user_id, int64_t exceptFolderId, UserLoginList& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllCoworkersExcept"))
            {
                pg_connection->prepare  ("getAllCoworkersExcept",
                                         "SELECT login FROM WorkGroupsAccess INNER JOIN "
                                         "(SELECT workgroup_id FROM WorkGroupsAccess WHERE user_id = $1) AS ff "
                                         "ON WorkGroupsAccess.workgroup_id = ff.workgroup_id "
                                         "EXCEPT "
                                         "SELECT login FROM WorkGroupsAccess WHERE workgroup_id = $2 ORDER BY login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getFolderCoworkersExcept");
            pqxx::result query_result = pg_transaction.prepared("getAllCoworkersExcept")(user_id)(exceptFolderId).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                userEmails.push_back(resi["login"].as<std::string>());
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers_ids(int64_t user_id, UserIdList& user_ids)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllCoworkersIds"))
            {
                pg_connection->prepare  ("getAllCoworkersIds",
                                         "SELECT user_id FROM WorkGroupsAccess INNER JOIN "
                                         "(SELECT workgroup_id FROM WorkGroupsAccess WHERE user_id = $1) "
                                         "AS ff ON WorkGroupsAccess.workgroup_id = ff.workgroup_id AND "
                                         "WorkGroupsAccess.invite_accepted=true GROUP BY user_id ORDER BY user_id;");
            }

            pqxx::work pg_transaction(*pg_connection, "getAllCoworkersIds");
            pqxx::result query_result = pg_transaction.prepared("getAllCoworkersIds")(user_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                int64_t uid;
                resi["user_id"].     to(uid);
                user_ids.push_back(uid);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to extra folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers_ids(int64_t user_id, int64_t workgroup_id, UserIdList& user_ids)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllCoworkersOnFolderIds"))
            {
                pg_connection->prepare  ("getAllCoworkersOnFolderIds",
                                         "SELECT user_id FROM WorkGroupsAccess WHERE workgroup_id = $1 ORDER BY user_id;");
            }

            pqxx::work pg_transaction(*pg_connection, "getAllCoworkersOnFolderIds");
            pqxx::result query_result = pg_transaction.prepared("getAllCoworkersOnFolderIds")(workgroup_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                int64_t uid;
                resi["user_id"].     to(uid);
                user_ids.push_back(uid);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to extra folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_invited_coworkers_ids(int64_t user_id, int64_t workgroup_id, UserIdList& user_ids)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getInvitedCoworkersOnFolderIds"))
            {
                pg_connection->prepare  ("getInvitedCoworkersOnFolderIds",
                                         "SELECT user_id FROM WorkGroupsAccess WHERE workgroup_id = $1 and invite_accepted = true "
                                         "ORDER BY user_id;");
            }

            pqxx::work pg_transaction(*pg_connection, "getInvitedCoworkersOnFolderIds");
            pqxx::result query_result = pg_transaction.prepared("getInvitedCoworkersOnFolderIds")(workgroup_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                int64_t uid;
                resi["user_id"].     to(uid);
                user_ids.push_back(uid);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to extra folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::unsubscribe_folder(int64_t user_id, int64_t workgroup_id)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("unsubscribeFolder"))
            {
                pg_connection->prepare  ("unsubscribeFolder",
                                         "DELETE FROM WorkGroupsAccess WHERE user_id=$1 AND workgroup_id=$2;");
            }
            pqxx::work pg_transaction(*pg_connection, "UnsubscribeFolder");
            pqxx::result query_result = pg_transaction.prepared("unsubscribeFolder")(user_id)(workgroup_id).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to unsubscribe folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}


rpc_status_code WorkGroupManagerPgSql::subscribe_folder(int64_t user_id, int64_t workgroup_id, int64_t accessMode, const std::string& encryption_key)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("subscribeFolder"))
            {
                pg_connection->prepare  ("subscribeFolder",
                                         "UPDATE WorkGroupsAccess SET invite_accepted = $3, access_mode = $4, encryption_key = $5 "
                                         "WHERE workgroup_id=$1 AND user_id=$2;");
            }
            pqxx::work pg_transaction(*pg_connection, "SubscribeFolder");
            pqxx::result query_result = pg_transaction.prepared("subscribeFolder")(workgroup_id)(user_id)(true)(accessMode)(encryption_key).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to subscribe folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::update_folder_size(int64_t user_id, int64_t workgroup_id, int64_t removedSize, int64_t addedSize)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("updateFolderSize"))
            {
                pg_connection->prepare  ("updateFolderSize",
                                         "UPDATE WorkGroups SET size = size + $2 WHERE workgroup_id=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "UpdateFolderSize");
            pqxx::result query_result = pg_transaction.prepared("updateFolderSize")(workgroup_id)(addedSize-removedSize).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to update folder %lli size for user %lli with %lli err: %s",workgroup_id,user_id,addedSize-removedSize,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::get_folders_sum_size(int64_t user_id, int64_t& foldersSumSize)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFoldersSumSize"))
            {
                pg_connection->prepare  ("getFoldersSumSize",
                                         "SELECT SUM(size) AS foldersSumSize FROM WorkGroups INNER JOIN WorkGroupsAccess "
                                         "ON WorkGroups.workgroup_id = WorkGroupsAccess.workgroup_id WHERE WorkGroups.is_deleted=false "
                                         "AND user_id=$1 AND WorkGroupsAccess.is_deleted=false;");
            }
            pqxx::work pg_transaction(*pg_connection, "GetFoldersSumSize");
            pqxx::result query_result = pg_transaction.prepared("getFoldersSumSize")(user_id).exec();

            if (query_result.size()>0)
            {
                query_result.begin()["foldersSumSize"].to(foldersSumSize);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folders for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_folders(int64_t user_id, bool showDeleted, WorkGroupsInfoList& foldersInfo, int64_t& lastEventId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFoldersInfoLong"))
            {
                pg_connection->prepare  ("getFoldersInfoLong",
                                         "SELECT WorkGroups.workgroup_id, workgroup_name, description, "
                                         "EXTRACT(EPOCH FROM WorkGroups.creation_date) AS creation, WorkGroups.creation_date, "
                                         "EXTRACT(EPOCH FROM deletion_date) AS deletion, deletion_date, creator_id, access_mode, "
                                         "invite_accepted, encryption_key, encryption_type, encryption_algo, key_signature, key_salt, "
                                         "creator_login, size, WorkGroups.is_deleted, WorkGroups.type, WorkGroups.metadata "
                                         "FROM WorkGroups INNER JOIN WorkGroupsAccess "
                                         "ON WorkGroups.workgroup_id = WorkGroupsAccess.workgroup_id "
                                         "WHERE WorkGroupsAccess.user_id = $1 AND WorkGroupsAccess.is_deleted = $2 "
                                         "AND WorkGroups.is_deleted=$2 ;");
            }
            if (pgSqlHelper().register_prep_statement("getLastEventId"))
            {
                pg_connection->prepare  ("getLastEventId",
                                         "SELECT MAX(event_id) as event_id FROM Events;"
                                        );
            }

            pqxx::work pg_transaction(*pg_connection, "GetFoldersInfoLong");
            pqxx::result query_result_event_id = pg_transaction.prepared("getLastEventId").exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["event_id"].to(lastEventId);
            }

            pqxx::result query_result = pg_transaction.prepared("getFoldersInfoLong")(user_id)(showDeleted).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                WorkGroupInfo foi;
                foi.workgroup_id   = resi["workgroup_id"].as<int64_t>();;
                foi.workgroup_name = resi["workgroup_name"].as<std::string>();
                foi.description = resi["description"].as<std::string>();
                foi.type = resi["type"].as<int32_t>();
                foi.metadata = resi["metadata"].as<std::string>();
                foi.workgroup_name = resi["workgroup_name"].as<std::string>();
                foi.creator_id  = resi["creator_id"].as<int64_t>();
                foi.creator_login  = resi["creator_login"].as<std::string>();
                foi.creation_date = resi["creation"].as<double>();
                foi.deletion_date = resi["deletion"].is_null() ? 0 : resi["deletion"].as<double>();
                foi.creation_date_str = resi["creation_date"].as<std::string>();
                foi.deletion_date_str = resi["deletion_date"].is_null() ? "" : resi["deletion_date"].as<std::string>();
                foi.access_mode = resi["access_mode"].as<int64_t>();
                foi.size = resi["size"].as<int64_t>();
                foi.invite_accepted = resi["invite_accepted"].as<bool>();
                foi.key = resi["encryption_key"].as<std::string>();
                foi.encryption_type = (workgroup_enc_type)resi["encryption_type"].as<int>();
                foi.encryption_algo = (workgroup_enc_algo)resi["encryption_algo"].as<int>();
                foi.is_deleted  = resi["is_deleted"].as<bool>();
                foi.key_signature  = resi["key_signature"].as<std::string>();
                foi.key_salt  = resi["key_salt"].as<std::string>();

                foldersInfo.push_back(foi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folders for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_folders(int64_t user_id, WorkGroupsInfoList& foldersInfo, int64_t& lastEventId)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getAllFoldersInfoLong"))
            {
                pg_connection->prepare  ("getAllFoldersInfoLong",
                                         "SELECT WorkGroups.workgroup_id, workgroup_name, description, "
                                         "EXTRACT(EPOCH FROM WorkGroups.creation_date) AS creation, WorkGroups.creation_date, "
                                         "EXTRACT(EPOCH FROM deletion_date) AS deletion, deletion_date, creator_id, access_mode, "
                                         "invite_accepted, encryption_key, encryption_type, encryption_algo, key_signature, key_salt, "
                                         "creator_login, size, WorkGroups.is_deleted, WorkGroups.type, WorkGroups.metadata "
                                         "FROM WorkGroups INNER JOIN WorkGroupsAccess "
                                         "ON WorkGroups.workgroup_id = WorkGroupsAccess.workgroup_id "
                                         "WHERE WorkGroupsAccess.user_id = $1;");
            }
            if (pgSqlHelper().register_prep_statement("getLastEventId"))
            {
                pg_connection->prepare  ("getLastEventId",
                                         "SELECT MAX(event_id) as event_id FROM Events;"
                                        );
            }

            pqxx::work pg_transaction(*pg_connection, "GetFoldersInfoLong");
            pqxx::result query_result_event_id = pg_transaction.prepared("getLastEventId").exec();

            if (query_result_event_id.size()>0)
            {
                query_result_event_id.begin()["event_id"].to(lastEventId);
            }

            pqxx::result query_result = pg_transaction.prepared("getAllFoldersInfoLong")(user_id).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                WorkGroupInfo foi;
                foi.workgroup_id   = resi["workgroup_id"].as<int64_t>();;
                foi.workgroup_name = resi["workgroup_name"].as<std::string>();
                foi.description = resi["description"].as<std::string>();
                foi.type = resi["type"].as<int32_t>();
                foi.metadata = resi["metadata"].as<std::string>();
                foi.workgroup_name = resi["workgroup_name"].as<std::string>();
                foi.creator_id  = resi["creator_id"].as<int64_t>();
                foi.creator_login  = resi["creator_login"].as<std::string>();
                foi.creation_date = resi["creation"].as<double>();
                foi.deletion_date = resi["deletion"].is_null() ? 0 : resi["deletion"].as<double>();
                foi.creation_date_str = resi["creation_date"].as<std::string>();
                foi.deletion_date_str = resi["deletion_date"].is_null() ? "" : resi["deletion_date"].as<std::string>();
                foi.access_mode = resi["access_mode"].as<int64_t>();
                foi.size = resi["size"].as<int64_t>();
                foi.invite_accepted = resi["invite_accepted"].as<bool>();
                foi.key = resi["encryption_key"].as<std::string>();
                foi.encryption_type = (workgroup_enc_type)resi["encryption_type"].as<int>();
                foi.encryption_algo = (workgroup_enc_algo)resi["encryption_algo"].as<int>();
                foi.is_deleted  = resi["is_deleted"].as<bool>();
                foi.key_signature  = resi["key_signature"].as<std::string>();
                foi.key_salt  = resi["key_salt"].as<std::string>();


                foldersInfo.push_back(foi);
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folders for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::get_folder_info(int64_t user_id, int64_t workgroup_id, WorkGroupInfo& folderInfo)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFolderInfo"))
            {
                pg_connection->prepare  ("getFolderInfo",
                                         "SELECT WorkGroups.workgroup_id, workgroup_name, description, creator_login, "
                                         "EXTRACT(EPOCH FROM (WorkGroups.creation_date)) AS creation, WorkGroups.creation_date, "
                                         "invite_accepted, encryption_key, encryption_type, encryption_algo, key_signature, key_salt, "
                                         "EXTRACT(EPOCH FROM deletion_date) AS deletion, deletion_date, creator_id, access_mode, size, "
                                         "WorkGroups.is_deleted, WorkGroups.type, WorkGroups.metadata "
                                         "FROM WorkGroups INNER JOIN WorkGroupsAccess "
                                         "ON WorkGroups.workgroup_id = WorkGroupsAccess.workgroup_id WHERE WorkGroupsAccess.user_id = $1 "
                                         "AND WorkGroups.workgroup_id = $2; ");
            }

            pqxx::work pg_transaction(*pg_connection, "GetFolderInfo");

            pqxx::result query_result = pg_transaction.prepared("getFolderInfo")(user_id)(workgroup_id).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            folderInfo.workgroup_id   = query_result.begin()["workgroup_id"].as<int64_t>();;
            folderInfo.workgroup_name = query_result.begin()["workgroup_name"].as<std::string>();
            folderInfo.description = query_result.begin()["description"].as<std::string>();
            folderInfo.type = query_result.begin()["type"].as<int32_t>();
            folderInfo.metadata = query_result.begin()["metadata"].as<std::string>();
            folderInfo.creator_id  = query_result.begin()["creator_id"].as<int64_t>();
            folderInfo.creation_date = query_result.begin()["creation"].as<double>();
            folderInfo.deletion_date = query_result.begin()["deletion"].is_null() ? 0 : query_result.begin()["deletion"].as<double>();
            folderInfo.creation_date_str = query_result.begin()["creation_date"].as<std::string>();
            folderInfo.deletion_date_str = query_result.begin()["deletion_date"].is_null() ? "" : query_result.begin()["deletion_date"].as<std::string>();
            folderInfo.access_mode = query_result.begin()["access_mode"].as<int64_t>();
            folderInfo.size = query_result.begin()["size"].as<int64_t>();
            folderInfo.creator_login = query_result.begin()["creator_login"].as<std::string>();
            folderInfo.invite_accepted = query_result.begin()["invite_accepted"].as<bool>();
            folderInfo.key = query_result.begin()["encryption_key"].as<std::string>();
            folderInfo.encryption_type = (workgroup_enc_type)query_result.begin()["encryption_type"].as<int>();
            folderInfo.encryption_algo = (workgroup_enc_algo)query_result.begin()["encryption_algo"].as<int>();
            folderInfo.is_deleted  = query_result.begin()["is_deleted"].as<bool>();
            folderInfo.key_signature  = query_result.begin()["key_signature"].as<std::string>();
            folderInfo.key_salt  = query_result.begin()["key_salt"].as<std::string>();


            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query info on folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::set_access_rights(int64_t user_id, int64_t workgroup_id, int64_t access_mode)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("setAccessRights"))
            {
                pg_connection->prepare  ("setAccessRights",
                                         "UPDATE WorkGroupsAccess SET access_mode = $3 WHERE user_id=$1 AND workgroup_id=$2; ");
            }

            pqxx::work pg_transaction(*pg_connection, "setAccessRights");

            pqxx::result query_result = pg_transaction.prepared("setAccessRights")(user_id)(workgroup_id)(access_mode).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to set access rights on folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::block_folder(int64_t user_id, int64_t workgroup_id, bool is_blocked)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("setFolderBlock"))
            {
                pg_connection->prepare  ("setFolderBlock",
                                         "UPDATE WorkGroups SET is_blocked = $2 WHERE workgroup_id = $1; ");
            }

            pqxx::work pg_transaction(*pg_connection, "setFolderBlock");

            pqxx::result query_result = pg_transaction.prepared("setFolderBlock")(workgroup_id)(is_blocked).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query info on folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::check_block_folder(int64_t user_id,
        int64_t workgroup_id, bool& is_blocked)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getFolderBlock"))
            {
                pg_connection->prepare  ("getFolderBlock",
                                         "SELECT workgroup_id, is_blocked FROM WorkGroups WHERE workgroup_id = $1; ");
            }

            pqxx::work pg_transaction(*pg_connection, "getFolderBlock");

            pqxx::result query_result = pg_transaction.prepared("getFolderBlock")(workgroup_id).exec();

            if (!query_result.size())
            {
                returnStatus = status_does_not_exist;
                break;
            }

            is_blocked   = query_result.begin()["is_blocked"].as<bool>();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query info on folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers_for_wgs(int64_t user_id, bool showDeleted, UserWorkGroupInfoMultiMap& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("getCoworkersForFoldersByFlag"))
            {
                pg_connection->prepare  ("getCoworkersForFoldersByFlag",
                        "SELECT Users.user_id, login, workgroup_id, invite_accepted, is_dummy, access_mode "
                        "FROM Users "
                        "INNER JOIN "
                        "( "
                        "SELECT WGA1.user_id, WGA1.workgroup_id, WGA1.invite_accepted, WGA1.access_mode FROM "
                        "WorkGroupsAccess as WGA1 "
                        "INNER JOIN "
                        "( "
                        "SELECT workgroup_id "
                        "FROM WorkGroupsAccess as WGA "
                        "WHERE user_id = $1 AND is_deleted = $2 AND invite_accepted = true "
                        ") "
                        "as WGA0 "
                        "ON WGA1.workgroup_id = WGA0.workgroup_id "
                        "WHERE user_id != $1 "
                        ") "
                        "as W "
                        "ON W.user_id = Users.user_id "
                        "ORDER BY workgroup_id, login;");
            }

            pqxx::work pg_transaction(*pg_connection, "getCoworkersForFoldersByFlag");
            pqxx::result query_result = pg_transaction.prepared("getCoworkersForFoldersByFlag")(user_id)(showDeleted).exec();

            for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
            {
                UserWorkGroupInfo ufi;
                resi["workgroup_id"].   to(ufi.workgroup_id);
                resi["user_id"].        to(ufi.user_id);
                resi["login"].          to(ufi.login);
                resi["is_dummy"].       to(ufi.is_dummy);
                resi["access_mode"].    to(ufi.access_mode);
                resi["invite_accepted"].to(ufi.invite_accepted);
                userEmails.insert(std::pair<int64_t,UserWorkGroupInfo>(ufi.workgroup_id,ufi));
            }

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to query folder coworkers for user %lli err: %s",user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::list_all_coworkers_for_wgs_all(int64_t user_id, UserWorkGroupInfoMultiMap& userEmails)
{
    rpc_status_code returnStatus = status_internal_error;

        do
        {
            pqxx::connection* pg_connection = pgSqlHelper().get_read_connection();
            if (!pg_connection)
            {
                break;
            }

            try
            {
                if (pgSqlHelper().register_prep_statement("getCoworkersForFoldersByFlagAll"))
                {
                    pg_connection->prepare  ("getCoworkersForFoldersByFlagAll",
                            "SELECT Users.user_id, login, workgroup_id, invite_accepted, is_dummy, access_mode "
                            "FROM Users "
                            "INNER JOIN "
                            "( "
                            "SELECT WGA1.user_id, WGA1.workgroup_id, WGA1.invite_accepted, WGA1.access_mode FROM "
                            "WorkGroupsAccess as WGA1 "
                            "INNER JOIN "
                            "( "
                            "SELECT workgroup_id "
                            "FROM WorkGroupsAccess as WGA "
                            "WHERE user_id = $1 AND invite_accepted = true "
                            ") "
                            "as WGA0 "
                            "ON WGA1.workgroup_id = WGA0.workgroup_id "
                            "WHERE user_id != $1 "
                            ") "
                            "as W "
                            "ON W.user_id = Users.user_id "
                            "ORDER BY workgroup_id, login; ");
                }

                pqxx::work pg_transaction(*pg_connection, "getCoworkersForFoldersByFlagAll");
                pqxx::result query_result = pg_transaction.prepared("getCoworkersForFoldersByFlagAll")(user_id).exec();

                for (pqxx::result::const_iterator resi = query_result.begin(); resi != query_result.end(); resi++)
                {
                    UserWorkGroupInfo ufi;
                    resi["user_id"].        to(ufi.user_id);
                    resi["login"].          to(ufi.login);
                    resi["is_dummy"].       to(ufi.is_dummy);
                    resi["access_mode"].    to(ufi.access_mode);
                    resi["invite_accepted"].to(ufi.invite_accepted);
                    userEmails.insert(std::pair<int64_t,UserWorkGroupInfo>(ufi.user_id,ufi));
                }

                pg_transaction.commit();

                returnStatus = status_success;
            }
            catch (const std::exception& e)
            {
                LOG_ERROR("Failure: trying to query folder coworkers for user %lli err: %s",user_id,e.what());
                break;
            }
            //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
        }
        while (false);

        return returnStatus;
}

rpc_status_code WorkGroupManagerPgSql::metadata_update(int64_t user_id, int64_t workgroup_id, const std::string& metadataUpdate)
{
    rpc_status_code returnStatus = status_internal_error;

    do
    {
        pqxx::connection* pg_connection = pgSqlHelper().get_write_connection();
        if (!pg_connection)
        {
            break;
        }

        try
        {
            if (pgSqlHelper().register_prep_statement("workgroupMeatadataUpdate"))
            {
                pg_connection->prepare  ("workgroupMeatadataUpdate",
                                         "UPDATE WorkGroups SET metadata = $2 WHERE workgroup_id=$1;");
            }
            pqxx::work pg_transaction(*pg_connection, "workgroupMeatadataUpdate");
            pqxx::result query_result = pg_transaction.prepared("workgroupMeatadataUpdate")(workgroup_id)(metadataUpdate).exec();

            pg_transaction.commit();

            returnStatus = status_success;
        }
        catch (const pqxx::unique_violation& e)
        {
            LOG_ERROR("Info: trying to create duplicate folder %s for user %lli err: %s",metadataUpdate.c_str(),user_id,e.what());
            returnStatus = status_already_exist;
            break;
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("Failure: trying to rename folder %lli for user %lli err: %s",workgroup_id,user_id,e.what());
            break;
        }
        //LOG_ABSOLUTE("Info: got user %lli for session %s",user_id,sessionId.c_str());
    }
    while (false);

    return returnStatus;
}
