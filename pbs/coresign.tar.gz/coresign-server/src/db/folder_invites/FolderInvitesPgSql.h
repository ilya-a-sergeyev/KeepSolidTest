/*
 * FolderInvitesPgSql.h
 *
 *  Created on: Aug 26, 2011
 *      Author: fireball
 */

#ifndef FOLDERINVITESPGSQL_H_
#define FOLDERINVITESPGSQL_H_

#include "types/status_codes.h"
#include "types/invitation.h"
#include "types/request_context.h"

class WorkGroupInvitesPgSql
{
public:
    static rpc_status_code     create_invitation    (const RequestContext& context, InviteInfo& invitationInfo);
    static rpc_status_code     get_invitation       (const RequestContext& context, const std::string& inviteId, InviteInfo& invitationInfo);
    static rpc_status_code     get_invitations      (const RequestContext& context, int64_t inviteeId, InviteInfosByWorkGroups& iibw);
    static rpc_status_code     get_invitations      (const RequestContext& context, const std::string& inviteeEmail, InviteInfosByWorkGroups& iibw);
    static rpc_status_code     get_invitations      (const RequestContext& context, int64_t inviteeId, int64_t workgroupId, InviteInfoList& inviteInfoList);
    static rpc_status_code     remove_invitation    (const RequestContext& context, const std::string& inviteId);
    static rpc_status_code     remove_invitations   (const RequestContext& context, int64_t inviteeId, int64_t workgroupId);
    static rpc_status_code     remove_invitations   (const RequestContext& context, int64_t inviterId, int64_t inviteeId, int64_t workgroupId);

};

#endif /* FOLDERINVITESPGSQL_H_ */
