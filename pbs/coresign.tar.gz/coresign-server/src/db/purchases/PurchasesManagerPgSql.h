/*
 * PurchasesManagerPgSql.h
 *
 *  Created on: Apr 3, 2014
 *      Author: fireballdark
 */

#ifndef PURCHASESMANAGERPGSQL_H_
#define PURCHASESMANAGERPGSQL_H_

#include "types/misc_info.h"

class PurchasesManagerPgSql
{
public:
    static rpc_status_code  create_purchase (int64_t userId, const PurchaseData& pd);
    static rpc_status_code  refund_purchase (int64_t userId, const std::string& purchase_hash);
    static rpc_status_code  get_purchase    (int64_t userId, const std::string& purchase_hash, PurchaseData& pd);
};

#endif /* PURCHASESMANAGERPGSQL_H_ */
