#include "init/setup_daemonizing.h"
#include <sutil/logging.h>

#include <unistd.h>
#include <sys/signal.h>
#include <zmq.hpp>
#include <boost/thread.hpp>
#include <boost/thread/locks.hpp>
#include <sutil/Timer.h>
#include "conf/DaemonParams.h"
#include "conf/Globals.h"
#include "network/FirstFolderCreator.h"
#include "network/EventNotifier.h"
#include "encryption/xopenssl.h"
#include <crash/linux/CrashReporter.h>
#include "sutil/AtomicConnectionStats.h"
#include "sutil/ProcessStats.h"

static void sigQuit(int signal);
static void sigInt (int signal);

/**
 * If the program is going to be a daemon than we need to
 *  - change current working directory (chdir)
 *  - get new session id (setsid)
 *  - close stdin-stdout-stderr
 *  - set signal handlers
 */
int setup_daemonizing_params()
{
    /*    char dir[] = "/";
        if ((chdir(dir)) < 0)
        {
        	LOG_CRITICAL("Failure: chdir to [%s]: %s",dir,strerror(errno));
        }
        else
        {
        	LOG_DEBUGGING( "Success: chdir to [%s]",dir);
       	}*/

    if (daemon_params().getDaemonize())
    {
        pid_t sid = setsid();
        if (sid < 0)
        {
            LOG_CRITICAL("Failure: set session id: %s",strerror(errno));
            return EXIT_FAILURE;
        }

        int res = close(STDIN_FILENO);
        res +=	  close(STDOUT_FILENO);
        res	+=	  close(STDERR_FILENO);

        if (res<0)
        {
            LOG_ERROR("Failure: stdio file descriptors close: %s",strerror(errno));
        }
    }
    else
    {
        LOG_DEBUGGING( "Success: stdio file descriptors close");
    }

    struct sigaction old_action, handled_action, new_action;
    new_action.sa_handler = SIG_IGN;
    sigemptyset (&new_action.sa_mask);
    new_action.sa_flags = SA_RESTART;
    sigaction(SIGPIPE,&new_action,&old_action);
    sigaction(SIGHUP,&new_action,&old_action);
    sigemptyset (&handled_action.sa_mask);
    handled_action.sa_flags = SA_RESTART;
    handled_action.sa_handler = &sigInt;
    sigaction(SIGINT,&handled_action,&old_action);
    handled_action.sa_handler = &sigQuit;
    sigaction(SIGQUIT,&handled_action,&old_action);

    return EXIT_SUCCESS;
}

static void sigQuit(int signal)
{
    Timer t("Stopping server");
    LOG_INFORMATION("Shutting down daemon by signal %i try 1..", signal);

    Globals::get_globals().setIsStopped(true);

    Globals::get_globals().getStopSignal()(0);

    static int i = 0;
    i++;

    if (i<2)
    {
        boost::lock_guard<boost::shared_mutex> lock(Globals::get_globals().getGlobalStopMutex());
        LOG_INFORMATION("Shutting down daemon by signal %i try 2.. Lock Acquired", signal);
    }
    else
    {
        LOG_INFORMATION("Shutting down daemon by signal %i try 2.. NON-LOCKED", signal);
    }

    FirstFolderCreator::close();
    EventNotifier::close();
    {
        // Block all signals for background thread.
        sigset_t new_mask;
        sigfillset(&new_mask);
        sigset_t old_mask;
        pthread_sigmask(SIG_BLOCK, &new_mask, &old_mask);
        Globals::get_globals().stopZMQContext();
        // Restore previous signals.
        pthread_sigmask(SIG_SETMASK, &old_mask, 0);
    }
    Globals::get_globals().getTimerIOService().stop();
    Globals::get_globals().getIOService().stop();

    LOG_INFORMATION("Shutting down daemon.. OK");
}

static void sigInt(int signal)
{
    //write_dump();
    //clear_ssl_cache(Globals::get_globals().getSSLContext().native_handle());
    Globals::get_globals().getStopSignal()(1);

    LOG_INFORMATION("Alive connections stats: Open-SSL-Mature [%lli:%lli:%lli]", AtomicConnectionStats::get_open_connections(), AtomicConnectionStats::get_ssl_connections(), AtomicConnectionStats::get_mature_connections());
    LOG_INFORMATION("Total connections stats: Open-SSL-Mature [%lli:%lli:%lli]", AtomicConnectionStats::get_total_open_connections(), AtomicConnectionStats::get_total_ssl_connections(), AtomicConnectionStats::get_total_mature_connections());
    LOG_INFORMATION("Request stats: OK:Failed [%lli:%lli]", AtomicConnectionStats::get_ok_requests(), AtomicConnectionStats::get_failed_requests());

    ProcessStats ps;
    LOG_INFORMATION("Process stats for [%s]:[%lli]:[%lli]:[%s]", ps.get_name().c_str(), ps.get_pid(), ps.get_ppid(), ps.get_state().c_str());
    LOG_INFORMATION("Process stats user:system time [%f]:[%f]", ps.get_user_time(), ps.get_system_time());
    LOG_INFORMATION("Process stats memory rss:threads [%lli]:[%lli]", ps.get_rss_memory()/1024, ps.get_threads());

}
