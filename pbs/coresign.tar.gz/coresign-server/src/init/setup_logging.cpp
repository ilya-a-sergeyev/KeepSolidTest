/*
 * setup_logging.cpp
 *
 *  Created on: 13 бер. 2011
 *      Author: fireball
 */
#include "init/setup_logging.h"
#include "conf/daemon_config.h"
#include <sutil/logging.h>
#include <sutil/LoggingData.h>


/**
 * Initialize all logging-related functions:
 *  - open syslog
 *  - open log file
 */
int setup_logging()
{


    return EXIT_SUCCESS;
}


