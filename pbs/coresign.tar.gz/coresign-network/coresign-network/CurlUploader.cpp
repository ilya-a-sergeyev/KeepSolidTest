#include <stdint.h>
#include <stdio.h>
#include <string>
#include <sstream>
#include <util/logging.h>
#include <fs/KSDFileSystem.hpp>

#ifdef DESKTOP_CLIENT
    #ifdef _WIN32
        #include <Services/StringConvert.h>
    #endif

    #include <headers/Encryption/Encryption.hpp>

    #define CERT_FILENAME "cacert.pem"
#else
    #define CERT_FILENAME "curl-ca-bundle.crt"

    #include <encryption/xopenssl.h>
#endif

#include "CurlUploader.h"

bool CurlUploader::bCurlInitialized = false;

tCurlCancelSignal CurlUploader::ms_cancelSignal;
tCurlProgressSignal CurlUploader::ms_uploadProgressSignal;
tCurlProgressSignal CurlUploader::ms_downloadProgressSignal;

CurlUploader::CurlUploader(const std::string& certificateFolder, bool verifyCerts /*= true*/)
    : curl_up(NULL)
    , curl_down(NULL)
    , formpost(NULL)
    , lastptr(NULL)
    , m_CertificateFolder(certificateFolder)
    , m_Ultotal(-1.0L)
    , m_Ulnow(-1.0L)
    , m_Dltotal(-1.0L)
    , m_Dlnow(-1.0L)
{
    if(!bCurlInitialized)
    {
        bCurlInitialized=true;
        curl_global_init(CURL_GLOBAL_ALL);
    }

#ifdef DESKTOP_CLIENT
    KSDEncryption::SSL_library_init();
    KSDEncryption::ERR_load_crypto_strings();
#endif

    curl_up = curl_easy_init();
    curl_down = curl_easy_init();

//#ifdef _DEBUG
//    curl_easy_setopt(curl_up,   CURLOPT_VERBOSE, 1L);
//    curl_easy_setopt(curl_up, CURLOPT_DEBUGFUNCTION, &CurlUploader::handle_trace);

//    curl_easy_setopt(curl_down, CURLOPT_VERBOSE, 1L);
//    curl_easy_setopt(curl_down, CURLOPT_DEBUGFUNCTION, &CurlUploader::handle_trace);
//#endif

    if (verifyCerts)
    {
        //verify certificates
        curl_easy_setopt(curl_up,   CURLOPT_SSL_VERIFYPEER, 1L);
        curl_easy_setopt(curl_down, CURLOPT_SSL_VERIFYPEER, 1L);
        //verify hostname and certificate hostname
        curl_easy_setopt(curl_up,   CURLOPT_SSL_VERIFYHOST, 2L);
        curl_easy_setopt(curl_down, CURLOPT_SSL_VERIFYHOST, 2L);
    }
    else
    {
        //verify certificates
        curl_easy_setopt(curl_up,   CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl_down, CURLOPT_SSL_VERIFYPEER, 0L);
        //verify hostname and certificate hostname
        curl_easy_setopt(curl_up,   CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl_down, CURLOPT_SSL_VERIFYHOST, 0L);
    }

    curl_easy_setopt(curl_up, CURLOPT_NOSIGNAL, 1L);
    curl_easy_setopt(curl_down, CURLOPT_NOSIGNAL, 1L);

    // will be ignored on iOS
    KSDFileSystem::path certFilePath = KSDFileSystem::getPathFromString(m_CertificateFolder);
    certFilePath /= KSDFileSystem::getPathFromString(CERT_FILENAME);

    curl_easy_setopt(curl_up, CURLOPT_CAINFO, KSDFileSystem::getStringFromPath(certFilePath).c_str());
    curl_easy_setopt(curl_down, CURLOPT_CAINFO, KSDFileSystem::getStringFromPath(certFilePath).c_str());

    curl_easy_setopt(curl_up, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl_down, CURLOPT_NOPROGRESS, 0L);

    //Upload-specific initialization
    {
        curl_easy_setopt(curl_up, CURLOPT_WRITEFUNCTION, upload_write_data);
        curl_easy_setopt(curl_up, CURLOPT_WRITEDATA, &reply_data);

        curl_easy_setopt(curl_up, CURLOPT_HEADERFUNCTION, upload_header_data);
        curl_easy_setopt(curl_up, CURLOPT_WRITEHEADER, &header_data);

        curl_easy_setopt(curl_up, CURLOPT_READFUNCTION, upload_read_file);
        curl_easy_setopt(curl_up, CURLOPT_ERRORBUFFER, mErrorBuffer);

        curl_easy_setopt(curl_up, CURLOPT_PROGRESSFUNCTION, upload_progress);
        curl_easy_setopt(curl_up, CURLOPT_PROGRESSDATA, this);
    }

    //Download-specific initialization
    {
        curl_easy_setopt(curl_down, CURLOPT_WRITEFUNCTION, download_write_file);

        curl_easy_setopt(curl_down, CURLOPT_HEADERFUNCTION, download_write_data);
        curl_easy_setopt(curl_down, CURLOPT_WRITEHEADER, &header_data);
        curl_easy_setopt(curl_down, CURLOPT_ERRORBUFFER, mErrorBuffer);

        curl_easy_setopt(curl_down, CURLOPT_PROGRESSFUNCTION, download_progress);
        curl_easy_setopt(curl_down, CURLOPT_PROGRESSDATA, this);
    }
}

CurlUploader::~CurlUploader()
{
    /* always cleanup */
    curl_easy_cleanup(curl_up);
    curl_easy_cleanup(curl_down);
}

size_t CurlUploader::upload_write_data(void *data, size_t size, size_t nmemb, void *destination)
{
    std::string* dest = (std::string*)destination;
    dest->append((const char*)data,nmemb*size);
    return size*nmemb;
}

size_t CurlUploader::upload_header_data(void *data, size_t size, size_t nmemb, void *destination)
{
    std::string* dest = (std::string*)destination;
    dest->append((const char*)data,nmemb*size);
    return size*nmemb;
}

size_t CurlUploader::upload_read_file(void *data, size_t size, size_t nmemb, void *file)
{
    FILE* fd = (FILE*) file;
    size_t ret = fread (data,size,nmemb,fd);
    //When ret!= size*nmemb, it means last file chunk
    return ret;
}

size_t CurlUploader::download_write_data(void *data, size_t size, size_t nmemb, void *destination)
{
    if (ms_cancelSignal())
    {
        LOG_INFORMATION("CurlUploader: download_write_data canceled");
        return 0;  // zero value should abort the transfer
    }

    std::string* dest = (std::string*)destination;
    dest->append((const char*)data,nmemb*size);
    return size*nmemb;
}

size_t CurlUploader::download_write_file(void *data, size_t size, size_t nmemb, void *file)
{
    if (ms_cancelSignal())
    {
        LOG_INFORMATION("CurlUploader: download_write_file canceled");
        return 0;  // zero value should abort the transfer
    }

    FILE* fd = (FILE*) file;
    size_t ret = fwrite (data,size,nmemb,fd);
    if (ret!=size*nmemb)
    {
        LOG_ERROR("Data size mismatch %lli:%lli",(int64_t)ret,(int64_t)size*nmemb);
    }

    return ret;
}

void CurlUploader::clean_data()
{
    reply_data.clear();
    header_data.clear();
    memset(mErrorBuffer, 0, sizeof(mErrorBuffer));
}

int CurlUploader::upload_progress(void* curlUploader, double, double, double ultotal, double ulnow)
{
    CurlUploader* tCurlUploader = static_cast<CurlUploader*>(curlUploader);

    if ((tCurlUploader->m_Ultotal != ultotal) || (tCurlUploader->m_Ulnow != ulnow))
    {
        tCurlUploader->m_Ultotal = ultotal;
        tCurlUploader->m_Ulnow = ulnow;

        if (ms_uploadProgressSignal(tCurlUploader->m_curFileName, (int64_t)ultotal, (int64_t)ulnow))
        {
            LOG_INFORMATION("CurlUploader: upload canceled from ProgressCallback");
            return 1; // this value should abort current operation
        }
    }

    return 0; // this value should allow to continue current operation
}

int CurlUploader::download_progress(void* curlUploader, double dltotal, double dlnow, double, double)
{
    if (ms_cancelSignal())
    {
        LOG_INFORMATION("CurlUploader: download canceled from CancelCallback");
        return 1; // this value should abort current operation
    }

    CurlUploader* tCurlUploader = static_cast<CurlUploader*>(curlUploader);

    if ((tCurlUploader->m_Dltotal != dltotal) || (tCurlUploader->m_Dlnow != dlnow))
    {
        tCurlUploader->m_Dltotal = dltotal;
        tCurlUploader->m_Dlnow = dlnow;

        if (ms_downloadProgressSignal(tCurlUploader->m_curFileName, (int64_t)dltotal, (int64_t)dlnow))
        {
            LOG_INFORMATION("CurlUploader: download canceled from ProgressCallback");
            return 1; // this value should abort current operation
        }
    }

    return 0; // this value should allow to continue current operation
}

int CurlUploader::handle_trace(CURL *handle, curl_infotype type, char *data, size_t size, void *userp)
{
    (void)userp;
    (void)handle; /* prevent compiler warning */

    std::string curl_str(data, size);
    switch (type)
    {
        case CURLINFO_TEXT:
            LOG_ABSOLUTE("== Info: %s", curl_str.c_str());
        default: /* in case a new one is introduced to shock us */
            return 0;
    }
    return 0;
}

CURLcode CurlUploader::upload_file(const std::string& fileName, const std::string& serverUrl, const tPostParams& params, std::string& uploaded_file_url)
{
    CURLcode curlResult = CURL_LAST;
    FILE* fd = NULL;

    do
    {
        LOG_INFORMATION("fileName: '%s'", fileName.c_str());
        LOG_INFORMATION("serverUrl: '%s'", serverUrl.c_str());
        if (fileName.empty() || serverUrl.empty())
        {
            LOG_ERROR("Empty filename or serverUrl are empty!");
            break;
        }

        if(false == KSDFileSystem::exists(fileName))
        {
            LOG_ERROR("File '%s' does not exists!", fileName.c_str());
            break;
        }

        int64_t fileSize = KSDFileSystem::file_size(fileName);
        if(0 > fileSize)
        {
            LOG_ERROR("Wrong size = %lli of file '%s'", fileSize, fileName.c_str());
        }

#ifdef _WIN32
        std::wstring w_fileName;

        CStringConverter::Utf82W(fileName, w_fileName);

        fd = _wfopen(w_fileName.c_str(), L"rb");
#else
        fd = fopen(fileName.c_str(), "rb");
#endif

        if(!fd)
        {
            LOG_ERROR("Unable open file '%s'", fileName.c_str());
            break;
        }

        for (tPostParams::const_iterator i = params.begin(); i != params.end(); ++i)
        {
            curl_formadd(&formpost,
                &lastptr,
                CURLFORM_COPYNAME, i->first.c_str(),
                CURLFORM_COPYCONTENTS, i->second.c_str(),
                CURLFORM_CONTENTSLENGTH, i->second.size(),
                CURLFORM_END);
        }

        // Fill in the file upload field
        curl_formadd(&formpost,
                &lastptr,
                CURLFORM_COPYNAME, "avatar_file",
                CURLFORM_CONTENTSLENGTH, (long)fileSize,
                CURLFORM_STREAM, fd,
                CURLFORM_CONTENTTYPE, "multipart/form-data",
                CURLFORM_FILENAME, KSDFileSystem::getPathFromString(fileName).leaf().string().c_str(),
                CURLFORM_END);

        // Fill in the submit field too, even if this is rarely needed
        curl_formadd(&formpost,
                &lastptr,
                CURLFORM_COPYNAME, "submit",
                CURLFORM_COPYCONTENTS, "send",
                CURLFORM_END);

        //Set POST HTTP method
        curl_easy_setopt(curl_up,   CURLOPT_URL, serverUrl.c_str());
        curl_easy_setopt(curl_up,   CURLOPT_HTTPPOST, formpost);

#ifdef _DEBUG
        char errorBuffer[CURL_ERROR_SIZE];
        curl_easy_setopt(curl_up, CURLOPT_ERRORBUFFER, errorBuffer);
#endif

        try
        {
            curlResult = curl_easy_perform(curl_up);
            uploaded_file_url = reply_data;
            LOG_ABSOLUTE("reply_data: '%s'", reply_data.c_str());
        }
        catch(...)
        {
            LOG_ERROR("exception in curl");
            break;
            //no return - can leak memory!
        }

        int64_t opStatus = ((curlResult == CURLE_OK) || (curlResult == CURLE_ABORTED_BY_CALLBACK)) ? -1LL : -2LL;
        m_Ultotal = (double) opStatus;
        m_Ulnow = (double) opStatus;
        ms_uploadProgressSignal(m_curFileName, opStatus, opStatus);

        long response_code = 0;
        double speed = 0;
        curl_easy_getinfo(curl_up, CURLINFO_RESPONSE_CODE, &response_code);
        curl_easy_getinfo(curl_up, CURLINFO_SPEED_UPLOAD, &speed);


        if (curlResult != CURLE_OK || response_code<200 || response_code>204)
        {
            //contains error message
            //also info in header_data and reply_data can be useful

            LOG_ERROR("Problem uploading file, response %li, error [%s]"
                "Open FileName: [%s]"
                "Server Url: [%s]"
                "Error Buffer: [%s]"
                "HTTP Headers: [%s]"
                "HTTP Reply: [%s]", response_code,curl_easy_strerror(curlResult),
                fileName.c_str(), serverUrl.c_str(), mErrorBuffer,
                header_data.c_str(), reply_data.c_str());
            break;
        }
    } while (false);

    /* then cleanup the formpost chain */
    curl_formfree(formpost);
    formpost = NULL;
    lastptr = NULL;
    clean_data();
    if (fd)
    {
        fclose(fd);
    }

    return curlResult;
}

CURLcode CurlUploader::upload_file(const std::string& fileName, const std::string& uploadUrl, const std::string& fileHash)
{
    m_curFileName = fileName;

    if (!KSDFileSystem::exists(fileName))
    {
        LOG_ERROR("Upload file %s does not exist",fileName.c_str());
    }

    CURLcode curlResult = CURL_LAST;
    FILE* fd = NULL;

    do
    {
#ifdef _WIN32
        std::wstring w_fileName;

        CStringConverter::Utf82W(fileName, w_fileName);

        fd = _wfopen(w_fileName.c_str(), L"rb");
#else
        fd = fopen(fileName.c_str(), "rb");
#endif

        if(!fd)
        {
            LOG_ERROR("Unable open file '%s'", fileName.c_str());
            break;
        }

        int64_t fileSize = KSDFileSystem::file_size(fileName);
        if(fileSize <= 0)
        {
            LOG_ERROR("Upload file size is %lli", fileSize);
        }

        curl_easy_setopt(curl_up, CURLOPT_UPLOAD, 1L);
        /* HTTP PUT please */
        curl_easy_setopt(curl_up, CURLOPT_PUT, 1L);

        curl_easy_setopt(curl_up, CURLOPT_URL, uploadUrl.c_str());

        curl_easy_setopt(curl_up, CURLOPT_READDATA, fd);

        curl_easy_setopt(curl_up, CURLOPT_INFILESIZE, (long)fileSize);

        struct curl_slist *slist=NULL;
        std::stringstream f_size;
        f_size<<fileSize;
        std::string strFileSize = "Content-Length: " + f_size.str();
        slist = curl_slist_append(slist, strFileSize.c_str());

        std::string content_md5 = "Content-MD5: ";
#ifdef DESKTOP_CLIENT
        content_md5 += KSDEncryption::base64_encodestring(KSDEncryption::hex_to_digest(fileHash));
#else
        content_md5 += base64_encodestring(hex_to_digest(fileHash));
#endif

        content_md5.erase(content_md5.length() - 1, std::string::npos);
        slist = curl_slist_append(slist, content_md5.c_str());
        curl_easy_setopt(curl_up, CURLOPT_HTTPHEADER, slist);

        try
        {
            curlResult = curl_easy_perform(curl_up);
        }
        catch(...)
        {
            LOG_ERROR("exception in curl");
            break;
            //no return - can leak memory!
        }

        int64_t opStatus = ((curlResult == CURLE_OK) || (curlResult == CURLE_ABORTED_BY_CALLBACK)) ? -1LL : -2LL;
        m_Ultotal = (double) opStatus;
        m_Ulnow = (double) opStatus;
        ms_uploadProgressSignal(m_curFileName, opStatus, opStatus);

        curl_slist_free_all(slist); /* free the list again */

        long response_code = 0;
        double speed = 0;
        curl_easy_getinfo(curl_up, CURLINFO_RESPONSE_CODE, &response_code);
        curl_easy_getinfo(curl_up, CURLINFO_SPEED_UPLOAD, &speed);


        if (curlResult != CURLE_OK || response_code<200 || response_code>204)
        {
            //contains error message
            //also info in header_data and reply_data can be useful
            LOG_ERROR("Problem uploading file, response %li, error [%s]"
                      "Open FileName: [%s]"
                      "Upload Url: [%s]"
                      "Error Buffer: [%s]"
                      "HTTP Headers: [%s]"
                      "HTTP Reply: [%s]", response_code, curl_easy_strerror(curlResult),
                      fileName.c_str(), uploadUrl.c_str(), mErrorBuffer,
                      header_data.c_str(), reply_data.c_str());
            break;
        }

    } while (false);

    clean_data();
    if (fd)
    {
        fclose(fd);
    }

    return curlResult;
}


CURLcode CurlUploader::download_file(const std::string& save_fileName, const std::string& downloadUrl)
{
    m_curFileName = save_fileName;

    //Where to store received data
#ifdef _WIN32
    std::wstring w_saveFileName;

    CStringConverter::Utf82W(save_fileName, w_saveFileName);

    FILE* fd = _wfopen(w_saveFileName.c_str(), L"wb");
#else
    FILE* fd = fopen(save_fileName.c_str(), "wb");
#endif
    CURLcode curlResult = CURL_LAST;

    do
    {
        if(!fd)
        {
            LOG_ERROR("Unable open file '%s'", save_fileName.c_str());
            break;
        }

        curl_easy_setopt(curl_down, CURLOPT_WRITEDATA, fd);

        curl_easy_setopt(curl_down, CURLOPT_URL, downloadUrl.c_str());

        try
        {
            curlResult = curl_easy_perform(curl_down);
        }
        catch(...)
        {
            LOG_ERROR("exception in curl");
            break;
        }

        int64_t opStatus = ((curlResult == CURLE_OK) || (curlResult == CURLE_ABORTED_BY_CALLBACK)) ? -1LL : -2LL;
        m_Dltotal = (double) opStatus;
        m_Dlnow = (double) opStatus;
        ms_downloadProgressSignal(m_curFileName, opStatus, opStatus);

        long response_code = 0;
        double speed = 0;
        curl_easy_getinfo(curl_down, CURLINFO_RESPONSE_CODE, &response_code);
        curl_easy_getinfo(curl_down, CURLINFO_SPEED_DOWNLOAD, &speed);

        if (curlResult != CURLE_OK || response_code != 200)
        {
            LOG_ERROR("Problem downloading file, response %li, error [%s]"
                      "Save FileName: [%s]"
                      "Download Url: [%s]"
                      "Error Buffer: [%s]"
                      "HTTP Headers: [%s]"
                      "HTTP Reply: [%s]", response_code,curl_easy_strerror(curlResult),
                      save_fileName.c_str(), downloadUrl.c_str(), mErrorBuffer,
                      header_data.c_str(), reply_data.c_str());
            break;
        }
    }
    while(false);

    clean_data();
    if (fd)
    {
        fclose(fd);
    }

    return curlResult;
}

CURLcode CurlUploader::post_request_base64(const std::string& serverUrl, const tPostParams& params, std::string& result, const std::string& basic_auth/* = "" */)
{
    tPostParams params_updated = params;
    for (tPostParams::const_iterator i = params.begin(); i != params.end(); ++i)
    {
        std::string first = i->first;
#ifdef DESKTOP_CLIENT
        std::string second = KSDEncryption::base64_encodestring(i->second);
#else
        std::string second = base64_encodestring(i->second);
#endif
        params_updated[first] = second;
    }
    
    return post_request(serverUrl, params_updated, result, basic_auth);
}

CURLcode CurlUploader::post_request(const std::string& serverUrl, const tPostParams& params, std::string& result, const std::string& basic_auth/* = "" */)
{
    CURLcode curlResult = CURL_LAST;

    do
    {
        LOG_INFORMATION("serverUrl: '%s'", serverUrl.c_str());
        if (serverUrl.empty())
        {
            LOG_ERROR("Empty filename or serverUrl are empty!");
            break;
        }

        for (tPostParams::const_iterator i = params.begin(); i != params.end(); ++i)
        {
            curl_formadd(&formpost,
                &lastptr,
                CURLFORM_COPYNAME,      i->first.c_str(),
                CURLFORM_COPYCONTENTS,  i->second.c_str(),
                CURLFORM_CONTENTSLENGTH,i->second.size(),
                CURLFORM_END);
        }

        if (!basic_auth.empty())
        {
            curl_easy_setopt(curl_up, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_easy_setopt(curl_up, CURLOPT_USERPWD, basic_auth.c_str());
        }

        //Set POST HTTP method
        curl_easy_setopt(curl_up,   CURLOPT_URL,        serverUrl.c_str());
        curl_easy_setopt(curl_up,   CURLOPT_HTTPPOST,   formpost);

#ifdef _DEBUG
        char errorBuffer[CURL_ERROR_SIZE];
        curl_easy_setopt(curl_up, CURLOPT_ERRORBUFFER, errorBuffer);
#endif

        try
        {
            curlResult = curl_easy_perform(curl_up);
        }
        catch(...)
        {
            LOG_ERROR("exception in curl");
            break;
            //no return - can leak memory!
        }

        long response_code = 0;
        double speed = 0;
        curl_easy_getinfo(curl_up, CURLINFO_RESPONSE_CODE, &response_code);
        curl_easy_getinfo(curl_up, CURLINFO_SPEED_UPLOAD, &speed);


        if (curlResult != CURLE_OK || response_code<200 || response_code>204)
        {
            //contains error message
            //also info in header_data and reply_data can be useful

            LOG_ERROR("Problem POST request, response %li, error [%s]"
                "Server Url: [%s]"
                "Error Buffer: [%s]"
                "HTTP Headers: [%s]"
                "HTTP Reply: [%s]", response_code,curl_easy_strerror(curlResult),
                serverUrl.c_str(), mErrorBuffer,
                header_data.c_str(), reply_data.c_str());
            break;
        }

        result = reply_data;
    } while (false);

    /* then cleanup the formpost chain */
    curl_formfree(formpost);
    formpost = NULL;
    lastptr = NULL;
    clean_data();

    return curlResult;
}
