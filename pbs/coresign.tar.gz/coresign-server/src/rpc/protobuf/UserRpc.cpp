/*
 * UserRpc.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */


#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "logic/AuthLogic.h"
#include "logic/MiscLogic.h"
#include "logic/UserLogic.h"
#include "types/structs_to_protobuf.h"



rpc_status_code_struct ProtobufZmqRpc::accountStats(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("AccountStats");

    rpc::AccountStatsRequest      input;
    rpc::AccountStatsResponse*    output = response.mutable_account_stats();
    response.set_message_type(RPC_ACCOUNT_STATS);

    do
    {
        if (request.has_account_stats())
        {
            input = request.account_stats();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_extended())
        {
            resultStatus = status_bad_request;
            LOG_ABSOLUTE("AccountStats sessionId %i extended %i",input.has_session_id(),input.has_extended());
            break;
        }

        std::string sessionId     = input.session_id();
        bool isExtended           = input.extended();
        bool getServersList       = input.has_get_servers_list() ? input.get_servers_list() : false;
        bool createIfNull         = input.has_create_if_null() ? input.create_if_null() : false;

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("AccountStats function called with [%s] service type[%d]",sessionId.c_str(), context.service_type);


        AccountStats accountStats;
        context.session_id = sessionId;
        resultStatus = UserLogic::accountStats(context,accountStats,isExtended,getServersList,createIfNull);

        if (resultStatus != status_success)
        {
            break;
        }

        for (LoginStatsList::iterator i = accountStats.device_stats.begin() ; i!= accountStats.device_stats.end() ; i++)
        {
            rpc::LoginStats* loginStats = output->add_device_stats();
            convert_accountstats((*i),loginStats);
        }

        for (LoginStatsList::iterator i = accountStats.login_history.begin() ; i!= accountStats.login_history.end() ; i++)
        {
            rpc::LoginStats* loginStats = output->add_login_history();
            convert_accountstats((*i),loginStats);
        }

        output->set_coworkers_count (accountStats.coworkers_count);
        output->set_data_size       (accountStats.data_size);
        output->set_data_size_limit  (accountStats.limits.data_size_limit);

        output->set_login(context.session_info.username);
        output->set_account_status(accountStats.account_status);
        output->set_creation_date(accountStats.creation_date);
        output->set_expiration_date(accountStats.expiration_date);
        output->set_now_date(accountStats.now_date);
        output->set_encrypted_password(accountStats.encrypted_password);

        for (AddressesList::iterator i = accountStats.api_servers.begin() ; i!= accountStats.api_servers.end() ; i++)
        {
            rpc::ConnectionEndpoint* connectionEndpoint = output->add_api_servers();
            connectionEndpoint->set_address((*i).first);
            connectionEndpoint->set_port((*i).second);
        }

        for (AddressesList::iterator i = accountStats.notification_servers.begin() ; i!= accountStats.notification_servers.end() ; i++)
        {
            rpc::ConnectionEndpoint* connectionEndpoint = output->add_notification_servers();
            connectionEndpoint->set_address((*i).first);
            connectionEndpoint->set_port((*i).second);
        }

        LOG_ABSOLUTE("AccountStats put deviceStats %i and loginStats %i, data_size %lli, data_size_limit %lli",
                output->device_stats_size(), output->login_history_size(), accountStats.data_size, accountStats.limits.data_size_limit);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("AccountStats function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::getMyData(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("GetMyData");

    rpc::GetMyDataRequest    input;
    rpc::GetMyDataResponse*  output =     response.mutable_get_my_data();
    response.set_message_type(RPC_GET_MY_DATA);

    do
    {
        if (request.has_get_my_data())
        {
            input = request.get_my_data();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("GetMyData function called with [%s]", sessionId.c_str());

        UserInfo userInfo;
        UserCredentials userCredentials;
        context.session_id = sessionId;
        resultStatus = UserLogic::getMyData(context, userInfo, userCredentials);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_first_name(userInfo.first_name);
        output->set_last_name(userInfo.last_name);
        output->set_public_key(userInfo.public_key);
        output->set_private_key(userInfo.private_key);
        output->set_private_key_salt(userInfo.salt_pk_password);
        output->set_user_pic(userInfo.user_pic);
        output->set_login(userInfo.login);
        output->set_email(userInfo.email);
        output->set_secret_question(userInfo.secret_question);
        output->set_keepsolid_password(userCredentials.encrypted_external_password);
        LOG_ABSOLUTE("Keepsolid password is [%s]", userCredentials.encrypted_external_password.c_str());
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("GetMyData function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::setMyData(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("SetMyData");

    rpc::SetMyDataRequest   input;
    rpc::SetMyDataResponse*  output =     response.mutable_set_my_data();
    response.set_message_type(RPC_SET_MY_DATA);

    do
    {
        if (request.has_set_my_data())
        {
            input = request.set_my_data();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId               = input.session_id();
        UserInfo userInfo;
        userInfo.email                       = input.has_email() ? input.email() : "";
        userInfo.first_name                  = input.has_first_name() ? input.first_name() : "";
        userInfo.last_name                   = input.has_last_name() ? input.last_name() : "";
        userInfo.user_pic                    = input.has_user_pic() ? input.user_pic() : "";

        if (!is_utf8_string(sessionId) || !is_utf8_string(userInfo.first_name) ||
                !is_utf8_string(userInfo.last_name) || !is_utf8_string(userInfo.user_pic))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("SetMyData function called with [%s], email [%s], names [%s]:[%s], pic [%s]", sessionId.c_str(), userInfo.email.c_str(),
                userInfo.first_name.c_str(), userInfo.last_name.c_str(), userInfo.user_pic.c_str());
        context.session_id = sessionId;
        resultStatus = UserLogic::setMyData(context,userInfo);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("SetMyData function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::notificationsGet(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("NotificationsGet");

    rpc::NotificationsGetRequest   input;
    rpc::NotificationsGetResponse*  output =     response.mutable_notifications_get();
    response.set_message_type(RPC_NOTIFICATIONS_GET);

    do
    {
        if (request.has_notifications_get())
        {
            input = request.notifications_get();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("NotificationsGet function called with [%s]", sessionId.c_str());

        NotificationsSubscription notifySub;
        context.session_id = sessionId;
        resultStatus = UserLogic::notificationsGet(context,notifySub);

        if (resultStatus != status_success)
        {
            break;
        }

        for (NotificationsSubscription::iterator i = notifySub.begin(); i!= notifySub.end(); i++)
        {
            rpc::KeyValue* keyvalue = output->add_notify_subscriptions();
            keyvalue->set_key       (i->first);
            keyvalue->set_value     (i->second);
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("NotificationsGet function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::notificationsSet(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("NotificationsSet");

    rpc::NotificationsSetRequest   input;
    rpc::NotificationsSetResponse*  output =     response.mutable_notifications_set();
    response.set_message_type(RPC_NOTIFICATIONS_SET);

    do
    {
        if (request.has_notifications_set())
        {
            input = request.notifications_set();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId   = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        typedef google::protobuf::RepeatedPtrField< rpc::KeyValue > KeyValueList;

        KeyValueList keyValueList = input.notify_subscriptions();
        NotificationsSubscription notifySub;
        for (int i=0; i<keyValueList.size(); i++)
        {
            std::string key     = keyValueList.Get(i).key();
            std::string value   = keyValueList.Get(i).value();
            boost::algorithm::to_lower(key);
            boost::algorithm::to_lower(value);
            if (key.empty() || value.empty())
            {
                LOG_INFORMATION("NotificationsSet: Got empty key or value! [%s]:[%s]",key.c_str(),value.c_str());
                continue;
            }
            if (!is_utf8_string(key) || !is_utf8_string(value))
            {
                resultStatus = status_invalid_utf8;
                break;
            }
            LOG_ABSOLUTE("NotificationsSet: Got [%s]:[%s]",key.c_str(),value.c_str());
            notifySub.insert(std::pair<std::string,std::string>(key,value));
        }

        LOG_ABSOLUTE("NotificationsSet function called with [%s] size %zi", sessionId.c_str(),notifySub.size());

        context.session_id = sessionId;
        resultStatus = UserLogic::notificationsSet(context,notifySub);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("NotificationsSet function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::userInfo(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("UserInfo");

    rpc::UserInfoRequest   input;
    rpc::UserInfoResponse*  output =     response.mutable_user_info();
    response.set_message_type(RPC_USER_INFO);

    do
    {
        if (request.has_user_info())
        {
            input = request.user_info();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_create_if_null())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        bool        createIfNull          = input.create_if_null();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("UserInfo function called with [%s] CreateIfNull %s", sessionId.c_str(), createIfNull?"YES":"NO");

        UserLoginList userEmailList;
        if (input.user_logins_size() > 0)
        {
            for (int i=0; i< input.user_logins_size(); i++)
            {
                std:: string email = input.user_logins(i);
                boost::algorithm::to_lower(email);
                if (!is_utf8_string(email))
                {
                    resultStatus = status_invalid_utf8;
                    break;
                }

                LOG_ABSOLUTE("UserInfo function called for user %s", email.c_str());
                userEmailList.push_back(email);
            }
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        UserInfoList userInfoList;
        context.session_id = sessionId;
        resultStatus = UserLogic::userInfoMass(context,userEmailList,userInfoList,createIfNull);

        if (resultStatus != status_success)
        {
            break;
        }

        if (userEmailList.size()!=userInfoList.size())
        {
            LOG_INFORMATION("Got %zi emails and %zi userinfos",userEmailList.size(),userInfoList.size());
        }

        for (UserInfoList::iterator i = userInfoList.begin(); i!=userInfoList.end(); i++)
        {
            rpc::UserInfoResponse_UserInfo* userInfo = output->add_user_info_list();
            userInfo->set_login             ((*i).login);
            userInfo->set_first_name        ((*i).first_name);
            userInfo->set_last_name         ((*i).last_name);
            userInfo->set_public_key        ((*i).public_key);
            userInfo->set_user_pic          ((*i).user_pic);
            userInfo->set_error_code        ((*i).returnStatus);
            userInfo->set_was_invited       ((*i).wasInvited);
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("UserInfo function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}
