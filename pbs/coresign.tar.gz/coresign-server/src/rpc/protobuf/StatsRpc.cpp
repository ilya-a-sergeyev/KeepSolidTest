/*
 * StatsRpc.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */


#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "logic/AuthLogic.h"
#include "logic/MiscLogic.h"
#include "logic/UserLogic.h"
#include "types/structs_to_protobuf.h"



rpc_status_code_struct ProtobufZmqRpc::serverVersion(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("ServerVersion");

    rpc::ServerVersionRequest   input;
    rpc::ServerVersionResponse*  output = response.mutable_server_version();
    response.set_message_type(RPC_SERVER_VERSION);

    do
    {
        if (request.has_server_version())
        {
            input = request.server_version();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("ServerVersion function called with [%s]", sessionId.c_str());

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("ServerVersion function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::serverTimingStats(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("ServerTimingStats");

    rpc::ServerTimingStatsRequest   input;
    rpc::ServerTimingStatsResponse*  output = response.mutable_server_timing_stats();
    response.set_message_type(RPC_SERVER_TIMING_STATS);

    do
    {
        if (request.has_server_timing_stats())
        {
            input = request.server_timing_stats();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("ServerTimingStats function called with [%s]", sessionId.c_str());

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("ServerTimingStats function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::serverUsersStats(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("ServerUsersStats");

    rpc::ServerUsersStatsRequest   input;
    rpc::ServerUsersStatsResponse*  output = response.mutable_server_users_stats();
    response.set_message_type(RPC_SERVER_USERS_STATS);

    do
    {
        if (request.has_server_users_stats())
        {
            input = request.server_users_stats();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("ServerUsersStats function called with [%s]", sessionId.c_str());

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("ServerUsersStats function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::serverWorkGroupsStats(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("ServerWorkGroupsStats");

    rpc::ServerWorkGroupsStatsRequest   input;
    rpc::ServerWorkGroupsStatsResponse*  output = response.mutable_server_workgroups_stats();
    response.set_message_type(RPC_SERVER_WORKGROUPS_STATS);

    do
    {
        if (request.has_server_workgroups_stats())
        {
            input = request.server_workgroups_stats();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("ServerWorkGroupsStats function called with [%s]", sessionId.c_str());

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("ServerWorkGroupsStats function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::serverFilesStats(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("ServerFilesStats");

    rpc::ServerFilesStatsRequest   input;
    rpc::ServerFilesStatsResponse*  output = response.mutable_server_files_stats();
    response.set_message_type(RPC_SERVER_FILES_STATS);

    do
    {
        if (request.has_server_files_stats())
        {
            input = request.server_files_stats();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("ServerFilesStats function called with [%s]", sessionId.c_str());

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("ServerFilesStats function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::serverMessagesStats(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("ServerMessagesStats");

    rpc::ServerMessagesStatsRequest   input;
    rpc::ServerMessagesStatsResponse*  output = response.mutable_server_messages_stats();
    response.set_message_type(RPC_SERVER_MESSAGES_STATS);

    do
    {
        if (request.has_server_messages_stats())
        {
            input = request.server_messages_stats();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string    sessionId          = input.session_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("ServerMessagesStats function called with [%s]", sessionId.c_str());

        resultStatus = status_not_implemented;

        if (resultStatus != status_success)
        {
            break;
        }

        /*TODO*/
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("ServerMessagesStats function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}
