/*
 * structs_to_protobuf.h
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */

#ifndef STRUCTS_TO_PROTOBUF_H_
#define STRUCTS_TO_PROTOBUF_H_
#include "protobuf/client/cpp/message_common.pb.h"
#include "protobuf/client/cpp/message_disc.pb.h"
#include "protobuf/client/cpp/message_decl.pb.h"
#include <protobuf/server/cpp/msg_serv_inner.pb.h>

#include "types/file_folder_info.h"
#include "types/topic_message_info.h"
#include "types/invitation.h"
#include "types/user_info.h"
#include "types/misc_info.h"

void convert_workgroupinfo  (const WorkGroupInfo& wgi, rpc::WorkGroupInfo* wgip);

void convert_coworkerinfo   (const UserWorkGroupInfo& uwgi, rpc::CoworkerUserInfo* cuip);

void convert_inviteinfo     (const InviteInfo& ii, rpc::WorkGroupInvite* wgi);

void convert_fileinfo       (const FileInfo& fi, rpc::FileInfo* fip);

void convert_topicinfo      (const TopicInfo& ti, rpc::TopicsListResponse_TopicInfo* tip);

void convert_messageinfo    (const MessageInfo& mi, rpc::MessagesListResponse_MessageInfo* mip);

void convert_accountstats   (const LoginStats& as, rpc::LoginStats* lsp);

void convert_purchaseinfo   (const server_rpc::PurchaseApplyRequest* par, PurchaseData& pd);

#endif /* STRUCTS_TO_PROTOBUF_H_ */
