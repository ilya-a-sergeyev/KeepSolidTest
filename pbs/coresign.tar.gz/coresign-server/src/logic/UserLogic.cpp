/*
 * logic.cpp
 *
 *  Created on: 31 бер. 2011
 *      Author: fireball
 */

#include "logic/UserLogic.h"

#include <sutil/logging.h>
#include <util/DataVerifier.h>
#include <sutil/MailerHelper.h>
#include "util/getNotificationLiterals.h"

#include "encryption/xopenssl.h"
#include <boost/algorithm/string.hpp>

#include "db/tariffs/TariffManagerPgSql.h"
#include "db/users/UserManagerPgSql.h"
#include "db/folders/FolderManagerPgSql.h"
#include "logic/EventLogic.h"
#include "logic/HelperLogic.h"
#include "logic/AuthLogic.h"
#include "network/FirstFolderCreator.h"
#include "db/purchases/PurchasesManagerPgSql.h"
#include "util/SimplexNotificationSender.h"
#include "MailTemplate.h"
#include <network/PrivateBridge.h>
#include <network/CurlUploaderLight.h>
#include <jsoncpp/json/json.h>
#include "db/folder_invites/FolderInvitesPgSql.h"
#include "logic/WorkGroupLogic.h"



rpc_status_code UserLogic::accountStatsNoSession        (RequestContext& context, const std::string& login, AccountStats& accountStats)
{

    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByLogin(login, userInfo);

        if (statusCode != status_success)
        {
            break;
        }

        statusCode = WorkGroupManagerPgSql::get_folders_sum_size(userId,accountStats.data_size);
        statusCode = TariffManagerPgSql::get_user_limits(userId,accountStats.limits);

        accountStats.expiration_date = userInfo.expiration_date;
        accountStats.creation_date = userInfo.creation_date;
        accountStats.now_date = time(NULL);
        if (accountStats.expiration_date < accountStats.now_date)
        {
            accountStats.account_status = "expired";
        }
        else
        {
            accountStats.account_status = "ok";
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("AccountStats function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("AccountStats function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::accountStats(RequestContext& context, AccountStats& accountStats,
        bool isExtended, bool getServersList, bool createIfNull)
{

    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (createIfNull == true && context.service_type != KeepSolidService && !context.session_info.username.empty())
        {
            // not needed?
            if (check_email(context.session_info.username) != EXIT_SUCCESS)
            {
                statusCode = status_bad_syntax;
                LOG_ABSOLUTE("CreateUser function failed: login [%s] is not valid e-mail ", context.session_info.username.c_str());
                break;
            }

            UserCredentials uc;
            statusCode = UserManagerPgSql::getCredentialsByLogin(context.session_info.username, uc);

            if (uc.user_id == 0 && statusCode == status_does_not_exist)
            {
                std::string password = randomstring(32);
                uc.login           = context.session_info.username;
                uc.password        = sha256(password);
                uc.license_accepted= true;
                uc.is_dummy        = false;

                bool res = rsa_easy_encrypt(password, context.session_info.public_key, accountStats.encrypted_password);
                if (res == false)
                {
                    LOG_ERROR("Problem encrypting data for user [%s]", uc.login.c_str());
                    break;
                }

                uc.encrypted_external_password = accountStats.encrypted_password;

                statusCode = AuthLogic::createDummyUserWithCredentials(uc);

                if (statusCode != status_success)
                {
                    break;
                }

                statusCode = UserManagerPgSql::updateUserProfile(context.session_info.username,"",
                        context.session_info.first_name,context.session_info.last_name,"");

                if (statusCode != status_success)
                {
                    break;
                }

//                {
//                    int64_t companyId = -1;
//                    statusCode = CompanyManagerPgSql::create_company(uc.user_id, uc.login, "Personal account "+uc.login, true, companyId);

//                    if (statusCode != status_success)
//                    {
//                        LOG_INFORMATION("Could not create personal company for %s", uc.login.c_str());
//                        break;
//                    }

//                    statusCode = CompanyManagerPgSql::create_user_in_company(uc.user_id, uc.login, companyId, 1, "Company creator");
//                }

                //User is registered for the first time, may be used for bonuses
                accountStats.is_first_login = true;

                if (context.service_type != KeepSolidService)
                {
                    auto f = [context]() {
                        std::string address     = "https://api.simplexsolutionsinc.com";
                        std::string auth        = "ptY70-26b-15m42z[Qt5_ffc2a^nxp1q65-lwMbnPx49f";

                        KeyValue outer;
                        KeyValue inner;

                        KeyValue params_packed;
                        inner["session"] = context.session_id;
                        outer["action"] = "checklist_registration_boost";
                        PrivateBridge::packDataAuth(outer, inner, auth, params_packed);
                        std::string response;
                        CurlUploaderLight::get_thread_local_ptr().set_timeout(15);
                        CurlUploaderLight::get_thread_local_ptr().set_check_ssl(false);
                        CurlUploaderLight::get_thread_local_ptr().post_request_base64(address, params_packed, response, "");
                        LOG_INFORMATION("Response for [KOSTIL] for [%s] is [%s]", context.session_info.username.c_str(), response.c_str());
                    };

                    Globals::get_globals().getThreadPoolSecondary().schedule(f);

                    if (context.session_info.custom_params["too_many_users"].compare("0") == 0)
                    {
                        UserManagerPgSql::prolongExpiration(uc.login, "10 days");
                    }
                }

                if (statusCode == status_success && context.service_type == KeepSolidService)
                {
                    FirstFolderCreator::create_first_folder(context.session_info.username,password,uc.public_key);
                }

                SimplexNotification notification("register_user");
                notification.set_recipient_login(uc.login);
                SimplexNotificationSender::send_non_block(context, notification);
            }
            else if (uc.user_id>0 && uc.is_dummy)
            {
                statusCode = status_user_is_dummy;
            }
            else if (uc.user_id>0 && !uc.is_activated)
            {
                statusCode = status_user_not_activated;
            }

            if (statusCode!=status_success)
            {
                break;
            }

            statusCode = HelperLogic::checkSession(context, userId, deviceId);

            if (statusCode != status_success || userId <= 0 )
            {
                statusCode = status_unauthorized;
                break;
            }

        }

        if (context.service_type != KeepSolidService)
        {
            UserCredentials uc;
            statusCode = UserManagerPgSql::getCredentialsByLogin(context.session_info.username, uc);
            accountStats.encrypted_password = uc.encrypted_external_password;
        }

        //Get all anonymous invites and accept them
        if (context.service_type != KeepSolidService)
        {
            InviteInfosByWorkGroups inviteInfoList;
            WorkGroupInvitesPgSql::get_invitations(context, context.session_info.username, inviteInfoList);
            for(auto invite : inviteInfoList)
            {
                WorkGroupLogic::workgroupSubscribe(context, invite.second.invite_id, true);
            }
        }

        //statusCode = WorkGroupManagerPgSql::get_folders_sum_size(userId,accountStats.data_size);
        //statusCode = TariffManagerPgSql::get_user_limits(userId, accountStats.limits);

        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId, userInfo);

        accountStats.expiration_date = userInfo.expiration_date;
        accountStats.creation_date = userInfo.creation_date;
        accountStats.now_date = time(NULL);

        if (accountStats.expiration_date < accountStats.now_date)
        {
            accountStats.account_status = "expired";
        }
        else
        {
            accountStats.account_status = "ok";
        }

        /*
        if (isExtended == true)
        {
            UserLoginList userEmails;
            statusCode = WorkGroupManagerPgSql::list_all_coworkers(userId,userEmails);
            accountStats.coworkers_count = userEmails.size();
            statusCode = LoginStatsPgSql::get_stats_by_date(userId,accountStats.login_history);
            statusCode = LoginStatsPgSql::get_stats_by_device(userId,accountStats.device_stats);
        }
        */

        if (getServersList == true)
        {
            accountStats.api_servers.push_back(AddressPortPair("rpc.v1.keepsolid.com", "443"));
            accountStats.notification_servers.push_back(AddressPortPair("notify.v1.keepsolid.com", "443"));
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("AccountStats function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("AccountStats function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::getMyData(RequestContext& context, UserInfo& userInfo, UserCredentials& userCredentials)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        statusCode = UserManagerPgSql::getUserInfoByUserId(userId, userInfo);

        if (statusCode != status_success)
        {
            break;
        }

        statusCode = UserManagerPgSql::getCredentialsByUserId(userId, userCredentials);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("GetMyData function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("GetMyData function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::setMyData           (RequestContext& context, UserInfo& userInfo)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        UserInfo userInfo_old;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo_old);

        if (statusCode != status_success)
        {
            LOG_DEBUGGING("SetMyData strange error! statusCode = %i", statusCode);
            statusCode = status_unauthorized;
            break;
        }

        userInfo.login = userInfo_old.login;

        if (userInfo.email.empty())
        {
            userInfo.email = userInfo_old.email;
        }
        else if (userInfo.email.compare("EMPTY") == 0)
        {
            userInfo.email = "";
        }

        if (userInfo.first_name.empty())
        {
            userInfo.first_name = userInfo_old.first_name;
        }
        else if (userInfo.first_name.compare("EMPTY") == 0)
        {
            userInfo.first_name = "";
        }

        if (userInfo.last_name.empty())
        {
            userInfo.last_name = userInfo_old.last_name;
        }
        else if (userInfo.last_name.compare("EMPTY") == 0)
        {
            userInfo.last_name = "";
        }

        if (userInfo.user_pic.empty())
        {
            userInfo.user_pic = userInfo_old.user_pic;
        }
        else if (userInfo.user_pic.compare("EMPTY") == 0)
        {
            userInfo.user_pic = "";
        }

        statusCode = UserManagerPgSql::updateUserProfile(userInfo.login,userInfo.email,userInfo.first_name,userInfo.last_name,userInfo.user_pic);

        if (statusCode == status_success)
        {
            bStatus = true;


            UserIdList userIds;
            WorkGroupManagerPgSql::list_all_coworkers_ids(userId,userIds);
            UserInfo userInfo;
            statusCode = UserManagerPgSql::getUserInfoByUserId(userId,userInfo);

            for (unsigned int i=0; i<userIds.size(); i++)
            {
                EventLogic::userInfoUpdate(userId,userInfo.login,deviceId,userInfo.first_name,userInfo.last_name,userInfo.user_pic,userIds[i]);
            }
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("SetMyData function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("SetMyData function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::notificationsGet    (RequestContext& context, NotificationsSubscription& notifySub)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        //LOG_INFORMATION("NotifyLiterals size is %zi",getNotifyLiterals().size());

        statusCode = UserManagerPgSql::getNotifications(userId,getNotifyLiterals(),notifySub);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("NotificationsGet function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("NotificationsGet function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}



rpc_status_code UserLogic::notificationsSet    (RequestContext& context, NotificationsSubscription& notifySub)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        //LOG_INFORMATION("NotifyLiterals size is %zi",getNotifyLiterals().size());

        std::vector<std::string> notifyLiterals = getNotifyLiterals();
        NotificationsSubscription notifySubWrite;
        for (unsigned int i=0; i < notifyLiterals.size(); i++)
        {
            if (notifySub.find(notifyLiterals[i]) != notifySub.end())
            {
                if (notifySub[notifyLiterals[i]].compare("1") == 0 || notifySub[notifyLiterals[i]].compare("true") == 0)
                {
                    notifySubWrite[notifyLiterals[i]] = "1";
                }
                else
                {
                    notifySubWrite[notifyLiterals[i]] = "0";
                }
            }
        }

        LOG_ABSOLUTE("NotificationSet got %zi params and cleaned up to %zi",notifySub.size(),notifySubWrite.size());

        statusCode = UserManagerPgSql::setNotifications(userId,notifySubWrite);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("NotificationsSet function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("NotificationsSet function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::userInfoMass(RequestContext& context, const UserLoginList& userEmailList, UserInfoList& userInfoList, bool createIfNull)
{
    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;

    do
    {
        statusCode = HelperLogic::checkSession(context, userId, deviceId);

        if (statusCode != status_success || userId <= 0 )
        {
            statusCode = status_unauthorized;
            break;
        }

        UserInfo inviterUserInfo;
        statusCode = UserManagerPgSql::getUserInfoByUserId(userId,inviterUserInfo);

        if (statusCode != status_success || inviterUserInfo.login.empty() )
        {
            LOG_ABSOLUTE("No user was found");
            break;
        }

        for (UserLoginList::const_iterator iter = userEmailList.begin(); iter!=userEmailList.end(); iter++)
        {
            UserInfo userInfo;
            userInfo.login = (*iter);
            rpc_status_code status = status_internal_error;
            if (context.service_type == KeepSolidService)
            {
                status = UserLogic::userInfoKS(context,inviterUserInfo,userInfo,createIfNull);
            }
            else
            {
                status = UserLogic::userInfoSX(context,userInfo);
            }
            userInfo.returnStatus = status;
            userInfoList.push_back(userInfo);

            if (status == status_success)
            {
                statusCode = status;
            }
        }
    }
    while (false);

    return statusCode;
}

rpc_status_code UserLogic::userInfoKS(RequestContext& context, const UserInfo& inviterUserInfo, UserInfo& userInfo, bool createIfNull)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {

        if (check_email(userInfo.login) != EXIT_SUCCESS)
        {
            statusCode = status_bad_syntax;
            LOG_INFORMATION("UserInfo function failed: login [%s] is not valid e-mail ", userInfo.login.c_str());
            break;
        }

        statusCode = UserManagerPgSql::getUserInfoByLogin(userInfo.login,userInfo);

        if (statusCode == status_does_not_exist && createIfNull == true)
        {
            {
                if (check_email(userInfo.login) != EXIT_SUCCESS)
                {
                    statusCode = status_bad_syntax;
                    LOG_ABSOLUTE("UserInfo function failed: login [%s] is not valid e-mail ", userInfo.login.c_str());
                    break;
                }

                LOG_ABSOLUTE("No invitee was found, creating dummy user");

                std::string password; // generate random password for dummy user;
                if (userInfo.user_id == 0)
                {
                    password = randomstring(12);

                    UserCredentials uc;
                    uc.login           = userInfo.login;
                    uc.password        = sha256(password);
                    uc.license_accepted= false;
                    uc.is_dummy        = true;

                    statusCode = AuthLogic::createDummyUserWithCredentials(uc);
                }

                MailTemplate::invite_new_user(inviterUserInfo.first_name, inviterUserInfo.last_name, inviterUserInfo.login,
                        userInfo.login, password);

                userInfo.wasInvited = true;
            }

            statusCode = UserManagerPgSql::getUserInfoByLogin(userInfo.login,userInfo);
        }

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("UserInfo function ended: userId [%lli]", inviterUserInfo.user_id);
    }
    else
    {
        LOG_INFORMATION("UserInfo function failed: userId [%lli]", inviterUserInfo.user_id);
    }

    return statusCode;
}

rpc_status_code UserLogic::userInfoSX(RequestContext& context, UserInfo& userInfo)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {

        if (check_social_id(userInfo.login) != EXIT_SUCCESS)
        {
            statusCode = status_bad_syntax;
            LOG_INFORMATION("UserInfo function failed: login [%s] is not valid Email or SocialId ", userInfo.login.c_str());
            break;
        }

        if (check_email(userInfo.login) != EXIT_SUCCESS)
        {
            do
            {
                KeyValue params_external;
                params_external["action"] = "whois";

                KeyValue params_outer;
                params_outer["session"] = context.session_id;

                std::vector<std::string> exploded;        //data exploded by @
                boost::algorithm::split(exploded,userInfo.login,boost::algorithm::is_any_of("@"),boost::algorithm::token_compress_on);

                if (exploded.size() != 2)
                {
                    LOG_INFORMATION("Bad size of exploded data [%s] -> [%zi]", userInfo.login.c_str(), exploded.size());
                    break;
                }

                params_outer["id"] = exploded[0];
                params_outer["type"] = exploded[1];
                KeyValue params_inner;

                KeyValue params_packed;
                bool result = PrivateBridge::packDataAuth(params_external, params_outer, "bPr_RvK61a-JeXX{b+A-dcFuSp_1729Teq0-[QbtF62L9", params_packed);
                if (result == false)
                {
                    LOG_ERROR("Problem packing data");
                    break;
                }

                std::string response;
                CURLcode res = CurlUploaderLight::get_thread_local_ptr().post_request_base64("https://auth.simplexsolutionsinc.com/", params_packed, response, "");
                LOG_INFORMATION("Response [%s]", response.c_str());

                if(res != CURLE_OK || response.empty())
                {
                    break;
                }

                Json::Value val;
                Json::Reader reader;
                result = reader.parse(response, val);

                if (result == false)
                {
                    LOG_INFORMATION("ShellExecutor: error [%i][%s]",result, reader.getFormatedErrorMessages().c_str());
                    break;
                }

                if (!val.isObject() || !val.isMember("response") || !val["response"].asInt() == 200)
                {
                    LOG_INFORMATION("BAD response");
                    break;
                }

                if (!val.isMember("userinfo") || !val["userinfo"].isArray())
                {
                    LOG_INFORMATION("BAD userinfo");
                    break;
                }

                if (val["userinfo"].empty() || !val["userinfo"][0].isObject() || !val["userinfo"][0].isMember("username"))
                {
                    LOG_INFORMATION("BAD userinfo array");
                    break;
                }

                std::string temp = val["userinfo"][0]["username"].asString();
                userInfo.login = temp;

                LOG_INFORMATION("Using login [%s] instead of [%s]", temp.c_str(), userInfo.login.c_str());
            }
            while(false);
        }

        statusCode = UserManagerPgSql::getUserInfoByLogin(userInfo.login, userInfo);

        if (statusCode == status_success)
        {
            bStatus = true;
        }

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("UserInfo function ended: user [%s]", userInfo.login.c_str());
    }
    else
    {
        LOG_INFORMATION("UserInfo function failed: user [%s]", userInfo.login.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::purchaseApply(RequestContext& context, const PurchaseData& purchase)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByLogin(purchase.login, userInfo);

        if (statusCode != status_success || userInfo.user_id <= 0)
        {
            LOG_ERROR("Bad user [%s] while purchasing, error [%lli]", purchase.login.c_str(), statusCode);
            ADD_ERROR_MESSAGE(context, "Bad user " + purchase.login + " while purchasing");
            break;
        }

        statusCode = PurchasesManagerPgSql::create_purchase(userInfo.user_id, purchase);

        for (auto p : purchase.infos)
        {
            if (check_purchase_type(p.type) != 0
                    && check_purchase_interval(p.count) != 0)
            {
                LOG_ERROR("Bad purchase type [%s] or count [%s]", p.type.c_str(), p.count.c_str());
                ADD_ERROR_MESSAGE(context, "Bad purchase type ["+p.type+"] or count ["+p.count+"]");
                continue;
            }
            std::string purchase_time;
            if (p.type.compare("interval") == 0)
            {
                purchase_time = p.count;
            }
            else
            {
                purchase_time = p.count + " " + p.type;
            }

            if (purchase.overwrite == true)
            {
                statusCode = UserManagerPgSql::prolongExpirationOverwrite(purchase.login, purchase_time, purchase.purchase_date);
            }
            else
            {
                statusCode = UserManagerPgSql::prolongExpiration(purchase.login, purchase_time);
            }
        }

        if (statusCode != status_success)
        {
            break;
        }

        bStatus = true;

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("purchaseApply function ended: user [%s]", purchase.login.c_str());
    }
    else
    {
        LOG_INFORMATION("purchaseApply function failed: user [%s]", purchase.login.c_str());
    }

    return statusCode;
}


rpc_status_code UserLogic::purchaseRefund(RequestContext& context, const std::string& login, const std::string& purchase_hash)
{
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByLogin(login, userInfo);

        if (statusCode != status_success || userInfo.user_id <= 0)
        {
            LOG_ERROR("Bad user [%s] while purchasing, error [%lli]", login.c_str(), statusCode);
            ADD_ERROR_MESSAGE(context, "Bad user " + login + " while refund");
            break;
        }

        PurchaseData purchase;
        statusCode = PurchasesManagerPgSql::get_purchase(userInfo.user_id, purchase_hash, purchase);

        for (auto p : purchase.infos)
        {
            if (check_purchase_type(p.type) != 0
                    && check_purchase_interval(p.count) != 0)
            {
                LOG_ERROR("Bad purchase type [%s] or count [%s]", p.type.c_str(), p.count.c_str());
                ADD_ERROR_MESSAGE(context, "Bad purchase type ["+p.type+"] or count ["+p.count+"]");
                continue;
            }
            std::string purchase_time;
            if (p.type.compare("interval") == 0)
            {
                purchase_time = p.count;
            }
            else
            {
                purchase_time = p.count + " " + p.type;
            }

            statusCode = UserManagerPgSql::reduceExpiration(purchase.login, purchase_time);
        }

        if (statusCode != status_success)
        {
            break;
        }

        bStatus = true;

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("purchaseRefund function ended: user [%s] hash [%s]", login.c_str(), purchase_hash.c_str());
    }
    else
    {
        LOG_INFORMATION("purchaseRefund function failed: user [%s] hash [%s]", login.c_str(), purchase_hash.c_str());
    }

    return statusCode;
}

rpc_status_code UserLogic::userRemove(RequestContext& context, const std::string& login)
{

    int64_t userId = -1;
    std::string deviceId;
    rpc_status_code statusCode = status_internal_error;
    bool bStatus = false;

    do
    {
        UserInfo userInfo;
        statusCode = UserManagerPgSql::getUserInfoByLogin(login, userInfo);

        if (statusCode != status_success)
        {
            break;
        }

        statusCode = UserManagerPgSql::removeUser(userInfo.user_id);

        if (statusCode != status_success)
        {
            break;
        }

        bStatus = true;

    }
    while(false);

    if (bStatus)
    {
        LOG_ABSOLUTE("userRemove function ended: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }
    else
    {
        LOG_INFORMATION("userRemove function failed: userId [%lli] : session [%s]", userId, context.session_id.c_str());
    }

    return statusCode;
}
