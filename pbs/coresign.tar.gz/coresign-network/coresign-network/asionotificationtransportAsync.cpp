#include "asionotificationtransportAsync.h"

#include <thread>
#include <functional>
#include <util/logging.h>
#include <types/transport_flags.h>

#ifdef DEBUG_FUNCTION
  #undef DEBUG_FUNCTION
#endif
#define DEBUG_FUNCTION

struct default_callback
{
    void operator()(const std::string& message) const
    {
        LOG_ERROR("NotificationReceiver: No callback for notification specified! got message [%s]", message.c_str());
    }
};

struct default_connection_cb
{
    void operator()(OperationStatus opstat, bool status) const
    {
        LOG_ERROR("NotificationReceiver: No callback for connection status! Got opstat [%i] and status [%s]", opstat, status ? "true" : "false");
    }
};

#define DEFAULT_TIMEOUT     90000
#define MAX_DATA_IN         1600000

AsioNotificationTransportAsync::AsioNotificationTransportAsync(const std::string &address, const std::string &port):
    _io_service(1),
    _is_service_running(false),
    _socket(_io_service),
    _timer(_io_service),
    _strand(_io_service),
    _callback(default_callback()),
    _connection_cb(default_connection_cb()),
    _address(address),
    _port(port),
    _data_in_size_planned(-1),
    _data_in_size_real(-1),
    _data_out_size(-1),
    _timeout_ms(DEFAULT_TIMEOUT),
    _operation_status(OPSTATUS_UNDEFINED),
    _waiting_notification(false)
{
    connect();
}

AsioNotificationTransportAsync::~AsioNotificationTransportAsync()
{
    _callback       = default_callback();
    _connection_cb  = default_connection_cb();
}

OperationStatus AsioNotificationTransportAsync::read(asio::error_code& err, std::string& data_in)
{
    DEBUG_FUNCTION;
    run_service();

    start_timeout();
    async_read_size();

    std::unique_lock<std::mutex> lock(_mutex);
    _operation_status = OPSTATUS_UNDEFINED;
    while(_operation_status == OPSTATUS_UNDEFINED)
    {
        _condition_var.wait(lock);
    }

    stop_timeout();

    if (_operation_status == OPSTATUS_OK)
    {
        if (_data_in_size_real < 0 || _data_in_vector.size() < _data_in_size_real)
        {
            LOG_ERROR("NotificationReceiver: data_in vector got not same data as planned [%lu]:[%lli]",_data_in_vector.size(), _data_in_size_real);
            return OPSTATUS_ERROR;
        }

        data_in.assign(_data_in_vector.data(), _data_in_size_real);
    }

    return _operation_status;
}

OperationStatus AsioNotificationTransportAsync::write(const std::string& data_out)
{
    DEBUG_FUNCTION;
    run_service();

    TransportFlagsHelper flags;
    flags.set_size(data_out.size());
    //flags.set_use_ksv2_format(true);
    _data_out       = data_out;
    _data_out_size  = flags.get_transport_data();

    start_timeout();
    async_write_size();

    std::unique_lock<std::mutex> lock(_mutex);
    _operation_status = OPSTATUS_UNDEFINED;
    while(_operation_status == OPSTATUS_UNDEFINED)
    {
        _condition_var.wait(lock);
    }

    stop_timeout();

    return _operation_status;
}

void AsioNotificationTransportAsync::subscribe(const function_MessageCallback& callback, const function_ConnectionCallback& connection_cb, bool start_service)
{
    if (start_service)
    {
        _callback = callback;
        _connection_cb = connection_cb;
        try
        {
        _connection_cb(OPSTATUS_OK, true);
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("NotificationReceiver: error calling callback: [%s]", e.what());
        }

        run_service();
    }
    schedule_ping();
}

void AsioNotificationTransportAsync::stop()
{
    LOG_INFORMATION("NotificationReceiver: STOP");
    try
    {
        _waiting_notification = false;
        _callback = default_callback();
        _connection_cb = default_connection_cb();
        disconnect();
        stop_service();
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("NotificationReceiver: Exception stopping IO service [%s]",e.what());
    }
}

bool AsioNotificationTransportAsync::is_connected()
{
    return _socket.is_open();
}

bool AsioNotificationTransportAsync::connect()
{
    try
    {
        asio::ip::tcp::resolver resolver(_socket.get_io_service());
        asio::ip::tcp::resolver::query query(_address,_port);
        asio::ip::tcp::endpoint endpoint = *resolver.resolve(query);

        _socket.lowest_layer().connect(endpoint);

        asio::socket_base::keep_alive option(true);
        _socket.lowest_layer().set_option(option);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("NotificationReceiver: Problem connecting [%s]",e.what());
        return false;
    }

    LOG_INFORMATION("NotificationReceiver: Connected OK");
    return true;
}

void AsioNotificationTransportAsync::disconnect()
{
    asio::error_code ignored_ec;
    _socket.shutdown(asio::ip::tcp::socket::shutdown_both, ignored_ec);
    _socket.close(ignored_ec);

    LOG_INFORMATION("NotificationReceiver: Disconnected OK");
}

void AsioNotificationTransportAsync::schedule_ping()
{
    _waiting_notification = true;
    start_timeout();
    async_read_size();
}

void AsioNotificationTransportAsync::run_service()
{
    std::lock_guard<std::mutex> lock(_mutex);
    if (!_is_service_running)
    {
        _is_service_running = true;
        std::thread t(std::bind(&AsioNotificationTransportAsync::run_service_function, shared_from_this()));
    }
}

void AsioNotificationTransportAsync::run_service_function()
{
    asio::error_code err;
    asio::io_service::work work(_io_service);
    _io_service.run(err);
    _io_service.reset();
    _is_service_running = false;

    LOG_INFORMATION("NotificationReceiver: IO Service stopped with err [%s]",err.message().c_str());
}

void AsioNotificationTransportAsync::stop_service()
{
    _io_service.stop();
}

void AsioNotificationTransportAsync::start_timeout()
{
    _timer.expires_from_now(boost::posix_time::milliseconds(_timeout_ms));
    _timer.async_wait(
                _strand.wrap(
                        std::bind(
                      &AsioNotificationTransportAsync::handle_timeout,
                      shared_from_this(),
                       asio::placeholders::error
                       )
                    )
                );
}

void AsioNotificationTransportAsync::stop_timeout()
{
    _timer.cancel();
}

void AsioNotificationTransportAsync::handle_timeout(const asio::error_code& error)
{
    if (error != asio::error::operation_aborted)
    {
        if (error)
        {
            LOG_ERROR("NotificationReceiver: Timeout handled with error [%i] : [%s]",error.value(),error.message().c_str());
        }
        else
        {
            LOG_INFORMATION("NotificationReceiver: Connection timed-out!");
            operation_complete(OPSTATUS_TIMEDOUT);
        }
    }
}

void AsioNotificationTransportAsync::async_write_size()
{
    DEBUG_FUNCTION;
    asio::async_write(_socket,
                             asio::buffer(&_data_out_size, sizeof(_data_out_size)),
                             _strand.wrap(
                                     std::bind(&AsioNotificationTransportAsync::handle_write,
                                             shared_from_this(),
                                             asio::placeholders::error,
                                             0)
                                 )
                             );
}

void AsioNotificationTransportAsync::async_write_data()
{
    DEBUG_FUNCTION;
    asio::async_write(_socket,
                             asio::buffer(_data_out.c_str(), _data_out.size()),
                             _strand.wrap(
                                     std::bind(&AsioNotificationTransportAsync::handle_write,
                                             shared_from_this(),
                                             asio::placeholders::error,
                                             1)
                                 )
                             );
}

void AsioNotificationTransportAsync::async_write_confirmation()
{
    DEBUG_FUNCTION;
    asio::async_write(_socket,
                             asio::buffer(&_data_in_size_real, sizeof(_data_in_size_real)),
                             _strand.wrap(
                                     std::bind(&AsioNotificationTransportAsync::handle_write,
                                             shared_from_this(),
                                             asio::placeholders::error,
                                             2)
                                 )
                             );
}

void AsioNotificationTransportAsync::handle_write(const asio::error_code& error, int type)
{
    DEBUG_FUNCTION;
    if (error.value() == asio::errc::success)
    {
        if (type == 0)  //we are handling write_size
        {
            async_write_data();
        }
        else if (type == 1) // we are handling write_data
        {
            operation_complete(OPSTATUS_OK);
        }
        else if (type == 2) // we are handling write_confirmation
        {
            //OK
        }
    }
    else if (error.value() == asio::errc::interrupted
             || error.value() == asio::errc::operation_canceled
             || error == asio::error::operation_aborted)
    {
        operation_complete(OPSTATUS_ABORTED);
        LOG_INFORMATION("NotificationReceiver: operation canceled type [%i] [%s]", type, error.message().c_str());
    }
    else
    {
        operation_complete(OPSTATUS_ERROR);
        LOG_ERROR("NotificationReceiver: Problem writing data type [%i] [%s]", type, error.message().c_str());
    }
}

void AsioNotificationTransportAsync::async_read_data()
{
    DEBUG_FUNCTION;
    if (_data_in_vector.capacity() < _data_in_size_planned)
    {
        _data_in_vector.resize((_data_in_size_planned/32+2)*32);
    }
    asio::async_read(_socket, asio::buffer(_data_in_vector),
                            asio::transfer_exactly(_data_in_size_planned),
                            _strand.wrap(
                                    std::bind(&AsioNotificationTransportAsync::handle_read,
                                            shared_from_this(),
                                            asio::placeholders::error,
                                            asio::placeholders::bytes_transferred,
                                            1)
                                )
                            );
}

void AsioNotificationTransportAsync::async_read_size()
{
    DEBUG_FUNCTION;
    asio::async_read(_socket, asio::buffer(&_data_in_size_planned,sizeof(_data_in_size_planned)),
                            _strand.wrap(
                                    std::bind(&AsioNotificationTransportAsync::handle_read,
                                            shared_from_this(),
                                            asio::placeholders::error,
                                            asio::placeholders::bytes_transferred,
                                            0)
                                )
                            );
}

std::size_t AsioNotificationTransportAsync::handle_read(const asio::error_code& error, std::size_t bytes_transferred, int type)
{
    DEBUG_FUNCTION;
    if (error.value() == asio::errc::success)
    {
        if (type == 0)  //we are handling read_size
        {
            TransportFlagsHelper flags;
            flags.init_with_transport_data(_data_in_size_planned);
            _data_in_size_planned = flags.get_size();
            if (_data_in_size_planned >= 0 && _data_in_size_planned < MAX_DATA_IN)
            {
                async_read_data();
            }
            else
            {
                LOG_ERROR("NotificationReceiver: Problem reading data size [%s] or it is invalid [%lli]", error.message().c_str(), _data_in_size_planned);
                operation_complete(OPSTATUS_ERROR);
            }
        }
        else if (type == 1) // we are handling read_data
        {
            _data_in_size_real = bytes_transferred;
            if (_data_in_size_planned == _data_in_size_real)    // if got data of correct size
            {
                async_write_confirmation();
                operation_complete(OPSTATUS_OK);
                handle_notification(error,bytes_transferred);
            }
            else
            {
                LOG_ERROR("NotificationReceiver: Planned and real data read mismatch [%lli]:[%lli]", _data_in_size_planned, _data_in_size_real);
                operation_complete(OPSTATUS_ERROR);
            }
        }
    }
    else if (error.value() == asio::errc::interrupted
             || error.value() == asio::errc::operation_canceled
             || error == asio::error::operation_aborted)
    {
        LOG_INFORMATION("NotificationReceiver: operation canceled type [%i] [%s]", type, error.message().c_str());
        operation_complete(OPSTATUS_ABORTED);
    }
    else
    {
        LOG_ERROR("NotificationReceiver: Problem reading type [%i] [%s]", type, error.message().c_str());
        operation_complete(OPSTATUS_ERROR);
    }

    return bytes_transferred;
}

void AsioNotificationTransportAsync::operation_complete(OperationStatus status)
{
    DEBUG_FUNCTION;

    if (_waiting_notification == true && status != OPSTATUS_OK)
    {
        try
        {
            _connection_cb(status, false);
        }
        catch (const std::exception& e)
        {
            LOG_ERROR("NotificationReceiver: error calling callback: [%s]", e.what());
        }

        stop();
    }

    {
        std::lock_guard<std::mutex> lock(_mutex);
        _operation_status=status;
    }
    _condition_var.notify_one();
}

std::size_t AsioNotificationTransportAsync::handle_notification(const asio::error_code& error, std::size_t bytes_transferred)
{
    do
    {
        //LOG_INFORMATION("NotificationReceiver: got some data [%lu]", bytes_transferred);

        if (_waiting_notification == false)
        {
            break;
        }

        {
            //If notification contains data
            if ( bytes_transferred > 0)
            {
                try
                {
                    std::string data_push;
                    data_push.assign(_data_in_vector.data(), _data_in_size_real);
                    _callback(data_push);
                }
                catch (const std::exception& e)
                {
                    LOG_ERROR("NotificationReceiver: error calling callback: [%s]", e.what());
                    break;
                }
            }

            //Wait for another notification
            schedule_ping();
        }
    }
    while (false);

    return bytes_transferred;
}
