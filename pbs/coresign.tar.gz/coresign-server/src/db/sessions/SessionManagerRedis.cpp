/*
 * SessionManagerPgSql.cpp
 *
 *  Created on: 25 бер. 2011
 *      Author: fireball
 */

#include "SessionManagerRedis.h"
#include <db/RedisHelper.h>
#include <sutil/logging.h>
#include <encryption/xopenssl.h>
#include "SessionManagerHelper.h"
#include "types/request_context.h"

#define SESSION_TIMEOUT_MINUTES     10*60
#define SESSION_PRETIMEOUT_MINUTES  4*60

rpc_status_code SessionManagerRedis::get_session(const std::string& session_id,
                                                 const std::string& ip_address,
                                                 SessionInfo& session)
{
    rpc_status_code	returnStatus = status_internal_error;

    do
    {
        Redis* r = RedisHelper::get().get_read_connection();
        if (r == nullptr)
        {
            LOG_ERROR("Redis is NULL! ALARM");
            break;
        }

        std::string key = "Simplex-Core:Sessions:s:"+session_id;
        Redis::redisMap m;

        bool stat = r->hgetall(key, m);
        if (stat == false)
        {
            LOG_INFORMATION("Failure: trying to query user for session [%s]",
                            session_id.c_str());
            returnStatus = status_unauthorized;
            break;
        }

        int32_t ttl = 0;
        stat = r->ttl(key, ttl);

        bool res = convert_sessioninfo_db(m, session);
        if (res == false)
        {
            LOG_INFORMATION("Failure: bad session [%s]", session_id.c_str());
            session = SessionInfo();
            returnStatus = status_unauthorized;
            break;
        }
        session.custom_params = m;

        session.session_id  = session_id;
        session.is_old      = ttl < SESSION_PRETIMEOUT_MINUTES;

//        if (ip_address.compare("127.0.0.1") != 0 && session.ip_address.compare(ip_address) != 0)
//        {
//            LOG_INFORMATION("Failure: ip_addresses are not equal [%s]:[%s]",
//                            session.ip_address.c_str(), ip_address.c_str());
//            session = SessionInfo();
//            returnStatus = status_unauthorized;
//            break;
//        }

        returnStatus = status_success;
    }
    while(false);

    return returnStatus;
}

rpc_status_code SessionManagerRedis::get_event_session(const std::string& event_session_id,
                                                       const std::string& ip_address,
                                                       SessionInfo& session)
{
    rpc_status_code	returnStatus = status_internal_error;

    do
    {
        Redis* r = RedisHelper::get().get_read_connection();
        if (r == nullptr)
        {
            break;
        }

        std::string key = "Simplex-Core:Sessions:es:"+event_session_id;

        std::string session_id;
        bool stat = r->get(key, session_id);
        if (stat == false)
        {
            LOG_INFORMATION("Failure: trying to query user for event_session [%s]",
                            event_session_id.c_str());
            returnStatus = status_unauthorized;
            break;
        }

        returnStatus = get_session(session_id, ip_address, session);
    }
    while(false);

    return returnStatus;
}

rpc_status_code SessionManagerRedis::update_session(const SessionInfo& session)
{
    rpc_status_code	returnStatus = status_internal_error;

    do
    {
        Redis* r = RedisHelper::get().get_write_connection();
        if (r == nullptr)
        {
            break;
        }

        std::string key1 = "Simplex-Core:Sessions:s:"+session.session_id;
        bool stat = r->expire(key1, session.prolong_ttl);
        if (stat == false)
        {
            break;
        }

        std::string key2 = "Simplex-Core:Sessions:es:"+session.event_session_id;
        stat = r->expire(key2, session.prolong_ttl);
        if (stat == false)
        {
               break;
        }

        returnStatus = status_success;
    }
    while(false);

    return returnStatus;
}
