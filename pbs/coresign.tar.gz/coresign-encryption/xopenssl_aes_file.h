/*
 * xopenssl_aes_file.h
 *
 *  Created on: May 27, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>
#include <istream>
#include <ostream>
#include "xopenssl_types.h"
#ifdef FILE_LOADER
#define NO_FCGI_DEFINES
    #include <fcgi_stdio.h>
#endif

xopenssl_status aes_easy_encrypt                ( FILE* in_stream, const std::string& password, FILE* out_stream, std::string& result_hash, bool write_signature, const bool * const pbCanContinue);
xopenssl_status aes_easy_encrypt                ( FILE* in_stream, const std::string& password, FILE* out_stream, bool write_signature, const bool * const pbCanContinue);
xopenssl_status aes_easy_decrypt                ( FILE* in_stream, const std::string& password, FILE* out_stream, const bool * const pbCanContinue);

xopenssl_status aes_easy_encrypt                ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, bool write_signature, const bool * const pbCanContinue);
xopenssl_status aes_easy_encrypt                ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash, bool write_signature, const bool * const pbCanContinue);
xopenssl_status aes_easy_decrypt                ( std::istream& in_stream, const std::string& password, std::ostream& out_stream, const bool * const pbCanContinue);

#ifdef FILE_LOADER
    xopenssl_status aes_easy_decrypt( std::istream& in_stream, const std::string& password, FCGI_FILE* out );
#endif
