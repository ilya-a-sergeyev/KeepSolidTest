/*
 * Globals.cpp
 *
 *  Created on: Jun 6, 2011
 *      Author: fireball
 */

#include "Globals.h"
#include <sutil/logging.h>
#include "conf/DaemonParams.h"
#include "encryption/xopenssl.h"

std::string password_callback(std::size_t max_length, boost::asio::ssl::context_base::password_purpose purpose)
{
    return "KeepSolid";
}

Globals::Globals():
    zmq_context(NULL),
    ssl_context(io_service,boost::asio::ssl::context::tlsv1_server),
    thread_pool_processing(daemon_params().getMaxWorkers()),
    thread_pool_secondary(4),
    is_stopped(false)
{
    try
    {
        ssl_context.set_options(
            boost::asio::ssl::context::default_workarounds
            | boost::asio::ssl::context::no_sslv2
            | boost::asio::ssl::context::single_dh_use);
        boost::function<std::string(std::size_t,boost::asio::ssl::context_base::password_purpose)>f (password_callback);
        ssl_context.set_password_callback(password_callback);
        ssl_context.use_certificate_chain_file("ca_cert.pem");
        //ssl_context.set_default_verify_paths();
        ssl_context.use_private_key_file("ssl_priv.pem", boost::asio::ssl::context::pem);
        ssl_context.use_tmp_dh_file("dh1024.pem");
        ssl_context.set_verify_mode(boost::asio::ssl::context::verify_none);

        void* context = ssl_context.native_handle();
        if (context!=NULL)
        {
            disable_ssl_cache(context);
        }
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure creating SSL context: %s",e.what());
    }

    try
    {
        zmq_context = new zmq::context_t(1);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure creating zmq context: %s",e.what());
    }
}

Globals::~Globals()
{
    delete zmq_context;
}

boost::shared_mutex& Globals::getGlobalStopMutex()
{
    return global_stop_mutex;
}

zmq::context_t* Globals::getZMQContext()
{
    return zmq_context;
}

boost::threadpool::pool& Globals::getThreadPoolProcessing()
{
    return thread_pool_processing;
}

boost::threadpool::pool& Globals::getThreadPoolSecondary()
{
    return thread_pool_secondary;
}

boost::asio::io_service& Globals::getIOService()
{
    return io_service;
}

boost::asio::io_service& Globals::getTimerIOService()
{
    return timer_io_service;
}

void Globals::runIOService()
{
    boost::asio::io_service::work work(io_service);
    boost::system::error_code err;
    io_service.run(err);
    LOG_INFORMATION("IO Service Main stopped with err %s",err.message().c_str());
}

boost::shared_ptr<boost::asio::ssl::context> Globals::getSSLContextPtr()
{
    boost::shared_ptr<boost::asio::ssl::context> context_ptr(new boost::asio::ssl::context(io_service,boost::asio::ssl::context::tlsv1_server));
    try
    {
        context_ptr->set_options(
            /*boost::asio::ssl::context::default_workarounds
            | */boost::asio::ssl::context::no_sslv2/*
            | boost::asio::ssl::context::single_dh_use*/);
        boost::function<std::string(std::size_t,boost::asio::ssl::context_base::password_purpose)>f (password_callback);
        context_ptr->set_password_callback(password_callback);
        context_ptr->use_certificate_chain_file("ca_cert.pem");
        context_ptr->use_private_key_file("ssl_priv.pem", boost::asio::ssl::context::pem);
        context_ptr->use_tmp_dh_file("dh1024.pem");
        context_ptr->set_verify_mode(boost::asio::ssl::context::verify_none);
    }
    catch (const std::exception& e)
    {
        LOG_ERROR("Failure creating SSL context: %s",e.what());
    }
    return context_ptr;
}

void Globals::runTimerIOService()
{
    boost::asio::io_service::work work(timer_io_service);
    boost::system::error_code err;
    timer_io_service.run(err);
    LOG_INFORMATION("IO Service Timer stopped with err %s",err.message().c_str());
}

boost::asio::ssl::context& Globals::getSSLContext()
{
    return ssl_context;
}


void Globals::stopZMQContext()
{
    zmq::context_t* temp = zmq_context;
    zmq_context = NULL;
    temp->close();
    delete temp;
}

bool Globals::isIsStopped() const
{
    return is_stopped;
}

void Globals::setIsStopped(bool isStopped)
{
    is_stopped = isStopped;
}

stop_signal_type& Globals::getStopSignal()
{
    return stop_signal;
}
