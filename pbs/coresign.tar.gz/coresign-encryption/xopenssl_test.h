#pragma once

bool xopenssl_test (const std::string& testDirPath);
