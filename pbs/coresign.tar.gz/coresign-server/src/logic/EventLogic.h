/*
 * EventLogic.h
 *
 *  Created on: Apr 1, 2013
 *      Author: fireballdark
 */

#ifndef EVENTLOGIC_H_
#define EVENTLOGIC_H_

#include "types/event_types.h"
#include "types/status_codes.h"
#include "types/misc_info.h"
#include "types/request_context.h"

class EventLogic
{
public:
    static rpc_status_code     eventsListForUser   (RequestContext& context, int64_t lastEventId, int64_t eventsLimit, bool reverse, EventsList& eventsList);

    static rpc_status_code     fileCreate                   (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t fileSize, const std::string& fileName);
    static rpc_status_code     fileDirectoryCreate          (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, const std::string& directoryName);
    static rpc_status_code     fileDelete                   (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, const std::string& fileName, bool isDirectory);
    static rpc_status_code     fileRename                   (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, const std::string& fileNameOld, const std::string& fileNameNew, bool isDirectory);
    static rpc_status_code     fileUpdate                   (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t fileSize, const std::string& fileName);
    static rpc_status_code     fileUndelete                 (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t fileSize, const std::string& fileName);

    static rpc_status_code     folderCreate        (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& folderName);
    static rpc_status_code     folderDelete        (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t workgroup_id, const std::string& folderName,  bool keep_data, int64_t hard_recipient_id);
    static rpc_status_code     folderRename        (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& folderNameOld, const std::string& folderNameNew);
    static rpc_status_code     folderInvite        (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& folderName, const std::string& inviteId, int64_t accessMode, const std::string& inviteeUser, int64_t recipientId);
    static rpc_status_code     folderSubscribe     (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& folderName, int64_t accessMode);
    static rpc_status_code     folderUnsubscribe   (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, bool keep_data, const std::string& recipientLogin, const std::string& folderName, int64_t recipientId);
    static rpc_status_code     folderReject        (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& recipientLogin, const std::string& folderName, int64_t recipientId);
    static rpc_status_code     folderAccessUpdate  (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& targetUserEmail, int64_t accessMode, const std::string& folderName);
    static rpc_status_code     folderUndelete      (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& folderName, int64_t hard_recipient_id);
    static rpc_status_code     folderMetadataUpdate(int64_t user_id, const std::string& userName, const std::string& deviceId, int64_t folderId, const std::string& folderName, const std::string& metadataNew);

    static rpc_status_code     topicCreate         (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t topicId, const std::string& topicBody);
    static rpc_status_code     topicDelete         (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t topicId, const std::string& topicBody);
    static rpc_status_code     topicUndelete       (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t topicId, const std::string& topicBody);
    static rpc_status_code     topicRename         (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t topicId, const std::string& topicBodyNew);

    static rpc_status_code     messageCreate       (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t messageId, const std::string& messageBody, int64_t topicId, int64_t parentMesId);
    static rpc_status_code     messageDelete       (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t messageId, const std::string& messageBody, int64_t topicId, int64_t parentMesId);
    static rpc_status_code     messageUndelete     (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t messageId, const std::string& messageBody, int64_t topicId, int64_t parentMesId);
    static rpc_status_code     messageEdit         (int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId, int64_t fileId, int64_t parentId, int64_t messageId, const std::string& messageBodyNew, int64_t topicId, int64_t parentMesId);

    static rpc_status_code     userInfoUpdate      (int64_t userId, const std::string& userName, const std::string& deviceId, const std::string& firstName, const std::string& lastName, const std::string& userPic, int64_t recipientId);

    static rpc_status_code     accPassChanged      (int64_t user_id, const std::string& login, const std::string& device_id, int64_t hard_recipient_id);

private:
    static rpc_status_code     createEvent         (event_type eventType, int64_t userId, const std::string& userName, const std::string& deviceId, int64_t folderId,
            int64_t fileId, int64_t parentId, const std::string& data1, const std::string& data2, const std::string& data3, const std::string& path,
            int64_t recipientId = 0, int64_t hardRecipientId = 0);
};

#endif /* EVENTLOGIC_H_ */
