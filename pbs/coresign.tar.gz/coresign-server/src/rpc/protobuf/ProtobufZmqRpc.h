/*
 * ProtobufZmqRpc.h
 *
 *  Created on: Jun 8, 2011
 *      Author: fireball
 */

#ifndef PROTOBUFZMQRPC_H_
#define PROTOBUFZMQRPC_H_
#include <string>
#include "protobuf/client/cpp/message.pb.h"
#include "protobuf/server/cpp/msg_serv_outer.pb.h"
#include "types/request_context.h"
#include "types/status_codes.h"

class ProtobufZmqRpc
{
public:
    static int                      processData             (const void* data_in, int data_in_size, std::string& data_out, const std::string& ipAddress);
    static int                      processDataServer       (const void* data_in, int data_in_size, std::string& data_out);

protected:
    static rpc_status_code_struct   callClientFunction      (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   callServerFunction      (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   accountStatusNoSession        (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   accountStatus           (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   inviteAccept            (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   purchaseApply           (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   purchaseRefund          (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   userRemove              (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   subscribeEvents         (const server_rpc::Request& request, server_rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   login                   (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   logout                  (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   createUser              (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   clientInfo              (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   userInfo                (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   activateUser            (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   changePassword          (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   changeSecretQA          (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   accountStats            (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   getMyData               (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   setMyData               (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   notificationsGet        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   notificationsSet        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   getSecretQuestion       (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   forgotPassword          (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   recoverPassword         (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   workgroupsList          (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupCoworkersList  (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupCoworkersExtra (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupCoworkersAll   (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupCoworkersAllEx (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupKickUser       (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupCreate         (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupDelete         (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupRename         (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupInvite         (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupSubscribe      (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupUnsubscribe    (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupInvitesList    (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupInfo           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupSetAccess      (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupUndelete       (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   workgroupMetadataUpdate (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   filesList               (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileDirectoryCreate     (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileDelete              (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileRename              (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileHistory             (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileInfo                (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileUpload              (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileUploadApprove       (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileDownload            (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileDirectoryHierarchy  (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileSearch              (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileUndelete            (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   fileMove                (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   eventsList              (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   topicCreate             (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   topicDelete             (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   topicRename             (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   topicUndelete           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   topicsList              (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   messageCreate           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   messageDelete           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   messageEdit             (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   messageUndelete         (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   messagesList            (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   createKeyPair           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   getKeyPair              (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   serverVersion           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   serverTimingStats       (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   serverUsersStats        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   serverWorkGroupsStats   (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   serverFilesStats        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   serverMessagesStats     (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   companyCreate           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyDelete           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyGetInfo          (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companySetInfo          (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyInvite           (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyChangeRole       (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyKickUser         (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyGetTariff        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companySetTariff        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyUsersList        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companyRolesList        (const rpc::Request& request, rpc::Response& response, RequestContext& context);
    static rpc_status_code_struct   companiesList           (const rpc::Request& request, rpc::Response& response, RequestContext& context);

    static rpc_status_code_struct   tariffsList             (const rpc::Request& request, rpc::Response& response, RequestContext& context);
};

#endif /* PROTOBUFZMQRPC_H_ */
