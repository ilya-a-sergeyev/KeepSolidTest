/*
 * FileRpc.cpp
 *
 *  Created on: Mar 20, 2013
 *      Author: fireballdark
 */

#include "ProtobufZmqRpc.h"
#include <boost/algorithm/string.hpp>
#include <sutil/logging.h>
#include <sutil/Timer.h>
#include <encryption/xopenssl.h>
#include <util/DataVerifier.h>

#include "logic/FileLogic.h"
#include "types/structs_to_protobuf.h"


rpc_status_code_struct ProtobufZmqRpc::filesList(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FilesList");

    rpc::FilesListRequest   input;
    rpc::FilesListResponse*  output = response.mutable_files_list();
    response.set_message_type(RPC_FILES_LIST);

    do
    {
        if (request.has_files_list())
        {
            input = request.files_list();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_filter())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id            = input.workgroup_id();
        rpc::Filter filesFilter           = input.filter();
        int64_t parent_id            = input.has_parent_id() ? input.parent_id() : -1 ;

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FilesList function called with [%s] for workgroup %lli and filter %i and parent_id %lli", sessionId.c_str(), workgroup_id, filesFilter, parent_id);

        FilesInfoList filesInfoList;
        int64_t   lastEventId = -1;
        context.session_id = sessionId;
        resultStatus = FileLogic::filesList(context, (int)filesFilter, workgroup_id, parent_id, filesInfoList, lastEventId);

        if (resultStatus != status_success)
        {
            break;
        }

        for (FilesInfoList::iterator i = filesInfoList.begin() ; i!= filesInfoList.end() ; i++)
        {
            rpc::FileInfo* fileInfo = output->add_file_info_list();
            convert_fileinfo(*i,fileInfo);
        }

        output->set_last_event_id(lastEventId);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FilesList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileDelete(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileDelete");

    rpc::FileDeleteRequest   input;
    rpc::FileDeleteResponse*  output = response.mutable_file_delete();
    response.set_message_type(RPC_FILE_DELETE);

    do
    {
        if (request.has_file_delete())
        {
            input = request.file_delete();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_file_id()
                || !input.has_workgroup_id() || !input.has_delete_now()
                || !input.has_revision() )
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id        = input.workgroup_id();
        int64_t   fileId          = input.file_id();
        int64_t   revision        = input.revision();
        bool            deleteNow       = input.delete_now();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileDelete function called for file %lli:%lli in workgroup %lli with NOW - %s", fileId, revision, workgroup_id, deleteNow ? "YES" : "NO");
        context.session_id = sessionId;
        resultStatus = FileLogic::fileDelete(context, workgroup_id, fileId, revision, deleteNow);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileDelete function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileUndelete(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileUndelete");

    rpc::FileUndeleteRequest   input;
    rpc::FileUndeleteResponse*  output = response.mutable_file_undelete();
    response.set_message_type(RPC_FILE_UNDELETE);

    do
    {
        if (request.has_file_undelete())
        {
            input = request.file_undelete();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_file_id()
                || !input.has_workgroup_id() || !input.has_revision() )
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        int64_t   workgroup_id        = input.workgroup_id();
        int64_t   fileId          = input.file_id();
        int64_t   revision        = input.revision();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileUndelete function called for file %lli:%lli in workgroup %lli", fileId, revision, workgroup_id);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileUndelete(context, workgroup_id, fileId, revision);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileUndelete function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileRename(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileRename");

    rpc::FileRenameRequest   input;
    rpc::FileRenameResponse*  output = response.mutable_file_rename();
    response.set_message_type(RPC_FILE_RENAME);

    do
    {
        if (request.has_file_rename())
        {
            input = request.file_rename();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id() || !input.has_file_name_new() || !input.has_file_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId       = input.session_id();
        std::string     fileNameNew     = input.file_name_new();
        int64_t   workgroup_id        = input.workgroup_id();
        int64_t   fileId          = input.file_id();

        if (!is_utf8_string(sessionId) || !is_utf8_string(fileNameNew))
        {
            resultStatus = status_invalid_utf8;
            break;
        }


        if (fileNameNew.empty())
        {
            resultStatus = status_bad_request;
            break;
        }

        LOG_ABSOLUTE("FileRename function called for workgroup %lli file %lli with new name [%s]:[%s]", workgroup_id, fileId, fileNameNew.c_str(),digest_to_x_hex_string(fileNameNew).c_str());

        int64_t revision = 0;
        context.session_id = sessionId;
        resultStatus = FileLogic::fileRename(context,workgroup_id,fileId,fileNameNew,revision);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_revision(revision);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileRename function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileHistory(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileHistory");

    rpc::FileHistoryRequest   input;
    rpc::FileHistoryResponse*  output = response.mutable_file_history();
    response.set_message_type(RPC_FILE_HISTORY);

    do
    {
        if (request.has_file_history())
        {
            input = request.file_history();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_file_id() || !input.has_filter())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId             = input.session_id();
        int64_t workgroup_id            = input.workgroup_id();
        int64_t fileId              = input.file_id();
        rpc::Filter filesFilter           = input.filter();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileHistory function called with [%s] for workgroup %lli file %lli and filter %i", sessionId.c_str(), workgroup_id, fileId, filesFilter);

        FilesInfoList filesInfoList;
        context.session_id = sessionId;
        resultStatus = FileLogic::fileHistory(context, (int)filesFilter, workgroup_id, fileId, filesInfoList);

        if (resultStatus != status_success)
        {
            break;
        }

        for (FilesInfoList::iterator i = filesInfoList.begin() ; i!= filesInfoList.end() ; i++)
        {
            rpc::FileInfo* fileInfo = output->add_file_info_list();
            convert_fileinfo(*i,fileInfo);
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FilesList function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileInfo(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileInfo");

    rpc::FileInfoRequest   input;
    rpc::FileInfoResponse*  output = response.mutable_file_info();
    response.set_message_type(RPC_FILE_INFO);

    do
    {
        if (request.has_file_info())
        {
            input = request.file_info();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_file_id()
                || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId   = input.session_id();
        FileInfo fileInfo;
        fileInfo.file_id         = input.file_id();
        fileInfo.workgroup_id       = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileInfo function called with [%s] for workgroup %lli file %lli", sessionId.c_str(), fileInfo.workgroup_id, fileInfo.file_id);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileInfo(context, fileInfo);

        if (resultStatus != status_success)
        {
            break;
        }

        rpc::FileInfo* fileInfoMes = output->mutable_file_info();
        convert_fileinfo(fileInfo,fileInfoMes);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileInfo function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileDirectoryCreate(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileDirectoryCreate");

    rpc::FileDirectoryCreateRequest   input;
    rpc::FileDirectoryCreateResponse*  output = response.mutable_file_directory_create();
    response.set_message_type(RPC_FILE_DIRECTORY_CREATE);

    do
    {
        if (request.has_file_directory_create())
        {
            input = request.file_directory_create();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_directory_name() || !input.has_parent_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId = input.session_id();
        FileInfo    fileInfo;
        fileInfo.file_name     = input.directory_name();
        fileInfo.workgroup_id     = input.workgroup_id();
        fileInfo.parent_id     = input.parent_id();
        //fileInfo.is_directory  = true; //it's FileDirectory, yeeeaaah!

        if (!is_utf8_string(sessionId) || !is_utf8_string(fileInfo.file_name))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileDirectoryCreate function called with session %s for file: %s %s %lli in workgroup %lli", sessionId.c_str(), fileInfo.file_name.c_str(), fileInfo.hash.c_str(), fileInfo.size, fileInfo.workgroup_id);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileDirectoryCreate(context, fileInfo);

        if (resultStatus != status_success && resultStatus != status_already_exist)
        {
            break;
        }

        resultStatus = FileLogic::fileInfo(context, fileInfo);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_file_id(fileInfo.file_id);
        output->set_revision(fileInfo.revision);
        output->set_creation_date(fileInfo.creation_date);
        output->set_creation_date_str(fileInfo.creation_date_str);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileDirectoryCreate function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileUpload(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileUpload");

    rpc::FileUploadRequest   input;
    rpc::FileUploadResponse*  output = response.mutable_file_upload();
    response.set_message_type(RPC_FILE_UPLOAD);

    do
    {
        if (request.has_file_upload())
        {
            input = request.file_upload();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_file_name() || !input.has_hash()
                || !input.has_size())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId = input.session_id();
        FileInfo    fileInfo;
        fileInfo.file_name     = input.file_name();
        fileInfo.hash     = input.hash();
        fileInfo.workgroup_id     = input.workgroup_id();
        fileInfo.size     = input.size();
        fileInfo.parent_id     = input.has_parent_id() ? input.parent_id() : 0;
        fileInfo.is_directory  = false; //it's file, OK? :)

        if (!is_utf8_string(sessionId) || !is_utf8_string(fileInfo.file_name) || !is_utf8_string(fileInfo.hash))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileUpload function called with session [%s] for file: [%s]:[%s] [%s] %lli in workgroup %lli parent_id %lli", sessionId.c_str(), fileInfo.file_name.c_str(), digest_to_x_hex_string(fileInfo.file_name).c_str(), fileInfo.hash.c_str(), fileInfo.size, fileInfo.workgroup_id, fileInfo.parent_id);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileUpload(context, fileInfo);

        if (resultStatus != status_success && resultStatus != status_already_exist)
        {
            break;
        }

        output->set_file_id(fileInfo.file_id);
        output->set_revision(fileInfo.revision);
        output->set_upload_url(fileInfo.s3_url);
        output->set_creation_date(fileInfo.creation_date);
        output->set_creation_date_str(fileInfo.creation_date_str);

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileUpload function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileUploadApprove(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileUploadApprove");

    rpc::FileUploadApproveRequest   input;
    rpc::FileUploadApproveResponse*  output = response.mutable_file_upload_approve();
    response.set_message_type(RPC_FILE_UPLOAD_APPROVE);

    do
    {
        if (request.has_file_upload_approve())
        {
            input = request.file_upload_approve();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_file_id()
                || !input.has_revision() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId = input.session_id();
        FileInfo fileInfo;
        fileInfo.file_id     = input.file_id();
        fileInfo.workgroup_id   = input.workgroup_id();
        fileInfo.revision   = input.revision();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileUploadApprove function called with session %s for workgroup %lli file: %lli-%lli", sessionId.c_str(), fileInfo.workgroup_id, fileInfo.file_id, fileInfo.revision);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileUploadApprove(context, fileInfo);

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileUploadApprove function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileDownload(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileDownload");

    rpc::FileDownloadRequest   input;
    rpc::FileDownloadResponse*  output = response.mutable_file_download();
    response.set_message_type(RPC_FILE_DOWNLOAD);

    do
    {
        if (request.has_file_download())
        {
            input = request.file_download();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId = input.session_id();
        FileInfo    fileInfo;
        fileInfo.workgroup_id     = input.workgroup_id();

        if (input.has_file_id())
        {
            fileInfo.file_id       = input.file_id();
            if (input.has_revision())
            {
                fileInfo.revision = input.revision();
            }
        }
        else if (input.has_file_name())
        {
            fileInfo.file_name     = input.file_name();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!is_utf8_string(sessionId) || !is_utf8_string(fileInfo.file_name))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileDownload function called with session %s for file: %s %lli in workgroup %lli", sessionId.c_str(), fileInfo.file_name.c_str(), fileInfo.file_id, fileInfo.workgroup_id);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileDownload(context, fileInfo);

        if (resultStatus != status_success)
        {
            break;
        }

        output->set_download_url(fileInfo.s3_url);
        output->set_file_name(fileInfo.file_name);
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileDownload function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileDirectoryHierarchy(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileDirectoryHierarchy");

    rpc::FileDirectoryHierarchyRequest   input;
    rpc::FileDirectoryHierarchyResponse*  output = response.mutable_file_directory_hierarchy();
    response.set_message_type(RPC_FILE_DIRECTORY_HIERARCHY);

    do
    {
        if (request.has_file_directory_hierarchy())
        {
            input = request.file_directory_hierarchy();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_file_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string sessionId = input.session_id();
        FileInfo    fileInfo;
        fileInfo.file_id       = input.file_id();
        fileInfo.workgroup_id     = input.workgroup_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileDirectoryHierarchy function called with session %s for directory: %lli in workgroup %lli", sessionId.c_str(), fileInfo.file_id, fileInfo.workgroup_id);

        FilesInfoList filesInfoList;
        context.session_id = sessionId;
        resultStatus = FileLogic::fileDirectoryHierarchy(context, fileInfo, filesInfoList);

        if (resultStatus != status_success)
        {
            break;
        }

        for (FilesInfoList::iterator i = filesInfoList.begin() ; i!= filesInfoList.end() ; i++)
        {
            rpc::FileDirectoryHierarchyResponse_Dirs* hierarchy = output->add_hierarchy();
            hierarchy->set_file_id           ((*i).file_id);
            hierarchy->set_directory_name    ((*i).file_name);
            hierarchy->set_parent_id         ((*i).parent_id);
            hierarchy->set_is_deleted        ((*i).is_deleted);
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileDirectoryHierarchy function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileSearch(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileSearch");

    rpc::FileSearchRequest   input;
    rpc::FileSearchResponse*  output = response.mutable_file_search();
    response.set_message_type(RPC_FILE_SEARCH);

    do
    {
        if (request.has_file_search())
        {
            input = request.file_search();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_search_string())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId           = input.session_id();
        int64_t   workgroup_id            = input.has_workgroup_id() ? input.workgroup_id() : -1 ;
        std::string     searchString        = input.search_string();
        int64_t   minSize             = input.has_min_size() ? input.min_size() : -1 ;
        int64_t   maxSize             = input.has_max_size() ? input.max_size() : -1 ;

        if (!is_utf8_string(sessionId) || !is_utf8_string(searchString))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileSearch function called with [%s] for workgroup %lli and string [%s] size %lli:%lli", sessionId.c_str(), workgroup_id, searchString.c_str(), minSize, maxSize);

        FilesInfoList filesInfoList;
        context.session_id = sessionId;
        resultStatus = FileLogic::fileSearch(context, workgroup_id, searchString, minSize, maxSize, filesInfoList);

        if (resultStatus != status_success)
        {
            break;
        }

        for (FilesInfoList::iterator i = filesInfoList.begin() ; i!= filesInfoList.end() ; i++)
        {
            rpc::FileInfo* fileInfo = output->add_file_info_list();
            convert_fileinfo(*i,fileInfo);
        }
    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileSearch function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}

rpc_status_code_struct ProtobufZmqRpc::fileMove(const rpc::Request& request, rpc::Response& response, RequestContext& context)
{
    rpc_status_code_struct resultStatus = status_internal_error;
    Timer timer("FileMove");

    rpc::FileMoveRequest   input;
    rpc::FileMoveResponse*  output = response.mutable_file_move();
    response.set_message_type(RPC_FILE_MOVE);

    do
    {
        if (request.has_file_move())
        {
            input = request.file_move();
        }
        else
        {
            resultStatus = status_bad_request;
            break;
        }

        if (!input.has_session_id() || !input.has_workgroup_id()
                || !input.has_file_id() || !input.has_new_parent_id())
        {
            resultStatus = status_bad_request;
            break;
        }

        std::string     sessionId           = input.session_id();
        int64_t   workgroup_id            = input.workgroup_id();
        int64_t   fileId              = input.file_id();
        int64_t   newParentId         = input.new_parent_id();

        if (!is_utf8_string(sessionId))
        {
            resultStatus = status_invalid_utf8;
            break;
        }

        LOG_ABSOLUTE("FileMove function called with [%s] for workgroup %lli file %lli moved to %lli", sessionId.c_str(), workgroup_id, fileId, newParentId);
        context.session_id = sessionId;
        resultStatus = FileLogic::fileMove(context, workgroup_id, fileId, newParentId);

        if (resultStatus != status_success)
        {
            break;
        }

    }
    while (false);

    output->set_error_code(resultStatus);

    LOG_ABSOLUTE("FileMove function ended with status %i [%s]",resultStatus.code,resultStatus.code_to_string().c_str());
    return resultStatus;
}
