//============================================================================
// Name        : LibEvXML.cpp
// Author      : Vasil Diakonov
// Version     :
// Copyright   :
// Description :
//============================================================================

#include <unistd.h>
#include <cstdlib>
#include <ctime>
#include <curl/curl.h>
#include <syslog.h>
#include <google/protobuf/stubs/common.h>

#include <sutil/logging.h>
#include <sutil/LoggingData.h>
#include <encryption/xopenssl.h>
#include <encryption/xopenssl_test.h>
#include <crash/linux/CrashReporter.h>

#include "conf/daemon_config.h"
#include "conf/parse_config.h"
#include "conf/parse_arguments.h"
#include "init/setup_daemonizing.h"
#include "init/setup_logging.h"
#include "init/setup_asio_server.h"

#include <sutil/LoggingData.h>
#include <snetwork/ServiceChannelServer.h>
#include "binders/BinderStatisticProc.h"
#include <sutil/configator.h>

using google::protobuf::ShutdownProtobufLibrary;


///Main function containing initialization and service start parts
/**
 * Main program's function which is used for service initialization,
 * library initialization, service start.
 */
int main(int argc, char** argv)
{
    srand((unsigned)time(0));

    openlog("EvXML", LOG_PID, LOG_LOCAL0);

    init_crash_reporter("./crashdumps/EvXML_Daemon","./planneddumps/EvXML_Daemon");

    //parse command-line arguments
    fprintf(stderr, "path = [%s]\n", argv[0]);
    if (parse_arguments(argc,argv)!=EXIT_SUCCESS)
    {
        exit(EXIT_FAILURE);
    }

    //parse config - from arguments or default pre-defined
    if (parse_config_file(daemon_params().getConfFilePath())!=EXIT_SUCCESS)
    {
        exit(EXIT_FAILURE);
    }

    //put default values if they are not defined in arguments or config
    if (daemon_params().initWithDefaults()!=EXIT_SUCCESS)
    {
        exit(EXIT_FAILURE);
    }

    print_daemon_params();

    if(daemon_params().getDaemonize()) //if we need to DAEMONIZE
    {
        pid_t pid = fork();
        if (pid < 0)
        {
            perror("EvXML: Could not create child");
            exit(EXIT_FAILURE);
        }

        if (pid > 0)	//We've got a good child so parent process can be closed
        {
            exit(EXIT_SUCCESS);
        }
    }
    else
    {
        printf("EvXML: TCP listening server starting...\n");
    }

    Configator::get_instance().setConfigPath(daemon_params().getConfFilePath());
    Configator::get_instance().readConfig();

    Configator::get_instance().subscribe("application.logging", boost::bind(&LoggingData::read_logging, &LoggingData::get_instance(), _1, _2));
    Configator::get_instance().subscribe("application.email",   boost::bind(&LoggingData::read_email, &LoggingData::get_instance(), _1, _2));

    ServiceChannelServer internal_server;
    Configator::get_instance().subscribe("application.service", boost::bind(&ServiceChannelServer::read_config, &internal_server, _1, _2));

    /*if (!xopenssl_test("./test_vectors"))
    {
        exit(EXIT_FAILURE);
    }*/

    LOG_INFORMATION( "EvXML: Starting server...");

    //pre-setup server environment, signals handling etc
    if (setup_daemonizing_params()!=EXIT_SUCCESS)
    {
        exit(EXIT_FAILURE);
    }

    openssl_init();

    curl_global_init(CURL_GLOBAL_ALL);

    {
        LOG_INFORMATION( "EvXML: Starting BOOST ASIO...");

        GOOGLE_PROTOBUF_VERIFY_VERSION;

        ///service initialization
        BinderStatisticProc::prepareBinding();//binding statistic functions
        internal_server.start();

        if (setup_asio_server()!=EXIT_SUCCESS)
        {
            exit(EXIT_FAILURE);
        }

        ShutdownProtobufLibrary();
    }

    openssl_cleanup();

    LOG_INFORMATION( "EvXML: Shut down successfully.");

    closelog();
    fclose(LoggingData::get_instance().get_log_file());
    exit(EXIT_SUCCESS);
}

