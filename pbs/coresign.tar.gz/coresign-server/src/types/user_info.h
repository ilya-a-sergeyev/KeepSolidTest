/*
 * user_info.h
 *
 *  Created on: Aug 31, 2011
 *      Author: fireball
 */

#ifndef USER_INFO_H_
#define USER_INFO_H_

#include <string>
#include <vector>
#include <map>
#include "types/status_codes.h"
#include "network/NotificationTypes.hpp"

struct UserInfo
{
    UserInfo():
        user_id(0),
        is_dummy(false),
        license_accepted(false),
        is_activated(false),
        is_tutorialated(false),
        returnStatus(status_unknown),
        wasInvited(false),
        creation_date(0),
        expiration_date(0)
    {}

    int64_t         user_id;
    std::string     login;
    std::string     email;
    std::string     first_name;
    std::string     last_name;
    std::string     public_key;
    std::string     private_key;
    std::string     salt_pk_password;
    std::string     user_pic;
    std::string     secret_question;

    bool            is_dummy;
    bool            license_accepted;
    bool            is_activated;
    bool            is_tutorialated;
    rpc_status_code returnStatus;   // for UserInfoResponse
    bool            wasInvited;     // for UserInfoResponse

    int64_t         creation_date;
    int64_t         expiration_date;
};


struct UserCredentials
{
    UserCredentials():
        user_id(0),
        is_dummy(false),
        license_accepted(false),
        is_activated(false)
    {}

    int64_t         user_id;
    std::string     login;
    std::string     password;
    std::string     salt_password;
    std::string     secret_question;
    std::string     secret_answer;
    std::string     salt_answer;
    std::string     public_key;
    std::string     private_key;
    std::string     private_key_answer;
    std::string     salt_pk_password;
    std::string     salt_pk_answer;
    bool            is_dummy;
    bool            license_accepted;
    bool            is_activated;

    std::string     encrypted_external_password; // For external auth, just like with Simplex
};

struct TariffLimits
{
    TariffLimits():
        tariff_id(0),
        data_size_limit(0),
        history_limit(0),
        users_limit(0),
        admins_limit(0)
    {}

    std::string     tariff_name;

    int64_t         tariff_id;
    int64_t         data_size_limit;
    int64_t         history_limit;
    int64_t         users_limit;
    int64_t         admins_limit;
};


struct LoginStats
{
    LoginStats():
        login_date(0),
        successful(false)
    {}

    int64_t         login_date;

    std::string     login_date_str;

    std::string     device_id;
    std::string     device_name;
    std::string     platform;
    std::string     ip_address;

    bool            successful;
};

struct LoginStatsExtended : public LoginStats
{
    LoginStatsExtended()
    {}

    std::string     version;
    std::string     platform_details;
    std::string     locale;
};

typedef std::vector<LoginStats> LoginStatsList;

struct RedirectInfo
{
    RedirectInfo()
    {}

    std::string     rpc_address;
    std::string     rpc_port;
    std::string     notify_address;
    std::string     notify_port;
};

struct AccountStats
{
    AccountStats():
        data_size(0),
        coworkers_count(0),
        creation_date(0),
        expiration_date(0),
        now_date(0),
        is_first_login(false)
    {}

    TariffLimits                limits;
    int64_t                     data_size;
    int64_t                     coworkers_count;
    std::vector<LoginStats>     device_stats;
    std::vector<LoginStats>     login_history;

    std::string                 login;
    std::string                 account_status; //"ok", "expired", "blocked"
    int64_t                     creation_date;
    int64_t                     expiration_date;
    int64_t                     now_date;
    std::string                 encrypted_password;

    AddressesList               api_servers;
    AddressesList               notification_servers;

    bool                        is_first_login;
};

typedef std::pair<std::string, bool> LoginForKick;
typedef std::vector<LoginForKick> LoginForKickList;
typedef std::vector<std::string> UserLoginList;

struct UserWorkGroupInfo
{
    UserWorkGroupInfo():
        user_id(0),
        workgroup_id(0),
        is_dummy(false),
        invite_accepted(false),
        access_mode(0)
    {}

    int64_t         user_id;
    int64_t         workgroup_id;
    std::string     login;
    std::string     first_name;
    std::string     last_name;
    std::string     user_pic;
    std::string     public_key;
    bool            is_dummy;
    bool            invite_accepted;
    int64_t         access_mode;
};


struct CompanyInfo
{
    CompanyInfo():
        company_id(0),
        creator_id(0),
        role(0),
        is_personal(false)
    {}

    int64_t         company_id;
    std::string     company_name;
    std::string     description;
    int64_t         creator_id;
    std::string     creator_login;
    std::string     creation_date_str;
    std::string     logo;
    std::string     url;
    int64_t         role;
    bool            is_personal;
};

struct UserInCompany
{
    UserInCompany():
        company_id(0),
        user_id(0),
        role_id(0),
        is_personal(false)
    {}

    int64_t         company_id;
    int64_t         user_id;
    std::string     company_name;
    std::string     login;
    int64_t         role_id;
    bool            is_personal;
};

struct UserRole
{
    UserRole():
        role_id(0),
        company_id(0)
    {}

    int64_t         role_id;
    int64_t         company_id;

    std::string     role_name;
    std::string     comment;
    std::string     creation_date_str;
};

typedef std::vector<CompanyInfo>  CompaniesList;

typedef std::vector<UserWorkGroupInfo> UserWorkGroupInfoList;
typedef std::multimap<int64_t, UserWorkGroupInfo> UserWorkGroupInfoMultiMap;

typedef std::map<std::string,std::string> NotificationsSubscription;

typedef std::vector<int64_t> UserIdList;

typedef std::vector<UserInCompany> UsersInCompanies;

typedef std::vector<UserRole> RolesList;

typedef std::vector<UserInfo> UserInfoList;


/*struct NotificationsSubscription
{
    NotificationsSubscription():
        news                (false),
        out_of_storage      (false),
        beginner_tips       (false),
        cabinet_activity    (false),
        new_invites         (false),
        new_discussions     (false),
        new_files           (false)
    {}

    bool   news                ;
    bool   out_of_storage      ;
    bool   beginner_tips       ;
    bool   cabinet_activity    ;
    bool   new_invites         ;
    bool   new_discussions     ;
    bool   new_files           ;
};*/




#endif /* USER_INFO_H_ */
