/*
 * setup_logging.h
 *
 *  Created on: 13 бер. 2011
 *      Author: fireball
 */

#ifndef SETUP_LOGGING_H_
#define SETUP_LOGGING_H_

int	setup_logging();

#endif /* SETUP_LOGGING_H_ */
