/*
 * xopenssl_hmac.cpp
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */

#include "xopenssl_hmac.h"
#include <openssl/hmac.h>
#include "util/logging.h"
#include "xopenssl_defines.h"
#include "xopenssl_util.h"

#pragma mark- HMAC

std::string sha1_hmac_raw(const std::string& data, const std::string& secret)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL SHA1 HMAC: data is empty");
        return "";
    }
    if (secret.empty())
    {
        LOG_ERROR("OpenSSL SHA1 HMAC: secret is empty");
        return "";
    }

    HMAC_CTX ctx;
    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, secret.c_str(), (int)secret.length(), EVP_sha1(), NULL);
    HMAC_Update(&ctx, (unsigned char*) data.c_str(), data.length());

    unsigned char hmac[EVP_MAX_MD_SIZE] = {0};
    unsigned int size = 0;
    HMAC_Final(&ctx, hmac, &size);
    HMAC_CTX_cleanup(&ctx);

    return std::string((char*) hmac, size);
}

std::string sha1_hmac(const std::string& data, const std::string& secret)
{
    return digest_to_hex_string( sha1_hmac_raw( data, secret ) );
}

std::string sha256_hmac_raw(const std::string& data, const std::string& secret)
{
    if (data.empty())
    {
        LOG_ERROR("OpenSSL SHA256 HMAC: data is empty");
        return "";
    }
    if (secret.empty())
    {
        LOG_ERROR("OpenSSL SHA256 HMAC: secret is empty");
        return "";
    }

    HMAC_CTX ctx;
    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, secret.c_str(), (int)secret.length(), EVP_sha256(), NULL);
    HMAC_Update(&ctx, (unsigned char*) data.c_str(), data.length());

    unsigned char hmac[EVP_MAX_MD_SIZE] = {0};
    unsigned int size = 0;
    HMAC_Final(&ctx, hmac, &size);
    HMAC_CTX_cleanup(&ctx);

    return std::string((char*) hmac, size);
}

std::string sha256_hmac(const std::string& data, const std::string& secret)
{
    return digest_to_hex_string( sha256_hmac_raw( data, secret ) );
}

std::string sha256_hmac_easy_sign(const std::string& secret)
{
    random_seed();
    std::string data_int = random256bits();

    std::string signature = sha256_hmac(data_int,secret);

    std::string result = base64_encodestring(data_int, true);
    result += '$';
    result += signature;

    return result;
}

bool sha256_hmac_easy_verify(const std::string& data, const std::string& secret)
{
    std::string::size_type pos_data_end = 0;
    //find first delimiter
    pos_data_end = data.find('$', 0);

    if (pos_data_end == std::string::npos)
    {
        LOG_ERROR("OpenSSL: sha256_hmac_easy_verify - one of delimiters not found");
        return false;
    }

    std::string data_int = base64_decodestring(data.substr(0,pos_data_end));
    std::string signature = data.substr(pos_data_end+1,std::string::npos);

    if (signature.compare(sha256_hmac(data_int,secret)) == 0)
    {
        //Signature check is OK
        return true;
    }

    return false;
}
