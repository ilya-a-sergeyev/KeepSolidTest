#pragma once

#include <cstdint>
#include <string>
#include <fstream>
#include <vector>
#include "xopenssl_types.h"

#ifdef FILE_LOADER
#define NO_FCGI_DEFINES
    #include <fcgi_stdio.h>
#endif

#define MAGIC_SALT_ITERATIONS   1024
#define MAGIC_LONG_RANDOM_DATA  64

void openssl_init(void);
void openssl_cleanup(void);

void disable_ssl_cache(void* context);
void clear_ssl_cache  (void* context);

std::string unite_lines( std::string text );
std::string digest_to_hex_string( const unsigned char* digest, unsigned int len );
std::string hex_to_digest( const std::string& hex_digest );
std::string digest_to_hex_string(const std::string& digest);

std::string digest_to_x_hex_string( const std::string& string );

std::string md5( std::istream& in_stream );
std::string md5( FILE* in_stream );
std::string md5( const std::string& text );

std::string sha1( const std::string& text );

std::string sha256( std::istream& in_stream );
std::string sha256( FILE* in_stream );
std::string sha256( const std::string& text );

std::string sha1_hmac_raw           (const std::string& text, const std::string& secret);
std::string sha1_hmac               (const std::string& data, const std::string& secret);

std::string sha256_hmac             (const std::string& data, const std::string& secret);
std::string sha256_hmac_easy_sign   (const std::string& secret);
bool        sha256_hmac_easy_verify (const std::string& data, const std::string& secret);

std::string sha256_pbkdf2           (const std::string& secret, const std::string& salt, int cycles);   //recommended 2^16 or more cycles

//return hash of secret
std::string sha256_pbkdf2_password_generate (const std::string& secret, std::string& salt_out, int cycles);         //auto-generates salt
std::string sha256_pbkdf2_password_stretch  (const std::string& secret, const std::string& salt);       //uses const salt
bool        sha256_pbkdf2_verify            (const std::string& good_hash, const std::string& secret, const std::string& salt);

/************************************************************************
    @param  key             Input key
    @param  secret          User password
    @param  key_salt        Output parameter, salt of input key, result of work sha256_pbkdf2_password_generate() function
    @param  key_sign        Output parameter, signature of input key, result of work sha256_hmac_easy_sign() function
    @param  key_encrypted   Output parameter, encrypted by aes_easy_encrypt() function
    @return                 TRUE if function was successful, otherwise - FALSE

************************************************************************/
bool        encrypt_key_with_password(const std::string& key, const std::string& secret, std::string& key_salt, std::string& key_sign, std::string& key_encrypted, int cycles);

/************************************************************************
    @param  secret          User password
    @param  key_salt        Salt of key, that will verify
    @param  key_sign        Signature of input key, that will verify
    @param  key_encrypted   Encrypted key, that will verify
    @param  key             Output parameter, original key
    @return                 TRUE if function was successful, otherwise - FALSE
************************************************************************/
bool        decrypt_key_with_password(const std::string& secret, const std::string& key_salt, const std::string& key_sign, const std::string& key_encrypted, std::string& key);

std::string base64_encodestring(const std::string& text , bool unite = false);
std::string base64_decodestring( std::string text );

std::string randomstring( int len = MAGIC_LONG_RANDOM_DATA );
int64_t     random_int64_t();

std::string aes_easy_encrypt( const std::string& data, const std::string& password );
std::string aes_easy_decrypt( const std::string& data, const std::string& password );

xopenssl_status aes_easy_encrypt( std::istream& in_stream, const std::string& password, std::ostream& out_stream, bool write_signature = false, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_encrypt( std::istream& in_stream, const std::string& password, std::ostream& out_stream, std::string& result_hash, bool write_signature = false, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_decrypt( std::istream& in_stream, const std::string& password, std::ostream& out_stream, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_encrypt( FILE* in_stream, const std::string& password, FILE* out_stream, bool write_signature = false, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_encrypt( FILE* in_stream, const std::string& password, FILE* out_stream, std::string& result_hash, bool write_signature = false, const bool * const pbCanContinue = 0 );
xopenssl_status aes_easy_decrypt( FILE* in_stream, const std::string& password, FILE* out_stream, const bool * const pbCanContinue = 0 );
#ifdef FILE_LOADER
xopenssl_status aes_easy_decrypt( std::istream& in_stream, const std::string& password, FCGI_FILE* out );
#endif

bool rsa_encode_private_keys (const std::string& key_pass_old, const std::string& private_key_old, const std::string& key_pass_new, std::string& private_key_new);
bool rsa_generate_keys (const std::vector<std::string>& key_passes, std::vector<std::string>& private_keys, std::string& public_key, int key_length);
bool rsa_check_private_key(const std::string& private_key, const std::string& private_key_password);
bool rsa_easy_encrypt ( const std::string& data, const std::string& public_key, std::string& encrypted_data_pack );
bool rsa_easy_decrypt ( const std::string& encrypted_data_pack, const std::string& private_key, const std::string& private_key_password, std::string& decrypted_data );
