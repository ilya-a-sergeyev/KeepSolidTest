/*
 * misc_info.cpp
 *
 *  Created on: Apr 3, 2014
 *      Author: fireballdark
 */

#include "misc_info.h"
#include <jsoncpp/json/json.h>
#include <sutil/logging.h>


std::string PurchaseData::infos_to_string() const
{
    Json::Value val;
    Json::StyledWriter writer;

    for (auto info : infos)
    {
        int i = val.size();
        val[i]["type"] = info.type;
        val[i]["count"] = info.count;
        val[i]["event"] = info.event;
    }

    return writer.write(val);
}

void PurchaseData::string_to_infos(const std::string& json)
{
    Json::Value val;
    Json::Reader reader;
    bool result = reader.parse(json, val);

    if (result == false)
    {
        LOG_INFORMATION("PurchaseData: error parsing [%s] \n result [%i] error [%s]", json.c_str(), result, reader.getFormatedErrorMessages().c_str());
        return;
    }

    if (val.isArray() == true)
    {
        for (unsigned int i=0; i < val.size(); i++)
        {
            PurchaseInfo pi;
            pi.type = val[i]["type"].asString();
            pi.count = val[i]["count"].asString();
            pi.event = val[i]["event"].asString();

            infos.push_back(pi);
        }
    }
}
