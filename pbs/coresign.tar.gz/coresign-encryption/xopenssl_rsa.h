/*
 * xopenssl_rsa.h
 *
 *  Created on: May 30, 2013
 *      Author: fireballdark
 */

#pragma once

#include <string>
#include <vector>

bool rsa_encode_private_keys( const std::string& key_pass_old, const std::string& private_key_old, const std::string& key_pass_new, std::string& private_key_new );
bool rsa_generate_keys      ( const std::vector<std::string>& key_passes, std::vector<std::string>& private_keys, std::string& public_key, int key_length);
bool rsa_check_private_key  ( const std::string& private_key, const std::string& private_key_password );
bool rsa_easy_encrypt       ( const std::string& data, const std::string& public_key, std::string& encrypted_data_pack );
bool rsa_easy_decrypt       ( const std::string& encrypted_data_pack, const std::string& private_key, const std::string& private_key_password, std::string& decrypted_data );
