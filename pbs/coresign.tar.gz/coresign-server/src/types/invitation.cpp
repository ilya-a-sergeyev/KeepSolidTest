/*
 * invitation.cpp
 *
 *  Created on: Mar 18, 2013
 *      Author: fireballdark
 */
#include "invitation.h"
#include "types/access_rights.h"
#include <algorithm>

bool compare_invite_pairs_by_access(const InvitePair& a, const InvitePair& b)
{
    return KSD::compare_access_rights(a.second.access_mode,b.second.access_mode);
}

bool compare_invites_by_access(const InviteInfo& a, const InviteInfo& b)
{
    return KSD::compare_access_rights(a.access_mode,b.access_mode);
}

InviteInfoList filter_out_max_rights_invites (const InviteInfosByWorkGroups& iibw)
{
    InviteInfosByWorkGroups::const_iterator itBeg = iibw.begin();
    InviteInfoList result;

    while (itBeg != iibw.end())
    {
        std::pair<InviteInfosByWorkGroups::const_iterator,InviteInfosByWorkGroups::const_iterator> keyRange = iibw.equal_range((*itBeg).first);
        itBeg = keyRange.second;

        result.push_back((*std::max_element<InviteInfosByWorkGroups::const_iterator>(keyRange.first,keyRange.second,compare_invite_pairs_by_access)).second);
    }

    return result;
}

InviteInfoList get_max_rights_invite (const InviteInfoList& iil)
{
    InviteInfoList result;
    InviteInfoList::const_iterator it = std::max_element<InviteInfoList::const_iterator>(iil.begin(),iil.end(),compare_invites_by_access);
    if (it != iil.end())
    {
        result.push_back(*it);
    }
    return result;
}
